<?php
/**
 * Plugin Name: RUD CRM Server
 * Description: Central CRM server for customers, connected websites, API access and CRM management.
 * Version: 0.9.32
 * Author: Olaf Rudolfsen
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * VERSION
 * =========================================================
 */

define(
    'RUD_CRM_VERSION',
    '0.9.32'
);

define(
    'RUD_CRM_DB_VERSION',
    '0.9.5'
);


/*
 * =========================================================
 * PLUGIN PATH
 * =========================================================
 */

define(
    'RUD_CRM_PLUGIN_DIR',
    plugin_dir_path(
        __FILE__
    )
);


/*
 * =========================================================
 * LOAD DATABASE FUNCTIONS
 * =========================================================
 */

$rud_crm_database_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/database.php';

if (
    file_exists(
        $rud_crm_database_file
    )
) {

    require_once
        $rud_crm_database_file;
}


/*
 * =========================================================
 * LOAD PROJECT FUNCTIONS
 * =========================================================
 */

$rud_crm_projects_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/projects.php';

if (
    file_exists(
        $rud_crm_projects_file
    )
) {

    require_once
        $rud_crm_projects_file;
}


/*
 * =========================================================
 * LOAD PHONE FIELD FUNCTIONS
 * =========================================================
 */

$rud_crm_phone_fields_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/phone-fields.php';

if (
    file_exists(
        $rud_crm_phone_fields_file
    )
) {

    require_once
        $rud_crm_phone_fields_file;
}


/*
 * =========================================================
 * LOAD CUSTOMER PROFILE FUNCTIONS
 * =========================================================
 */

$rud_crm_customer_profile_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/customer-profile.php';

if (
    file_exists(
        $rud_crm_customer_profile_file
    )
) {

    require_once
        $rud_crm_customer_profile_file;
}


/*
 * =========================================================
 * LOAD CUSTOMER FUNCTIONS
 * =========================================================
 */

$rud_crm_customers_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/customers.php';

if (
    file_exists(
        $rud_crm_customers_file
    )
) {

    require_once
        $rud_crm_customers_file;
}


/*
 * =========================================================
 * LOAD ADMIN / CLIENT HIERARCHY
 * =========================================================
 */

$rud_crm_admin_hierarchy_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/admin-hierarchy.php';

if (
    file_exists(
        $rud_crm_admin_hierarchy_file
    )
) {

    require_once
        $rud_crm_admin_hierarchy_file;
}


/*
 * =========================================================
 * LOAD CUSTOMER SERVICE AREAS
 * =========================================================
 */

$rud_crm_service_areas_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/service-areas.php';

if (
    file_exists(
        $rud_crm_service_areas_file
    )
) {

    require_once
        $rud_crm_service_areas_file;
}


/*
 * =========================================================
 * LOAD WEB SERVICES - DOMAINS
 * =========================================================
 */

$rud_crm_domains_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/domains.php';

if (
    file_exists(
        $rud_crm_domains_file
    )
) {

    require_once
        $rud_crm_domains_file;
}


/*
 * =========================================================
 * LOAD ACCOUNT IDENTITY
 * =========================================================
 */

$rud_crm_account_identity_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/account-identity.php';

if (
    file_exists(
        $rud_crm_account_identity_file
    )
) {

    require_once
        $rud_crm_account_identity_file;
}


/*
 * =========================================================
 * LOAD ADMIN MANAGEMENT
 * =========================================================
 */

$rud_crm_admin_management_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/admin-management.php';

if (
    file_exists(
        $rud_crm_admin_management_file
    )
) {

    require_once
        $rud_crm_admin_management_file;
}


/*
 * =========================================================
 * LOAD SECURITY SETTINGS
 * =========================================================
 */

$rud_crm_security_settings_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/security-settings.php';

if (
    file_exists(
        $rud_crm_security_settings_file
    )
) {

    require_once
        $rud_crm_security_settings_file;
}


/*
 * =========================================================
 * LOAD USER ACCESS / DEMO ACCOUNT FUNCTIONS
 * =========================================================
 */

$rud_crm_user_access_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/user-access.php';

if (
    file_exists(
        $rud_crm_user_access_file
    )
) {

    require_once
        $rud_crm_user_access_file;
}


/*
 * =========================================================
 * LOAD CUSTOMER OWNERSHIP / TRIAL LIMIT FUNCTIONS
 * =========================================================
 */

$rud_crm_customer_ownership_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/customer-ownership.php';

if (
    file_exists(
        $rud_crm_customer_ownership_file
    )
) {

    require_once
        $rud_crm_customer_ownership_file;
}


/*
 * =========================================================
 * LOAD DEMO DATA FUNCTIONS
 * =========================================================
 */

$rud_crm_demo_data_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/demo-data.php';

if (
    file_exists(
        $rud_crm_demo_data_file
    )
) {

    require_once
        $rud_crm_demo_data_file;
}


/*
 * =========================================================
 * LOAD CRM PERMISSIONS
 * =========================================================
 */

$rud_crm_permissions_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/permissions.php';

if (
    file_exists(
        $rud_crm_permissions_file
    )
) {

    require_once
        $rud_crm_permissions_file;
}


/*
 * =========================================================
 * LOAD PUBLIC CRM REGISTRATION
 * =========================================================
 */

$rud_crm_registration_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/registration.php';

if (
    file_exists(
        $rud_crm_registration_file
    )
) {

    require_once
        $rud_crm_registration_file;
}


/*
 * =========================================================
 * LOAD EMAIL VERIFICATION
 * =========================================================
 */

$rud_crm_email_verification_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/email-verification.php';

if (
    file_exists(
        $rud_crm_email_verification_file
    )
) {

    require_once
        $rud_crm_email_verification_file;
}


/*
 * =========================================================
 * LOAD CRM ACCOUNT / LOGIN
 * =========================================================
 */

$rud_crm_account_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/account.php';

if (
    file_exists(
        $rud_crm_account_file
    )
) {

    require_once
        $rud_crm_account_file;
}


/*
 * =========================================================
 * LOAD FRONTEND ACCESS CONTROL
 * =========================================================
 */

$rud_crm_frontend_access_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-access.php';

if (
    file_exists(
        $rud_crm_frontend_access_file
    )
) {
    require_once
        $rud_crm_frontend_access_file;
}


/*
 * =========================================================
 * LOAD GLOBAL DESIGN SETTINGS
 * =========================================================
 */

$rud_crm_design_settings_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/design-settings.php';

if (
    file_exists(
        $rud_crm_design_settings_file
    )
) {

    require_once
        $rud_crm_design_settings_file;
}

/*
 * =========================================================
 * LOAD EDIT MY PROFILE
 * =========================================================
 */

$rud_crm_edit_profile_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/edit-profile.php';

if (
    file_exists(
        $rud_crm_edit_profile_file
    )
) {

    require_once
        $rud_crm_edit_profile_file;
}


/*
 * =========================================================
 * LOAD STATISTICS
 * =========================================================
 */

$rud_crm_statistics_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/statistics.php';

if (
    file_exists(
        $rud_crm_statistics_file
    )
) {

    require_once
        $rud_crm_statistics_file;
}


/*
 * =========================================================
 * LOAD UPGRADE ACCOUNT
 * =========================================================
 */

$rud_crm_upgrade_account_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/upgrade-account.php';

if (
    file_exists(
        $rud_crm_upgrade_account_file
    )
) {

    require_once
        $rud_crm_upgrade_account_file;
}


/*
 * =========================================================
 * LOAD IMPORT / EXPORT FUNCTIONS
 * =========================================================
 */

$rud_crm_import_export_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/import-export.php';

if (
    file_exists(
        $rud_crm_import_export_file
    )
) {

    require_once
        $rud_crm_import_export_file;
}


/*
 * =========================================================
 * LOAD SOCIAL MEDIA FUNCTIONS
 * =========================================================
 */

$rud_crm_social_media_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/social-media.php';

if (
    file_exists(
        $rud_crm_social_media_file
    )
) {

    require_once
        $rud_crm_social_media_file;
}


/*
 * =========================================================
 * LOAD CONNECTED WEBSITES FUNCTIONS
 * =========================================================
 */

$rud_crm_websites_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/websites.php';

if (
    file_exists(
        $rud_crm_websites_file
    )
) {

    require_once
        $rud_crm_websites_file;
}


/*
 * =========================================================
 * LOAD API / SECURITY FUNCTIONS
 * =========================================================
 */

$rud_crm_api_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/api.php';

if (
    file_exists(
        $rud_crm_api_file
    )
) {

    require_once
        $rud_crm_api_file;
}


/*
 * =========================================================
 * LOAD FRONT-END CRM FUNCTIONS
 * =========================================================
 */

$rud_crm_frontend_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend.php';

if (
    file_exists(
        $rud_crm_frontend_file
    )
) {

    require_once
        $rud_crm_frontend_file;
}


/*
 * =========================================================
 * LOAD COMPANY CONTACT PERSONS / EMPLOYEES
 * =========================================================
 */

$rud_crm_company_contacts_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/company-contacts.php';

if (
    file_exists(
        $rud_crm_company_contacts_file
    )
) {

    require_once
        $rud_crm_company_contacts_file;
}


/*
 * =========================================================
 * LOAD FRONT-END COMPANY CONTACT PERSONS / EMPLOYEES
 * =========================================================
 */

$rud_crm_frontend_company_contacts_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-company-contacts.php';

if (
    file_exists(
        $rud_crm_frontend_company_contacts_file
    )
) {

    require_once
        $rud_crm_frontend_company_contacts_file;
}


/*
 * =========================================================
 * LOAD TASKS / REMINDERS / TO DO
 * =========================================================
 */

$rud_crm_tasks_reminders_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/tasks-reminders.php';

if (
    file_exists(
        $rud_crm_tasks_reminders_file
    )
) {

    require_once
        $rud_crm_tasks_reminders_file;
}


/*
 * =========================================================
 * LOAD FRONT-END TASKS / REMINDERS / TO DO
 * =========================================================
 */

$rud_crm_frontend_tasks_reminders_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-tasks-reminders.php';

if (
    file_exists(
        $rud_crm_frontend_tasks_reminders_file
    )
) {

    require_once
        $rud_crm_frontend_tasks_reminders_file;
}


/*
 * =========================================================
 * LOAD ALARM / REMINDER ENGINE
 * =========================================================
 */

$rud_crm_alarm_reminder_engine_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/alarm-reminder-engine.php';

if (
    file_exists(
        $rud_crm_alarm_reminder_engine_file
    )
) {

    require_once
        $rud_crm_alarm_reminder_engine_file;
}


/*
 * =========================================================
 * LOAD FRONT-END CRM NOTIFICATIONS
 * =========================================================
 */

$rud_crm_frontend_notifications_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-notifications.php';

if (
    file_exists(
        $rud_crm_frontend_notifications_file
    )
) {

    require_once
        $rud_crm_frontend_notifications_file;
}


/*
 * =========================================================
 * LOAD FRONT-END NOTIFICATION ALERT
 * =========================================================
 */

$rud_crm_frontend_notification_alert_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-notification-alert.php';

if (
    file_exists(
        $rud_crm_frontend_notification_alert_file
    )
) {

    require_once
        $rud_crm_frontend_notification_alert_file;
}


/*
 * =========================================================
 * LOAD TEMPORARY ALARM DIAGNOSTICS
 * =========================================================
 */

$rud_crm_alarm_diagnostics_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/alarm-diagnostics.php';

if (
    file_exists(
        $rud_crm_alarm_diagnostics_file
    )
) {

    require_once
        $rud_crm_alarm_diagnostics_file;
}


/*
 * =========================================================
 * LOAD EMAIL SYSTEM FOUNDATION
 * =========================================================
 */

$rud_crm_email_system_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/email-system.php';

if (
    file_exists(
        $rud_crm_email_system_file
    )
) {

    require_once
        $rud_crm_email_system_file;
}


/*
 * =========================================================
 * LOAD FRONT-END EMAIL SETUP / TEMPLATES
 * =========================================================
 */

$rud_crm_frontend_email_setup_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-email-setup.php';

if (
    file_exists(
        $rud_crm_frontend_email_setup_file
    )
) {

    require_once
        $rud_crm_frontend_email_setup_file;
}


/*
 * =========================================================
 * LOAD EMAIL SENDER
 * =========================================================
 */

$rud_crm_email_sender_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/email-sender.php';

if (
    file_exists(
        $rud_crm_email_sender_file
    )
) {

    require_once
        $rud_crm_email_sender_file;
}


/*
 * =========================================================
 * LOAD FRONT-END SEND EMAIL
 * =========================================================
 */

$rud_crm_frontend_send_email_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-send-email.php';

if (
    file_exists(
        $rud_crm_frontend_send_email_file
    )
) {

    require_once
        $rud_crm_frontend_send_email_file;
}


/*
 * =========================================================
 * LOAD SMS SYSTEM
 * =========================================================
 */

$rud_crm_sms_system_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/sms-system.php';

if (
    file_exists(
        $rud_crm_sms_system_file
    )
) {

    require_once
        $rud_crm_sms_system_file;
}


/*
 * =========================================================
 * LOAD FRONT-END SMS SETUP
 * =========================================================
 */

$rud_crm_frontend_sms_setup_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-sms-setup.php';

if (
    file_exists(
        $rud_crm_frontend_sms_setup_file
    )
) {

    require_once
        $rud_crm_frontend_sms_setup_file;
}


/*
 * =========================================================
 * LOAD SMS SENDER
 * =========================================================
 */

$rud_crm_sms_sender_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/sms-sender.php';

if (
    file_exists(
        $rud_crm_sms_sender_file
    )
) {

    require_once
        $rud_crm_sms_sender_file;
}


/*
 * =========================================================
 * LOAD FRONT-END SEND SMS
 * =========================================================
 */

$rud_crm_frontend_send_sms_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-send-sms.php';

if (
    file_exists(
        $rud_crm_frontend_send_sms_file
    )
) {

    require_once
        $rud_crm_frontend_send_sms_file;
}


/*
 * =========================================================
 * LOAD FRONT-END SMS TEMPLATES
 * =========================================================
 */

$rud_crm_frontend_sms_templates_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-sms-templates.php';

if (
    file_exists(
        $rud_crm_frontend_sms_templates_file
    )
) {

    require_once
        $rud_crm_frontend_sms_templates_file;
}


/*
 * =========================================================
 * LOAD FRONT-END MASS SMS
 * =========================================================
 */

$rud_crm_frontend_mass_sms_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-mass-sms.php';

if (
    file_exists(
        $rud_crm_frontend_mass_sms_file
    )
) {

    require_once
        $rud_crm_frontend_mass_sms_file;
}


/*
 * =========================================================
 * LOAD FRONT-END PROJECTS
 * =========================================================
 */

$rud_crm_frontend_projects_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-projects.php';

if (
    file_exists(
        $rud_crm_frontend_projects_file
    )
) {

    require_once
        $rud_crm_frontend_projects_file;
}


/*
 * =========================================================
 * LOAD BRØNNØYSUND COMPANY SEARCH
 * =========================================================
 */

$rud_crm_brreg_company_search_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/brreg-company-search.php';

if (
    file_exists(
        $rud_crm_brreg_company_search_file
    )
) {

    require_once
        $rud_crm_brreg_company_search_file;
}


/*
 * =========================================================
 * LOAD FRONT-END CUSTOMER CREATE
 * =========================================================
 */

$rud_crm_frontend_customer_create_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-customer-create.php';

if (
    file_exists(
        $rud_crm_frontend_customer_create_file
    )
) {

    require_once
        $rud_crm_frontend_customer_create_file;
}


/*
 * =========================================================
 * LOAD FRONT-END CUSTOMER EDIT / DELETE
 * =========================================================
 */

$rud_crm_frontend_customer_edit_delete_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-customer-edit-delete.php';

if (
    file_exists(
        $rud_crm_frontend_customer_edit_delete_file
    )
) {

    require_once
        $rud_crm_frontend_customer_edit_delete_file;
}


/*
 * =========================================================
 * LOAD FRONT-END CUSTOMER PROFILE IMAGE / LOGO
 * =========================================================
 */

$rud_crm_frontend_customer_image_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/frontend-customer-image.php';

if (
    file_exists(
        $rud_crm_frontend_customer_image_file
    )
) {

    require_once
        $rud_crm_frontend_customer_image_file;
}


/*
 * =========================================================
 * LOAD ELEMENTOR INTEGRATION
 * =========================================================
 */

$rud_crm_elementor_file =
    RUD_CRM_PLUGIN_DIR .
    'includes/elementor/elementor.php';

if (
    file_exists(
        $rud_crm_elementor_file
    )
) {

    require_once
        $rud_crm_elementor_file;
}


/*
 * =========================================================
 * PLUGIN ACTIVATION
 * =========================================================
 */

function rud_crm_server_activate() {

    if (
        function_exists(
            'rud_crm_server_install_database'
        )
    ) {

        rud_crm_server_install_database();
    }

    if (
        function_exists(
            'rud_crm_customer_permissions_install'
        )
    ) {

        rud_crm_customer_permissions_install();
    }
}


register_activation_hook(
    __FILE__,
    'rud_crm_server_activate'
);


/*
 * =========================================================
 * DATABASE VERSION CHECK
 * =========================================================
 */

function rud_crm_run_database_check() {

    if (
        function_exists(
            'rud_crm_check_database_version'
        )
    ) {

        rud_crm_check_database_version();
    }
}


add_action(
    'plugins_loaded',
    'rud_crm_run_database_check',
    30
);


/*
 * =========================================================
 * CUSTOMER IMAGE TABLE CHECK
 * =========================================================
 */

function rud_crm_run_image_table_check() {

    if (
        function_exists(
            'rud_crm_ensure_customer_images_table'
        )
    ) {

        rud_crm_ensure_customer_images_table();
    }
}


add_action(
    'admin_init',
    'rud_crm_run_image_table_check',
    30
);


/*
 * =========================================================
 * CUSTOMER PERMISSIONS TABLE CHECK
 * =========================================================
 */

function rud_crm_run_permissions_table_check() {

    if (
        function_exists(
            'rud_crm_customer_permissions_install'
        )
    ) {

        global $wpdb;

        $table =
            $wpdb->prefix .
            'rudcrm_customer_permissions';

        $exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW TABLES LIKE %s',
                    $table
                )
            );

        if (
            $exists !==
            $table
        ) {

            rud_crm_customer_permissions_install();
        }
    }
}


add_action(
    'admin_init',
    'rud_crm_run_permissions_table_check',
    31
);


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_admin_menu() {

    add_menu_page(

        'RUD CRM',

        'RUD CRM',

        'manage_options',

        'rud-crm',

        'rud_crm_dashboard_page',

        'dashicons-groups',

        25
    );


    add_submenu_page(

        'rud-crm',

        'Dashboard',

        'Dashboard',

        'manage_options',

        'rud-crm',

        'rud_crm_dashboard_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_admin_menu'
);


/*
 * =========================================================
 * DASHBOARD
 * =========================================================
 */

function rud_crm_dashboard_page() {

    global $wpdb;

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    $sites_table =
        $wpdb->prefix .
        'rudcrm_sites';

    $images_table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $api_table =
        $wpdb->prefix .
        'rudcrm_api_credentials';

    $permissions_table =
        $wpdb->prefix .
        'rudcrm_customer_permissions';

    $activity_table =
        $wpdb->prefix .
        'rudcrm_customer_activity';

    $projects_table =
        $wpdb->prefix .
        'rudcrm_projects';

    $project_customers_table =
        $wpdb->prefix .
        'rudcrm_project_customers';


    $customer_count =
        (int)
        $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$customers_table}"
        );

    $site_count =
        (int)
        $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$sites_table}"
        );

    $demo_customer_count =
        (int)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM {$customers_table}
                 WHERE customer_number LIKE %s",
                'DEMO-%'
            )
        );


    $image_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $images_table
            )
        );

    $api_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $api_table
            )
        );

    $permissions_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $permissions_table
            )
        );

    $activity_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $activity_table
            )
        );

    $projects_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $projects_table
            )
        );

    $project_customers_table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $project_customers_table
            )
        );


    echo '<div class="wrap">';

    echo '<h1>';
    echo 'RUD CRM Server';
    echo '</h1>';

    echo '<p>';
    echo 'Central CRM database and website connection management.';
    echo '</p>';

    echo '<hr>';

    echo '<h2>';
    echo 'CRM Status';
    echo '</h2>';


    echo '<p><strong>Customers:</strong> ';
    echo esc_html( $customer_count );
    echo '</p>';

    echo '<p><strong>Demo Customers:</strong> ';
    echo esc_html( $demo_customer_count );
    echo '</p>';

    echo '<p><strong>Connected Websites:</strong> ';
    echo esc_html( $site_count );
    echo '</p>';

    echo '<p><strong>Plugin Version:</strong> ';
    echo esc_html( RUD_CRM_VERSION );
    echo '</p>';

    echo '<p><strong>Database Version:</strong> ';
    echo esc_html( RUD_CRM_DB_VERSION );
    echo '</p>';


    echo '<p><strong>Projects Module:</strong> ';

    if (
        function_exists(
            'rud_crm_get_projects'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Projects Table:</strong> ';

    if (
        $projects_table_exists ===
        $projects_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Project / Customer Connections Table:</strong> ';

    if (
        $project_customers_table_exists ===
        $project_customers_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Customer Images Table:</strong> ';

    if (
        $image_table_exists ===
        $images_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Customer Permissions System:</strong> ';

    if (
        function_exists(
            'rud_crm_get_customer_permissions'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Customer Permissions Table:</strong> ';

    if (
        $permissions_table_exists ===
        $permissions_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Customer Permissions DB Version:</strong> ';

    echo esc_html(
        get_option(
            'rud_crm_customer_permissions_db_version',
            'Not installed'
        )
    );

    echo '</p>';


    echo '<p><strong>Customer Activity Table:</strong> ';

    if (
        $activity_table_exists ===
        $activity_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Demo User Access System:</strong> ';

    if (
        function_exists(
            'rud_crm_is_demo_user'
        )
        &&
        function_exists(
            'rud_crm_user_access_is_active'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Demo Customer Access Protection:</strong> ';

    if (
        function_exists(
            'rud_crm_user_can_access_customer'
        )
        &&
        function_exists(
            'rud_crm_demo_customer_prefix'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Demo Data Generator:</strong> ';

    if (
        function_exists(
            'rud_crm_create_demo_customers'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Social Media Module:</strong> ';

    if (
        function_exists(
            'rud_crm_social_platforms'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>International Phone System:</strong> ';

    if (
        function_exists(
            'rud_crm_phone_input'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Connected Websites Module:</strong> ';

    if (
        function_exists(
            'rud_crm_websites_page'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>API / Security Module:</strong> ';

    if (
        function_exists(
            'rud_crm_api_security_page'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>API Credentials Table:</strong> ';

    if (
        $api_table_exists ===
        $api_table
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }

    echo '</p>';


    echo '<p><strong>Front-End CRM:</strong> ';

    if (
        shortcode_exists(
            'rud_crm_frontend'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Elementor Integration:</strong> ';

    if (
        function_exists(
            'rud_crm_elementor_register_widgets'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">READY</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }

    echo '</p>';


    echo '<p><strong>Default Phone Country:</strong> ';

    if (
        function_exists(
            'rud_crm_phone_default_country'
        )
    ) {

        echo esc_html(
            strtoupper(
                rud_crm_phone_default_country()
            )
        );

    } else {

        echo 'Unavailable';
    }

    echo '</p>';

    echo '</div>';
}
