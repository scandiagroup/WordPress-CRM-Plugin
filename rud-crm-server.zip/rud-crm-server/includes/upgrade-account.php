<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * UPGRADE ACCOUNT / PACKAGE REQUEST SYSTEM
 * =========================================================
 *
 * Shortcode:
 *
 * [rud_crm_upgrade_account]
 *
 *
 * PACKAGE STRUCTURE
 * -----------------
 *
 * Package 1
 * Demo - 90 days
 *
 * Package 2
 * Full CRM - 6 months
 *
 * Package 3
 * Full CRM - 12 months
 *
 * Package 4
 * Full CRM - 24 months
 *
 * Package 5
 * Full CRM - 5 years
 *
 * Package 6
 * 24/7 Support Agreement
 *
 *
 * IMPORTANT
 * ---------
 *
 * Package 6 is an optional support agreement.
 * It is NOT a replacement for Packages 2-5.
 *
 * Selecting a package creates an upgrade REQUEST.
 *
 * It does NOT:
 *
 * - activate a paid package
 * - change the user's role
 * - extend validity
 * - create an invoice
 * - process payment
 *
 * =========================================================
 */


/*
 * =========================================================
 * PACKAGE DEFINITIONS
 * =========================================================
 */

function rud_crm_packages() {

    return array(

        1 => array(

            'name' =>
                'Demo',

            'title' =>
                'Package 1 – Demo',

            'duration' =>
                '90 Days',

            'price' =>
                'Free',

            'description' =>
                'Free RUD CRM Demo account for 90 days.',

            'upgradeable' =>
                false
        ),


        2 => array(

            'name' =>
                'Full CRM – 6 Months',

            'title' =>
                'Package 2 – Full CRM',

            'duration' =>
                '6 Months',

            'price' =>
                'Price Coming Later',

            'description' =>
                'Full access to RUD CRM for six months.',

            'upgradeable' =>
                true
        ),


        3 => array(

            'name' =>
                'Full CRM – 12 Months',

            'title' =>
                'Package 3 – Full CRM',

            'duration' =>
                '12 Months',

            'price' =>
                'Price Coming Later',

            'description' =>
                'Full access to RUD CRM for twelve months.',

            'upgradeable' =>
                true
        ),


        4 => array(

            'name' =>
                'Full CRM – 24 Months',

            'title' =>
                'Package 4 – Full CRM',

            'duration' =>
                '24 Months',

            'price' =>
                'Price Coming Later',

            'description' =>
                'Full access to RUD CRM for twenty-four months.',

            'upgradeable' =>
                true
        ),


        5 => array(

            'name' =>
                'Full CRM – 5 Years',

            'title' =>
                'Package 5 – Full CRM',

            'duration' =>
                '5 Years',

            'price' =>
                'Price Coming Later',

            'description' =>
                'Long-term full access to RUD CRM for five years.',

            'upgradeable' =>
                true
        )
    );
}


/*
 * =========================================================
 * SUPPORT PACKAGE
 * =========================================================
 */

function rud_crm_support_package() {

    return array(

        'number' =>
            6,

        'title' =>
            'Package 6 – 24/7 Support Agreement',

        'duration' =>
            'For the agreed CRM licence period',

        'price' =>
            'Price Coming Later',

        'description' =>
            'Optional premium 24/7 support agreement for your active RUD CRM licence period.'
    );
}


/*
 * =========================================================
 * CURRENT PACKAGE
 * =========================================================
 */

function rud_crm_current_package_number(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    /*
     * Explicit saved package.
     */

    $saved_package =
        absint(
            get_user_meta(
                $user_id,
                'rud_crm_package',
                true
            )
        );


    if (
        $saved_package >= 1
        &&
        $saved_package <= 5
    ) {

        return $saved_package;
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return 0;
    }


    /*
     * Legacy Demo account.
     */

    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        return 1;
    }


    /*
     * Existing full client without explicit
     * package metadata yet.
     */

    if (
        in_array(
            'rud_crm_client',
            (array)
            $user->roles,
            true
        )
    ) {

        return 0;
    }


    return 0;
}


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_upgrade_account_can_access() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    $user =
        wp_get_current_user();


    if (
        ! $user
        ||
        ! $user->exists()
    ) {

        return false;
    }


    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    if (
        in_array(
            'rud_crm_client',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    /*
     * CRM administrators can preview the page.
     */

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            $user->ID
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * REQUEST STATUS
 * =========================================================
 */

function rud_crm_upgrade_request_status(
    $user_id
) {

    $status =
        sanitize_key(
            get_user_meta(
                $user_id,
                'rud_crm_upgrade_request_status',
                true
            )
        );


    if (
        ! in_array(
            $status,
            array(
                'pending',
                'approved',
                'rejected',
                'cancelled'
            ),
            true
        )
    ) {

        return '';
    }


    return $status;
}


/*
 * =========================================================
 * GET PENDING REQUEST
 * =========================================================
 */

function rud_crm_get_upgrade_request(
    $user_id
) {

    $package =
        absint(
            get_user_meta(
                $user_id,
                'rud_crm_upgrade_request_package',
                true
            )
        );


    $support =
        (bool)
        get_user_meta(
            $user_id,
            'rud_crm_upgrade_request_support',
            true
        );


    $status =
        rud_crm_upgrade_request_status(
            $user_id
        );


    $date =
        get_user_meta(
            $user_id,
            'rud_crm_upgrade_request_date',
            true
        );


    return array(

        'package' =>
            $package,

        'support' =>
            $support,

        'status' =>
            $status,

        'date' =>
            $date
    );
}


/*
 * =========================================================
 * PROCESS UPGRADE REQUEST
 * =========================================================
 */

function rud_crm_process_upgrade_request() {

    if (
        empty(
            $_POST['rud_crm_upgrade_action']
        )
    ) {

        return;
    }


    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_upgrade_action']
            )
        );


    if (
        'submit_upgrade_request' !==
        $action
    ) {

        return;
    }


    if (
        ! rud_crm_upgrade_account_can_access()
    ) {

        return;
    }


    /*
     * -----------------------------------------------------
     * NONCE
     * -----------------------------------------------------
     */

    if (
        empty(
            $_POST['rud_crm_upgrade_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_upgrade_nonce']
                )
            ),
            'rud_crm_upgrade_request'
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_upgrade',
                'security_error',
                home_url(
                    '/upgrade-account/'
                )
            )
        );

        exit;
    }


    $user_id =
        get_current_user_id();


    /*
     * -----------------------------------------------------
     * PREVENT MULTIPLE PENDING REQUESTS
     * -----------------------------------------------------
     */

    if (
        'pending' ===
        rud_crm_upgrade_request_status(
            $user_id
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_upgrade',
                'already_pending',
                home_url(
                    '/upgrade-account/'
                )
            )
        );

        exit;
    }


    /*
     * -----------------------------------------------------
     * PACKAGE
     * -----------------------------------------------------
     */

    $package =
        isset(
            $_POST['rud_crm_selected_package']
        )
        ? absint(
            $_POST['rud_crm_selected_package']
        )
        : 0;


    $packages =
        rud_crm_packages();


    /*
     * Only paid licence Packages 2-5
     * can be requested.
     */

    if (
        ! isset(
            $packages[
                $package
            ]
        )
        ||
        empty(
            $packages[
                $package
            ]['upgradeable']
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_upgrade',
                'invalid_package',
                home_url(
                    '/upgrade-account/'
                )
            )
        );

        exit;
    }


    /*
     * -----------------------------------------------------
     * SUPPORT AGREEMENT
     * -----------------------------------------------------
     */

    $support =
        ! empty(
            $_POST['rud_crm_support_agreement']
        )
        ? 1
        : 0;


    /*
     * -----------------------------------------------------
     * SAVE REQUEST
     * -----------------------------------------------------
     */

    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_package',
        $package
    );


    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_support',
        $support
    );


    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_status',
        'pending'
    );


    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_date',
        current_time(
            'mysql'
        )
    );


    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_updated',
        current_time(
            'mysql'
        )
    );


    /*
     * -----------------------------------------------------
     * AUDIT INFORMATION
     * -----------------------------------------------------
     */

    update_user_meta(
        $user_id,
        'rud_crm_upgrade_request_ip',
        isset(
            $_SERVER['REMOTE_ADDR']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_SERVER['REMOTE_ADDR']
            )
        )
        : ''
    );


    /*
     * -----------------------------------------------------
     * SUCCESS
     * -----------------------------------------------------
     */

    wp_safe_redirect(
        add_query_arg(
            'rud_upgrade',
            'request_sent',
            home_url(
                '/upgrade-account/'
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_process_upgrade_request',
    20
);


/*
 * =========================================================
 * CANCEL PENDING REQUEST
 * =========================================================
 */

function rud_crm_process_cancel_upgrade_request() {

    if (
        empty(
            $_POST['rud_crm_upgrade_action']
        )
    ) {

        return;
    }


    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_upgrade_action']
            )
        );


    if (
        'cancel_upgrade_request' !==
        $action
    ) {

        return;
    }


    if (
        ! rud_crm_upgrade_account_can_access()
    ) {

        return;
    }


    if (
        empty(
            $_POST['rud_crm_upgrade_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_upgrade_nonce']
                )
            ),
            'rud_crm_upgrade_request'
        )
    ) {

        return;
    }


    $user_id =
        get_current_user_id();


    if (
        'pending' ===
        rud_crm_upgrade_request_status(
            $user_id
        )
    ) {

        update_user_meta(
            $user_id,
            'rud_crm_upgrade_request_status',
            'cancelled'
        );


        update_user_meta(
            $user_id,
            'rud_crm_upgrade_request_updated',
            current_time(
                'mysql'
            )
        );
    }


    wp_safe_redirect(
        add_query_arg(
            'rud_upgrade',
            'request_cancelled',
            home_url(
                '/upgrade-account/'
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_process_cancel_upgrade_request',
    21
);


/*
 * =========================================================
 * MESSAGE
 * =========================================================
 */

function rud_crm_upgrade_message_html() {

    if (
        empty(
            $_GET['rud_upgrade']
        )
    ) {

        return '';
    }


    $status =
        sanitize_key(
            wp_unslash(
                $_GET['rud_upgrade']
            )
        );


    $type =
        'info';


    $title =
        'RUD CRM';


    $message =
        '';


    if (
        'request_sent' ===
        $status
    ) {

        $type =
            'success';

        $title =
            'Upgrade Request Received';

        $message =
            'Your upgrade request has been successfully submitted and is now pending review.';
    }


    if (
        'request_cancelled' ===
        $status
    ) {

        $type =
            'info';

        $title =
            'Upgrade Request Cancelled';

        $message =
            'Your pending upgrade request has been cancelled.';
    }


    if (
        'already_pending' ===
        $status
    ) {

        $type =
            'info';

        $title =
            'Request Already Pending';

        $message =
            'You already have an upgrade request waiting for review.';
    }


    if (
        'invalid_package' ===
        $status
    ) {

        $type =
            'error';

        $title =
            'Invalid Package';

        $message =
            'Please select a valid Full RUD CRM package.';
    }


    if (
        'security_error' ===
        $status
    ) {

        $type =
            'error';

        $title =
            'Security Verification Failed';

        $message =
            'The request could not be verified. Please reload the page and try again.';
    }


    if (
        '' ===
        $message
    ) {

        return '';
    }


    ob_start();

    ?>

    <div class="rud-crm-upgrade-message rud-crm-upgrade-message-<?php echo esc_attr( $type ); ?>">

        <strong>
            <?php echo esc_html( $title ); ?>
        </strong>

        <p>
            <?php echo esc_html( $message ); ?>
        </p>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * FORMAT REQUEST DATE
 * =========================================================
 */

function rud_crm_upgrade_format_date(
    $date
) {

    if (
        ! $date
    ) {

        return '—';
    }


    $timestamp =
        strtotime(
            $date
        );


    if (
        ! $timestamp
    ) {

        return $date;
    }


    return wp_date(
        get_option(
            'date_format'
        ) .
        ' ' .
        get_option(
            'time_format'
        ),
        $timestamp
    );
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_upgrade_account_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return
            '<div class="rud-crm-upgrade-access-message">' .
                '<h2>Login Required</h2>' .
                '<p>You must be logged in to manage your RUD CRM package.</p>' .
            '</div>';
    }


    if (
        ! rud_crm_upgrade_account_can_access()
    ) {

        return
            '<div class="rud-crm-upgrade-access-message">' .
                '<h2>Access Restricted</h2>' .
                '<p>Your account does not have access to this page.</p>' .
            '</div>';
    }


    $user =
        wp_get_current_user();


    $user_id =
        $user->ID;


    $packages =
        rud_crm_packages();


    $support_package =
        rud_crm_support_package();


    $current_package =
        rud_crm_current_package_number(
            $user_id
        );


    $request =
        rud_crm_get_upgrade_request(
            $user_id
        );


    $has_pending_request =
        (
            'pending' ===
            $request['status']
        );


    ob_start();

    ?>

    <div class="rud-crm-upgrade-page">


        <?php

        echo rud_crm_upgrade_message_html();

        ?>


        <div class="rud-crm-upgrade-header">

            <h2>
                Upgrade to Full Version
            </h2>

            <p>
                Choose the RUD CRM licence period that best fits your needs.
            </p>

            <p>
                Submitting this form creates an upgrade request.
                Your account will not be changed until the request has been reviewed and approved.
            </p>

        </div>


        <?php if ( $current_package && isset( $packages[ $current_package ] ) ) : ?>

            <div class="rud-crm-current-package">

                <span>
                    Current Package
                </span>

                <strong>
                    <?php
                    echo esc_html(
                        $packages[
                            $current_package
                        ]['title']
                    );
                    ?>
                    —
                    <?php
                    echo esc_html(
                        $packages[
                            $current_package
                        ]['duration']
                    );
                    ?>
                </strong>

            </div>

        <?php endif; ?>


        <?php if ( $has_pending_request ) : ?>


            <?php

            $pending_package =
                isset(
                    $packages[
                        $request['package']
                    ]
                )
                ? $packages[
                    $request['package']
                ]
                : null;

            ?>


            <div class="rud-crm-pending-request">


                <div class="rud-crm-pending-badge">
                    PENDING
                </div>


                <h3>
                    Pending Upgrade Request
                </h3>


                <?php if ( $pending_package ) : ?>

                    <div class="rud-crm-request-row">

                        <span>
                            Requested Package
                        </span>

                        <strong>
                            <?php
                            echo esc_html(
                                $pending_package['name']
                            );
                            ?>
                        </strong>

                    </div>

                <?php endif; ?>


                <div class="rud-crm-request-row">

                    <span>
                        24/7 Support Agreement
                    </span>

                    <strong>
                        <?php
                        echo esc_html(
                            $request['support']
                            ? 'Requested'
                            : 'Not Requested'
                        );
                        ?>
                    </strong>

                </div>


                <div class="rud-crm-request-row">

                    <span>
                        Request Date
                    </span>

                    <strong>
                        <?php
                        echo esc_html(
                            rud_crm_upgrade_format_date(
                                $request['date']
                            )
                        );
                        ?>
                    </strong>

                </div>


                <p class="rud-crm-pending-note">
                    Your current CRM account remains unchanged while this request is pending.
                </p>


                <form method="post">

                    <?php

                    wp_nonce_field(
                        'rud_crm_upgrade_request',
                        'rud_crm_upgrade_nonce'
                    );

                    ?>

                    <input
                        type="hidden"
                        name="rud_crm_upgrade_action"
                        value="cancel_upgrade_request"
                    >


                    <button
                        type="submit"
                        class="rud-crm-cancel-request"
                    >
                        CANCEL UPGRADE REQUEST
                    </button>

                </form>


            </div>


        <?php else : ?>


            <form
                method="post"
                class="rud-crm-package-form"
            >


                <?php

                wp_nonce_field(
                    'rud_crm_upgrade_request',
                    'rud_crm_upgrade_nonce'
                );

                ?>


                <input
                    type="hidden"
                    name="rud_crm_upgrade_action"
                    value="submit_upgrade_request"
                >


                <h3 class="rud-crm-section-title">
                    Select Full CRM Package
                </h3>


                <div class="rud-crm-package-grid">


                    <?php

                    foreach (
                        $packages
                        as
                        $package_number =>
                        $package
                    ) :

                        if (
                            1 ===
                            $package_number
                        ) {

                            continue;
                        }

                    ?>


                        <label class="rud-crm-package-card">


                            <input
                                type="radio"
                                name="rud_crm_selected_package"
                                value="<?php echo esc_attr( $package_number ); ?>"
                                required
                            >


                            <div class="rud-crm-package-select-indicator">
                                SELECT
                            </div>


                            <h3>
                                <?php
                                echo esc_html(
                                    $package['title']
                                );
                                ?>
                            </h3>


                            <div class="rud-crm-package-duration">
                                <?php
                                echo esc_html(
                                    $package['duration']
                                );
                                ?>
                            </div>


                            <div class="rud-crm-package-price">
                                <?php
                                echo esc_html(
                                    $package['price']
                                );
                                ?>
                            </div>


                            <p>
                                <?php
                                echo esc_html(
                                    $package['description']
                                );
                                ?>
                            </p>


                        </label>


                    <?php endforeach; ?>


                </div>


                <div class="rud-crm-support-package">


                    <div class="rud-crm-support-heading">

                        <div>

                            <h3>
                                <?php
                                echo esc_html(
                                    $support_package['title']
                                );
                                ?>
                            </h3>

                            <strong>
                                Optional Add-on
                            </strong>

                        </div>

                    </div>


                    <p>
                        <?php
                        echo esc_html(
                            $support_package['description']
                        );
                        ?>
                    </p>


                    <p>
                        <strong>
                            <?php
                            echo esc_html(
                                $support_package['duration']
                            );
                            ?>
                        </strong>
                    </p>


                    <p>
                        <?php
                        echo esc_html(
                            $support_package['price']
                        );
                        ?>
                    </p>


                    <label class="rud-crm-support-checkbox">

                        <input
                            type="checkbox"
                            name="rud_crm_support_agreement"
                            value="1"
                        >

                        I would like to include the 24/7 Support Agreement.

                    </label>


                </div>


                <div class="rud-crm-request-information">

                    <strong>
                        This is an upgrade request only.
                    </strong>

                    <p>
                        Submitting this request does not activate a package and does not create a payment.
                        RUD CRM administration will review the request before any account changes are made.
                    </p>

                </div>


                <button
                    type="submit"
                    class="rud-crm-submit-upgrade"
                >
                    SUBMIT UPGRADE REQUEST
                </button>


            </form>


        <?php endif; ?>


        <div class="rud-crm-upgrade-actions">

            <a
                href="<?php
                echo esc_url(
                    function_exists(
                        'rud_crm_my_account_page_url'
                    )
                    ? rud_crm_my_account_page_url()
                    : home_url(
                        '/my-account/'
                    )
                );
                ?>"
            >
                ← Back to My Account
            </a>

        </div>


    </div>


    <style>

        .rud-crm-upgrade-page {
            width:100%;
            max-width:1100px;
            margin:0 auto;
        }


        .rud-crm-upgrade-header {
            margin-bottom:25px;
        }


        .rud-crm-upgrade-header h2 {
            margin-top:0;
        }


        .rud-crm-current-package {
            display:flex;
            justify-content:space-between;
            gap:20px;
            margin-bottom:25px;
            padding:17px 20px;
            border:1px solid #dddddd;
            border-radius:7px;
        }


        .rud-crm-current-package span {
            opacity:.7;
        }


        /*
         * PACKAGE GRID
         */

        .rud-crm-package-grid {
            display:grid;
            grid-template-columns:
                repeat(
                    2,
                    minmax(
                        0,
                        1fr
                    )
                );
            gap:20px;
        }


        .rud-crm-package-card {
            position:relative;
            display:block;
            padding:24px;
            border:2px solid #dddddd;
            border-radius:9px;
            cursor:pointer;
            background:#ffffff;
        }


        .rud-crm-package-card:hover {
            border-color:#888888;
        }


        .rud-crm-package-card input[type="radio"] {
            position:absolute;
            opacity:0;
            pointer-events:none;
        }


        .rud-crm-package-card:has(input:checked) {
            border-color:#1d2327;
            box-shadow:
                0 0 0 1px #1d2327;
        }


        .rud-crm-package-card:has(input:checked)
        .rud-crm-package-select-indicator {
            background:#1d2327;
            color:#ffffff;
        }


        .rud-crm-package-select-indicator {
            display:inline-block;
            margin-bottom:15px;
            padding:5px 10px;
            border:1px solid #cccccc;
            border-radius:999px;
            font-size:11px;
            font-weight:700;
        }


        .rud-crm-package-card h3 {
            margin:0 0 8px;
        }


        .rud-crm-package-duration {
            margin-bottom:5px;
            font-size:20px;
            font-weight:700;
        }


        .rud-crm-package-price {
            margin-bottom:15px;
            opacity:.7;
        }


        /*
         * SUPPORT
         */

        .rud-crm-support-package {
            margin-top:28px;
            padding:24px;
            border:2px solid #dddddd;
            border-radius:9px;
        }


        .rud-crm-support-package h3 {
            margin:0 0 4px;
        }


        .rud-crm-support-checkbox {
            display:block;
            margin-top:18px;
            padding:15px;
            background:#f7f7f7;
            border-radius:6px;
            font-weight:600;
            cursor:pointer;
        }


        .rud-crm-support-checkbox input {
            margin-right:8px;
        }


        /*
         * REQUEST INFORMATION
         */

        .rud-crm-request-information {
            margin-top:25px;
            padding:18px 20px;
            background:#f7f7f7;
            border-radius:7px;
        }


        .rud-crm-request-information p {
            margin-bottom:0;
        }


        /*
         * SUBMIT
         */

        .rud-crm-submit-upgrade {
            display:block;
            width:100%;
            margin-top:22px;
            padding:15px 20px;
            border:0;
            border-radius:6px;
            background:#1d2327;
            color:#ffffff;
            font-size:16px;
            font-weight:700;
            cursor:pointer;
        }


        /*
         * PENDING REQUEST
         */

        .rud-crm-pending-request {
            padding:25px;
            border:2px solid #dba617;
            border-radius:9px;
        }


        .rud-crm-pending-request h3 {
            margin-top:10px;
        }


        .rud-crm-pending-badge {
            display:inline-block;
            padding:5px 10px;
            border-radius:999px;
            background:#fff8dc;
            font-size:12px;
            font-weight:700;
        }


        .rud-crm-request-row {
            display:flex;
            justify-content:space-between;
            gap:20px;
            padding:12px 0;
            border-bottom:1px solid #eeeeee;
        }


        .rud-crm-request-row span {
            opacity:.7;
        }


        .rud-crm-pending-note {
            margin-top:18px;
        }


        .rud-crm-cancel-request {
            margin-top:10px;
            padding:11px 18px;
            border:1px solid #b32d2e;
            border-radius:5px;
            background:#ffffff;
            color:#b32d2e;
            cursor:pointer;
            font-weight:600;
        }


        /*
         * MESSAGES
         */

        .rud-crm-upgrade-message {
            margin-bottom:22px;
            padding:17px 20px;
            border-radius:7px;
        }


        .rud-crm-upgrade-message p {
            margin-bottom:0;
        }


        .rud-crm-upgrade-message-success {
            border-left:4px solid #00a32a;
            background:#f3fff5;
        }


        .rud-crm-upgrade-message-info {
            border-left:4px solid #2271b1;
            background:#f4f8fc;
        }


        .rud-crm-upgrade-message-error {
            border-left:4px solid #b32d2e;
            background:#fff5f5;
        }


        /*
         * ACTIONS
         */

        .rud-crm-upgrade-actions {
            margin-top:25px;
        }


        .rud-crm-upgrade-actions a {
            text-decoration:none;
        }


        @media (max-width:700px) {

            .rud-crm-package-grid {
                grid-template-columns:1fr;
            }


            .rud-crm-current-package,
            .rud-crm-request-row {
                display:block;
            }


            .rud-crm-current-package strong,
            .rud-crm-request-row strong {
                display:block;
                margin-top:5px;
            }
        }

    </style>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_upgrade_account',
    'rud_crm_upgrade_account_shortcode'
);