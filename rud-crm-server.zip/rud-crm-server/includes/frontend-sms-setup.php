<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END SMS SETUP
 * Version 1.2
 * =========================================================
 *
 * Shortcode:
 * [rud_crm_sms_setup]
 *
 * Provider settings ONLY.
 * SMS Templates are managed on a separate page.
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_sms_setup_can_manage() {

    if (
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_frontend_is_crm_admin'
        )
        &&
        rud_crm_frontend_is_crm_admin()
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            get_current_user_id()
        )
    ) {
        return true;
    }

    return false;
}


/*
 * =========================================================
 * SAVE PROVIDER SETTINGS
 * =========================================================
 */

function rud_crm_sms_setup_process_form() {

    if (
        empty(
            $_POST['rud_crm_sms_setup_action']
        )
        ||
        'save_settings' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_sms_setup_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_sms_setup_can_manage()
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_sms_setup_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_sms_setup_nonce']
                )
            ),
            'rud_crm_sms_setup'
        )
    ) {
        return;
    }

    rud_crm_update_sms_settings(
        array(

            'provider' =>
                sanitize_key(
                    wp_unslash(
                        $_POST['provider']
                        ?? 'twilio'
                    )
                ),

            'sender_type' =>
                sanitize_key(
                    wp_unslash(
                        $_POST['sender_type']
                        ?? 'number'
                    )
                ),

            'sender_id' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['sender_id']
                        ?? ''
                    )
                ),

            'account_sid' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['account_sid']
                        ?? ''
                    )
                ),

            'auth_token' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['auth_token']
                        ?? ''
                    )
                ),

            'messaging_service_sid' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['messaging_service_sid']
                        ?? ''
                    )
                ),
        )
    );

    wp_safe_redirect(
        add_query_arg(
            'rud_sms_message',
            'settings_saved',
            home_url(
                '/sms-setup/'
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_sms_setup_process_form',
    80
);


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_sms_setup_shortcode() {

    if (
        ! is_user_logged_in()
    ) {
        return
            '<p>You must be logged in to access SMS Setup.</p>';
    }

    if (
        ! rud_crm_sms_setup_can_manage()
    ) {
        return
            '<p>You do not have permission to manage SMS Setup.</p>';
    }

    if (
        ! function_exists(
            'rud_crm_get_sms_settings'
        )
    ) {
        return
            '<p>The SMS System module is not available.</p>';
    }

    $settings =
        rud_crm_get_sms_settings();

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_sms_message']
                ?? ''
            )
        );

    ob_start();

    ?>

    <div class="rud-crm-sms-setup">

        <h1>
            SMS Setup
        </h1>

        <p class="rud-crm-sms-intro">
            Configure the SMS provider and sender credentials.
            SMS Templates are managed separately from the Account menu.
            <strong>SMS Setup v1.2</strong>
        </p>

        <?php if ( 'settings_saved' === $message ) : ?>

            <div class="rud-crm-sms-message rud-crm-sms-success">
                SMS settings saved successfully.
            </div>

        <?php endif; ?>


        <section class="rud-crm-sms-panel">

            <h2>
                Provider Settings
            </h2>

            <form method="post">

                <?php
                wp_nonce_field(
                    'rud_crm_sms_setup',
                    'rud_crm_sms_setup_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_sms_setup_action"
                    value="save_settings"
                >

                <div class="rud-crm-sms-grid">

                    <div>

                        <label>
                            SMS Provider
                        </label>

                        <select name="provider">

                            <option
                                value="twilio"
                                <?php selected( $settings['provider'], 'twilio' ); ?>
                            >
                                Twilio
                            </option>

                        </select>

                    </div>

                    <div>

                        <label>
                            Sender Type
                        </label>

                        <select name="sender_type">

                            <option
                                value="number"
                                <?php selected( $settings['sender_type'], 'number' ); ?>
                            >
                                Phone Number
                            </option>

                            <option
                                value="alphanumeric"
                                <?php selected( $settings['sender_type'], 'alphanumeric' ); ?>
                            >
                                Alphanumeric Sender ID
                            </option>

                        </select>

                    </div>

                    <div class="rud-crm-sms-wide">

                        <label>
                            Sender Number / Sender ID
                        </label>

                        <input
                            type="text"
                            name="sender_id"
                            value="<?php echo esc_attr( $settings['sender_id'] ); ?>"
                            placeholder="+47... or RUDCRM"
                        >

                    </div>

                    <div>

                        <label>
                            Twilio Account SID
                        </label>

                        <input
                            type="text"
                            name="account_sid"
                            value="<?php echo esc_attr( $settings['account_sid'] ); ?>"
                            autocomplete="off"
                        >

                    </div>

                    <div>

                        <label>
                            Twilio Auth Token
                        </label>

                        <input
                            type="password"
                            name="auth_token"
                            value="<?php echo esc_attr( $settings['auth_token'] ); ?>"
                            autocomplete="new-password"
                        >

                    </div>

                    <div class="rud-crm-sms-wide">

                        <label>
                            Twilio Messaging Service SID
                        </label>

                        <input
                            type="text"
                            name="messaging_service_sid"
                            value="<?php echo esc_attr( $settings['messaging_service_sid'] ); ?>"
                            autocomplete="off"
                        >

                        <small>
                            Optional. Leave empty when sending directly from a Twilio phone number.
                        </small>

                    </div>

                </div>

                <button
                    type="submit"
                    class="rud-crm-sms-primary-button"
                >
                    SAVE SMS SETTINGS
                </button>

            </form>

        </section>

    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_sms_setup',
    'rud_crm_sms_setup_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_sms_setup_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    ?>

    <style id="rud-crm-sms-setup-styles">

        .rud-crm-sms-setup {
            width:100%;
            max-width:1100px;
            margin:0 auto;
        }

        .rud-crm-sms-intro {
            margin-bottom:24px;
            color:#667085;
        }

        .rud-crm-sms-panel {
            margin-bottom:24px;
            padding:24px;
            border:1px solid #e4e7ec;
            border-radius:12px;
            background:#fff;
        }

        .rud-crm-sms-panel * {
            box-sizing:border-box;
        }

        .rud-crm-sms-panel h2 {
            margin-top:0 !important;
        }

        .rud-crm-sms-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:14px;
        }

        .rud-crm-sms-wide {
            grid-column:1 / -1;
        }

        .rud-crm-sms-grid label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }

        .rud-crm-sms-grid input,
        .rud-crm-sms-grid select {
            width:100%;
            padding:10px 12px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            font:inherit;
        }

        .rud-crm-sms-grid small {
            display:block;
            margin-top:5px;
            color:#667085;
            font-size:11px;
        }

        .rud-crm-sms-primary-button {
            display:inline-block;
            min-height:38px;
            margin-top:16px;
            padding:8px 13px;
            border:1px solid #1d2939;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            cursor:pointer;
            font-size:11px;
            font-weight:700;
        }

        .rud-crm-sms-message {
            margin-bottom:18px;
            padding:11px 13px;
            border-radius:7px;
        }

        .rud-crm-sms-success {
            border-left:4px solid #00a32a;
            background:#f3fff5;
        }

        @media (max-width:700px) {

            .rud-crm-sms-grid {
                grid-template-columns:1fr;
            }

            .rud-crm-sms-wide {
                grid-column:auto;
            }
        }

    </style>

    <?php
}


add_action(
    'wp_head',
    'rud_crm_sms_setup_styles',
    90
);
