<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END PROJECTS
 * Version 1.0
 * =========================================================
 *
 * Shortcode:
 * [rud_crm_projects]
 *
 * Features:
 * - Project list
 * - Create project
 * - Open project
 * - Edit project
 * - Connect existing CRM customer to project
 * - Remove customer from project
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_frontend_projects_can_access() {

    if (
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        function_exists(
            'rud_crm_frontend_user_can_access'
        )
    ) {
        return (bool)
            rud_crm_frontend_user_can_access();
    }

    return current_user_can(
        'read'
    );
}


/*
 * =========================================================
 * PAGE URL
 * =========================================================
 */

function rud_crm_frontend_projects_page_url() {

    $page =
        get_page_by_path(
            'projects'
        );

    if (
        $page
        &&
        'publish' ===
        $page->post_status
    ) {
        return get_permalink(
            $page->ID
        );
    }

    return home_url(
        '/projects/'
    );
}


/*
 * =========================================================
 * PROJECT URL
 * =========================================================
 */

function rud_crm_frontend_project_url(
    $project_id
) {

    return add_query_arg(
        array(
            'rud_project_id' =>
                absint(
                    $project_id
                ),
        ),
        rud_crm_frontend_projects_page_url()
    );
}


/*
 * =========================================================
 * PROCESS CREATE PROJECT
 * =========================================================
 */

function rud_crm_frontend_projects_process_create() {

    if (
        empty(
            $_POST['rud_crm_project_action']
        )
        ||
        'create_project' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_projects_can_access()
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_project_nonce']
                )
            ),
            'rud_crm_create_project'
        )
    ) {
        wp_die(
            'Security verification failed.'
        );
    }

    if (
        ! function_exists(
            'rud_crm_create_project'
        )
    ) {
        wp_die(
            'Projects module is not available.'
        );
    }

    $project_id =
        rud_crm_create_project(
            array(
                'project_title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['project_title']
                            ?? ''
                        )
                    ),

                'project_type' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['project_type']
                            ?? ''
                        )
                    ),

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status']
                            ?? 'planning'
                        )
                    ),

                'start_date' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['start_date']
                            ?? ''
                        )
                    ),

                'end_date' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['end_date']
                            ?? ''
                        )
                    ),

                'description' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['description']
                            ?? ''
                        )
                    ),

                'internal_notes' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['internal_notes']
                            ?? ''
                        )
                    ),
            )
        );

    if (
        is_wp_error(
            $project_id
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_project_error',
                'create_failed',
                rud_crm_frontend_projects_page_url()
            )
        );

        exit;
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_project_message',
            'created',
            rud_crm_frontend_project_url(
                $project_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_projects_process_create',
    25
);


/*
 * =========================================================
 * PROCESS UPDATE PROJECT
 * =========================================================
 */

function rud_crm_frontend_projects_process_update() {

    if (
        empty(
            $_POST['rud_crm_project_action']
        )
        ||
        'update_project' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_projects_can_access()
    ) {
        return;
    }

    $project_id =
        absint(
            $_POST['project_id']
            ?? 0
        );

    if (
        ! $project_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_project_nonce']
                )
            ),
            'rud_crm_update_project_' .
            $project_id
        )
    ) {
        wp_die(
            'Security verification failed.'
        );
    }

    $result =
        rud_crm_update_project(
            $project_id,
            array(
                'project_title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['project_title']
                            ?? ''
                        )
                    ),

                'project_type' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['project_type']
                            ?? ''
                        )
                    ),

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status']
                            ?? 'planning'
                        )
                    ),

                'start_date' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['start_date']
                            ?? ''
                        )
                    ),

                'end_date' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['end_date']
                            ?? ''
                        )
                    ),

                'description' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['description']
                            ?? ''
                        )
                    ),

                'internal_notes' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['internal_notes']
                            ?? ''
                        )
                    ),
            )
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_project_error',
                'update_failed',
                rud_crm_frontend_project_url(
                    $project_id
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_project_message',
            'updated',
            rud_crm_frontend_project_url(
                $project_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_projects_process_update',
    26
);


/*
 * =========================================================
 * PROCESS CONNECT CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_projects_process_connect_customer() {

    if (
        empty(
            $_POST['rud_crm_project_action']
        )
        ||
        'connect_customer' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_projects_can_access()
    ) {
        return;
    }

    $project_id =
        absint(
            $_POST['project_id']
            ?? 0
        );

    $customer_id =
        absint(
            $_POST['customer_id']
            ?? 0
        );

    if (
        ! $project_id
        ||
        ! $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_project_nonce']
                )
            ),
            'rud_crm_connect_customer_' .
            $project_id
        )
    ) {
        wp_die(
            'Security verification failed.'
        );
    }

    if (
        function_exists(
            'rud_crm_frontend_can_view_customer'
        )
        &&
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {
        wp_die(
            'You do not have permission to use this customer.'
        );
    }

    $result =
        rud_crm_connect_customer_to_project(
            $project_id,
            $customer_id,
            array(
                'relationship_role' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['relationship_role']
                            ?? ''
                        )
                    ),

                'relationship_status' =>
                    'active',
            )
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_project_error',
                'connect_failed',
                rud_crm_frontend_project_url(
                    $project_id
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_project_message',
            'customer_connected',
            rud_crm_frontend_project_url(
                $project_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_projects_process_connect_customer',
    27
);


/*
 * =========================================================
 * PROCESS DISCONNECT CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_projects_process_disconnect_customer() {

    if (
        empty(
            $_POST['rud_crm_project_action']
        )
        ||
        'disconnect_customer' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_projects_can_access()
    ) {
        return;
    }

    $project_id =
        absint(
            $_POST['project_id']
            ?? 0
        );

    $customer_id =
        absint(
            $_POST['customer_id']
            ?? 0
        );

    if (
        ! $project_id
        ||
        ! $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_project_nonce']
                )
            ),
            'rud_crm_disconnect_customer_' .
            $project_id .
            '_' .
            $customer_id
        )
    ) {
        wp_die(
            'Security verification failed.'
        );
    }

    rud_crm_disconnect_customer_from_project(
        $project_id,
        $customer_id
    );

    wp_safe_redirect(
        add_query_arg(
            'rud_project_message',
            'customer_removed',
            rud_crm_frontend_project_url(
                $project_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_projects_process_disconnect_customer',
    28
);


/*
 * =========================================================
 * GET VISIBLE CUSTOMERS FOR DROPDOWN
 * =========================================================
 */

function rud_crm_frontend_projects_customer_options() {

    if (
        function_exists(
            'rud_crm_frontend_get_customers'
        )
    ) {

        return
            rud_crm_frontend_get_customers();
    }

    return array();
}


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_frontend_projects_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_project_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_project_error']
                ?? ''
            )
        );

    if (
        'created' ===
        $message
    ) {

        return
            '<div class="rud-crm-project-success">' .
            '<strong>Project Created</strong>' .
            '<span>The project was created successfully.</span>' .
            '</div>';
    }

    if (
        'updated' ===
        $message
    ) {

        return
            '<div class="rud-crm-project-success">' .
            '<strong>Project Updated</strong>' .
            '<span>The project information was saved.</span>' .
            '</div>';
    }

    if (
        'customer_connected' ===
        $message
    ) {

        return
            '<div class="rud-crm-project-success">' .
            '<strong>Customer Connected</strong>' .
            '<span>The customer is now connected to this project.</span>' .
            '</div>';
    }

    if (
        'customer_removed' ===
        $message
    ) {

        return
            '<div class="rud-crm-project-success">' .
            '<strong>Customer Removed</strong>' .
            '<span>The customer was removed from this project.</span>' .
            '</div>';
    }

    if (
        $error
    ) {

        return
            '<div class="rud-crm-project-error">' .
            '<strong>Something went wrong</strong>' .
            '<span>Please try again.</span>' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * CREATE PROJECT FORM
 * =========================================================
 */

function rud_crm_frontend_projects_create_form() {

    $statuses =
        rud_crm_project_statuses();

    ob_start();

    ?>

    <details class="rud-crm-project-create-panel">

        <summary>
            + Create New Project
        </summary>

        <form
            method="post"
            class="rud-crm-project-form"
        >

            <?php
            wp_nonce_field(
                'rud_crm_create_project',
                'rud_crm_project_nonce'
            );
            ?>

            <input
                type="hidden"
                name="rud_crm_project_action"
                value="create_project"
            >

            <div class="rud-crm-project-grid">

                <div class="rud-crm-project-wide">

                    <label>
                        Project Title
                    </label>

                    <input
                        type="text"
                        name="project_title"
                        required
                        placeholder="Et liv med Camping"
                    >

                </div>

                <div>

                    <label>
                        Project Type
                    </label>

                    <input
                        type="text"
                        name="project_type"
                        placeholder="TV Documentary / Series"
                    >

                </div>

                <div>

                    <label>
                        Status
                    </label>

                    <select name="status">

                        <?php
                        foreach (
                            $statuses
                            as
                            $key =>
                            $label
                        ) :
                        ?>

                            <option
                                value="<?php echo esc_attr( $key ); ?>"
                            >
                                <?php echo esc_html( $label ); ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div>

                    <label>
                        Start Date
                    </label>

                    <input
                        type="date"
                        name="start_date"
                    >

                </div>

                <div>

                    <label>
                        End Date
                    </label>

                    <input
                        type="date"
                        name="end_date"
                    >

                </div>

                <div class="rud-crm-project-wide">

                    <label>
                        Description
                    </label>

                    <textarea
                        name="description"
                        rows="4"
                    ></textarea>

                </div>

                <div class="rud-crm-project-wide">

                    <label>
                        Internal Project Notes
                    </label>

                    <textarea
                        name="internal_notes"
                        rows="4"
                    ></textarea>

                </div>

            </div>

            <button
                type="submit"
                class="rud-crm-project-primary-button"
            >
                CREATE PROJECT
            </button>

        </form>

    </details>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * PROJECT LIST
 * =========================================================
 */

function rud_crm_frontend_projects_list_html() {

    $projects =
        rud_crm_get_projects(
            array(
                'orderby' =>
                    'updated_at',

                'order' =>
                    'DESC',
            )
        );

    ob_start();

    ?>

    <div class="rud-crm-project-list-wrap">

        <div class="rud-crm-project-list-heading">

            <h2>
                Projects
            </h2>

            <span>
                <?php echo esc_html( count( $projects ) ); ?> project(s)
            </span>

        </div>

        <?php if ( empty( $projects ) ) : ?>

            <div class="rud-crm-project-empty">
                No projects have been created yet.
            </div>

        <?php else : ?>

            <div class="rud-crm-project-list">

                <div class="rud-crm-project-row rud-crm-project-row-head">

                    <div>
                        Project
                    </div>

                    <div>
                        Type
                    </div>

                    <div>
                        Status
                    </div>

                    <div>
                        Customers
                    </div>

                    <div></div>

                </div>

                <?php foreach ( $projects as $project ) : ?>

                    <div class="rud-crm-project-row">

                        <div>

                            <strong>
                                <?php
                                echo esc_html(
                                    $project->project_title
                                );
                                ?>
                            </strong>

                            <small>
                                <?php
                                echo esc_html(
                                    $project->project_number
                                );
                                ?>
                            </small>

                        </div>

                        <div>
                            <?php
                            echo esc_html(
                                $project->project_type
                                ?: '—'
                            );
                            ?>
                        </div>

                        <div>
                            <?php
                            echo esc_html(
                                rud_crm_project_statuses()[
                                    $project->status
                                ]
                                ?? ucfirst(
                                    $project->status
                                )
                            );
                            ?>
                        </div>

                        <div>
                            <?php
                            echo esc_html(
                                rud_crm_project_customer_count(
                                    $project->id
                                )
                            );
                            ?>
                        </div>

                        <div class="rud-crm-project-row-action">

                            <a
                                class="rud-crm-project-primary-button rud-crm-project-small-button"
                                href="<?php
                                echo esc_url(
                                    rud_crm_frontend_project_url(
                                        $project->id
                                    )
                                );
                                ?>"
                            >
                                Open Project
                            </a>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * OPEN PROJECT
 * =========================================================
 */

function rud_crm_frontend_project_detail_html(
    $project_id
) {

    $project =
        rud_crm_get_project(
            $project_id
        );

    if (
        ! $project
    ) {

        return
            '<div class="rud-crm-project-empty">' .
            'Project could not be found.' .
            '</div>';
    }

    $statuses =
        rud_crm_project_statuses();

    $customers =
        rud_crm_get_project_customers(
            $project_id
        );

    $all_customers =
        rud_crm_frontend_projects_customer_options();

    $connected_ids =
        array_map(
            function( $customer ) {
                return absint(
                    $customer->id
                );
            },
            (array)
            $customers
        );

    ob_start();

    ?>

    <div class="rud-crm-project-detail">

        <div class="rud-crm-project-toolbar">

            <a
                href="<?php
                echo esc_url(
                    rud_crm_frontend_projects_page_url()
                );
                ?>"
                class="rud-crm-project-secondary-button"
            >
                ← Back to Projects
            </a>

        </div>

        <?php
        echo rud_crm_frontend_projects_message_html();
        ?>

        <section class="rud-crm-project-hero">

            <div>

                <span class="rud-crm-project-status">
                    <?php
                    echo esc_html(
                        $statuses[
                            $project->status
                        ]
                        ?? ucfirst(
                            $project->status
                        )
                    );
                    ?>
                </span>

                <h1>
                    <?php
                    echo esc_html(
                        $project->project_title
                    );
                    ?>
                </h1>

                <div class="rud-crm-project-number">
                    <?php
                    echo esc_html(
                        $project->project_number
                    );
                    ?>
                </div>

            </div>

            <div class="rud-crm-project-hero-count">

                <strong>
                    <?php
                    echo esc_html(
                        count(
                            $customers
                        )
                    );
                    ?>
                </strong>

                <span>
                    Connected Customers
                </span>

            </div>

        </section>

        <section class="rud-crm-project-card">

            <h2>
                Project Information
            </h2>

            <form
                method="post"
                class="rud-crm-project-form"
            >

                <?php
                wp_nonce_field(
                    'rud_crm_update_project_' .
                    $project_id,
                    'rud_crm_project_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_project_action"
                    value="update_project"
                >

                <input
                    type="hidden"
                    name="project_id"
                    value="<?php echo esc_attr( $project_id ); ?>"
                >

                <div class="rud-crm-project-grid">

                    <div class="rud-crm-project-wide">

                        <label>
                            Project Title
                        </label>

                        <input
                            type="text"
                            name="project_title"
                            value="<?php
                            echo esc_attr(
                                $project->project_title
                            );
                            ?>"
                            required
                        >

                    </div>

                    <div>

                        <label>
                            Project Type
                        </label>

                        <input
                            type="text"
                            name="project_type"
                            value="<?php
                            echo esc_attr(
                                $project->project_type
                            );
                            ?>"
                        >

                    </div>

                    <div>

                        <label>
                            Status
                        </label>

                        <select name="status">

                            <?php
                            foreach (
                                $statuses
                                as
                                $key =>
                                $label
                            ) :
                            ?>

                                <option
                                    value="<?php echo esc_attr( $key ); ?>"
                                    <?php selected( $project->status, $key ); ?>
                                >
                                    <?php echo esc_html( $label ); ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div>

                        <label>
                            Start Date
                        </label>

                        <input
                            type="date"
                            name="start_date"
                            value="<?php
                            echo esc_attr(
                                $project->start_date
                            );
                            ?>"
                        >

                    </div>

                    <div>

                        <label>
                            End Date
                        </label>

                        <input
                            type="date"
                            name="end_date"
                            value="<?php
                            echo esc_attr(
                                $project->end_date
                            );
                            ?>"
                        >

                    </div>

                    <div class="rud-crm-project-wide">

                        <label>
                            Description
                        </label>

                        <textarea
                            name="description"
                            rows="5"
                        ><?php
                        echo esc_textarea(
                            $project->description
                        );
                        ?></textarea>

                    </div>

                    <div class="rud-crm-project-wide">

                        <label>
                            Internal Project Notes
                        </label>

                        <textarea
                            name="internal_notes"
                            rows="5"
                        ><?php
                        echo esc_textarea(
                            $project->internal_notes
                        );
                        ?></textarea>

                    </div>

                </div>

                <button
                    type="submit"
                    class="rud-crm-project-primary-button"
                >
                    SAVE PROJECT
                </button>

            </form>

        </section>

        <section class="rud-crm-project-card">

            <h2>
                Connect Customer to Project
            </h2>

            <form
                method="post"
                class="rud-crm-project-connect-form"
            >

                <?php
                wp_nonce_field(
                    'rud_crm_connect_customer_' .
                    $project_id,
                    'rud_crm_project_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_project_action"
                    value="connect_customer"
                >

                <input
                    type="hidden"
                    name="project_id"
                    value="<?php echo esc_attr( $project_id ); ?>"
                >

                <div class="rud-crm-project-connect-grid">

                    <div>

                        <label>
                            Customer / Company
                        </label>

                        <select
                            name="customer_id"
                            required
                        >

                            <option value="">
                                Select customer...
                            </option>

                            <?php
                            foreach (
                                $all_customers
                                as
                                $customer
                            ) :

                                if (
                                    in_array(
                                        absint(
                                            $customer->id
                                        ),
                                        $connected_ids,
                                        true
                                    )
                                ) {
                                    continue;
                                }

                                $display_name =
                                    function_exists(
                                        'rud_crm_frontend_customer_name'
                                    )
                                    ? rud_crm_frontend_customer_name(
                                        $customer
                                    )
                                    : (
                                        $customer->company_name
                                        ?: trim(
                                            (
                                                $customer->first_name
                                                ?? ''
                                            )
                                            .
                                            ' '
                                            .
                                            (
                                                $customer->last_name
                                                ?? ''
                                            )
                                        )
                                    );

                            ?>

                                <option
                                    value="<?php echo esc_attr( $customer->id ); ?>"
                                >
                                    <?php
                                    echo esc_html(
                                        $display_name .
                                        ' — ' .
                                        $customer->customer_number
                                    );
                                    ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div>

                        <label>
                            Role / Relationship
                        </label>

                        <input
                            type="text"
                            name="relationship_role"
                            placeholder="Supplier, participant, interview source..."
                        >

                    </div>

                    <div class="rud-crm-project-connect-action">

                        <button
                            type="submit"
                            class="rud-crm-project-primary-button"
                        >
                            CONNECT TO PROJECT
                        </button>

                    </div>

                </div>

            </form>

        </section>

        <section class="rud-crm-project-card">

            <h2>
                Connected Customers
            </h2>

            <?php if ( empty( $customers ) ) : ?>

                <div class="rud-crm-project-empty">
                    No customers are connected to this project yet.
                </div>

            <?php else : ?>

                <div class="rud-crm-project-customer-list">

                    <?php foreach ( $customers as $customer ) : ?>

                        <?php

                        $display_name =
                            function_exists(
                                'rud_crm_frontend_customer_name'
                            )
                            ? rud_crm_frontend_customer_name(
                                $customer
                            )
                            : (
                                $customer->company_name
                                ?: trim(
                                    (
                                        $customer->first_name
                                        ?? ''
                                    )
                                    .
                                    ' '
                                    .
                                    (
                                        $customer->last_name
                                        ?? ''
                                    )
                                )
                            );

                        ?>

                        <div class="rud-crm-project-customer-row">

                            <div>

                                <strong>
                                    <?php echo esc_html( $display_name ); ?>
                                </strong>

                                <span>
                                    <?php
                                    echo esc_html(
                                        $customer->customer_number
                                    );
                                    ?>
                                </span>

                            </div>

                            <div>
                                <?php
                                echo esc_html(
                                    $customer->relationship_role
                                    ?: '—'
                                );
                                ?>
                            </div>

                            <div class="rud-crm-project-customer-actions">

                                <?php
                                if (
                                    function_exists(
                                        'rud_crm_frontend_customer_url'
                                    )
                                ) :
                                ?>

                                    <a
                                        href="<?php
                                        echo esc_url(
                                            rud_crm_frontend_customer_url(
                                                $customer->id
                                            )
                                        );
                                        ?>"
                                        class="rud-crm-project-secondary-button"
                                    >
                                        Open Customer
                                    </a>

                                <?php endif; ?>

                                <form method="post">

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_disconnect_customer_' .
                                        $project_id .
                                        '_' .
                                        $customer->id,
                                        'rud_crm_project_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_project_action"
                                        value="disconnect_customer"
                                    >

                                    <input
                                        type="hidden"
                                        name="project_id"
                                        value="<?php echo esc_attr( $project_id ); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="customer_id"
                                        value="<?php echo esc_attr( $customer->id ); ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="rud-crm-project-remove-button"
                                    >
                                        Remove
                                    </button>

                                </form>

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </section>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_frontend_projects_shortcode() {

    if (
        ! rud_crm_frontend_projects_can_access()
    ) {

        return
            '<div class="rud-crm-project-empty">' .
            'You must be logged in to access Projects.' .
            '</div>';
    }

    if (
        ! function_exists(
            'rud_crm_get_projects'
        )
    ) {

        return
            '<div class="rud-crm-project-empty">' .
            'Projects module is not loaded.' .
            '</div>';
    }

    $project_id =
        absint(
            $_GET['rud_project_id']
            ?? 0
        );

    ob_start();

    ?>

    <div class="rud-crm-projects-frontend">

        <?php

        if (
            $project_id
        ) {

            echo rud_crm_frontend_project_detail_html(
                $project_id
            );

        } else {

            echo rud_crm_frontend_projects_message_html();

            echo rud_crm_frontend_projects_create_form();

            echo rud_crm_frontend_projects_list_html();
        }

        ?>

    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_projects',
    'rud_crm_frontend_projects_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_projects_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-projects-frontend,
    .rud-crm-projects-frontend * {
        box-sizing:border-box;
    }

    .rud-crm-project-create-panel,
    .rud-crm-project-card,
    .rud-crm-project-hero,
    .rud-crm-project-list {
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
    }

    .rud-crm-project-create-panel {
        margin-bottom:24px;
        overflow:hidden;
    }

    .rud-crm-project-create-panel summary {
        padding:16px 18px;
        cursor:pointer;
        font-weight:700;
        list-style:none;
    }

    .rud-crm-project-create-panel summary::-webkit-details-marker {
        display:none;
    }

    .rud-crm-project-form {
        padding:20px;
        border-top:1px solid #eaecf0;
    }

    .rud-crm-project-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:16px;
    }

    .rud-crm-project-wide {
        grid-column:1 / -1;
    }

    .rud-crm-project-form label,
    .rud-crm-project-connect-form label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-project-form input,
    .rud-crm-project-form select,
    .rud-crm-project-form textarea,
    .rud-crm-project-connect-form input,
    .rud-crm-project-connect-form select {
        width:100%;
        min-height:42px;
        padding:9px 11px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-project-form textarea {
        min-height:auto;
    }

    .rud-crm-project-primary-button,
    .rud-crm-project-secondary-button,
    .rud-crm-project-remove-button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:40px;
        padding:9px 14px;
        border-radius:7px;
        text-decoration:none !important;
        cursor:pointer;
        font-weight:600;
    }

    .rud-crm-project-primary-button {
        margin-top:18px;
        border:1px solid #1d2939;
        background:#1d2939;
        color:#fff !important;
    }

    .rud-crm-project-secondary-button {
        border:1px solid #d0d5dd;
        background:#fff;
        color:#1d2939 !important;
    }

    .rud-crm-project-remove-button {
        border:1px solid #b42318;
        background:#fff;
        color:#b42318;
    }

    .rud-crm-project-small-button {
        min-height:34px;
        margin:0;
        padding:7px 11px;
        font-size:12px;
    }

    .rud-crm-project-list-heading {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        margin-bottom:12px;
    }

    .rud-crm-project-list-heading h2 {
        margin:0;
    }

    .rud-crm-project-list-heading span {
        color:#667085;
        font-size:13px;
    }

    .rud-crm-project-list {
        overflow:hidden;
    }

    .rud-crm-project-row {
        display:grid;
        grid-template-columns:minmax(220px,2fr) minmax(160px,1fr) 120px 90px auto;
        align-items:center;
        gap:16px;
        min-height:58px;
        padding:10px 14px;
        border-bottom:1px solid #eaecf0;
    }

    .rud-crm-project-row:last-child {
        border-bottom:0;
    }

    .rud-crm-project-row-head {
        min-height:38px;
        background:#f9fafb;
        color:#667085;
        font-size:11px;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.04em;
    }

    .rud-crm-project-row strong,
    .rud-crm-project-row small {
        display:block;
    }

    .rud-crm-project-row small {
        margin-top:3px;
        color:#667085;
    }

    .rud-crm-project-row-action {
        justify-self:end;
    }

    .rud-crm-project-toolbar {
        margin-bottom:18px;
    }

    .rud-crm-project-hero {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:24px;
        padding:24px;
        margin-bottom:20px;
    }

    .rud-crm-project-hero h1 {
        margin:8px 0 3px !important;
    }

    .rud-crm-project-status {
        display:inline-flex;
        padding:4px 9px;
        border-radius:999px;
        background:#f2f4f7;
        font-size:11px;
        font-weight:700;
        text-transform:uppercase;
    }

    .rud-crm-project-number {
        color:#667085;
        font-size:13px;
    }

    .rud-crm-project-hero-count {
        display:flex;
        flex-direction:column;
        align-items:flex-end;
    }

    .rud-crm-project-hero-count strong {
        font-size:30px;
        line-height:1;
    }

    .rud-crm-project-hero-count span {
        margin-top:5px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-project-card {
        margin-bottom:20px;
        padding:22px;
    }

    .rud-crm-project-card h2 {
        margin:0 0 16px !important;
    }

    .rud-crm-project-connect-form {
        margin:0;
    }

    .rud-crm-project-connect-grid {
        display:grid;
        grid-template-columns:minmax(250px,2fr) minmax(220px,1fr) auto;
        align-items:end;
        gap:14px;
    }

    .rud-crm-project-connect-action .rud-crm-project-primary-button {
        margin:0;
    }

    .rud-crm-project-customer-list {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-project-customer-row {
        display:grid;
        grid-template-columns:minmax(220px,2fr) minmax(180px,1fr) auto;
        align-items:center;
        gap:14px;
        padding:11px 13px;
        border-bottom:1px solid #eaecf0;
    }

    .rud-crm-project-customer-row:last-child {
        border-bottom:0;
    }

    .rud-crm-project-customer-row strong,
    .rud-crm-project-customer-row span {
        display:block;
    }

    .rud-crm-project-customer-row span {
        margin-top:3px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-project-customer-actions {
        display:flex;
        align-items:center;
        gap:8px;
    }

    .rud-crm-project-customer-actions form {
        margin:0;
    }

    .rud-crm-project-success,
    .rud-crm-project-error {
        display:flex;
        flex-direction:column;
        gap:4px;
        margin-bottom:18px;
        padding:14px 16px;
        border-radius:8px;
    }

    .rud-crm-project-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-project-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    .rud-crm-project-empty {
        padding:20px;
        border:1px solid #eaecf0;
        border-radius:10px;
        background:#fff;
    }

    @media (max-width:900px) {

        .rud-crm-project-row-head {
            display:none;
        }

        .rud-crm-project-row {
            grid-template-columns:1fr auto;
        }

        .rud-crm-project-connect-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-project-connect-action .rud-crm-project-primary-button {
            width:100%;
        }

        .rud-crm-project-customer-row {
            grid-template-columns:1fr;
        }

        .rud-crm-project-customer-actions {
            flex-wrap:wrap;
        }
    }

    @media (max-width:600px) {

        .rud-crm-project-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-project-wide {
            grid-column:auto;
        }

        .rud-crm-project-hero {
            align-items:flex-start;
            flex-direction:column;
        }

        .rud-crm-project-hero-count {
            align-items:flex-start;
        }

        .rud-crm-project-row {
            grid-template-columns:1fr;
        }

        .rud-crm-project-row-action {
            justify-self:stretch;
        }

        .rud-crm-project-row-action .rud-crm-project-primary-button {
            width:100%;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-projects',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-projects'
    );

    wp_add_inline_style(
        'rud-crm-frontend-projects',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_projects_styles',
    30
);
