<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * ADD CUSTOMER ACTIVITY
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Add_Activity
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-add-activity';
    }


    public function get_title() {

        return 'Add Customer Activity';
    }


    public function get_icon() {

        return 'eicon-plus-circle';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Add Activity'
            )
        );


        $this->add_control(
            'show_heading',
            array(
                'label' => 'Show Heading',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'heading',
            array(
                'label' => 'Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Add Customer Activity',
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'type_label',
            array(
                'label' => 'Activity Type Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Activity Type'
            )
        );


        $this->add_control(
            'title_label',
            array(
                'label' => 'Title Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Title'
            )
        );


        $this->add_control(
            'content_label',
            array(
                'label' => 'Content Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Details'
            )
        );


        $this->add_control(
            'source_label',
            array(
                'label' => 'Source Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Source'
            )
        );


        $this->add_control(
            'date_label',
            array(
                'label' => 'Date Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Activity Date'
            )
        );


        $this->add_control(
            'button_text',
            array(
                'label' => 'Save Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Add Activity'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * FORM OPTIONS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'options_section',
            array(
                'label' => 'Form Options'
            )
        );


        $this->add_control(
            'default_type',
            array(
                'label' => 'Default Activity Type',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'note',
                'options' => array(
                    'note'     => 'Note',
                    'call'     => 'Call',
                    'email'    => 'Email',
                    'meeting'  => 'Meeting',
                    'task'     => 'Task',
                    'consent'  => 'Consent Change',
                    'website'  => 'Website Activity',
                    'order'    => 'Order',
                    'system'   => 'System Event',
                    'other'    => 'Other'
                )
            )
        );


        $this->add_control(
            'default_source',
            array(
                'label' => 'Default Source',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'CRM'
            )
        );


        $this->add_control(
            'show_source',
            array(
                'label' => 'Show Source Field',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_date',
            array(
                'label' => 'Show Activity Date',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-add-activity'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-add-activity'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * HEADING STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'heading_style',
            array(
                'label' => 'Heading',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'heading_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity-heading' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'heading_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-add-activity-heading'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * FIELD STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'field_style',
            array(
                'label' => 'Fields',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'field_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity input,
                     {{WRAPPER}} .rud-crm-add-activity select,
                     {{WRAPPER}} .rud-crm-add-activity textarea' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'field_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity input,
                     {{WRAPPER}} .rud-crm-add-activity select,
                     {{WRAPPER}} .rud-crm-add-activity textarea' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'field_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-add-activity input,
                     {{WRAPPER}} .rud-crm-add-activity select,
                     {{WRAPPER}} .rud-crm-add-activity textarea'
            )
        );


        $this->add_responsive_control(
            'field_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity input,
                     {{WRAPPER}} .rud-crm-add-activity select,
                     {{WRAPPER}} .rud-crm-add-activity textarea' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * BUTTON STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' => 'Button',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'button_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity-button' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity-button' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'button_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-add-activity-button'
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-add-activity-button' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * EDIT ACCESS
     * =====================================================
     */

    private function can_edit() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            current_user_can(
                'manage_options'
            )
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_edit'
            )
        ) {

            return rud_crm_user_can_edit();
        }


        return false;
    }


    /*
     * =====================================================
     * CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        /*
         * Elementor preview.
         */

        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * TABLE EXISTS
     * =====================================================
     */

    private function activity_table_exists() {

        global $wpdb;


        $table =
            $wpdb->prefix .
            'rudcrm_customer_activity';


        return
            $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW TABLES LIKE %s',
                    $table
                )
            )
            ===
            $table;
    }


    /*
     * =====================================================
     * ACTIVITY TYPES
     * =====================================================
     */

    private function activity_types() {

        return array(

            'note' =>
                'Note',

            'call' =>
                'Call',

            'email' =>
                'Email',

            'meeting' =>
                'Meeting',

            'task' =>
                'Task',

            'consent' =>
                'Consent Change',

            'website' =>
                'Website Activity',

            'order' =>
                'Order',

            'system' =>
                'System Event',

            'other' =>
                'Other'
        );
    }


    /*
     * =====================================================
     * HANDLE FORM
     * =====================================================
     */

    private function handle_form(
        $customer_id
    ) {

        global $wpdb;


        if (
            ! isset(
                $_POST['rud_crm_add_activity_action']
            )
        ) {

            return '';
        }


        /*
         * Make sure this form belongs to
         * the currently displayed customer.
         */

        $posted_customer_id =
            isset(
                $_POST['rud_crm_activity_customer_id']
            )
            ? absint(
                $_POST['rud_crm_activity_customer_id']
            )
            : 0;


        if (
            $posted_customer_id !==
            $customer_id
        ) {

            return '';
        }


        /*
         * Security.
         */

        if (
            ! isset(
                $_POST['rud_crm_activity_nonce']
            )
            ||
            ! wp_verify_nonce(
                sanitize_text_field(
                    wp_unslash(
                        $_POST['rud_crm_activity_nonce']
                    )
                ),
                'rud_crm_add_activity_' .
                $customer_id
            )
        ) {

            return 'Security check failed.';
        }


        if (
            ! $this->can_edit()
        ) {

            return 'You are not allowed to add customer activity.';
        }


        if (
            ! $this->activity_table_exists()
        ) {

            return 'Customer activity database table is missing.';
        }


        /*
         * -------------------------------------------------
         * TYPE
         * -------------------------------------------------
         */

        $activity_type =
            isset(
                $_POST['rud_crm_activity_type']
            )
            ? sanitize_key(
                wp_unslash(
                    $_POST['rud_crm_activity_type']
                )
            )
            : 'note';


        $types =
            $this->activity_types();


        if (
            ! isset(
                $types[
                    $activity_type
                ]
            )
        ) {

            $activity_type =
                'other';
        }


        /*
         * -------------------------------------------------
         * TITLE
         * -------------------------------------------------
         */

        $title =
            isset(
                $_POST['rud_crm_activity_title']
            )
            ? sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_activity_title']
                )
            )
            : '';


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $content =
            isset(
                $_POST['rud_crm_activity_content']
            )
            ? wp_kses_post(
                wp_unslash(
                    $_POST['rud_crm_activity_content']
                )
            )
            : '';


        /*
         * Require something useful.
         */

        if (
            '' ===
            trim(
                $title
            )
            &&
            '' ===
            trim(
                wp_strip_all_tags(
                    $content
                )
            )
        ) {

            return 'Please enter a title or activity details.';
        }


        /*
         * -------------------------------------------------
         * SOURCE
         * -------------------------------------------------
         */

        $source =
            isset(
                $_POST['rud_crm_activity_source']
            )
            ? sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_activity_source']
                )
            )
            : 'CRM';


        if (
            '' ===
            $source
        ) {

            $source =
                'CRM';
        }


        /*
         * -------------------------------------------------
         * ACTIVITY DATE
         * -------------------------------------------------
         */

        $activity_date =
            current_time(
                'mysql'
            );


        if (
            isset(
                $_POST['rud_crm_activity_date']
            )
            &&
            '' !==
            trim(
                (string)
                $_POST['rud_crm_activity_date']
            )
        ) {

            $submitted_date =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['rud_crm_activity_date']
                    )
                );


            $timestamp =
                strtotime(
                    $submitted_date
                );


            if (
                $timestamp
            ) {

                $activity_date =
                    wp_date(
                        'Y-m-d H:i:s',
                        $timestamp
                    );
            }
        }


        /*
         * -------------------------------------------------
         * SAVE
         * -------------------------------------------------
         */

        $now =
            current_time(
                'mysql'
            );


        $table =
            $wpdb->prefix .
            'rudcrm_customer_activity';


        $result =
            $wpdb->insert(

                $table,

                array(

                    'customer_id' =>
                        $customer_id,

                    'activity_type' =>
                        $activity_type,

                    'title' =>
                        $title,

                    'content' =>
                        $content,

                    'source' =>
                        $source,

                    'source_reference' =>
                        '',

                    'created_by' =>
                        get_current_user_id(),

                    'activity_date' =>
                        $activity_date,

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now
                ),

                array(
                    '%d',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%d',
                    '%s',
                    '%s',
                    '%s'
                )
            );


        if (
            false ===
            $result
        ) {

            return 'The activity could not be saved.';
        }


        return 'Customer activity was added successfully.';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_edit()
        ) {

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        if (
            ! $this->activity_table_exists()
        ) {

            echo '<div>Customer activity database table is missing.</div>';

            return;
        }


        $message =
            $this->handle_form(
                $customer_id
            );


        echo '<div class="rud-crm-add-activity">';


        /*
         * -------------------------------------------------
         * HEADING
         * -------------------------------------------------
         */

        if (
            'yes' ===
            $settings['show_heading']
        ) {

            echo '<h3 class="rud-crm-add-activity-heading">';

            echo esc_html(
                $settings['heading']
            );

            echo '</h3>';
        }


        /*
         * -------------------------------------------------
         * MESSAGE
         * -------------------------------------------------
         */

        if (
            '' !==
            $message
        ) {

            echo '<div class="rud-crm-add-activity-message">';

            echo esc_html(
                $message
            );

            echo '</div>';
        }


        /*
         * -------------------------------------------------
         * FORM
         * -------------------------------------------------
         */

        echo '<form
            method="post"
            class="rud-crm-add-activity-form"
        >';


        wp_nonce_field(
            'rud_crm_add_activity_' .
            $customer_id,
            'rud_crm_activity_nonce'
        );


        echo '<input
            type="hidden"
            name="rud_crm_activity_customer_id"
            value="' .
            esc_attr(
                $customer_id
            ) .
            '"
        >';


        /*
         * ACTIVITY TYPE
         */

        echo '<div class="rud-crm-add-activity-field">';


        echo '<label>';

        echo esc_html(
            $settings['type_label']
        );

        echo '</label>';


        echo '<select name="rud_crm_activity_type">';


        foreach (
            $this->activity_types()
            as
            $type_key =>
            $type_label
        ) {

            echo '<option
                value="' .
                esc_attr(
                    $type_key
                ) .
                '"';


            selected(
                $settings['default_type'],
                $type_key
            );


            echo '>';

            echo esc_html(
                $type_label
            );

            echo '</option>';
        }


        echo '</select>';

        echo '</div>';


        /*
         * TITLE
         */

        echo '<div class="rud-crm-add-activity-field">';


        echo '<label>';

        echo esc_html(
            $settings['title_label']
        );

        echo '</label>';


        echo '<input
            type="text"
            name="rud_crm_activity_title"
            placeholder="Short description"
        >';


        echo '</div>';


        /*
         * CONTENT
         */

        echo '<div class="rud-crm-add-activity-field">';


        echo '<label>';

        echo esc_html(
            $settings['content_label']
        );

        echo '</label>';


        echo '<textarea
            name="rud_crm_activity_content"
            rows="6"
            placeholder="Enter activity details..."
        ></textarea>';


        echo '</div>';


        /*
         * SOURCE
         */

        if (
            'yes' ===
            $settings['show_source']
        ) {

            echo '<div class="rud-crm-add-activity-field">';


            echo '<label>';

            echo esc_html(
                $settings['source_label']
            );

            echo '</label>';


            echo '<input
                type="text"
                name="rud_crm_activity_source"
                value="' .
                esc_attr(
                    $settings['default_source']
                ) .
                '"
            >';


            echo '</div>';
        }


        /*
         * ACTIVITY DATE
         */

        if (
            'yes' ===
            $settings['show_date']
        ) {

            echo '<div class="rud-crm-add-activity-field">';


            echo '<label>';

            echo esc_html(
                $settings['date_label']
            );

            echo '</label>';


            echo '<input
                type="datetime-local"
                name="rud_crm_activity_date"
                value="' .
                esc_attr(
                    wp_date(
                        'Y-m-d\TH:i'
                    )
                ) .
                '"
            >';


            echo '</div>';
        }


        /*
         * SUBMIT
         */

        echo '<div class="rud-crm-add-activity-actions">';


        echo '<button
            type="submit"
            name="rud_crm_add_activity_action"
            value="save"
            class="rud-crm-add-activity-button"
        >';

        echo esc_html(
            $settings['button_text']
        );

        echo '</button>';


        echo '</div>';


        echo '</form>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-add-activity {
            width:100%;
        }

        .rud-crm-add-activity-heading {
            margin-top:0;
            margin-bottom:18px;
        }

        .rud-crm-add-activity-message {
            margin-bottom:16px;
            padding:10px 12px;
            border:1px solid #c8d9ec;
            border-radius:6px;
            background:#f1f7fd;
        }

        .rud-crm-add-activity-form {
            display:flex;
            flex-direction:column;
            gap:15px;
        }

        .rud-crm-add-activity-field {
            display:flex;
            flex-direction:column;
            gap:6px;
        }

        .rud-crm-add-activity-field label {
            font-weight:600;
        }

        .rud-crm-add-activity-field input,
        .rud-crm-add-activity-field select,
        .rud-crm-add-activity-field textarea {
            width:100%;
            box-sizing:border-box;
        }

        .rud-crm-add-activity-field textarea {
            resize:vertical;
        }

        .rud-crm-add-activity-actions {
            display:flex;
            flex-wrap:wrap;
            gap:10px;
        }

        .rud-crm-add-activity-button {
            cursor:pointer;
            padding:9px 16px;
        }

        </style>

        <?php
    }
}