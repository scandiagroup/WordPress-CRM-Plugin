<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER SOCIAL MEDIA WIDGET
 * ICON-ENABLED VERSION
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Social
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-social';
    }


    public function get_title() {

        return 'Customer Social Media';
    }


    public function get_icon() {

        return 'eicon-social-icons';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Social Media'
            )
        );


        $this->add_control(
            'display_mode',
            array(
                'label' => 'Display',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon_text',
                'options' => array(
                    'icon_text' => 'Icon + Text',
                    'icon_only' => 'Icon Only',
                    'text_only' => 'Text Only'
                )
            )
        );


        $this->add_control(
            'show_platform_name',
            array(
                'label' => 'Show Platform Name',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'show_account_name',
            array(
                'label' => 'Show Account Name',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'show_link',
            array(
                'label' => 'Show Link Text',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'link_text',
            array(
                'label' => 'Link Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Open Profile',
                'condition' => array(
                    'show_link' => 'yes',
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'open_new_window',
            array(
                'label' => 'Open Links in New Window',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-grid' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CARD STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'card_style',
            array(
                'label' => 'Cards',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'card_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-item' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'card_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-social-item'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'card_shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-social-item'
            )
        );


        $this->add_responsive_control(
            'card_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-item' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'card_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-item' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * ICON STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'icon_style',
            array(
                'label' => 'Icons',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'display_mode!' => 'text_only'
                )
            )
        );


        $this->add_responsive_control(
            'icon_size',
            array(
                'label' => 'Icon Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 10,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-icon' =>
                        'font-size:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'icon_color',
            array(
                'label' => 'Icon Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-icon' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'icon_background',
            array(
                'label' => 'Icon Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-icon-wrap' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'icon_box_size',
            array(
                'label' => 'Icon Box Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 20,
                        'max' => 120
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-icon-wrap' =>
                        'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'icon_radius',
            array(
                'label' => 'Icon Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-icon-wrap' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * PLATFORM STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'platform_style',
            array(
                'label' => 'Platform Name',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_platform_name' => 'yes',
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'platform_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-platform' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'platform_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-social-platform'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * ACCOUNT STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'account_style',
            array(
                'label' => 'Account Name',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_account_name' => 'yes',
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'account_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-account' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'account_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-social-account'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LINK STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'link_style',
            array(
                'label' => 'Link',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_link' => 'yes',
                    'display_mode!' => 'icon_only'
                )
            )
        );


        $this->add_control(
            'link_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-social-link' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'link_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-social-link'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * PLATFORM ICON MAP
     * =====================================================
     */

    private function get_icon_class(
        $platform
    ) {

        $icons =
            array(

                'facebook' =>
                    'fab fa-facebook-f',

                'instagram' =>
                    'fab fa-instagram',

                'tiktok' =>
                    'fab fa-tiktok',

                'youtube' =>
                    'fab fa-youtube',

                'x' =>
                    'fab fa-x-twitter',

                'threads' =>
                    'fab fa-threads',

                'linkedin' =>
                    'fab fa-linkedin-in',

                'linkedin_company' =>
                    'fab fa-linkedin-in',

                'pinterest' =>
                    'fab fa-pinterest-p',

                'snapchat' =>
                    'fab fa-snapchat-ghost',

                'whatsapp' =>
                    'fab fa-whatsapp',

                'telegram' =>
                    'fab fa-telegram-plane',

                'messenger' =>
                    'fab fa-facebook-messenger',

                'signal' =>
                    'fas fa-comment-dots',

                'viber' =>
                    'fab fa-viber',

                'wechat' =>
                    'fab fa-weixin',

                'line' =>
                    'fab fa-line',

                'kakao' =>
                    'fas fa-comment',

                'skype' =>
                    'fab fa-skype',

                'discord' =>
                    'fab fa-discord',

                'twitch' =>
                    'fab fa-twitch',

                'xing' =>
                    'fab fa-xing',

                'reddit' =>
                    'fab fa-reddit-alien',

                'tumblr' =>
                    'fab fa-tumblr',

                'medium' =>
                    'fab fa-medium-m',

                'quora' =>
                    'fab fa-quora',

                'truth_social' =>
                    'fas fa-comment-alt',

                'bluesky' =>
                    'fas fa-cloud',

                'mastodon' =>
                    'fab fa-mastodon',

                'gab' =>
                    'fas fa-comments',

                'parler' =>
                    'fas fa-comment',

                'spotify' =>
                    'fab fa-spotify',

                'soundcloud' =>
                    'fab fa-soundcloud',

                'vimeo' =>
                    'fab fa-vimeo-v',

                'website' =>
                    'fas fa-globe',

                'other' =>
                    'fas fa-link'
            );


        return
            isset(
                $icons[
                    $platform
                ]
            )
            ?
            $icons[
                $platform
            ]
            :
            'fas fa-link';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {
            return;
        }


        global $wpdb;


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {
                echo 'No customer available for preview.';
            }

            return;
        }


        $rows =
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_social_accounts
                     WHERE customer_id = %d
                     AND is_active = 1
                     ORDER BY platform ASC",
                    $customer_id
                )
            );


        if (
            empty(
                $rows
            )
        ) {

            if (
                $this->is_editor()
            ) {
                echo 'No active social media accounts.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        echo '<div class="rud-crm-social-grid">';


        foreach (
            $rows as
            $row
        ) {

            if (
                function_exists(
                    'rud_crm_social_platform_label'
                )
            ) {

                $platform_name =
                    rud_crm_social_platform_label(
                        $row->platform
                    );

            } else {

                $platform_name =
                    ucfirst(
                        str_replace(
                            array(
                                '_',
                                '-'
                            ),
                            ' ',
                            $row->platform
                        )
                    );
            }


            $icon_class =
                $this->get_icon_class(
                    $row->platform
                );


            $is_icon_only =
                (
                    'icon_only' ===
                    $settings['display_mode']
                );


            echo '<div class="rud-crm-social-item">';


            /*
             * ICON
             */

            if (
                'text_only' !==
                $settings['display_mode']
            ) {

                $icon_html =
                    '<span class="rud-crm-social-icon-wrap">' .
                        '<i class="rud-crm-social-icon ' .
                        esc_attr(
                            $icon_class
                        ) .
                        '" aria-hidden="true"></i>' .
                    '</span>';


                if (
                    $is_icon_only
                    &&
                    ! empty(
                        $row->profile_url
                    )
                ) {

                    echo '<a
                        class="rud-crm-social-icon-link"
                        href="' .
                        esc_url(
                            $row->profile_url
                        ) .
                        '"';


                    if (
                        'yes' ===
                        $settings['open_new_window']
                    ) {

                        echo ' target="_blank" rel="noopener noreferrer"';
                    }


                    echo ' aria-label="' .
                        esc_attr(
                            $platform_name
                        ) .
                        '">';

                    echo $icon_html;

                    echo '</a>';

                } else {

                    echo $icon_html;
                }
            }


            /*
             * TEXT
             */

            if (
                ! $is_icon_only
            ) {

                echo '<div class="rud-crm-social-text">';


                if (
                    'yes' ===
                    $settings['show_platform_name']
                ) {

                    echo '<div class="rud-crm-social-platform">';

                    echo esc_html(
                        $platform_name
                    );

                    echo '</div>';
                }


                if (
                    'yes' ===
                    $settings['show_account_name']
                    &&
                    ! empty(
                        $row->account_name
                    )
                ) {

                    echo '<div class="rud-crm-social-account">';

                    echo esc_html(
                        $row->account_name
                    );

                    echo '</div>';
                }


                if (
                    'yes' ===
                    $settings['show_link']
                    &&
                    ! empty(
                        $row->profile_url
                    )
                ) {

                    echo '<a
                        class="rud-crm-social-link"
                        href="' .
                        esc_url(
                            $row->profile_url
                        ) .
                        '"';


                    if (
                        'yes' ===
                        $settings['open_new_window']
                    ) {

                        echo ' target="_blank" rel="noopener noreferrer"';
                    }


                    echo '>';

                    echo esc_html(
                        $settings['link_text']
                    );

                    echo '</a>';
                }


                echo '</div>';
            }


            echo '</div>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-social-grid {
            display:grid;
            grid-template-columns:repeat(3,minmax(0,1fr));
            gap:15px;
        }

        .rud-crm-social-item {
            display:flex;
            align-items:center;
            gap:12px;
            min-width:0;
        }

        .rud-crm-social-icon-wrap {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            flex:0 0 auto;
            width:42px;
            height:42px;
        }

        .rud-crm-social-icon {
            line-height:1;
        }

        .rud-crm-social-icon-link {
            display:inline-flex;
            text-decoration:none;
            color:inherit;
        }

        .rud-crm-social-text {
            display:flex;
            flex-direction:column;
            gap:3px;
            min-width:0;
        }

        .rud-crm-social-platform {
            font-weight:700;
        }

        .rud-crm-social-account {
            overflow-wrap:anywhere;
        }

        </style>

        <?php
    }
}