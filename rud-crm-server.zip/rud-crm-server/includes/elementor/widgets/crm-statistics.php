<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CRM STATISTICS WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_CRM_Statistics
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-statistics';
    }


    public function get_title() {

        return 'CRM Statistics';
    }


    public function get_icon() {

        return 'eicon-counter';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * STATISTICS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'statistics_section',
            array(
                'label' => 'Statistics'
            )
        );


        $this->add_control(
            'show_total_customers',
            array(
                'label' => 'Total Customers',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_leads',
            array(
                'label' => 'Leads',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_customers',
            array(
                'label' => 'Customers',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_partners',
            array(
                'label' => 'Partners',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_inactive',
            array(
                'label' => 'Inactive',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_companies',
            array(
                'label' => 'Companies',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_people',
            array(
                'label' => 'People',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_connected_websites',
            array(
                'label' => 'Connected Websites',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABELS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'labels_section',
            array(
                'label' => 'Labels'
            )
        );


        $this->add_control(
            'total_customers_label',
            array(
                'label' => 'Total Customers Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Total Customers'
            )
        );


        $this->add_control(
            'leads_label',
            array(
                'label' => 'Leads Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Leads'
            )
        );


        $this->add_control(
            'customers_label',
            array(
                'label' => 'Customers Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customers'
            )
        );


        $this->add_control(
            'partners_label',
            array(
                'label' => 'Partners Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Partners'
            )
        );


        $this->add_control(
            'inactive_label',
            array(
                'label' => 'Inactive Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Inactive'
            )
        );


        $this->add_control(
            'companies_label',
            array(
                'label' => 'Companies Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Companies'
            )
        );


        $this->add_control(
            'people_label',
            array(
                'label' => 'People Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'People'
            )
        );


        $this->add_control(
            'connected_websites_label',
            array(
                'label' => 'Connected Websites Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Connected Websites'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                    '7' => '7',
                    '8' => '8'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-statistics-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-statistics-grid' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CARD STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'card_style',
            array(
                'label' => 'Cards',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'card_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-stat-card' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'card_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-stat-card'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'card_shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-stat-card'
            )
        );


        $this->add_responsive_control(
            'card_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-stat-card' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'card_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-stat-card' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * NUMBER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'number_style',
            array(
                'label' => 'Numbers',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'number_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-stat-number' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'number_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-stat-number'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABEL STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Labels',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-stat-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-stat-label'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {
            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * CARD OUTPUT
     * =====================================================
     */

    private function render_card(
        $number,
        $label
    ) {

        echo '<div class="rud-crm-stat-card">';

        echo '<div class="rud-crm-stat-number">';

        echo esc_html(
            number_format_i18n(
                (int) $number
            )
        );

        echo '</div>';


        echo '<div class="rud-crm-stat-label">';

        echo esc_html(
            $label
        );

        echo '</div>';

        echo '</div>';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {
            return;
        }


        global $wpdb;


        $settings =
            $this->get_settings_for_display();


        $customers_table =
            $wpdb->prefix .
            'rudcrm_customers';


        $sites_table =
            $wpdb->prefix .
            'rudcrm_sites';


        /*
         * -------------------------------------------------
         * COUNTS
         * -------------------------------------------------
         */

        $total_customers =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table"
            );


        $leads =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE status = 'lead'"
            );


        $customers =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE status = 'customer'"
            );


        $partners =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE status = 'partner'"
            );


        $inactive =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE status = 'inactive'"
            );


        $companies =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE customer_type = 'company'"
            );


        $people =
            (int)
            $wpdb->get_var(
                "SELECT COUNT(*)
                 FROM $customers_table
                 WHERE customer_type = 'person'"
            );


        /*
         * Connected websites.
         */

        $sites_table_exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW TABLES LIKE %s',
                    $sites_table
                )
            );


        $connected_websites =
            0;


        if (
            $sites_table_exists ===
            $sites_table
        ) {

            $connected_websites =
                (int)
                $wpdb->get_var(
                    "SELECT COUNT(*)
                     FROM $sites_table"
                );
        }


        /*
         * -------------------------------------------------
         * OUTPUT
         * -------------------------------------------------
         */

        echo '<div class="rud-crm-statistics-grid">';


        if (
            'yes' ===
            $settings['show_total_customers']
        ) {

            $this->render_card(
                $total_customers,
                $settings[
                    'total_customers_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_leads']
        ) {

            $this->render_card(
                $leads,
                $settings[
                    'leads_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_customers']
        ) {

            $this->render_card(
                $customers,
                $settings[
                    'customers_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_partners']
        ) {

            $this->render_card(
                $partners,
                $settings[
                    'partners_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_inactive']
        ) {

            $this->render_card(
                $inactive,
                $settings[
                    'inactive_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_companies']
        ) {

            $this->render_card(
                $companies,
                $settings[
                    'companies_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings['show_people']
        ) {

            $this->render_card(
                $people,
                $settings[
                    'people_label'
                ]
            );
        }


        if (
            'yes' ===
            $settings[
                'show_connected_websites'
            ]
        ) {

            $this->render_card(
                $connected_websites,
                $settings[
                    'connected_websites_label'
                ]
            );
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-statistics-grid {
            display:grid;
            grid-template-columns:
                repeat(
                    4,
                    minmax(0,1fr)
                );
            gap:15px;
            width:100%;
        }

        .rud-crm-stat-card {
            display:flex;
            flex-direction:column;
            gap:5px;
            min-width:0;
            padding:20px;
            background:#ffffff;
            border:1px solid #e3e6ea;
            border-radius:10px;
        }

        .rud-crm-stat-number {
            font-size:30px;
            font-weight:700;
            line-height:1.1;
        }

        .rud-crm-stat-label {
            font-size:13px;
            opacity:.7;
        }

        </style>

        <?php
    }
}