<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER TIMELINE / ACTIVITY HISTORY
 * DISPLAY VERSION
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Timeline
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-timeline';
    }


    public function get_title() {

        return 'Customer Timeline';
    }


    public function get_icon() {

        return 'eicon-time-line';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Timeline'
            )
        );


        $this->add_control(
            'show_heading',
            array(
                'label' => 'Show Heading',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'heading',
            array(
                'label' => 'Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customer Activity',
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'empty_message',
            array(
                'label' => 'Empty Message',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'No customer activity has been recorded yet.'
            )
        );


        $this->add_control(
            'items_limit',
            array(
                'label' => 'Maximum Items',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 25,
                'min' => 1,
                'max' => 200
            )
        );


        $this->add_control(
            'show_date',
            array(
                'label' => 'Show Date',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_type',
            array(
                'label' => 'Show Activity Type',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_source',
            array(
                'label' => 'Show Source',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_user',
            array(
                'label' => 'Show Added By',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * FILTER
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'filter_section',
            array(
                'label' => 'Filter'
            )
        );


        $this->add_control(
            'activity_type',
            array(
                'label' => 'Activity Type',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'all',
                'options' => array(
                    'all'        => 'All Activities',
                    'note'       => 'Notes',
                    'call'       => 'Calls',
                    'email'      => 'Emails',
                    'meeting'    => 'Meetings',
                    'task'       => 'Tasks',
                    'consent'    => 'Consent Changes',
                    'website'    => 'Website Activity',
                    'order'      => 'Orders',
                    'system'     => 'System Events',
                    'other'      => 'Other'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'timeline',
                'options' => array(
                    'timeline' => 'Timeline',
                    'cards'    => 'Cards',
                    'simple'   => 'Simple List'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Item Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-list' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * HEADING STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'heading_style',
            array(
                'label' => 'Heading',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'heading_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-heading' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'heading_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-heading'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * ITEM STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'item_style',
            array(
                'label' => 'Activity Items',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'item_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-item' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'item_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-item'
            )
        );


        $this->add_responsive_control(
            'item_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-item' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'item_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-item' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * TITLE STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'title_style',
            array(
                'label' => 'Activity Title',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'title_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-title' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'title_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-title'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * TEXT STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'text_style',
            array(
                'label' => 'Activity Text',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'text_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-content' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'text_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-content'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * META STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'meta_style',
            array(
                'label' => 'Date / Meta Information',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'meta_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-timeline-meta' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'meta_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-timeline-meta'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {
            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * ACTIVITY TABLE
     * =====================================================
     */

    private function activity_table() {

        global $wpdb;


        return
            $wpdb->prefix .
            'rudcrm_customer_activity';
    }


    /*
     * =====================================================
     * TABLE EXISTS
     * =====================================================
     */

    private function table_exists() {

        global $wpdb;


        $table =
            $this->activity_table();


        return
            $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW TABLES LIKE %s',
                    $table
                )
            ) ===
            $table;
    }


    /*
     * =====================================================
     * ACTIVITY TYPE LABEL
     * =====================================================
     */

    private function activity_type_label(
        $type
    ) {

        $labels =
            array(

                'note' =>
                    'Note',

                'call' =>
                    'Call',

                'email' =>
                    'Email',

                'meeting' =>
                    'Meeting',

                'task' =>
                    'Task',

                'consent' =>
                    'Consent',

                'website' =>
                    'Website',

                'order' =>
                    'Order',

                'system' =>
                    'System',

                'other' =>
                    'Other'
            );


        return
            isset(
                $labels[
                    $type
                ]
            )
            ?
            $labels[
                $type
            ]
            :
            ucwords(
                str_replace(
                    array(
                        '_',
                        '-'
                    ),
                    ' ',
                    $type
                )
            );
    }


    /*
     * =====================================================
     * USER NAME
     * =====================================================
     */

    private function user_name(
        $user_id
    ) {

        $user_id =
            absint(
                $user_id
            );


        if (
            ! $user_id
        ) {

            return '';
        }


        $user =
            get_userdata(
                $user_id
            );


        if (
            ! $user
        ) {

            return '';
        }


        return
            $user->display_name;
    }


    /*
     * =====================================================
     * DATE FORMAT
     * =====================================================
     */

    private function format_date(
        $date
    ) {

        $timestamp =
            strtotime(
                $date
            );


        if (
            ! $timestamp
        ) {

            return $date;
        }


        return
            date_i18n(
                get_option(
                    'date_format'
                ) .
                ' ' .
                get_option(
                    'time_format'
                ),
                $timestamp
            );
    }


    /*
     * =====================================================
     * GET ACTIVITIES
     * =====================================================
     */

    private function get_activities(
        $customer_id,
        $activity_type,
        $limit
    ) {

        global $wpdb;


        $table =
            $this->activity_table();


        if (
            'all' ===
            $activity_type
        ) {

            return
                $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT *
                         FROM {$table}
                         WHERE customer_id = %d
                         ORDER BY activity_date DESC, id DESC
                         LIMIT %d",
                        $customer_id,
                        $limit
                    )
                );
        }


        return
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$table}
                     WHERE customer_id = %d
                     AND activity_type = %s
                     ORDER BY activity_date DESC, id DESC
                     LIMIT %d",
                    $customer_id,
                    $activity_type,
                    $limit
                )
            );
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        $limit =
            max(
                1,
                min(
                    200,
                    absint(
                        $settings['items_limit']
                    )
                )
            );


        $layout =
            isset(
                $settings['layout']
            )
            ? sanitize_html_class(
                $settings['layout']
            )
            : 'timeline';


        echo '<div class="rud-crm-timeline-wrapper rud-crm-timeline-layout-' .
            esc_attr(
                $layout
            ) .
            '">';


        /*
         * HEADING
         */

        if (
            'yes' ===
            $settings['show_heading']
        ) {

            echo '<h3 class="rud-crm-timeline-heading">';

            echo esc_html(
                $settings['heading']
            );

            echo '</h3>';
        }


        /*
         * TABLE DOES NOT EXIST YET
         */

        if (
            ! $this->table_exists()
        ) {

            echo '<div class="rud-crm-timeline-empty">';

            echo esc_html(
                $settings['empty_message']
            );

            echo '</div>';

            echo '</div>';

            return;
        }


        /*
         * GET ACTIVITIES
         */

        $activity_type =
            sanitize_key(
                $settings['activity_type']
            );


        $activities =
            $this->get_activities(
                $customer_id,
                $activity_type,
                $limit
            );


        if (
            empty(
                $activities
            )
        ) {

            echo '<div class="rud-crm-timeline-empty">';

            echo esc_html(
                $settings['empty_message']
            );

            echo '</div>';

            echo '</div>';

            return;
        }


        echo '<div class="rud-crm-timeline-list">';


        foreach (
            $activities as
            $activity
        ) {

            echo '<div class="rud-crm-timeline-item">';


            /*
             * MARKER
             */

            if (
                'timeline' ===
                $layout
            ) {

                echo '<div class="rud-crm-timeline-marker"></div>';
            }


            echo '<div class="rud-crm-timeline-item-content">';


            /*
             * TITLE
             */

            if (
                ! empty(
                    $activity->title
                )
            ) {

                echo '<div class="rud-crm-timeline-title">';

                echo esc_html(
                    $activity->title
                );

                echo '</div>';
            }


            /*
             * META
             */

            echo '<div class="rud-crm-timeline-meta">';


            $meta =
                array();


            if (
                'yes' ===
                $settings['show_date']
                &&
                ! empty(
                    $activity->activity_date
                )
            ) {

                $meta[] =
                    $this->format_date(
                        $activity->activity_date
                    );
            }


            if (
                'yes' ===
                $settings['show_type']
                &&
                ! empty(
                    $activity->activity_type
                )
            ) {

                $meta[] =
                    $this->activity_type_label(
                        $activity->activity_type
                    );
            }


            if (
                'yes' ===
                $settings['show_source']
                &&
                ! empty(
                    $activity->source
                )
            ) {

                $meta[] =
                    'Source: ' .
                    $activity->source;
            }


            if (
                'yes' ===
                $settings['show_user']
                &&
                ! empty(
                    $activity->created_by
                )
            ) {

                $user_name =
                    $this->user_name(
                        $activity->created_by
                    );


                if (
                    '' !==
                    $user_name
                ) {

                    $meta[] =
                        'Added by ' .
                        $user_name;
                }
            }


            echo esc_html(
                implode(
                    ' · ',
                    $meta
                )
            );


            echo '</div>';


            /*
             * CONTENT
             */

            if (
                ! empty(
                    $activity->content
                )
            ) {

                echo '<div class="rud-crm-timeline-content">';

                echo wp_kses_post(
                    wpautop(
                        $activity->content
                    )
                );

                echo '</div>';
            }


            echo '</div>';

            echo '</div>';
        }


        echo '</div>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-timeline-wrapper {
            width:100%;
        }

        .rud-crm-timeline-heading {
            margin-top:0;
            margin-bottom:20px;
        }

        .rud-crm-timeline-list {
            display:flex;
            flex-direction:column;
            gap:14px;
        }

        .rud-crm-timeline-item {
            position:relative;
            display:flex;
            gap:14px;
            padding:15px;
        }

        .rud-crm-timeline-layout-timeline
        .rud-crm-timeline-item {
            padding-left:32px;
        }

        .rud-crm-timeline-layout-timeline
        .rud-crm-timeline-item::before {
            content:"";
            position:absolute;
            left:10px;
            top:0;
            bottom:-14px;
            width:2px;
            background:#e0e4e8;
        }

        .rud-crm-timeline-layout-timeline
        .rud-crm-timeline-item:last-child::before {
            bottom:50%;
        }

        .rud-crm-timeline-marker {
            position:absolute;
            left:4px;
            top:21px;
            width:14px;
            height:14px;
            border-radius:50%;
            background:#777;
            border:3px solid #fff;
            box-sizing:border-box;
            z-index:2;
        }

        .rud-crm-timeline-item-content {
            min-width:0;
            width:100%;
        }

        .rud-crm-timeline-title {
            font-weight:700;
            margin-bottom:4px;
        }

        .rud-crm-timeline-meta {
            font-size:11px;
            opacity:.65;
            margin-bottom:6px;
        }

        .rud-crm-timeline-content {
            overflow-wrap:anywhere;
        }

        .rud-crm-timeline-content p:last-child {
            margin-bottom:0;
        }

        .rud-crm-timeline-layout-cards
        .rud-crm-timeline-item {
            border:1px solid #e2e6ea;
            border-radius:8px;
            background:#fff;
        }

        .rud-crm-timeline-layout-simple
        .rud-crm-timeline-item {
            padding:8px 0;
            border-bottom:1px solid #e5e5e5;
        }

        .rud-crm-timeline-empty {
            opacity:.7;
        }

        </style>

        <?php
    }
}