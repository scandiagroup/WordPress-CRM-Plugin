<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER HEADER / PROFILE SUMMARY
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Header
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-header';
    }


    public function get_title() {

        return 'Customer Header';
    }


    public function get_icon() {

        return 'eicon-user-circle-o';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Header'
            )
        );


        $this->add_control(
            'show_image',
            array(
                'label' => 'Show Customer Image',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' => 'Show Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' => 'Show Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' => 'Show Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_phone',
            array(
                'label' => 'Show Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_email',
            array(
                'label' => 'Show Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_actions',
            array(
                'label' => 'Show Quick Actions',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABELS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'labels_section',
            array(
                'label' => 'Labels'
            )
        );


        $this->add_control(
            'customer_number_label',
            array(
                'label' => 'Customer Number Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customer Number'
            )
        );


        $this->add_control(
            'phone_label',
            array(
                'label' => 'Phone Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Phone'
            )
        );


        $this->add_control(
            'email_label',
            array(
                'label' => 'Email Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Email'
            )
        );


        $this->add_control(
            'edit_text',
            array(
                'label' => 'Edit Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Edit Customer'
            )
        );


        $this->add_control(
            'email_button_text',
            array(
                'label' => 'Email Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Email'
            )
        );


        $this->add_control(
            'call_button_text',
            array(
                'label' => 'Call Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Call'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'horizontal',
                'options' => array(
                    'horizontal' => 'Horizontal',
                    'vertical'   => 'Vertical'
                )
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'flex-start' => array(
                        'title' => 'Left',
                        'icon' => 'eicon-h-align-left'
                    ),
                    'center' => array(
                        'title' => 'Center',
                        'icon' => 'eicon-h-align-center'
                    ),
                    'flex-end' => array(
                        'title' => 'Right',
                        'icon' => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header' =>
                        'align-items:{{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-header'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-header'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * IMAGE STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'image_style',
            array(
                'label' => 'Customer Image',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_image' => 'yes'
                )
            )
        );


        $this->add_responsive_control(
            'image_size',
            array(
                'label' => 'Image Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 40,
                        'max' => 400
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-image' =>
                        'width:{{SIZE}}{{UNIT}};height:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'image_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-image' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * NAME STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'name_style',
            array(
                'label' => 'Customer Name',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'name_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-name' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'name_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-header-name'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * META STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'meta_style',
            array(
                'label' => 'Information',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'meta_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-meta' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'meta_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-header-meta'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * STATUS STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'status_style',
            array(
                'label' => 'Status',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_status' => 'yes'
                )
            )
        );


        $this->add_control(
            'status_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-status' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'status_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-status' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * BUTTON STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' => 'Action Buttons',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_actions' => 'yes'
                )
            )
        );


        $this->add_control(
            'button_text_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-button' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-button' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'button_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-header-button'
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-header-button' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {
            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * GET CUSTOMER
     * =====================================================
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {

            return null;
        }


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * =====================================================
     * CUSTOMER NAME
     * =====================================================
     */

    private function customer_name(
        $customer
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if (
            '' ===
            $name
        ) {

            $name =
                ! empty(
                    $customer->company_name
                )
                ? $customer->company_name
                : 'Unnamed Customer';
        }


        return $name;
    }


    /*
     * =====================================================
     * GET CONTACT
     * =====================================================
     */

    private function get_contact(
        $customer_id,
        $types
    ) {

        global $wpdb;


        foreach (
            $types as
            $type
        ) {

            $value =
                (string)
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT contact_value
                         FROM {$wpdb->prefix}rudcrm_contact_methods
                         WHERE customer_id = %d
                         AND contact_type = %s
                         ORDER BY is_primary DESC, id ASC
                         LIMIT 1",
                        $customer_id,
                        $type
                    )
                );


            $value =
                trim(
                    $value
                );


            if (
                '' !==
                $value
            ) {

                return $value;
            }
        }


        return '';
    }


    /*
     * =====================================================
     * PRIMARY IMAGE
     * =====================================================
     */

    private function get_primary_image(
        $customer_id
    ) {

        global $wpdb;


        $attachment_id =
            (int)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT attachment_id
                     FROM {$wpdb->prefix}rudcrm_customer_images
                     WHERE customer_id = %d
                     ORDER BY is_primary DESC, sort_order ASC, id ASC
                     LIMIT 1",
                    $customer_id
                )
            );


        if (
            ! $attachment_id
        ) {

            return '';
        }


        $url =
            wp_get_attachment_image_url(
                $attachment_id,
                'medium'
            );


        return
            $url
            ? $url
            : '';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {
            return;
        }


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        $customer_id =
            (int)
            $customer->id;


        $name =
            $this->customer_name(
                $customer
            );


        $phone =
            $this->get_contact(
                $customer_id,
                array(
                    'mobile_phone',
                    'office_phone',
                    'home_phone'
                )
            );


        $email =
            $this->get_contact(
                $customer_id,
                array(
                    'private_email',
                    'work_email'
                )
            );


        $image =
            $this->get_primary_image(
                $customer_id
            );


        $layout_class =
            (
                'vertical' ===
                $settings['layout']
            )
            ? 'rud-crm-customer-header-vertical'
            : 'rud-crm-customer-header-horizontal';


        echo '<div class="rud-crm-customer-header ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        /*
         * IMAGE
         */

        if (
            'yes' ===
            $settings['show_image']
        ) {

            echo '<div class="rud-crm-customer-header-image-wrap">';


            if (
                '' !==
                $image
            ) {

                echo '<img
                    class="rud-crm-customer-header-image"
                    src="' .
                    esc_url(
                        $image
                    ) .
                    '"
                    alt="' .
                    esc_attr(
                        $name
                    ) .
                    '"
                >';

            } else {

                echo '<div class="rud-crm-customer-header-image rud-crm-customer-header-placeholder">';

                echo esc_html(
                    strtoupper(
                        substr(
                            $name,
                            0,
                            1
                        )
                    )
                );

                echo '</div>';
            }


            echo '</div>';
        }


        /*
         * MAIN CONTENT
         */

        echo '<div class="rud-crm-customer-header-content">';


        echo '<div class="rud-crm-customer-header-top">';


        echo '<h2 class="rud-crm-customer-header-name">';

        echo esc_html(
            $name
        );

        echo '</h2>';


        if (
            'yes' ===
            $settings['show_status']
            &&
            ! empty(
                $customer->status
            )
        ) {

            echo '<span class="rud-crm-customer-header-status">';

            echo esc_html(
                ucwords(
                    str_replace(
                        array(
                            '_',
                            '-'
                        ),
                        ' ',
                        $customer->status
                    )
                )
            );

            echo '</span>';
        }


        echo '</div>';


        /*
         * CUSTOMER NUMBER
         */

        if (
            'yes' ===
            $settings['show_customer_number']
            &&
            ! empty(
                $customer->customer_number
            )
        ) {

            echo '<div class="rud-crm-customer-header-meta">';

            echo '<strong>';

            echo esc_html(
                $settings['customer_number_label']
            );

            echo ':</strong> ';

            echo esc_html(
                $customer->customer_number
            );

            echo '</div>';
        }


        /*
         * COMPANY
         */

        if (
            'yes' ===
            $settings['show_company']
            &&
            ! empty(
                $customer->company_name
            )
        ) {

            echo '<div class="rud-crm-customer-header-company">';

            echo esc_html(
                $customer->company_name
            );

            echo '</div>';
        }


        /*
         * CONTACT DETAILS
         */

        echo '<div class="rud-crm-customer-header-contact">';


        if (
            'yes' ===
            $settings['show_phone']
            &&
            '' !==
            $phone
        ) {

            echo '<div class="rud-crm-customer-header-meta">';

            echo '<strong>';

            echo esc_html(
                $settings['phone_label']
            );

            echo ':</strong> ';

            echo '<a href="tel:' .
                esc_attr(
                    preg_replace(
                        '/[^0-9+]/',
                        '',
                        $phone
                    )
                ) .
                '">';

            echo esc_html(
                $phone
            );

            echo '</a>';

            echo '</div>';
        }


        if (
            'yes' ===
            $settings['show_email']
            &&
            '' !==
            $email
        ) {

            echo '<div class="rud-crm-customer-header-meta">';

            echo '<strong>';

            echo esc_html(
                $settings['email_label']
            );

            echo ':</strong> ';

            echo '<a href="mailto:' .
                esc_attr(
                    sanitize_email(
                        $email
                    )
                ) .
                '">';

            echo esc_html(
                $email
            );

            echo '</a>';

            echo '</div>';
        }


        echo '</div>';


        /*
         * ACTIONS
         */

        if (
            'yes' ===
            $settings['show_actions']
        ) {

            echo '<div class="rud-crm-customer-header-actions">';


            if (
                '' !==
                $email
            ) {

                echo '<a
                    class="rud-crm-customer-header-button"
                    href="mailto:' .
                    esc_attr(
                        sanitize_email(
                            $email
                        )
                    ) .
                    '"
                >';

                echo esc_html(
                    $settings['email_button_text']
                );

                echo '</a>';
            }


            if (
                '' !==
                $phone
            ) {

                echo '<a
                    class="rud-crm-customer-header-button"
                    href="tel:' .
                    esc_attr(
                        preg_replace(
                            '/[^0-9+]/',
                            '',
                            $phone
                        )
                    ) .
                    '"
                >';

                echo esc_html(
                    $settings['call_button_text']
                );

                echo '</a>';
            }


            if (
                current_user_can(
                    'manage_options'
                )
                ||
                (
                    function_exists(
                        'rud_crm_user_can_edit'
                    )
                    &&
                    rud_crm_user_can_edit()
                )
            ) {

                $edit_url =
                    admin_url(
                        'admin.php?page=rud-crm-customers&action=edit&customer_id=' .
                        $customer_id
                    );


                echo '<a
                    class="rud-crm-customer-header-button"
                    href="' .
                    esc_url(
                        $edit_url
                    ) .
                    '"
                >';

                echo esc_html(
                    $settings['edit_text']
                );

                echo '</a>';
            }


            echo '</div>';
        }


        echo '</div>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-customer-header {
            display:flex;
            width:100%;
            gap:24px;
            padding:24px;
            background:#fff;
            border:1px solid #e3e6ea;
            border-radius:12px;
        }

        .rud-crm-customer-header-horizontal {
            flex-direction:row;
            align-items:center;
        }

        .rud-crm-customer-header-vertical {
            flex-direction:column;
            align-items:flex-start;
        }

        .rud-crm-customer-header-image-wrap {
            flex:0 0 auto;
        }

        .rud-crm-customer-header-image {
            width:120px;
            height:120px;
            display:block;
            object-fit:cover;
            border-radius:50%;
        }

        .rud-crm-customer-header-placeholder {
            display:flex;
            align-items:center;
            justify-content:center;
            background:#eef1f4;
            font-size:40px;
            font-weight:700;
        }

        .rud-crm-customer-header-content {
            flex:1 1 auto;
            min-width:0;
        }

        .rud-crm-customer-header-top {
            display:flex;
            align-items:center;
            flex-wrap:wrap;
            gap:10px;
        }

        .rud-crm-customer-header-name {
            margin:0;
        }

        .rud-crm-customer-header-status {
            display:inline-flex;
            align-items:center;
            padding:4px 9px;
            border-radius:999px;
            background:#f0f2f5;
            font-size:12px;
            font-weight:600;
        }

        .rud-crm-customer-header-company {
            margin-top:4px;
            font-weight:600;
        }

        .rud-crm-customer-header-meta {
            margin-top:4px;
        }

        .rud-crm-customer-header-meta a {
            color:inherit;
        }

        .rud-crm-customer-header-contact {
            margin-top:10px;
        }

        .rud-crm-customer-header-actions {
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            margin-top:16px;
        }

        .rud-crm-customer-header-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            padding:8px 14px;
            text-decoration:none;
            background:#f1f3f5;
            color:#222;
            border-radius:6px;
        }

        .rud-crm-customer-header-button:hover {
            text-decoration:none;
        }

        @media (max-width:767px) {

            .rud-crm-customer-header-horizontal {
                flex-direction:column;
                align-items:flex-start;
            }
        }

        </style>

        <?php
    }
}