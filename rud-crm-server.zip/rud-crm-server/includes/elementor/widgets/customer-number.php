<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER NUMBER WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Number
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-number';
    }


    public function get_title() {

        return 'Customer Number';
    }


    public function get_icon() {

        return 'eicon-number-field';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Number'
            )
        );


        $this->add_control(
            'show_label',
            array(
                'label' => 'Show Label',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'label_text',
            array(
                'label' => 'Label Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customer Number',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'separator',
            array(
                'label' => 'Separator',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ':',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => array(
                    'inline'  => 'Inline',
                    'stacked' => 'Stacked'
                )
            )
        );


        $this->add_control(
            'html_tag',
            array(
                'label' => 'HTML Tag',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'div',
                'options' => array(
                    'div'  => 'DIV',
                    'p'    => 'P',
                    'span' => 'SPAN',
                    'h2'   => 'H2',
                    'h3'   => 'H3',
                    'h4'   => 'H4',
                    'h5'   => 'H5',
                    'h6'   => 'H6'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper' =>
                        'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper' =>
                        'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper' =>
                        'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'flex-start' => array(
                        'title' => 'Left',
                        'icon'  => 'eicon-h-align-left'
                    ),
                    'center' => array(
                        'title' => 'Center',
                        'icon'  => 'eicon-h-align-center'
                    ),
                    'flex-end' => array(
                        'title' => 'Right',
                        'icon'  => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-wrapper' =>
                        'align-items: {{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABEL STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Label',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-label' =>
                        'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-number-label'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * NUMBER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'number_style',
            array(
                'label' => 'Number',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'number_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-number-value' =>
                        'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'number_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-number-value'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * ELEMENTOR EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * GET CURRENT CUSTOMER
     * =====================================================
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        /*
         * Elementor preview:
         * use the first CRM customer.
         */

        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {

            return null;
        }


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        /*
         * SECURITY
         */

        if (
            ! $this->is_editor()
        ) {

            if (
                function_exists(
                    'rud_crm_user_can_view'
                )
            ) {

                if (
                    ! rud_crm_user_can_view()
                ) {

                    return;
                }

            } elseif (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            ) {

                return;
            }
        }


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>';
                echo 'No CRM customer available for preview.';
                echo '</div>';
            }

            return;
        }


        $customer_number =
            isset(
                $customer->customer_number
            )
            ? trim(
                (string)
                $customer->customer_number
            )
            : '';


        if (
            '' ===
            $customer_number
        ) {

            if (
                $this->is_editor()
            ) {

                $customer_number =
                    'No customer number';

            } else {

                return;
            }
        }


        $settings =
            $this->get_settings_for_display();


        $allowed_tags =
            array(
                'div',
                'p',
                'span',
                'h2',
                'h3',
                'h4',
                'h5',
                'h6'
            );


        $tag =
            in_array(
                $settings['html_tag'],
                $allowed_tags,
                true
            )
            ? $settings['html_tag']
            : 'div';


        $layout_class =
            (
                'stacked' ===
                $settings['layout']
            )
            ? 'rud-crm-number-stacked'
            : 'rud-crm-number-inline';


        echo '<' .
            esc_attr(
                $tag
            ) .
            ' class="rud-crm-customer-number-wrapper ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_label']
        ) {

            echo '<span class="rud-crm-customer-number-label">';

            echo esc_html(
                $settings['label_text']
            );


            if (
                '' !==
                trim(
                    (string)
                    $settings['separator']
                )
            ) {

                echo esc_html(
                    $settings['separator']
                );
            }


            echo '</span>';
        }


        echo '<span class="rud-crm-customer-number-value">';

        echo esc_html(
            $customer_number
        );

        echo '</span>';


        echo '</' .
            esc_attr(
                $tag
            ) .
            '>';


        ?>

        <style>

        .rud-crm-customer-number-wrapper {
            display:flex;
            gap:6px;
            width:100%;
        }

        .rud-crm-number-inline {
            flex-direction:row;
            align-items:baseline;
        }

        .rud-crm-number-stacked {
            flex-direction:column;
        }

        .rud-crm-customer-number-label {
            font-weight:600;
        }

        .rud-crm-customer-number-value {
            overflow-wrap:anywhere;
        }

        </style>

        <?php
    }
}