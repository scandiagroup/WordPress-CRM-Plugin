<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM
 * ELEMENTOR WIDGET: CUSTOMER CONTACT INFORMATION
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Contact
    extends \Elementor\Widget_Base {


    /*
     * -----------------------------------------------------
     * WIDGET INFORMATION
     * -----------------------------------------------------
     */

    public function get_name() {
        return 'rud-crm-customer-contact';
    }


    public function get_title() {
        return 'Contact Information';
    }


    public function get_icon() {
        return 'eicon-mail';
    }


    public function get_categories() {
        return array(
            'rud-crm'
        );
    }


    /*
     * -----------------------------------------------------
     * ELEMENTOR CONTROLS
     * -----------------------------------------------------
     */

    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Contact Information'
            )
        );


        $this->add_control(
            'show_mobile',
            array(
                'label' => 'Mobile Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_home_phone',
            array(
                'label' => 'Home Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_office_phone',
            array(
                'label' => 'Office Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_whatsapp',
            array(
                'label' => 'WhatsApp',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_private_email',
            array(
                'label' => 'Private Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_work_email',
            array(
                'label' => 'Work Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_labels',
            array(
                'label' => 'Show Labels',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'rows',
                'options' => array(
                    'rows'   => 'Rows',
                    'inline' => 'Inline',
                    'grid'   => 'Grid'
                )
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,

                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',

                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3'
                ),

                'condition' => array(
                    'layout' => 'grid'
                ),

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-grid' =>

                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',

                'type' =>
                    \Elementor\Controls_Manager::SLIDER,

                'range' => array(

                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-wrapper' =>

                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * CONTAINER STYLE
         * =================================================
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-wrapper' =>

                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(

                'name' =>
                    'border',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-contact-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(

                'name' =>
                    'shadow',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-contact-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>
                    array(
                        'px',
                        'em'
                    ),

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-wrapper' =>

                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>
                    array(
                        'px',
                        '%'
                    ),

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-wrapper' =>

                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LABEL STYLE
         * =================================================
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Labels',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE,

                'condition' => array(
                    'show_labels' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-label' =>

                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(

                'name' =>
                    'label_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-contact-label'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * VALUE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'value_style',
            array(
                'label' => 'Values',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'value_color',
            array(
                'label' => 'Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' => array(

                    '{{WRAPPER}} .rud-crm-contact-value' =>

                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(

                'name' =>
                    'value_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-contact-value'
            )
        );


        $this->end_controls_section();
    }


    /*
     * -----------------------------------------------------
     * CHECK IF ELEMENTOR EDITOR
     * -----------------------------------------------------
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * -----------------------------------------------------
     * GET CUSTOMER ID
     * -----------------------------------------------------
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ?
            absint(
                $_GET['rud_customer_id']
            )
            :
            0;


        /*
         * Elementor preview:
         * use first customer in database.
         */

        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(

                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * -----------------------------------------------------
     * GET CONTACT VALUE
     * -----------------------------------------------------
     */

    private function get_contact(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(

                $wpdb->prepare(

                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",

                    $customer_id,
                    $type
                )
            );
    }


    /*
     * -----------------------------------------------------
     * OUTPUT ONE CONTACT ITEM
     * -----------------------------------------------------
     */

    private function contact_item(
        $label,
        $value,
        $show_labels,
        $link_type = ''
    ) {

        if (
            '' ===
            trim(
                (string) $value
            )
        ) {
            return;
        }


        echo '<div class="rud-crm-contact-item">';


        if (
            'yes' ===
            $show_labels
        ) {

            echo '<div class="rud-crm-contact-label">';

            echo esc_html(
                $label
            );

            echo '</div>';
        }


        echo '<div class="rud-crm-contact-value">';


        /*
         * EMAIL LINK
         */

        if (
            'email' ===
            $link_type
        ) {

            echo '<a href="mailto:' .
                esc_attr(
                    $value
                ) .
                '">';

            echo esc_html(
                $value
            );

            echo '</a>';
        }


        /*
         * PHONE LINK
         */

        elseif (
            'phone' ===
            $link_type
        ) {

            $phone_link =
                preg_replace(
                    '/[^0-9+]/',
                    '',
                    $value
                );


            echo '<a href="tel:' .
                esc_attr(
                    $phone_link
                ) .
                '">';

            echo esc_html(
                $value
            );

            echo '</a>';
        }


        /*
         * NORMAL VALUE
         */

        else {

            echo esc_html(
                $value
            );
        }


        echo '</div>';

        echo '</div>';
    }


    /*
     * -----------------------------------------------------
     * RENDER
     * -----------------------------------------------------
     */

    protected function render() {


        /*
         * SECURITY
         */

        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {

            echo '<div>CRM access restricted.</div>';

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No customer available for preview.</div>';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        /*
         * GET DATA
         */

        $mobile =
            $this->get_contact(
                $customer_id,
                'mobile_phone'
            );


        $home =
            $this->get_contact(
                $customer_id,
                'home_phone'
            );


        $office =
            $this->get_contact(
                $customer_id,
                'office_phone'
            );


        $whatsapp =
            $this->get_contact(
                $customer_id,
                'whatsapp'
            );


        $private_email =
            $this->get_contact(
                $customer_id,
                'private_email'
            );


        $work_email =
            $this->get_contact(
                $customer_id,
                'work_email'
            );


        /*
         * LAYOUT CLASS
         */

        $layout_class =
            'rud-crm-contact-' .
            sanitize_html_class(
                $settings['layout']
            );


        /*
         * OUTPUT
         */

        echo '<div class="rud-crm-contact-wrapper ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_mobile']
        ) {

            $this->contact_item(
                'Mobile Phone',
                $mobile,
                $settings['show_labels'],
                'phone'
            );
        }


        if (
            'yes' ===
            $settings['show_home_phone']
        ) {

            $this->contact_item(
                'Home Phone',
                $home,
                $settings['show_labels'],
                'phone'
            );
        }


        if (
            'yes' ===
            $settings['show_office_phone']
        ) {

            $this->contact_item(
                'Office Phone',
                $office,
                $settings['show_labels'],
                'phone'
            );
        }


        if (
            'yes' ===
            $settings['show_whatsapp']
        ) {

            $this->contact_item(
                'WhatsApp',
                $whatsapp,
                $settings['show_labels'],
                'phone'
            );
        }


        if (
            'yes' ===
            $settings['show_private_email']
        ) {

            $this->contact_item(
                'Private Email',
                $private_email,
                $settings['show_labels'],
                'email'
            );
        }


        if (
            'yes' ===
            $settings['show_work_email']
        ) {

            $this->contact_item(
                'Work Email',
                $work_email,
                $settings['show_labels'],
                'email'
            );
        }


        echo '</div>';


        /*
         * BASIC LAYOUT CSS
         */

        ?>

        <style>

        .rud-crm-contact-wrapper {
            display:flex;
            flex-direction:column;
            gap:10px;
        }


        .rud-crm-contact-inline {
            flex-direction:row;
            flex-wrap:wrap;
        }


        .rud-crm-contact-grid {
            display:grid;
            grid-template-columns:
                repeat(
                    2,
                    minmax(0,1fr)
                );
        }


        .rud-crm-contact-item {
            min-width:0;
        }


        .rud-crm-contact-label {
            font-size:12px;
            opacity:.65;
            margin-bottom:2px;
        }


        .rud-crm-contact-value {
            overflow-wrap:anywhere;
        }


        .rud-crm-contact-value a {
            color:inherit;
            text-decoration:inherit;
        }

        </style>

        <?php
    }
}