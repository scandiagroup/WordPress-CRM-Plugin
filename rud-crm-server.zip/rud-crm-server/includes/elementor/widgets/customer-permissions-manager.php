<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER PERMISSIONS MANAGER
 * EDITABLE ADMIN / CRM STAFF VERSION
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Permissions_Manager
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-permissions-manager';
    }


    public function get_title() {

        return 'Customer Permissions Manager';
    }


    public function get_icon() {

        return 'eicon-lock-user';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Permissions Manager'
            )
        );


        $this->add_control(
            'show_heading',
            array(
                'label' => 'Show Heading',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'heading',
            array(
                'label' => 'Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customer Permissions',
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'allow_all_text',
            array(
                'label' => 'Allow All Button',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Allow All'
            )
        );


        $this->add_control(
            'deny_all_text',
            array(
                'label' => 'Deny All Button',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Deny All'
            )
        );


        $this->add_control(
            'save_text',
            array(
                'label' => 'Save Button',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Save Changes'
            )
        );


        $this->add_control(
            'source_label',
            array(
                'label' => 'Source Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Consent Source'
            )
        );


        $this->add_control(
            'notes_label',
            array(
                'label' => 'Notes Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Notes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager-grid' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-manager'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-manager'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * HEADING STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'heading_style',
            array(
                'label' => 'Heading',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'heading_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager-heading' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'heading_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-manager-heading'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * ITEM STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'item_style',
            array(
                'label' => 'Permission Items',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'item_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-manager-item' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'item_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permission-manager-item'
            )
        );


        $this->add_responsive_control(
            'item_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-manager-item' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * BUTTON STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' => 'Buttons',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'button_text_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager button' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager button' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'button_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-manager button'
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-manager button' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * EDIT ACCESS
     * =====================================================
     */

    private function can_edit() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            current_user_can(
                'manage_options'
            )
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_edit'
            )
        ) {

            return rud_crm_user_can_edit();
        }


        return false;
    }


    /*
     * =====================================================
     * CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * SAVE FORM
     * =====================================================
     */

    private function handle_save(
        $customer_id
    ) {

        if (
            ! isset(
                $_POST['rud_crm_permissions_manager_action']
            )
        ) {

            return '';
        }


        if (
            ! isset(
                $_POST['rud_crm_permissions_nonce']
            )
            ||
            ! wp_verify_nonce(
                sanitize_text_field(
                    wp_unslash(
                        $_POST['rud_crm_permissions_nonce']
                    )
                ),
                'rud_crm_save_customer_permissions_' .
                $customer_id
            )
        ) {

            return 'Security check failed.';
        }


        if (
            ! $this->can_edit()
        ) {

            return 'You are not allowed to edit customer permissions.';
        }


        $definitions =
            function_exists(
                'rud_crm_customer_permission_definitions'
            )
            ?
            rud_crm_customer_permission_definitions()
            :
            array();


        if (
            empty(
                $definitions
            )
        ) {

            return 'Customer permission definitions are unavailable.';
        }


        $action =
            sanitize_key(
                wp_unslash(
                    $_POST['rud_crm_permissions_manager_action']
                )
            );


        $source =
            isset(
                $_POST['rud_crm_permission_source']
            )
            ?
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_permission_source']
                )
            )
            :
            'CRM';


        $notes =
            isset(
                $_POST['rud_crm_permission_notes']
            )
            ?
            sanitize_textarea_field(
                wp_unslash(
                    $_POST['rud_crm_permission_notes']
                )
            )
            :
            '';


        /*
         * ALLOW ALL
         */

        if (
            'allow_all' ===
            $action
        ) {

            if (
                function_exists(
                    'rud_crm_allow_all_customer_permissions'
                )
            ) {

                rud_crm_allow_all_customer_permissions(
                    $customer_id,
                    $source
                );
            }


            return 'All customer permissions were allowed.';
        }


        /*
         * DENY ALL
         */

        if (
            'deny_all' ===
            $action
        ) {

            if (
                function_exists(
                    'rud_crm_deny_all_customer_permissions'
                )
            ) {

                rud_crm_deny_all_customer_permissions(
                    $customer_id,
                    $source
                );
            }


            return 'All customer permissions were denied.';
        }


        /*
         * SAVE INDIVIDUAL VALUES
         */

        if (
            'save' ===
            $action
        ) {

            $submitted =
                isset(
                    $_POST['rud_crm_permission']
                )
                &&
                is_array(
                    $_POST['rud_crm_permission']
                )
                ?
                wp_unslash(
                    $_POST['rud_crm_permission']
                )
                :
                array();


            foreach (
                $definitions as
                $permission_key =>
                $label
            ) {

                $allowed =
                    isset(
                        $submitted[
                            $permission_key
                        ]
                    )
                    ?
                    true
                    :
                    false;


                if (
                    function_exists(
                        'rud_crm_set_customer_permission'
                    )
                ) {

                    rud_crm_set_customer_permission(
                        $customer_id,
                        $permission_key,
                        $allowed,
                        $source,
                        $notes
                    );
                }
            }


            return 'Customer permissions were saved.';
        }


        return '';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_edit()
        ) {

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        $message =
            $this->handle_save(
                $customer_id
            );


        $definitions =
            function_exists(
                'rud_crm_customer_permission_definitions'
            )
            ?
            rud_crm_customer_permission_definitions()
            :
            array();


        $permissions =
            function_exists(
                'rud_crm_get_customer_permissions'
            )
            ?
            rud_crm_get_customer_permissions(
                $customer_id
            )
            :
            array();


        if (
            empty(
                $definitions
            )
        ) {

            echo '<div>Customer permission definitions are unavailable.</div>';

            return;
        }


        /*
         * -------------------------------------------------
         * DEFAULT SOURCE / NOTES
         * -------------------------------------------------
         */

        $default_source =
            'CRM';


        $default_notes =
            '';


        foreach (
            $permissions as
            $permission_data
        ) {

            if (
                ! empty(
                    $permission_data['source']
                )
            ) {

                $default_source =
                    $permission_data['source'];

                break;
            }
        }


        foreach (
            $permissions as
            $permission_data
        ) {

            if (
                ! empty(
                    $permission_data['notes']
                )
            ) {

                $default_notes =
                    $permission_data['notes'];

                break;
            }
        }


        echo '<div class="rud-crm-permissions-manager">';


        /*
         * HEADING
         */

        if (
            'yes' ===
            $settings['show_heading']
        ) {

            echo '<h3 class="rud-crm-permissions-manager-heading">';

            echo esc_html(
                $settings['heading']
            );

            echo '</h3>';
        }


        /*
         * MESSAGE
         */

        if (
            '' !==
            $message
        ) {

            echo '<div class="rud-crm-permissions-manager-message">';

            echo esc_html(
                $message
            );

            echo '</div>';
        }


        /*
         * FORM
         */

        echo '<form method="post" class="rud-crm-permissions-manager-form">';


        wp_nonce_field(
            'rud_crm_save_customer_permissions_' .
            $customer_id,
            'rud_crm_permissions_nonce'
        );


        /*
         * PERMISSIONS
         */

        echo '<div class="rud-crm-permissions-manager-grid">';


        foreach (
            $definitions as
            $permission_key =>
            $label
        ) {

            $allowed =
                isset(
                    $permissions[
                        $permission_key
                    ]
                )
                &&
                ! empty(
                    $permissions[
                        $permission_key
                    ]['value']
                );


            echo '<label class="rud-crm-permission-manager-item">';


            echo '<span class="rud-crm-permission-manager-name">';

            echo esc_html(
                $label
            );

            echo '</span>';


            echo '<input
                type="checkbox"
                name="rud_crm_permission[' .
                esc_attr(
                    $permission_key
                ) .
                ']"
                value="1"';


            checked(
                $allowed,
                true
            );


            echo '>';


            echo '</label>';
        }


        echo '</div>';


        /*
         * SOURCE
         */

        echo '<div class="rud-crm-permissions-manager-field">';


        echo '<label>';

        echo esc_html(
            $settings['source_label']
        );

        echo '</label>';


        echo '<input
            type="text"
            name="rud_crm_permission_source"
            value="' .
            esc_attr(
                $default_source
            ) .
            '"
        >';


        echo '</div>';


        /*
         * NOTES
         */

        echo '<div class="rud-crm-permissions-manager-field">';


        echo '<label>';

        echo esc_html(
            $settings['notes_label']
        );

        echo '</label>';


        echo '<textarea
            name="rud_crm_permission_notes"
            rows="4"
        >';

        echo esc_textarea(
            $default_notes
        );

        echo '</textarea>';


        echo '</div>';


        /*
         * BUTTONS
         */

        echo '<div class="rud-crm-permissions-manager-actions">';


        echo '<button
            type="submit"
            name="rud_crm_permissions_manager_action"
            value="allow_all"
        >';

        echo esc_html(
            $settings['allow_all_text']
        );

        echo '</button>';


        echo '<button
            type="submit"
            name="rud_crm_permissions_manager_action"
            value="deny_all"
        >';

        echo esc_html(
            $settings['deny_all_text']
        );

        echo '</button>';


        echo '<button
            type="submit"
            name="rud_crm_permissions_manager_action"
            value="save"
        >';

        echo esc_html(
            $settings['save_text']
        );

        echo '</button>';


        echo '</div>';


        echo '</form>';


        echo '</div>';


        ?>

        <style>

        .rud-crm-permissions-manager {
            width:100%;
        }

        .rud-crm-permissions-manager-heading {
            margin-top:0;
            margin-bottom:18px;
        }

        .rud-crm-permissions-manager-message {
            margin-bottom:15px;
            padding:10px 12px;
            background:#f0f6ff;
            border:1px solid #c7dcf7;
            border-radius:6px;
        }

        .rud-crm-permissions-manager-form {
            display:flex;
            flex-direction:column;
            gap:18px;
        }

        .rud-crm-permissions-manager-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-permission-manager-item {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:15px;
            padding:12px;
            cursor:pointer;
        }

        .rud-crm-permission-manager-item input[type="checkbox"] {
            width:18px;
            height:18px;
            flex:0 0 auto;
        }

        .rud-crm-permissions-manager-field {
            display:flex;
            flex-direction:column;
            gap:6px;
        }

        .rud-crm-permissions-manager-field label {
            font-weight:600;
        }

        .rud-crm-permissions-manager-field input,
        .rud-crm-permissions-manager-field textarea {
            width:100%;
            box-sizing:border-box;
        }

        .rud-crm-permissions-manager-actions {
            display:flex;
            flex-wrap:wrap;
            gap:10px;
        }

        .rud-crm-permissions-manager-actions button {
            cursor:pointer;
            padding:9px 16px;
        }

        </style>

        <?php
    }
}