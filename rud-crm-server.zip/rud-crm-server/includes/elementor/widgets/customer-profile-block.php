<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class RUD_CRM_Elementor_Customer_Profile_Block
    extends \Elementor\Widget_Base {


    public function get_name() {
        return 'rud-crm-customer-profile-block';
    }


    public function get_title() {
        return 'Customer Profile Block';
    }


    public function get_icon() {
        return 'eicon-person';
    }


    public function get_categories() {
        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =====================================================
         * CONTENT
         * =====================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Profile Content'
            )
        );


        $this->add_control(
            'show_image',
            array(
                'label' => 'Profile Image',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' => 'Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' => 'Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' => 'Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_contact',
            array(
                'label' => 'Contact Information',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_address',
            array(
                'label' => 'Private Address',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_social',
            array(
                'label' => 'Social Media',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_gallery',
            array(
                'label' => 'Image Gallery',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_notes',
            array(
                'label' => 'Notes',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * LAYOUT
         * =====================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'hero_layout',
            array(
                'label' => 'Header Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'image-left',
                'options' => array(
                    'image-left' => 'Image Left',
                    'image-top'  => 'Image Top',
                    'no-image'   => 'No Image'
                )
            )
        );


        $this->add_responsive_control(
            'panel_columns',
            array(
                'label' => 'Information Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-panels'
                        =>
                    'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'section_gap',
            array(
                'label' => 'Section Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block'
                        =>
                    '--rud-profile-gap: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * OUTER STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'outer_style',
            array(
                'label' => 'Main Block',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'outer_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block'
                        =>
                    'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'outer_border',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block'
            )
        );


        $this->add_responsive_control(
            'outer_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'outer_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block'
                        =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'outer_shadow',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * NAME STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'name_style',
            array(
                'label' => 'Customer Name',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'name_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-name'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block-name'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * IMAGE STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'image_style',
            array(
                'label' => 'Profile Image',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_image' => 'yes'
                )
            )
        );


        $this->add_responsive_control(
            'image_width',
            array(
                'label' => 'Width',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'range' => array(
                    'px' => array(
                        'min' => 40,
                        'max' => 800
                    ),
                    '%' => array(
                        'min' => 5,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-image img,
                     {{WRAPPER}} .rud-crm-profile-block-placeholder'
                        =>
                    'width: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'image_height',
            array(
                'label' => 'Height',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 40,
                        'max' => 800
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-image img,
                     {{WRAPPER}} .rud-crm-profile-block-placeholder'
                        =>
                    'height: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'image_fit',
            array(
                'label' => 'Object Fit',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => array(
                    'cover' => 'Cover',
                    'contain' => 'Contain',
                    'fill' => 'Fill'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-image img'
                        =>
                    'object-fit: {{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'image_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-image img,
                     {{WRAPPER}} .rud-crm-profile-block-placeholder'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * PANELS STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'panel_style',
            array(
                'label' => 'Information Panels',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'panel_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-panel'
                        =>
                    'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'panel_border',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block-panel'
            )
        );


        $this->add_responsive_control(
            'panel_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-panel'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'panel_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-panel'
                        =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'panel_heading_color',
            array(
                'label' => 'Heading Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-panel h3'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'panel_heading_typography',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block-panel h3'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * LABEL / VALUE STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'values_style',
            array(
                'label' => 'Labels & Values',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Label Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-label'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block-label'
            )
        );


        $this->add_control(
            'value_color',
            array(
                'label' => 'Value Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-profile-block-value'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'value_typography',
                'selector' => '{{WRAPPER}} .rud-crm-profile-block-value'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            ) &&
            \Elementor\Plugin::$instance->editor->is_edit_mode();
    }


    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if ( ! $customer_id ) {
            return null;
        }


        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d",
                $customer_id
            )
        );
    }


    private function get_contact(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $type
                )
            );
    }


    private function get_address(
        $customer_id
    ) {

        global $wpdb;


        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_addresses
                 WHERE customer_id = %d
                 AND address_type = 'private'
                 ORDER BY is_primary DESC, id ASC
                 LIMIT 1",
                $customer_id
            )
        );
    }


    private function get_details(
        $customer_id
    ) {

        global $wpdb;


        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_details
                 WHERE customer_id = %d",
                $customer_id
            )
        );
    }


    private function get_social(
        $customer_id
    ) {

        global $wpdb;


        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_social_accounts
                 WHERE customer_id = %d
                 AND is_active = 1
                 ORDER BY platform ASC",
                $customer_id
            )
        );
    }


    private function get_images(
        $customer_id
    ) {

        global $wpdb;


        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_images
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC, sort_order ASC, id ASC",
                $customer_id
            )
        );
    }


    private function customer_name(
        $customer
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if ( '' !== $name ) {
            return $name;
        }


        if (
            ! empty(
                $customer->company_name
            )
        ) {
            return $customer->company_name;
        }


        return 'Unnamed Customer';
    }


    private function value_row(
        $label,
        $value
    ) {

        if (
            '' === trim(
                (string) $value
            )
        ) {
            return;
        }


        echo '<div class="rud-crm-profile-block-row">';

        echo '<span class="rud-crm-profile-block-label">';

        echo esc_html(
            $label
        );

        echo '</span>';

        echo '<span class="rud-crm-profile-block-value">';

        echo esc_html(
            $value
        );

        echo '</span>';

        echo '</div>';
    }


    protected function render() {

        if (
            ! $this->is_editor() &&
            (
                ! is_user_logged_in() ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {

            echo '<div>CRM access restricted.</div>';

            return;
        }


        $customer =
            $this->get_customer();


        if ( ! $customer ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $details =
            $this->get_details(
                $customer->id
            );


        $address =
            $this->get_address(
                $customer->id
            );


        $social =
            $this->get_social(
                $customer->id
            );


        $images =
            $this->get_images(
                $customer->id
            );


        $name =
            $this->customer_name(
                $customer
            );


        $primary_attachment =
            0;


        if (
            ! empty(
                $images
            )
        ) {

            $primary_attachment =
                (int)
                $images[0]->attachment_id;
        }


        $primary_url =
            $primary_attachment
            ? wp_get_attachment_image_url(
                $primary_attachment,
                'large'
            )
            : '';


        $hero_class =
            'rud-crm-profile-block-hero-' .
            sanitize_html_class(
                $settings['hero_layout']
            );


        echo '<div class="rud-crm-profile-block">';


        /*
         * HEADER
         */

        echo '<div class="rud-crm-profile-block-hero ' .
            esc_attr(
                $hero_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_image'] &&
            'no-image' !==
            $settings['hero_layout']
        ) {

            echo '<div class="rud-crm-profile-block-image">';


            if (
                $primary_url
            ) {

                echo '<img
                    src="' .
                    esc_url(
                        $primary_url
                    ) .
                    '"
                    alt="' .
                    esc_attr(
                        $name
                    ) .
                    '"
                >';

            } else {

                echo '<div class="rud-crm-profile-block-placeholder">';

                echo esc_html(
                    strtoupper(
                        substr(
                            $name,
                            0,
                            1
                        )
                    )
                );

                echo '</div>';
            }


            echo '</div>';
        }


        echo '<div class="rud-crm-profile-block-heading">';


        if (
            'yes' ===
            $settings['show_status']
        ) {

            echo '<div class="rud-crm-profile-block-status">';

            echo esc_html(
                ucfirst(
                    $customer->status
                )
            );

            echo '</div>';
        }


        echo '<h2 class="rud-crm-profile-block-name">';

        echo esc_html(
            $name
        );

        echo '</h2>';


        if (
            'yes' ===
            $settings['show_customer_number']
        ) {

            echo '<div class="rud-crm-profile-block-number">';

            echo esc_html(
                $customer->customer_number
            );

            echo '</div>';
        }


        if (
            'yes' ===
            $settings['show_company'] &&
            ! empty(
                $customer->company_name
            )
        ) {

            echo '<div class="rud-crm-profile-block-company">';

            echo esc_html(
                $customer->company_name
            );

            echo '</div>';
        }


        echo '</div>';

        echo '</div>';


        /*
         * PANELS
         */

        echo '<div class="rud-crm-profile-block-panels">';


        if (
            'yes' ===
            $settings['show_contact']
        ) {

            echo '<section class="rud-crm-profile-block-panel">';

            echo '<h3>Contact Information</h3>';


            $this->value_row(
                'Mobile Phone',
                $this->get_contact(
                    $customer->id,
                    'mobile_phone'
                )
            );


            $this->value_row(
                'Home Phone',
                $this->get_contact(
                    $customer->id,
                    'home_phone'
                )
            );


            $this->value_row(
                'Office Phone',
                $this->get_contact(
                    $customer->id,
                    'office_phone'
                )
            );


            $this->value_row(
                'WhatsApp',
                $this->get_contact(
                    $customer->id,
                    'whatsapp'
                )
            );


            $this->value_row(
                'Private Email',
                $this->get_contact(
                    $customer->id,
                    'private_email'
                )
            );


            $this->value_row(
                'Work Email',
                $this->get_contact(
                    $customer->id,
                    'work_email'
                )
            );


            echo '</section>';
        }


        if (
            'yes' ===
            $settings['show_company']
        ) {

            echo '<section class="rud-crm-profile-block-panel">';

            echo '<h3>Company</h3>';


            $this->value_row(
                'Company',
                $customer->company_name
            );


            $this->value_row(
                'Organization Number',
                $customer->organization_number
            );


            $this->value_row(
                'Job Title',
                $customer->job_title
            );


            $this->value_row(
                'Department',
                $customer->department
            );


            echo '</section>';
        }


        if (
            $details
        ) {

            echo '<section class="rud-crm-profile-block-panel">';

            echo '<h3>Personal Information</h3>';


            $this->value_row(
                'Preferred Name',
                $customer->preferred_name
            );


            $this->value_row(
                'Birth Date',
                $details->birth_date
            );


            $this->value_row(
                'Gender',
                $details->gender
            );


            $this->value_row(
                'Preferred Language',
                $details->preferred_language
            );


            $this->value_row(
                'Nationality',
                $details->nationality
            );


            echo '</section>';
        }


        if (
            'yes' ===
            $settings['show_address']
        ) {

            echo '<section class="rud-crm-profile-block-panel">';

            echo '<h3>Private Address</h3>';


            if (
                $address
            ) {

                $this->value_row(
                    'Address',
                    $address->address_line_1 ?? ''
                );


                $this->value_row(
                    'Address Line 2',
                    $address->address_line_2 ?? ''
                );


                $this->value_row(
                    'Postal Code',
                    $address->postal_code ?? ''
                );


                $this->value_row(
                    'City',
                    $address->city ?? ''
                );


                $this->value_row(
                    'State / Region',
                    $address->state_region ?? ''
                );


                $this->value_row(
                    'Country',
                    $address->country_code ?? ''
                );

            } else {

                echo '<div>No address saved.</div>';
            }


            echo '</section>';
        }


        echo '</div>';


        /*
         * SOCIAL MEDIA
         */

        if (
            'yes' ===
            $settings['show_social'] &&
            ! empty(
                $social
            )
        ) {

            echo '<section class="rud-crm-profile-block-panel rud-crm-profile-block-full">';

            echo '<h3>Social Media & Messaging</h3>';

            echo '<div class="rud-crm-profile-block-social">';


            foreach (
                $social as
                $item
            ) {

                echo '<div class="rud-crm-profile-block-social-item">';

                echo '<strong>';

                echo esc_html(
                    ucfirst(
                        str_replace(
                            array(
                                '_',
                                '-'
                            ),
                            ' ',
                            $item->platform
                        )
                    )
                );

                echo '</strong>';


                if (
                    ! empty(
                        $item->account_name
                    )
                ) {

                    echo '<span>';

                    echo esc_html(
                        $item->account_name
                    );

                    echo '</span>';
                }


                if (
                    ! empty(
                        $item->profile_url
                    )
                ) {

                    echo '<a
                        href="' .
                        esc_url(
                            $item->profile_url
                        ) .
                        '"
                        target="_blank"
                        rel="noopener noreferrer"
                    >Open</a>';
                }


                echo '</div>';
            }


            echo '</div>';

            echo '</section>';
        }


        /*
         * GALLERY
         */

        if (
            'yes' ===
            $settings['show_gallery'] &&
            ! empty(
                $images
            )
        ) {

            echo '<section class="rud-crm-profile-block-panel rud-crm-profile-block-full">';

            echo '<h3>Customer Images</h3>';

            echo '<div class="rud-crm-profile-block-gallery">';


            foreach (
                $images as
                $image
            ) {

                $url =
                    wp_get_attachment_image_url(
                        $image->attachment_id,
                        'large'
                    );


                if ( ! $url ) {
                    continue;
                }


                echo '<div class="rud-crm-profile-block-gallery-item">';

                echo '<img
                    src="' .
                    esc_url(
                        $url
                    ) .
                    '"
                    alt=""
                    loading="lazy"
                >';

                echo '</div>';
            }


            echo '</div>';

            echo '</section>';
        }


        /*
         * NOTES
         */

        if (
            'yes' ===
            $settings['show_notes'] &&
            $details &&
            ! empty(
                $details->notes
            )
        ) {

            echo '<section class="rud-crm-profile-block-panel rud-crm-profile-block-full">';

            echo '<h3>Internal CRM Notes</h3>';

            echo '<div class="rud-crm-profile-block-notes">';

            echo nl2br(
                esc_html(
                    $details->notes
                )
            );

            echo '</div>';

            echo '</section>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-profile-block {
            --rud-profile-gap:20px;
            display:flex;
            flex-direction:column;
            gap:var(--rud-profile-gap);
        }

        .rud-crm-profile-block-hero {
            display:flex;
            gap:24px;
            align-items:center;
        }

        .rud-crm-profile-block-hero-image-top {
            flex-direction:column;
            align-items:flex-start;
        }

        .rud-crm-profile-block-hero-no-image {
            display:block;
        }

        .rud-crm-profile-block-image img,
        .rud-crm-profile-block-placeholder {
            width:180px;
            height:180px;
            display:block;
        }

        .rud-crm-profile-block-image img {
            object-fit:cover;
        }

        .rud-crm-profile-block-placeholder {
            display:flex;
            align-items:center;
            justify-content:center;
            background:#f2f4f7;
            font-size:54px;
            font-weight:700;
        }

        .rud-crm-profile-block-name {
            margin:8px 0 4px;
        }

        .rud-crm-profile-block-status {
            display:inline-block;
            padding:4px 9px;
            border-radius:999px;
            background:#f2f4f7;
            font-size:11px;
            font-weight:700;
            text-transform:uppercase;
        }

        .rud-crm-profile-block-number {
            opacity:.65;
        }

        .rud-crm-profile-block-company {
            margin-top:8px;
            font-weight:600;
        }

        .rud-crm-profile-block-panels {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:var(--rud-profile-gap);
        }

        .rud-crm-profile-block-panel {
            min-width:0;
        }

        .rud-crm-profile-block-full {
            width:100%;
        }

        .rud-crm-profile-block-row {
            display:grid;
            grid-template-columns:minmax(110px,35%) 1fr;
            gap:14px;
            padding:8px 0;
        }

        .rud-crm-profile-block-label {
            opacity:.65;
            font-size:12px;
        }

        .rud-crm-profile-block-social {
            display:grid;
            grid-template-columns:repeat(4,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-profile-block-social-item {
            display:flex;
            flex-direction:column;
            gap:5px;
        }

        .rud-crm-profile-block-gallery {
            display:grid;
            grid-template-columns:repeat(5,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-profile-block-gallery-item img {
            width:100%;
            aspect-ratio:1 / 1;
            object-fit:cover;
            display:block;
        }

        @media (max-width:1024px) {

            .rud-crm-profile-block-social {
                grid-template-columns:repeat(2,minmax(0,1fr));
            }

            .rud-crm-profile-block-gallery {
                grid-template-columns:repeat(3,minmax(0,1fr));
            }
        }

        @media (max-width:767px) {

            .rud-crm-profile-block-hero {
                flex-direction:column;
                align-items:flex-start;
            }

            .rud-crm-profile-block-panels {
                grid-template-columns:1fr;
            }

            .rud-crm-profile-block-row {
                grid-template-columns:1fr;
                gap:4px;
            }

            .rud-crm-profile-block-social {
                grid-template-columns:1fr;
            }

            .rud-crm-profile-block-gallery {
                grid-template-columns:repeat(2,minmax(0,1fr));
            }
        }

        </style>

        <?php
    }
}