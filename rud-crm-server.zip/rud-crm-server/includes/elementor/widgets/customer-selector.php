<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER SELECTOR
 * =========================================================
 *
 * Purpose:
 * - Choose a customer from the front-end CRM page
 * - Reload the current page with ?rud_customer_id=ID
 * - Makes all existing RUD CRM widgets display the same
 *   selected customer
 *
 * Demo security:
 * - CRM Demo Users only see DEMO- customers
 * - Administrators / normal CRM users see all customers
 *
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Selector
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-selector';
    }


    public function get_title() {

        return 'Customer Selector';
    }


    public function get_icon() {

        return 'eicon-select';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Selector'
            )
        );


        $this->add_control(
            'show_label',
            array(
                'label' => 'Show Label',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'label_text',
            array(
                'label' => 'Label Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Select Customer',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'placeholder',
            array(
                'label' => 'Placeholder',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Choose a customer'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' => 'Show Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' => 'Show Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' => 'Show Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'no'
            )
        );


        $this->add_control(
            'auto_submit',
            array(
                'label' => 'Auto Load Customer',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'button_text',
            array(
                'label' => 'Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Open Customer',
                'condition' => array(
                    'auto_submit!' => 'yes'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'stacked',
                'options' => array(
                    'stacked' => 'Stacked',
                    'inline'  => 'Inline'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 60
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-selector-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-selector-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABEL STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Label',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-selector-label'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * SELECT STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'select_style',
            array(
                'label' => 'Select Field',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'select_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-select' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'select_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-select' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'select_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-selector-select'
            )
        );


        $this->add_responsive_control(
            'select_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-selector-select' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'select_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-selector-select'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return
                rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * DEMO USER CHECK
     * =====================================================
     */

    private function is_demo_user() {

        /*
         * Elementor editing should always show all customers
         * to the administrator building the page.
         */

        if (
            $this->is_editor()
        ) {

            return false;
        }


        if (
            function_exists(
                'rud_crm_is_demo_user'
            )
        ) {

            return
                rud_crm_is_demo_user();
        }


        return false;
    }


    /*
     * =====================================================
     * SELECTED CUSTOMER
     * =====================================================
     */

    private function selected_customer_id() {

        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        /*
         * Extra safety.
         *
         * If a Demo User somehow reaches this widget with
         * a non-demo customer ID, do not mark it selected.
         */

        if (
            $customer_id
            &&
            $this->is_demo_user()
            &&
            function_exists(
                'rud_crm_user_can_access_customer'
            )
            &&
            ! rud_crm_user_can_access_customer(
                $customer_id
            )
        ) {

            return 0;
        }


        return
            $customer_id;
    }


    /*
     * =====================================================
     * GET CUSTOMERS
     * =====================================================
     */

    private function get_customers() {

        global $wpdb;


        $table =
            $wpdb->prefix .
            'rudcrm_customers';


        /*
         * -------------------------------------------------
         * DEMO USER
         * -------------------------------------------------
         *
         * Only customers beginning with DEMO-
         * may appear in the selector.
         *
         * -------------------------------------------------
         */

        if (
            $this->is_demo_user()
        ) {

            $prefix =
                'DEMO-';


            if (
                function_exists(
                    'rud_crm_demo_customer_prefix'
                )
            ) {

                $prefix =
                    rud_crm_demo_customer_prefix();
            }


            return
                $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT *
                         FROM {$table}
                         WHERE customer_number LIKE %s
                         ORDER BY
                            customer_number ASC,
                            last_name ASC,
                            first_name ASC,
                            company_name ASC,
                            id ASC",
                        $wpdb->esc_like(
                            $prefix
                        ) .
                        '%'
                    )
                );
        }


        /*
         * -------------------------------------------------
         * ADMINISTRATOR / NORMAL CRM USER
         * -------------------------------------------------
         */

        return
            $wpdb->get_results(
                "SELECT *
                 FROM {$table}
                 ORDER BY
                    last_name ASC,
                    first_name ASC,
                    company_name ASC,
                    id ASC"
            );
    }


    /*
     * =====================================================
     * CUSTOMER DISPLAY NAME
     * =====================================================
     */

    private function customer_display_name(
        $customer,
        $settings
    ) {

        $parts =
            array();


        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if (
            '' ===
            $name
        ) {

            $name =
                ! empty(
                    $customer->company_name
                )
                ? $customer->company_name
                : 'Unnamed Customer';
        }


        $parts[] =
            $name;


        if (
            'yes' ===
            $settings['show_customer_number']
            &&
            ! empty(
                $customer->customer_number
            )
        ) {

            $parts[] =
                '#' .
                $customer->customer_number;
        }


        if (
            'yes' ===
            $settings['show_company']
            &&
            ! empty(
                $customer->company_name
            )
            &&
            $customer->company_name !==
            $name
        ) {

            $parts[] =
                $customer->company_name;
        }


        if (
            'yes' ===
            $settings['show_status']
            &&
            ! empty(
                $customer->status
            )
        ) {

            $parts[] =
                ucwords(
                    str_replace(
                        array(
                            '_',
                            '-'
                        ),
                        ' ',
                        $customer->status
                    )
                );
        }


        return
            implode(
                ' — ',
                $parts
            );
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $selected_id =
            $this->selected_customer_id();


        $customers =
            $this->get_customers();


        $layout_class =
            (
                'inline' ===
                $settings['layout']
            )
            ? 'rud-crm-customer-selector-inline'
            : 'rud-crm-customer-selector-stacked';


        echo '<div class="rud-crm-customer-selector-wrapper">';


        echo '<form
            method="get"
            class="rud-crm-customer-selector ' .
            esc_attr(
                $layout_class
            ) .
            '"
        >';


        /*
         * -------------------------------------------------
         * PRESERVE OTHER URL VALUES
         * -------------------------------------------------
         */

        foreach (
            $_GET as
            $key =>
            $value
        ) {

            if (
                'rud_customer_id' ===
                $key
            ) {

                continue;
            }


            if (
                is_array(
                    $value
                )
            ) {

                continue;
            }


            echo '<input
                type="hidden"
                name="' .
                esc_attr(
                    sanitize_key(
                        $key
                    )
                ) .
                '"
                value="' .
                esc_attr(
                    sanitize_text_field(
                        wp_unslash(
                            $value
                        )
                    )
                ) .
                '"
            >';
        }


        /*
         * -------------------------------------------------
         * LABEL
         * -------------------------------------------------
         */

        if (
            'yes' ===
            $settings['show_label']
        ) {

            echo '<label class="rud-crm-customer-selector-label">';

            echo esc_html(
                $settings['label_text']
            );

            echo '</label>';
        }


        /*
         * -------------------------------------------------
         * SELECT
         * -------------------------------------------------
         */

        echo '<select
            name="rud_customer_id"
            class="rud-crm-customer-selector-select"';


        if (
            'yes' ===
            $settings['auto_submit']
        ) {

            echo ' onchange="this.form.submit();"';
        }


        echo '>';


        echo '<option value="">';

        echo esc_html(
            $settings['placeholder']
        );

        echo '</option>';


        foreach (
            $customers as
            $customer
        ) {

            /*
             * Additional application-level safety.
             *
             * Even though the SQL query already filters demo
             * users, never output an inaccessible customer.
             */

            if (
                $this->is_demo_user()
                &&
                function_exists(
                    'rud_crm_user_can_access_customer'
                )
                &&
                ! rud_crm_user_can_access_customer(
                    (int)
                    $customer->id
                )
            ) {

                continue;
            }


            echo '<option
                value="' .
                esc_attr(
                    $customer->id
                ) .
                '"';


            selected(
                $selected_id,
                (int)
                $customer->id
            );


            echo '>';

            echo esc_html(
                $this->customer_display_name(
                    $customer,
                    $settings
                )
            );

            echo '</option>';
        }


        echo '</select>';


        /*
         * -------------------------------------------------
         * BUTTON
         * -------------------------------------------------
         */

        if (
            'yes' !==
            $settings['auto_submit']
        ) {

            echo '<button
                type="submit"
                class="rud-crm-customer-selector-button"
            >';

            echo esc_html(
                $settings['button_text']
            );

            echo '</button>';
        }


        echo '</form>';


        /*
         * -------------------------------------------------
         * DEMO INDICATOR
         * -------------------------------------------------
         */

        if (
            $this->is_demo_user()
        ) {

            echo '<div class="rud-crm-customer-selector-demo-notice">';

            echo esc_html__(
                'Demo account — showing demonstration customers only.',
                'rud-crm-server'
            );

            echo '</div>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-customer-selector-wrapper {
            width:100%;
        }

        .rud-crm-customer-selector {
            display:flex;
            width:100%;
            gap:8px;
        }

        .rud-crm-customer-selector-stacked {
            flex-direction:column;
        }

        .rud-crm-customer-selector-inline {
            flex-direction:row;
            align-items:center;
            flex-wrap:wrap;
        }

        .rud-crm-customer-selector-label {
            font-weight:600;
        }

        .rud-crm-customer-selector-select {
            width:100%;
            min-width:220px;
            box-sizing:border-box;
        }

        .rud-crm-customer-selector-inline
        .rud-crm-customer-selector-select {
            flex:1 1 300px;
        }

        .rud-crm-customer-selector-button {
            cursor:pointer;
            flex:0 0 auto;
        }

        .rud-crm-customer-selector-demo-notice {
            margin-top:7px;
            font-size:11px;
            opacity:.65;
        }

        </style>

        <?php
    }
}