<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER ACTIONS WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Actions
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-actions';
    }


    public function get_title() {

        return 'Customer Actions';
    }


    public function get_icon() {

        return 'eicon-button';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * ACTIONS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'actions_section',
            array(
                'label' => 'Actions'
            )
        );


        $this->add_control(
            'show_open_profile',
            array(
                'label' => 'Open Profile',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_edit_customer',
            array(
                'label' => 'Edit Customer',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_email',
            array(
                'label' => 'Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_call',
            array(
                'label' => 'Call',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_whatsapp',
            array(
                'label' => 'WhatsApp',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_back',
            array(
                'label' => 'Back to Customer List',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * BUTTON LABELS
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'labels_section',
            array(
                'label' => 'Button Labels'
            )
        );


        $this->add_control(
            'open_profile_text',
            array(
                'label' => 'Open Profile Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Open Profile'
            )
        );


        $this->add_control(
            'edit_customer_text',
            array(
                'label' => 'Edit Customer Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Edit Customer'
            )
        );


        $this->add_control(
            'email_text',
            array(
                'label' => 'Email Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Email'
            )
        );


        $this->add_control(
            'call_text',
            array(
                'label' => 'Call Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Call'
            )
        );


        $this->add_control(
            'whatsapp_text',
            array(
                'label' => 'WhatsApp Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'WhatsApp'
            )
        );


        $this->add_control(
            'back_text',
            array(
                'label' => 'Back Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Back to Customers'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => array(
                    'inline' => 'Inline',
                    'stacked' => 'Stacked',
                    'grid' => 'Grid'
                )
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6'
                ),
                'condition' => array(
                    'layout' => 'grid'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-actions-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-actions-wrapper' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * BUTTON STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' => 'Buttons',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'button_text_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_hover_text_color',
            array(
                'label' => 'Hover Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button:hover' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_hover_background',
            array(
                'label' => 'Hover Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button:hover' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'button_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-action-button'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'button_shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-action-button'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'button_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-action-button'
            )
        );


        $this->add_responsive_control(
            'button_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-action-button' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * CURRENT CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * CONTACT VALUE
     * =====================================================
     */

    private function get_contact(
        $customer_id,
        $types
    ) {

        global $wpdb;


        foreach (
            $types as
            $type
        ) {

            $value =
                (string)
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT contact_value
                         FROM {$wpdb->prefix}rudcrm_contact_methods
                         WHERE customer_id = %d
                         AND contact_type = %s
                         ORDER BY is_primary DESC, id ASC
                         LIMIT 1",
                        $customer_id,
                        $type
                    )
                );


            $value =
                trim(
                    $value
                );


            if (
                '' !==
                $value
            ) {

                return $value;
            }
        }


        return '';
    }


    /*
     * =====================================================
     * ACTION BUTTON
     * =====================================================
     */

    private function action_button(
        $url,
        $label,
        $extra_class = ''
    ) {

        if (
            '' ===
            trim(
                (string)
                $url
            )
        ) {

            return;
        }


        echo '<a class="rud-crm-action-button ' .
            esc_attr(
                $extra_class
            ) .
            '" href="' .
            esc_url(
                $url
            ) .
            '">';

        echo esc_html(
            $label
        );

        echo '</a>';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        /*
         * -------------------------------------------------
         * CONTACT INFORMATION
         * -------------------------------------------------
         */

        $email =
            $this->get_contact(
                $customer_id,
                array(
                    'private_email',
                    'work_email'
                )
            );


        $phone =
            $this->get_contact(
                $customer_id,
                array(
                    'mobile_phone',
                    'office_phone',
                    'home_phone'
                )
            );


        $whatsapp =
            $this->get_contact(
                $customer_id,
                array(
                    'whatsapp',
                    'mobile_phone'
                )
            );


        /*
         * -------------------------------------------------
         * URLS
         * -------------------------------------------------
         */

        $profile_url =
            add_query_arg(
                'rud_customer_id',
                $customer_id
            );


        $edit_url =
            admin_url(
                'admin.php?page=rud-crm-customers&action=edit&customer_id=' .
                absint(
                    $customer_id
                )
            );


        $back_url =
            remove_query_arg(
                'rud_customer_id'
            );


        $email_url =
            '';


        if (
            '' !==
            $email
        ) {

            $email_url =
                'mailto:' .
                sanitize_email(
                    $email
                );
        }


        $phone_url =
            '';


        if (
            '' !==
            $phone
        ) {

            $phone_url =
                'tel:' .
                preg_replace(
                    '/[^0-9+]/',
                    '',
                    $phone
                );
        }


        $whatsapp_url =
            '';


        if (
            '' !==
            $whatsapp
        ) {

            $wa_number =
                preg_replace(
                    '/[^0-9]/',
                    '',
                    $whatsapp
                );


            if (
                '' !==
                $wa_number
            ) {

                $whatsapp_url =
                    'https://wa.me/' .
                    $wa_number;
            }
        }


        /*
         * -------------------------------------------------
         * LAYOUT CLASS
         * -------------------------------------------------
         */

        $layout =
            isset(
                $settings['layout']
            )
            ? sanitize_html_class(
                $settings['layout']
            )
            : 'inline';


        echo '<div class="rud-crm-actions-wrapper rud-crm-actions-' .
            esc_attr(
                $layout
            ) .
            '">';


        /*
         * OPEN PROFILE
         */

        if (
            'yes' ===
            $settings['show_open_profile']
        ) {

            $this->action_button(
                $profile_url,
                $settings['open_profile_text'],
                'rud-crm-action-profile'
            );
        }


        /*
         * EDIT CUSTOMER
         */

        if (
            'yes' ===
            $settings['show_edit_customer']
            &&
            (
                current_user_can(
                    'manage_options'
                )
                ||
                (
                    function_exists(
                        'rud_crm_user_can_edit'
                    )
                    &&
                    rud_crm_user_can_edit()
                )
            )
        ) {

            $this->action_button(
                $edit_url,
                $settings['edit_customer_text'],
                'rud-crm-action-edit'
            );
        }


        /*
         * EMAIL
         */

        if (
            'yes' ===
            $settings['show_email']
            &&
            '' !==
            $email_url
        ) {

            $this->action_button(
                $email_url,
                $settings['email_text'],
                'rud-crm-action-email'
            );
        }


        /*
         * CALL
         */

        if (
            'yes' ===
            $settings['show_call']
            &&
            '' !==
            $phone_url
        ) {

            $this->action_button(
                $phone_url,
                $settings['call_text'],
                'rud-crm-action-call'
            );
        }


        /*
         * WHATSAPP
         */

        if (
            'yes' ===
            $settings['show_whatsapp']
            &&
            '' !==
            $whatsapp_url
        ) {

            $this->action_button(
                $whatsapp_url,
                $settings['whatsapp_text'],
                'rud-crm-action-whatsapp'
            );
        }


        /*
         * BACK
         */

        if (
            'yes' ===
            $settings['show_back']
        ) {

            $this->action_button(
                $back_url,
                $settings['back_text'],
                'rud-crm-action-back'
            );
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-actions-wrapper {
            display:flex;
            flex-wrap:wrap;
            gap:10px;
            width:100%;
        }

        .rud-crm-actions-stacked {
            flex-direction:column;
        }

        .rud-crm-actions-grid {
            display:grid;
            grid-template-columns:repeat(3,minmax(0,1fr));
        }

        .rud-crm-action-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            text-align:center;
            text-decoration:none;
            min-height:40px;
            padding:9px 16px;
            border-radius:6px;
            background:#f1f3f5;
            color:#222;
            transition:
                background-color .2s ease,
                color .2s ease,
                border-color .2s ease,
                box-shadow .2s ease;
        }

        .rud-crm-action-button:hover {
            text-decoration:none;
        }

        </style>

        <?php
    }
}