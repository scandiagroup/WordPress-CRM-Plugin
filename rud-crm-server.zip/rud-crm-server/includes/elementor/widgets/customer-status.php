<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER STATUS WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Status
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-status';
    }


    public function get_title() {

        return 'Customer Status';
    }


    public function get_icon() {

        return 'eicon-info-circle';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Status'
            )
        );


        $this->add_control(
            'show_label',
            array(
                'label' => 'Show Label',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => ''
            )
        );


        $this->add_control(
            'label_text',
            array(
                'label' => 'Label Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Status',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'separator',
            array(
                'label' => 'Separator',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ':',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'display_style',
            array(
                'label' => 'Display Style',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'badge',
                'options' => array(
                    'badge' => 'Badge',
                    'text'  => 'Plain Text'
                )
            )
        );


        $this->add_control(
            'capitalize',
            array(
                'label' => 'Capitalize Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => array(
                    'inline'  => 'Inline',
                    'stacked' => 'Stacked'
                )
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'flex-start' => array(
                        'title' => 'Left',
                        'icon'  => 'eicon-h-align-left'
                    ),
                    'center' => array(
                        'title' => 'Center',
                        'icon'  => 'eicon-h-align-center'
                    ),
                    'flex-end' => array(
                        'title' => 'Right',
                        'icon'  => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-wrapper' =>
                        'align-items:{{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LABEL STYLE
         * =================================================
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Label',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-status-label'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * STATUS STYLE
         * =================================================
         */

        $this->start_controls_section(
            'status_style',
            array(
                'label' => 'Status',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'status_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-value' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'status_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'condition' => array(
                    'display_style' => 'badge'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-badge' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'status_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-status-value'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'status_border',
                'condition' => array(
                    'display_style' => 'badge'
                ),
                'selector' =>
                    '{{WRAPPER}} .rud-crm-status-badge'
            )
        );


        $this->add_responsive_control(
            'status_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'condition' => array(
                    'display_style' => 'badge'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-badge' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'status_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'condition' => array(
                    'display_style' => 'badge'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-status-badge' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'status_shadow',
                'condition' => array(
                    'display_style' => 'badge'
                ),
                'selector' =>
                    '{{WRAPPER}} .rud-crm-status-badge'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * ELEMENTOR EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * GET CUSTOMER
     * =====================================================
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {
            return null;
        }


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        /*
         * SECURITY
         */

        if (
            ! $this->is_editor()
        ) {

            if (
                function_exists(
                    'rud_crm_user_can_view'
                )
            ) {

                if (
                    ! rud_crm_user_can_view()
                ) {
                    return;
                }

            } elseif (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            ) {

                return;
            }
        }


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No CRM customer available for preview.';
            }

            return;
        }


        $status =
            isset(
                $customer->status
            )
            ? trim(
                (string)
                $customer->status
            )
            : '';


        if (
            '' ===
            $status
        ) {

            if (
                $this->is_editor()
            ) {

                $status =
                    'No status';

            } else {

                return;
            }
        }


        $settings =
            $this->get_settings_for_display();


        if (
            'yes' ===
            $settings['capitalize']
        ) {

            $status =
                ucwords(
                    str_replace(
                        array(
                            '_',
                            '-'
                        ),
                        ' ',
                        $status
                    )
                );
        }


        $layout_class =
            (
                'stacked' ===
                $settings['layout']
            )
            ? 'rud-crm-status-stacked'
            : 'rud-crm-status-inline';


        $value_class =
            (
                'badge' ===
                $settings['display_style']
            )
            ? 'rud-crm-status-value rud-crm-status-badge'
            : 'rud-crm-status-value';


        echo '<div class="rud-crm-status-wrapper ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_label']
        ) {

            echo '<span class="rud-crm-status-label">';

            echo esc_html(
                $settings['label_text']
            );


            if (
                '' !==
                trim(
                    (string)
                    $settings['separator']
                )
            ) {

                echo esc_html(
                    $settings['separator']
                );
            }


            echo '</span>';
        }


        echo '<span class="' .
            esc_attr(
                $value_class
            ) .
            '">';

        echo esc_html(
            $status
        );

        echo '</span>';


        echo '</div>';


        ?>

        <style>

        .rud-crm-status-wrapper {
            display:flex;
            width:100%;
            gap:7px;
        }

        .rud-crm-status-inline {
            flex-direction:row;
            align-items:center;
        }

        .rud-crm-status-stacked {
            flex-direction:column;
        }

        .rud-crm-status-label {
            font-weight:600;
        }

        .rud-crm-status-badge {
            display:inline-flex;
            width:auto;
            align-items:center;
            justify-content:center;
            background:#f2f4f7;
            padding:5px 10px;
            border-radius:999px;
        }

        </style>

        <?php
    }
}