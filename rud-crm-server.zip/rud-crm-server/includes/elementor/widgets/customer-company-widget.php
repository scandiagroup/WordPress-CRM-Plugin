<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER COMPANY WIDGET
 * FRESH CLASS VERSION
 * =========================================================
 */

class RUD_CRM_Elementor_Company_Widget
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-company-widget';
    }


    public function get_title() {

        return 'Customer Company';
    }


    public function get_icon() {

        return 'eicon-posts-group';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * CONTENT
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Company Information'
            )
        );


        $this->add_control(
            'show_company_name',
            array(
                'label' => 'Company Name',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_organization_number',
            array(
                'label' => 'Organization Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_job_title',
            array(
                'label' => 'Job Title',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_department',
            array(
                'label' => 'Department',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_labels',
            array(
                'label' => 'Show Labels',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * LAYOUT
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'rows',
                'options' => array(
                    'rows'   => 'Rows',
                    'inline' => 'Inline',
                    'grid'   => 'Grid'
                )
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4'
                ),
                'condition' => array(
                    'layout' => 'grid'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-wrapper' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * CONTAINER STYLE
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-company-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-company-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * LABEL STYLE
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Labels',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_labels' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-company-label'
            )
        );


        $this->end_controls_section();


        /*
         * VALUE STYLE
         */

        $this->start_controls_section(
            'value_style',
            array(
                'label' => 'Values',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'value_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-company-value' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'value_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-company-value'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {

            return null;
        }


        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );
    }


    private function render_item(
        $label,
        $value,
        $show_labels
    ) {

        $value =
            trim(
                (string) $value
            );


        if (
            '' === $value
        ) {

            return;
        }


        echo '<div class="rud-crm-company-item">';


        if (
            'yes' ===
            $show_labels
        ) {

            echo '<div class="rud-crm-company-label">';

            echo esc_html(
                $label
            );

            echo '</div>';
        }


        echo '<div class="rud-crm-company-value">';

        echo esc_html(
            $value
        );

        echo '</div>';


        echo '</div>';
    }


    protected function render() {


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No customer available for preview.</div>';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $layout =
            isset(
                $settings['layout']
            )
            ? sanitize_html_class(
                $settings['layout']
            )
            : 'rows';


        echo '<div class="rud-crm-company-wrapper rud-crm-company-' .
            esc_attr(
                $layout
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_company_name']
        ) {

            $this->render_item(
                'Company',
                $customer->company_name ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_organization_number']
        ) {

            $this->render_item(
                'Organization Number',
                $customer->organization_number ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_job_title']
        ) {

            $this->render_item(
                'Job Title',
                $customer->job_title ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_department']
        ) {

            $this->render_item(
                'Department',
                $customer->department ?? '',
                $settings['show_labels']
            );
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-company-wrapper {
            display:flex;
            flex-direction:column;
            gap:10px;
        }

        .rud-crm-company-inline {
            flex-direction:row;
            flex-wrap:wrap;
        }

        .rud-crm-company-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-company-item {
            min-width:0;
        }

        .rud-crm-company-label {
            font-size:12px;
            opacity:.65;
        }

        .rud-crm-company-value {
            overflow-wrap:anywhere;
        }

        </style>

        <?php
    }
}