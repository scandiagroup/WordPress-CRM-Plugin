<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER DETAILS WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Details
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-details';
    }


    public function get_title() {

        return 'Customer Details';
    }


    public function get_icon() {

        return 'eicon-user-circle-o';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Details'
            )
        );


        $this->add_control(
            'show_preferred_name',
            array(
                'label' => 'Preferred Name',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_gender',
            array(
                'label' => 'Gender',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_birth_date',
            array(
                'label' => 'Date of Birth',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_customer_type',
            array(
                'label' => 'Customer Type',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_labels',
            array(
                'label' => 'Show Labels',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => array(
                    'rows'   => 'Rows',
                    'inline' => 'Inline',
                    'grid'   => 'Grid'
                )
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,

                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',

                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4'
                ),

                'condition' => array(
                    'layout' => 'grid'
                ),

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',

                'type' =>
                    \Elementor\Controls_Manager::SLIDER,

                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-wrapper' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-details-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-details-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' => array(
                    'px',
                    'em'
                ),

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' => array(
                    'px',
                    '%'
                ),

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LABEL STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Labels',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,

                'condition' => array(
                    'show_labels' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-details-label'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * VALUE STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'value_style',
            array(
                'label' => 'Values',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'value_color',
            array(
                'label' => 'Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-details-value' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'value_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-details-value'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * GET CUSTOMER
     * =====================================================
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        /*
         * Elementor preview:
         * automatically use the first CRM customer.
         */

        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {

            return null;
        }


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * =====================================================
     * FORMAT VALUE
     * =====================================================
     */

    private function readable_value(
        $value
    ) {

        $value =
            trim(
                (string) $value
            );


        if (
            '' === $value
        ) {

            return '';
        }


        return ucwords(
            str_replace(
                array(
                    '_',
                    '-'
                ),
                ' ',
                $value
            )
        );
    }


    /*
     * =====================================================
     * DATE FORMAT
     * =====================================================
     */

    private function format_date(
        $date
    ) {

        $date =
            trim(
                (string) $date
            );


        if (
            '' === $date
            ||
            '0000-00-00' === $date
        ) {

            return '';
        }


        $timestamp =
            strtotime(
                $date
            );


        if (
            ! $timestamp
        ) {

            return $date;
        }


        return date_i18n(
            get_option(
                'date_format'
            ),
            $timestamp
        );
    }


    /*
     * =====================================================
     * ITEM OUTPUT
     * =====================================================
     */

    private function render_item(
        $label,
        $value,
        $show_labels
    ) {

        $value =
            trim(
                (string) $value
            );


        if (
            '' === $value
        ) {

            return;
        }


        echo '<div class="rud-crm-details-item">';


        if (
            'yes' ===
            $show_labels
        ) {

            echo '<div class="rud-crm-details-label">';

            echo esc_html(
                $label
            );

            echo '</div>';
        }


        echo '<div class="rud-crm-details-value">';

        echo esc_html(
            $value
        );

        echo '</div>';


        echo '</div>';
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {

            return;
        }


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        $layout =
            isset(
                $settings['layout']
            )
            ? sanitize_html_class(
                $settings['layout']
            )
            : 'grid';


        echo '<div class="rud-crm-details-wrapper rud-crm-details-' .
            esc_attr(
                $layout
            ) .
            '">';


        /*
         * PREFERRED NAME
         */

        if (
            'yes' ===
            $settings['show_preferred_name']
        ) {

            $this->render_item(
                'Preferred Name',
                $customer->preferred_name ?? '',
                $settings['show_labels']
            );
        }


        /*
         * GENDER
         */

        if (
            'yes' ===
            $settings['show_gender']
        ) {

            $this->render_item(
                'Gender',
                $this->readable_value(
                    $customer->gender ?? ''
                ),
                $settings['show_labels']
            );
        }


        /*
         * DATE OF BIRTH
         */

        if (
            'yes' ===
            $settings['show_birth_date']
        ) {

            $birth_date =
                '';


            if (
                isset(
                    $customer->birth_date
                )
            ) {

                $birth_date =
                    $this->format_date(
                        $customer->birth_date
                    );

            } elseif (
                isset(
                    $customer->date_of_birth
                )
            ) {

                $birth_date =
                    $this->format_date(
                        $customer->date_of_birth
                    );

            } elseif (
                isset(
                    $customer->birth_year
                )
            ) {

                $birth_date =
                    trim(
                        (string)
                        $customer->birth_year
                    );
            }


            $this->render_item(
                'Date of Birth',
                $birth_date,
                $settings['show_labels']
            );
        }


        /*
         * CUSTOMER TYPE
         */

        if (
            'yes' ===
            $settings['show_customer_type']
        ) {

            $this->render_item(
                'Customer Type',
                $this->readable_value(
                    $customer->customer_type ?? ''
                ),
                $settings['show_labels']
            );
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-details-wrapper {
            display:flex;
            flex-direction:column;
            gap:12px;
            width:100%;
        }

        .rud-crm-details-inline {
            flex-direction:row;
            flex-wrap:wrap;
        }

        .rud-crm-details-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-details-item {
            min-width:0;
        }

        .rud-crm-details-label {
            font-size:12px;
            opacity:.65;
            margin-bottom:3px;
        }

        .rud-crm-details-value {
            overflow-wrap:anywhere;
        }

        </style>

        <?php
    }
}