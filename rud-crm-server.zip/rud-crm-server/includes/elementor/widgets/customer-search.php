<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER SEARCH WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Search
    extends \Elementor\Widget_Base {


    public function get_name() {
        return 'rud-crm-customer-search';
    }


    public function get_title() {
        return 'Customer Search';
    }


    public function get_icon() {
        return 'eicon-search';
    }


    public function get_categories() {
        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Search'
            )
        );


        $this->add_control(
            'placeholder',
            array(
                'label' => 'Search Placeholder',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Search customers...'
            )
        );


        $this->add_control(
            'button_text',
            array(
                'label' => 'Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Search'
            )
        );


        $this->add_control(
            'show_button',
            array(
                'label' => 'Show Search Button',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_clear_button',
            array(
                'label' => 'Show Clear Button',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'clear_text',
            array(
                'label' => 'Clear Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Clear',
                'condition' => array(
                    'show_clear_button' => 'yes'
                )
            )
        );


        $this->add_control(
            'results_limit',
            array(
                'label' => 'Maximum Results',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 25,
                'min' => 1,
                'max' => 200
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * SEARCH FIELDS
         * =================================================
         */

        $this->start_controls_section(
            'fields_section',
            array(
                'label' => 'Search In'
            )
        );


        $this->add_control(
            'search_name',
            array(
                'label' => 'Customer Name',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'search_company',
            array(
                'label' => 'Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'search_customer_number',
            array(
                'label' => 'Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'search_email',
            array(
                'label' => 'Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'search_phone',
            array(
                'label' => 'Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * RESULT DISPLAY
         * =================================================
         */

        $this->start_controls_section(
            'results_section',
            array(
                'label' => 'Results'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' => 'Show Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' => 'Show Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' => 'Show Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'profile_button_text',
            array(
                'label' => 'Open Profile Button',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Open Profile'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * FORM STYLE
         * =================================================
         */

        $this->start_controls_section(
            'form_style',
            array(
                'label' => 'Search Form',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'form_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-form' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'form_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-form' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'form_gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 60
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-form' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * INPUT STYLE
         * =================================================
         */

        $this->start_controls_section(
            'input_style',
            array(
                'label' => 'Search Input',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'input_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-input' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'input_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-input' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'input_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-search-input'
            )
        );


        $this->add_responsive_control(
            'input_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-input' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'input_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-search-input'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * RESULTS STYLE
         * =================================================
         */

        $this->start_controls_section(
            'results_style',
            array(
                'label' => 'Results',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'result_background',
            array(
                'label' => 'Result Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-result' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'result_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-search-result'
            )
        );


        $this->add_responsive_control(
            'result_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-result' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'result_gap',
            array(
                'label' => 'Result Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 60
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-search-results' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function can_view() {

        if (
            $this->is_editor()
        ) {
            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    private function customer_name(
        $customer
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if (
            '' !== $name
        ) {
            return $name;
        }


        if (
            ! empty(
                $customer->company_name
            )
        ) {
            return $customer->company_name;
        }


        return 'Unnamed Customer';
    }


    private function profile_url(
        $customer_id
    ) {

        return add_query_arg(
            'rud_customer_id',
            absint(
                $customer_id
            )
        );
    }


    protected function render() {


        if (
            ! $this->can_view()
        ) {
            return;
        }


        global $wpdb;


        $settings =
            $this->get_settings_for_display();


        $query =
            isset(
                $_GET['rud_crm_search']
            )
            ? sanitize_text_field(
                wp_unslash(
                    $_GET['rud_crm_search']
                )
            )
            : '';


        echo '<div class="rud-crm-search-widget">';


        /*
         * SEARCH FORM
         */

        echo '<form
            method="get"
            class="rud-crm-search-form"
        >';


        /*
         * Preserve current customer parameter only when needed.
         */

        foreach (
            $_GET as
            $key =>
            $value
        ) {

            if (
                'rud_crm_search' ===
                $key
                ||
                'rud_customer_id' ===
                $key
            ) {
                continue;
            }


            if (
                is_array(
                    $value
                )
            ) {
                continue;
            }


            echo '<input
                type="hidden"
                name="' .
                esc_attr(
                    sanitize_key(
                        $key
                    )
                ) .
                '"
                value="' .
                esc_attr(
                    sanitize_text_field(
                        wp_unslash(
                            $value
                        )
                    )
                ) .
                '"
            >';
        }


        echo '<input
            type="search"
            name="rud_crm_search"
            class="rud-crm-search-input"
            value="' .
            esc_attr(
                $query
            ) .
            '"
            placeholder="' .
            esc_attr(
                $settings['placeholder']
            ) .
            '"
        >';


        if (
            'yes' ===
            $settings['show_button']
        ) {

            echo '<button
                type="submit"
                class="rud-crm-search-button"
            >';

            echo esc_html(
                $settings['button_text']
            );

            echo '</button>';
        }


        if (
            'yes' ===
            $settings['show_clear_button']
            &&
            '' !==
            $query
        ) {

            $clear_url =
                remove_query_arg(
                    array(
                        'rud_crm_search',
                        'rud_customer_id'
                    )
                );


            echo '<a
                class="rud-crm-search-clear"
                href="' .
                esc_url(
                    $clear_url
                ) .
                '"
            >';

            echo esc_html(
                $settings['clear_text']
            );

            echo '</a>';
        }


        echo '</form>';


        /*
         * ELEMENTOR PREVIEW
         */

        if (
            '' ===
            $query
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div class="rud-crm-search-preview">';

                echo 'Enter a customer name, company, customer number, email or phone to search.';

                echo '</div>';
            }


            echo '</div>';

            return;
        }


        /*
         * BUILD SEARCH CONDITIONS
         */

        $like =
            '%' .
            $wpdb->esc_like(
                $query
            ) .
            '%';


        $conditions =
            array();


        $params =
            array();


        if (
            'yes' ===
            $settings['search_name']
        ) {

            $conditions[] =
                '(c.first_name LIKE %s
                OR c.middle_name LIKE %s
                OR c.last_name LIKE %s
                OR c.preferred_name LIKE %s)';


            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }


        if (
            'yes' ===
            $settings['search_company']
        ) {

            $conditions[] =
                'c.company_name LIKE %s';

            $params[] =
                $like;
        }


        if (
            'yes' ===
            $settings['search_customer_number']
        ) {

            $conditions[] =
                'c.customer_number LIKE %s';

            $params[] =
                $like;
        }


        if (
            'yes' ===
            $settings['search_email']
        ) {

            $conditions[] =
                "EXISTS (
                    SELECT 1
                    FROM {$wpdb->prefix}rudcrm_contact_methods cm_email
                    WHERE cm_email.customer_id = c.id
                    AND cm_email.contact_type IN (
                        'private_email',
                        'work_email'
                    )
                    AND cm_email.contact_value LIKE %s
                )";

            $params[] =
                $like;
        }


        if (
            'yes' ===
            $settings['search_phone']
        ) {

            $conditions[] =
                "EXISTS (
                    SELECT 1
                    FROM {$wpdb->prefix}rudcrm_contact_methods cm_phone
                    WHERE cm_phone.customer_id = c.id
                    AND cm_phone.contact_type IN (
                        'mobile_phone',
                        'home_phone',
                        'office_phone',
                        'whatsapp'
                    )
                    AND cm_phone.contact_value LIKE %s
                )";

            $params[] =
                $like;
        }


        if (
            empty(
                $conditions
            )
        ) {

            echo '<div>No search fields are enabled.</div>';

            echo '</div>';

            return;
        }


        $limit =
            max(
                1,
                min(
                    200,
                    absint(
                        $settings['results_limit']
                    )
                )
            );


        $sql =
            "SELECT c.*
             FROM {$wpdb->prefix}rudcrm_customers c
             WHERE " .
            implode(
                ' OR ',
                $conditions
            ) .
            "
             ORDER BY c.last_name ASC,
                      c.first_name ASC,
                      c.company_name ASC
             LIMIT %d";


        $params[] =
            $limit;


        $customers =
            $wpdb->get_results(
                $wpdb->prepare(
                    $sql,
                    $params
                )
            );


        /*
         * RESULTS
         */

        echo '<div class="rud-crm-search-results">';


        if (
            empty(
                $customers
            )
        ) {

            echo '<div class="rud-crm-search-empty">';

            echo 'No customers found.';

            echo '</div>';

        } else {


            foreach (
                $customers as
                $customer
            ) {

                echo '<div class="rud-crm-search-result">';


                echo '<div class="rud-crm-search-result-main">';


                echo '<div class="rud-crm-search-name">';

                echo esc_html(
                    $this->customer_name(
                        $customer
                    )
                );

                echo '</div>';


                if (
                    'yes' ===
                    $settings['show_customer_number']
                    &&
                    ! empty(
                        $customer->customer_number
                    )
                ) {

                    echo '<div class="rud-crm-search-meta">';

                    echo '<strong>Customer Number:</strong> ';

                    echo esc_html(
                        $customer->customer_number
                    );

                    echo '</div>';
                }


                if (
                    'yes' ===
                    $settings['show_company']
                    &&
                    ! empty(
                        $customer->company_name
                    )
                ) {

                    echo '<div class="rud-crm-search-meta">';

                    echo '<strong>Company:</strong> ';

                    echo esc_html(
                        $customer->company_name
                    );

                    echo '</div>';
                }


                if (
                    'yes' ===
                    $settings['show_status']
                    &&
                    ! empty(
                        $customer->status
                    )
                ) {

                    echo '<div class="rud-crm-search-meta">';

                    echo '<strong>Status:</strong> ';

                    echo esc_html(
                        ucwords(
                            str_replace(
                                array(
                                    '_',
                                    '-'
                                ),
                                ' ',
                                $customer->status
                            )
                        )
                    );

                    echo '</div>';
                }


                echo '</div>';


                echo '<div class="rud-crm-search-result-action">';


                echo '<a
                    class="rud-crm-search-profile-button"
                    href="' .
                    esc_url(
                        $this->profile_url(
                            $customer->id
                        )
                    ) .
                    '"
                >';

                echo esc_html(
                    $settings['profile_button_text']
                );

                echo '</a>';


                echo '</div>';


                echo '</div>';
            }
        }


        echo '</div>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-search-widget {
            width:100%;
        }

        .rud-crm-search-form {
            display:flex;
            align-items:center;
            flex-wrap:wrap;
            gap:10px;
        }

        .rud-crm-search-input {
            flex:1 1 260px;
            min-width:0;
        }

        .rud-crm-search-button,
        .rud-crm-search-clear,
        .rud-crm-search-profile-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            text-decoration:none;
            cursor:pointer;
        }

        .rud-crm-search-results {
            display:flex;
            flex-direction:column;
            gap:12px;
            margin-top:20px;
        }

        .rud-crm-search-result {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:20px;
            padding:15px;
        }

        .rud-crm-search-result-main {
            min-width:0;
        }

        .rud-crm-search-name {
            font-weight:700;
            font-size:18px;
            margin-bottom:5px;
        }

        .rud-crm-search-meta {
            font-size:13px;
            margin-top:3px;
        }

        .rud-crm-search-result-action {
            flex:0 0 auto;
        }

        @media (max-width:767px) {

            .rud-crm-search-result {
                flex-direction:column;
                align-items:flex-start;
            }
        }

        </style>

        <?php
    }
}