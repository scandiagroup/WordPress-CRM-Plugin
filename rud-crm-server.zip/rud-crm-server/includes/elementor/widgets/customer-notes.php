<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER NOTES WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Notes
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-notes';
    }


    public function get_title() {

        return 'Customer Notes';
    }


    public function get_icon() {

        return 'eicon-editor-paragraph';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Notes'
            )
        );


        $this->add_control(
            'show_heading',
            array(
                'label' => 'Show Heading',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'heading',
            array(
                'label' => 'Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Internal CRM Notes',
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'empty_message',
            array(
                'label' => 'Empty Message',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'No CRM notes saved for this customer.'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * CONTAINER STYLE
         * =================================================
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-notes-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-notes-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * HEADING STYLE
         * =================================================
         */

        $this->start_controls_section(
            'heading_style',
            array(
                'label' => 'Heading',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'heading_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-heading' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'heading_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-notes-heading'
            )
        );


        $this->add_responsive_control(
            'heading_margin',
            array(
                'label' => 'Margin',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-heading' =>
                        'margin:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * NOTE TEXT STYLE
         * =================================================
         */

        $this->start_controls_section(
            'text_style',
            array(
                'label' => 'Note Text',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'text_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-notes-text' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'text_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-notes-text'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    private function get_notes(
        $customer_id
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT notes
                     FROM {$wpdb->prefix}rudcrm_customer_details
                     WHERE customer_id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    protected function render() {


        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {
            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No customer available for preview.';
            }

            return;
        }


        $notes =
            $this->get_notes(
                $customer_id
            );


        $settings =
            $this->get_settings_for_display();


        if (
            '' === trim(
                $notes
            )
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div class="rud-crm-notes-wrapper">';

                if (
                    'yes' ===
                    $settings['show_heading']
                ) {

                    echo '<h3 class="rud-crm-notes-heading">';

                    echo esc_html(
                        $settings['heading']
                    );

                    echo '</h3>';
                }


                echo '<div class="rud-crm-notes-text">';

                echo esc_html(
                    $settings['empty_message']
                );

                echo '</div>';

                echo '</div>';
            }

            return;
        }


        echo '<div class="rud-crm-notes-wrapper">';


        if (
            'yes' ===
            $settings['show_heading']
        ) {

            echo '<h3 class="rud-crm-notes-heading">';

            echo esc_html(
                $settings['heading']
            );

            echo '</h3>';
        }


        echo '<div class="rud-crm-notes-text">';

        echo nl2br(
            esc_html(
                $notes
            )
        );

        echo '</div>';


        echo '</div>';
    }
}