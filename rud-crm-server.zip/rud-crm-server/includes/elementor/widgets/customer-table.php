<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class RUD_CRM_Elementor_Customer_Table
    extends \Elementor\Widget_Base {


    public function get_name() {

        return
            'rud-crm-customer-table';
    }


    public function get_title() {

        return
            'Customer Table';
    }


    public function get_icon() {

        return
            'eicon-table';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =====================================================
         * TABLE CONTENT
         * =====================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' =>
                    'Table'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' =>
                    'Customer Number',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'label_on' =>
                    'Show',

                'label_off' =>
                    'Hide',

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_name',
            array(
                'label' =>
                    'Name',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' =>
                    'Company',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_phone',
            array(
                'label' =>
                    'Mobile Phone',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_email',
            array(
                'label' =>
                    'Email',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' =>
                    'Status',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'show_button',
            array(
                'label' =>
                    'Open Profile Button',

                'type' =>
                    \Elementor\Controls_Manager::SWITCHER,

                'return_value' =>
                    'yes',

                'default' =>
                    'yes'
            )
        );


        $this->add_control(
            'button_text',
            array(
                'label' =>
                    'Button Text',

                'type' =>
                    \Elementor\Controls_Manager::TEXT,

                'default' =>
                    'Open Profile',

                'condition' =>
                    array(
                        'show_button' =>
                            'yes'
                    )
            )
        );


        $this->add_control(
            'limit',
            array(
                'label' =>
                    'Maximum Customers',

                'type' =>
                    \Elementor\Controls_Manager::NUMBER,

                'min' =>
                    1,

                'max' =>
                    500,

                'default' =>
                    100
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * TABLE STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'table_style',
            array(
                'label' =>
                    'Table',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'table_background',
            array(
                'label' =>
                    'Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->add_control(
            'table_text_color',
            array(
                'label' =>
                    'Text Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table td'
                            =>
                        'color: {{VALUE}};'
                    )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' =>
                    'table_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-elementor-table td'
            )
        );


        $this->add_control(
            'border_color',
            array(
                'label' =>
                    'Border Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table, {{WRAPPER}} .rud-crm-elementor-table th, {{WRAPPER}} .rud-crm-elementor-table td'
                            =>
                        'border-color: {{VALUE}};'
                    )
            )
        );


        $this->add_responsive_control(
            'cell_padding',
            array(
                'label' =>
                    'Cell Padding',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>
                    array(
                        'px',
                        'em',
                        '%'
                    ),

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table th, {{WRAPPER}} .rud-crm-elementor-table td'
                            =>
                        'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                    )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * HEADER STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'header_style',
            array(
                'label' =>
                    'Header',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'header_background',
            array(
                'label' =>
                    'Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table thead th'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->add_control(
            'header_color',
            array(
                'label' =>
                    'Text Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table thead th'
                            =>
                        'color: {{VALUE}};'
                    )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' =>
                    'header_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-elementor-table thead th'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * ROW STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'row_style',
            array(
                'label' =>
                    'Rows',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'row_background',
            array(
                'label' =>
                    'Row Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table tbody tr'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->add_control(
            'alternate_background',
            array(
                'label' =>
                    'Alternate Row Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table tbody tr:nth-child(even)'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->add_control(
            'row_hover_background',
            array(
                'label' =>
                    'Hover Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-table tbody tr:hover'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * BUTTON STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' =>
                    'Profile Button',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE,

                'condition' =>
                    array(
                        'show_button' =>
                            'yes'
                    )
            )
        );


        $this->add_control(
            'button_color',
            array(
                'label' =>
                    'Text Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-profile-button'
                            =>
                        'color: {{VALUE}};'
                    )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' =>
                    'Background',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-profile-button'
                            =>
                        'background-color: {{VALUE}};'
                    )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' =>
                    'button_typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-elementor-profile-button'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' =>
                    'button_border',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-elementor-profile-button'
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' =>
                    'Border Radius',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>
                    array(
                        'px',
                        '%'
                    ),

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-profile-button'
                            =>
                        'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                    )
            )
        );


        $this->add_responsive_control(
            'button_padding',
            array(
                'label' =>
                    'Padding',

                'type' =>
                    \Elementor\Controls_Manager::DIMENSIONS,

                'size_units' =>
                    array(
                        'px',
                        'em'
                    ),

                'selectors' =>
                    array(
                        '{{WRAPPER}} .rud-crm-elementor-profile-button'
                            =>
                        'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                    )
            )
        );


        $this->end_controls_section();
    }


    /*
     * ---------------------------------------------------------
     * CONTACT VALUE
     * ---------------------------------------------------------
     */

    private function get_contact(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $type
                )
            );
    }


    /*
     * ---------------------------------------------------------
     * PROFILE URL
     * ---------------------------------------------------------
     */

    private function profile_url(
        $customer_id
    ) {

        return add_query_arg(
            'rud_customer_id',
            absint(
                $customer_id
            )
        );
    }


    /*
     * ---------------------------------------------------------
     * RENDER
     * ---------------------------------------------------------
     */

    protected function render() {

        global $wpdb;


        /*
         * Security.
         */

        if (
            ! is_user_logged_in() ||
            ! current_user_can(
                'manage_options'
            )
        ) {

            echo '<div>';
            echo 'CRM access restricted.';
            echo '</div>';

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $limit =
            max(
                1,
                min(
                    500,
                    absint(
                        $settings['limit']
                    )
                )
            );


        $customers =
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY last_name ASC,
                              first_name ASC,
                              company_name ASC
                     LIMIT %d",
                    $limit
                )
            );


        if (
            empty(
                $customers
            )
        ) {

            echo '<div>';
            echo 'No customers found.';
            echo '</div>';

            return;
        }


        echo '<div style="overflow-x:auto;">';


        echo '<table
            class="rud-crm-elementor-table"
            style="
                width:100%;
                border-collapse:collapse;
                border:1px solid #ddd;
            "
        >';


        /*
         * HEADER
         */

        echo '<thead>';

        echo '<tr>';


        if (
            'yes' ===
            $settings[
                'show_customer_number'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Customer ID';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_name'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Name';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_company'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Company';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_phone'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Mobile';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_email'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Email';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_status'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo 'Status';
            echo '</th>';
        }


        if (
            'yes' ===
            $settings[
                'show_button'
            ]
        ) {

            echo '<th style="border:1px solid #ddd;">';
            echo '';
            echo '</th>';
        }


        echo '</tr>';

        echo '</thead>';


        /*
         * ROWS
         */

        echo '<tbody>';


        foreach (
            $customers as
            $customer
        ) {

            $name =
                trim(
                    implode(
                        ' ',
                        array_filter(
                            array(
                                $customer->first_name,
                                $customer->middle_name,
                                $customer->last_name
                            )
                        )
                    )
                );


            if (
                '' === $name
            ) {

                $name =
                    $customer->company_name
                    ? $customer->company_name
                    : 'Unnamed Customer';
            }


            $mobile =
                $this->get_contact(
                    $customer->id,
                    'mobile_phone'
                );


            $email =
                $this->get_contact(
                    $customer->id,
                    'private_email'
                );


            if (
                '' === $email
            ) {

                $email =
                    $this->get_contact(
                        $customer->id,
                        'work_email'
                    );
            }


            echo '<tr>';


            if (
                'yes' ===
                $settings[
                    'show_customer_number'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    $customer->customer_number
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_name'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    $name
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_company'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    $customer->company_name
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_phone'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    $mobile
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_email'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    $email
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_status'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';

                echo esc_html(
                    ucfirst(
                        $customer->status
                    )
                );

                echo '</td>';
            }


            if (
                'yes' ===
                $settings[
                    'show_button'
                ]
            ) {

                echo '<td style="border:1px solid #ddd;">';


                echo '<a
                    class="rud-crm-elementor-profile-button"
                    href="' .
                    esc_url(
                        $this->profile_url(
                            $customer->id
                        )
                    ) .
                    '"
                    style="
                        display:inline-block;
                        text-decoration:none;
                    "
                >';

                echo esc_html(
                    $settings[
                        'button_text'
                    ]
                );

                echo '</a>';


                echo '</td>';
            }


            echo '</tr>';
        }


        echo '</tbody>';

        echo '</table>';

        echo '</div>';
    }
}