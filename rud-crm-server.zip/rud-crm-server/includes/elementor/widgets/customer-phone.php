<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER PHONE WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Phone
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-phone';
    }


    public function get_title() {

        return 'Customer Phone';
    }


    public function get_icon() {

        return 'eicon-phone';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Phone'
            )
        );


        $this->add_control(
            'phone_type',
            array(
                'label' => 'Phone Type',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'mobile_phone',
                'options' => array(
                    'mobile_phone' => 'Mobile Phone',
                    'home_phone'   => 'Home Phone',
                    'office_phone' => 'Office Phone',
                    'whatsapp'     => 'WhatsApp'
                )
            )
        );


        $this->add_control(
            'show_label',
            array(
                'label' => 'Show Label',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'custom_label',
            array(
                'label' => 'Custom Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => 'Leave empty to use phone type name',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'separator',
            array(
                'label' => 'Separator',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ':',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'clickable',
            array(
                'label' => 'Clickable Phone Link',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_icon',
            array(
                'label' => 'Show Icon',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => array(
                    'inline'  => 'Inline',
                    'stacked' => 'Stacked'
                )
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'flex-start' => array(
                        'title' => 'Left',
                        'icon' => 'eicon-h-align-left'
                    ),
                    'center' => array(
                        'title' => 'Center',
                        'icon' => 'eicon-h-align-center'
                    ),
                    'flex-end' => array(
                        'title' => 'Right',
                        'icon' => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-wrapper' =>
                        'align-items:{{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * CONTAINER STYLE
         * =================================================
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-phone-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-phone-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * ICON STYLE
         * =================================================
         */

        $this->start_controls_section(
            'icon_style',
            array(
                'label' => 'Icon',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_icon' => 'yes'
                )
            )
        );


        $this->add_control(
            'icon_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-icon' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'icon_size',
            array(
                'label' => 'Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 8,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-icon' =>
                        'font-size:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LABEL STYLE
         * =================================================
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Label',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-phone-label'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * PHONE VALUE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'phone_style',
            array(
                'label' => 'Phone Number',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'phone_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-phone-value,
                     {{WRAPPER}} .rud-crm-phone-value a' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'phone_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-phone-value'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    private function get_phone(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $type
                )
            );
    }


    private function get_label(
        $type
    ) {

        $labels =
            array(
                'mobile_phone' => 'Mobile Phone',
                'home_phone'   => 'Home Phone',
                'office_phone' => 'Office Phone',
                'whatsapp'     => 'WhatsApp'
            );


        return
            isset(
                $labels[
                    $type
                ]
            )
            ? $labels[
                $type
            ]
            : 'Phone';
    }


    private function get_icon_class(
        $type
    ) {

        switch (
            $type
        ) {

            case 'whatsapp':

                return 'fab fa-whatsapp';


            case 'mobile_phone':

                return 'fas fa-mobile-alt';


            case 'office_phone':

            case 'home_phone':

            default:

                return 'fas fa-phone';
        }
    }


    protected function render() {


        if (
            ! $this->is_editor()
        ) {

            if (
                function_exists(
                    'rud_crm_user_can_view'
                )
            ) {

                if (
                    ! rud_crm_user_can_view()
                ) {
                    return;
                }

            } elseif (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            ) {

                return;
            }
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No CRM customer available for preview.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $phone_type =
            sanitize_key(
                $settings['phone_type']
            );


        $phone =
            trim(
                $this->get_phone(
                    $customer_id,
                    $phone_type
                )
            );


        if (
            '' ===
            $phone
        ) {

            if (
                $this->is_editor()
            ) {

                $phone =
                    'No phone number saved';

            } else {

                return;
            }
        }


        $label =
            trim(
                (string)
                $settings['custom_label']
            );


        if (
            '' ===
            $label
        ) {

            $label =
                $this->get_label(
                    $phone_type
                );
        }


        $layout_class =
            (
                'stacked' ===
                $settings['layout']
            )
            ? 'rud-crm-phone-stacked'
            : 'rud-crm-phone-inline';


        echo '<div class="rud-crm-phone-wrapper ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_icon']
        ) {

            echo '<span class="rud-crm-phone-icon-wrap">';

            echo '<i class="' .
                esc_attr(
                    $this->get_icon_class(
                        $phone_type
                    )
                ) .
                ' rud-crm-phone-icon" aria-hidden="true"></i>';

            echo '</span>';
        }


        echo '<div class="rud-crm-phone-content">';


        if (
            'yes' ===
            $settings['show_label']
        ) {

            echo '<span class="rud-crm-phone-label">';

            echo esc_html(
                $label
            );


            if (
                '' !==
                trim(
                    (string)
                    $settings['separator']
                )
            ) {

                echo esc_html(
                    $settings['separator']
                );
            }


            echo '</span>';
        }


        echo '<span class="rud-crm-phone-value">';


        if (
            'yes' ===
            $settings['clickable']
            &&
            'No phone number saved' !==
            $phone
        ) {

            $tel =
                preg_replace(
                    '/[^0-9+]/',
                    '',
                    $phone
                );


            echo '<a href="tel:' .
                esc_attr(
                    $tel
                ) .
                '">';

            echo esc_html(
                $phone
            );

            echo '</a>';

        } else {

            echo esc_html(
                $phone
            );
        }


        echo '</span>';


        echo '</div>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-phone-wrapper {
            display:flex;
            width:100%;
            gap:10px;
        }

        .rud-crm-phone-inline {
            flex-direction:row;
            align-items:center;
        }

        .rud-crm-phone-stacked {
            flex-direction:column;
        }

        .rud-crm-phone-icon-wrap {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            flex:0 0 auto;
        }

        .rud-crm-phone-content {
            display:flex;
            gap:5px;
            min-width:0;
        }

        .rud-crm-phone-stacked .rud-crm-phone-content {
            flex-direction:column;
        }

        .rud-crm-phone-label {
            font-weight:600;
        }

        .rud-crm-phone-value {
            overflow-wrap:anywhere;
        }

        .rud-crm-phone-value a {
            color:inherit;
            text-decoration:inherit;
        }

        </style>

        <?php
    }
}