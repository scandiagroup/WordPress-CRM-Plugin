<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER ADDRESS WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Address
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-address';
    }


    public function get_title() {

        return 'Customer Address';
    }


    public function get_icon() {

        return 'eicon-map-pin';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Address'
            )
        );


        $this->add_control(
            'show_address_1',
            array(
                'label' => 'Address Line 1',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_address_2',
            array(
                'label' => 'Address Line 2',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_postal_code',
            array(
                'label' => 'Postal Code',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_city',
            array(
                'label' => 'City',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_region',
            array(
                'label' => 'State / Region',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_country',
            array(
                'label' => 'Country',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_labels',
            array(
                'label' => 'Show Labels',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'rows',
                'options' => array(
                    'rows' => 'Rows',
                    'inline' => 'Inline',
                    'grid' => 'Grid',
                    'formatted' => 'Formatted Address'
                )
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3'
                ),
                'condition' => array(
                    'layout' => 'grid'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * CONTAINER STYLE
         * =================================================
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-address-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-address-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-wrapper' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LABEL STYLE
         * =================================================
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Labels',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_labels' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-address-label'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * VALUE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'value_style',
            array(
                'label' => 'Values',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'value_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-address-value' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'value_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-address-value'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    private function get_address(
        $customer_id
    ) {

        global $wpdb;


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_addresses
                     WHERE customer_id = %d
                     AND address_type = 'private'
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    private function render_item(
        $label,
        $value,
        $show_labels
    ) {

        if (
            '' ===
            trim(
                (string) $value
            )
        ) {
            return;
        }


        echo '<div class="rud-crm-address-item">';


        if (
            'yes' ===
            $show_labels
        ) {

            echo '<div class="rud-crm-address-label">';

            echo esc_html(
                $label
            );

            echo '</div>';
        }


        echo '<div class="rud-crm-address-value">';

        echo esc_html(
            $value
        );

        echo '</div>';


        echo '</div>';
    }


    protected function render() {


        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {
            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No customer available for preview.';
            }

            return;
        }


        $address =
            $this->get_address(
                $customer_id
            );


        if (
            ! $address
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No private address saved.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        if (
            'formatted' ===
            $settings['layout']
        ) {

            $lines =
                array_filter(
                    array(
                        $address->address_line_1 ?? '',
                        $address->address_line_2 ?? '',
                        trim(
                            ($address->postal_code ?? '') .
                            ' ' .
                            ($address->city ?? '')
                        ),
                        $address->state_region ?? '',
                        $address->country_code ?? ''
                    )
                );


            echo '<div class="rud-crm-address-wrapper">';

            echo '<div class="rud-crm-address-value">';

            echo nl2br(
                esc_html(
                    implode(
                        "\n",
                        $lines
                    )
                )
            );

            echo '</div>';

            echo '</div>';

            return;
        }


        $class =
            'rud-crm-address-' .
            sanitize_html_class(
                $settings['layout']
            );


        echo '<div class="rud-crm-address-wrapper ' .
            esc_attr(
                $class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_address_1']
        ) {

            $this->render_item(
                'Address',
                $address->address_line_1 ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_address_2']
        ) {

            $this->render_item(
                'Address Line 2',
                $address->address_line_2 ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_postal_code']
        ) {

            $this->render_item(
                'Postal Code',
                $address->postal_code ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_city']
        ) {

            $this->render_item(
                'City',
                $address->city ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_region']
        ) {

            $this->render_item(
                'State / Region',
                $address->state_region ?? '',
                $settings['show_labels']
            );
        }


        if (
            'yes' ===
            $settings['show_country']
        ) {

            $this->render_item(
                'Country',
                $address->country_code ?? '',
                $settings['show_labels']
            );
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-address-wrapper {
            display:flex;
            flex-direction:column;
            gap:10px;
        }

        .rud-crm-address-inline {
            flex-direction:row;
            flex-wrap:wrap;
        }

        .rud-crm-address-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-address-item {
            min-width:0;
        }

        .rud-crm-address-label {
            font-size:12px;
            opacity:.65;
        }

        .rud-crm-address-value {
            overflow-wrap:anywhere;
        }

        </style>

        <?php
    }
}