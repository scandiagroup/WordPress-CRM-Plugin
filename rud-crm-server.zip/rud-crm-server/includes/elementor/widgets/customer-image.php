<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class RUD_CRM_Elementor_Customer_Image
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-image';
    }


    public function get_title() {

        return 'Customer Image';
    }


    public function get_icon() {

        return 'eicon-image';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =====================================================
         * CONTENT
         * =====================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Image'
            )
        );


        $this->add_control(
            'image_size',
            array(
                'label' => 'WordPress Image Size',
                'type'  => \Elementor\Controls_Manager::SELECT,
                'default' => 'large',
                'options' => array(
                    'thumbnail' => 'Thumbnail',
                    'medium'    => 'Medium',
                    'large'     => 'Large',
                    'full'      => 'Full'
                )
            )
        );


        $this->add_control(
            'link_image',
            array(
                'label' => 'Link to Full Image',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
                'default' => ''
            )
        );


        $this->add_control(
            'show_placeholder',
            array(
                'label' => 'Show Placeholder',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => 'Yes',
                'label_off' => 'No',
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'image_style',
            array(
                'label' => 'Image',
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_responsive_control(
            'width',
            array(
                'label' => 'Width',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'range' => array(
                    'px' => array(
                        'min' => 20,
                        'max' => 1200
                    ),
                    '%' => array(
                        'min' => 1,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image img,
                     {{WRAPPER}} .rud-crm-customer-image-placeholder'
                        =>
                    'width: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'height',
            array(
                'label' => 'Height',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => array(
                    'px'
                ),
                'range' => array(
                    'px' => array(
                        'min' => 20,
                        'max' => 1200
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image img,
                     {{WRAPPER}} .rud-crm-customer-image-placeholder'
                        =>
                    'height: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'object_fit',
            array(
                'label' => 'Object Fit',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => array(
                    'cover'   => 'Cover',
                    'contain' => 'Contain',
                    'fill'    => 'Fill'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image img'
                        =>
                    'object-fit: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-image img,
                     {{WRAPPER}} .rud-crm-customer-image-placeholder'
            )
        );


        $this->add_responsive_control(
            'border_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image img,
                     {{WRAPPER}} .rud-crm-customer-image-placeholder'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'box_shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-image img,
                     {{WRAPPER}} .rud-crm-customer-image-placeholder'
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(

                    'flex-start' => array(
                        'title' => 'Left',
                        'icon'  => 'eicon-h-align-left'
                    ),

                    'center' => array(
                        'title' => 'Center',
                        'icon'  => 'eicon-h-align-center'
                    ),

                    'flex-end' => array(
                        'title' => 'Right',
                        'icon'  => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image'
                        =>
                    'justify-content: {{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * PLACEHOLDER STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'placeholder_style',
            array(
                'label' => 'Placeholder',
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_placeholder' => 'yes'
                )
            )
        );


        $this->add_control(
            'placeholder_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image-placeholder'
                        =>
                    'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_control(
            'placeholder_color',
            array(
                'label' => 'Letter Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-image-placeholder'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'placeholder_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-image-placeholder'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =========================================================
     * CURRENT CUSTOMER
     * =========================================================
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {
            return null;
        }


        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d",
                $customer_id
            )
        );
    }


    /*
     * =========================================================
     * PRIMARY IMAGE
     * =========================================================
     */

    private function get_primary_attachment_id(
        $customer_id
    ) {

        global $wpdb;


        return
            (int)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT attachment_id
                     FROM {$wpdb->prefix}rudcrm_customer_images
                     WHERE customer_id = %d
                     ORDER BY is_primary DESC,
                              sort_order ASC,
                              id ASC
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * =========================================================
     * RENDER
     * =========================================================
     */

    protected function render() {

        $customer =
            $this->get_customer();


        if ( ! $customer ) {

            if (
                \Elementor\Plugin::$instance
                    ->editor
                    ->is_edit_mode()
            ) {

                echo 'No CRM customer available for preview.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $attachment_id =
            $this->get_primary_attachment_id(
                $customer->id
            );


        echo '<div
            class="rud-crm-customer-image"
            style="
                display:flex;
                width:100%;
            "
        >';


        if (
            $attachment_id
        ) {

            $image_url =
                wp_get_attachment_image_url(
                    $attachment_id,
                    $settings['image_size']
                );


            $full_url =
                wp_get_attachment_image_url(
                    $attachment_id,
                    'full'
                );


            if (
                'yes' ===
                $settings['link_image'] &&
                $full_url
            ) {

                echo '<a
                    href="' .
                    esc_url(
                        $full_url
                    ) .
                    '"
                    target="_blank"
                    rel="noopener"
                >';
            }


            echo '<img
                src="' .
                esc_url(
                    $image_url
                ) .
                '"
                alt="' .
                esc_attr(
                    trim(
                        $customer->first_name .
                        ' ' .
                        $customer->last_name
                    )
                ) .
                '"
                style="
                    display:block;
                    max-width:100%;
                "
            >';


            if (
                'yes' ===
                $settings['link_image'] &&
                $full_url
            ) {

                echo '</a>';
            }

        } elseif (
            'yes' ===
            $settings['show_placeholder']
        ) {

            $name =
                trim(
                    $customer->first_name .
                    ' ' .
                    $customer->last_name
                );


            $letter =
                '' !== $name
                ? strtoupper(
                    substr(
                        $name,
                        0,
                        1
                    )
                )
                : '?';


            echo '<div
                class="rud-crm-customer-image-placeholder"
                style="
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    width:200px;
                    height:200px;
                    background:#f2f4f7;
                "
            >';

            echo esc_html(
                $letter
            );

            echo '</div>';
        }


        echo '</div>';
    }
}