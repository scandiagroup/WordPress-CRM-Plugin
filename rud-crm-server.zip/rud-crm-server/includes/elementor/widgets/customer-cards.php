<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


class RUD_CRM_Elementor_Customer_Cards
    extends \Elementor\Widget_Base {


    public function get_name() {
        return 'rud-crm-customer-cards';
    }


    public function get_title() {
        return 'Customer Cards';
    }


    public function get_icon() {
        return 'eicon-gallery-grid';
    }


    public function get_categories() {
        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =====================================================
         * CONTENT
         * =====================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customers'
            )
        );


        $this->add_control(
            'limit',
            array(
                'label' => 'Maximum Customers',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 500,
                'default' => 50
            )
        );


        $this->add_control(
            'show_image',
            array(
                'label' => 'Profile Image',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_customer_number',
            array(
                'label' => 'Customer Number',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_status',
            array(
                'label' => 'Status',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_company',
            array(
                'label' => 'Company',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_phone',
            array(
                'label' => 'Mobile Phone',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_email',
            array(
                'label' => 'Email',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'button_text',
            array(
                'label' => 'Button Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Open Profile'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * LAYOUT
         * =====================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-cards-grid'
                        =>
                    'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-cards-grid'
                        =>
                    'gap: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * CARD STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'card_style',
            array(
                'label' => 'Cards',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'card_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card'
                        =>
                    'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .rud-crm-customer-card'
            )
        );


        $this->add_responsive_control(
            'card_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'card_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card'
                        =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'card_shadow',
                'selector' => '{{WRAPPER}} .rud-crm-customer-card'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * IMAGE STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'image_style',
            array(
                'label' => 'Image',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_image' => 'yes'
                )
            )
        );


        $this->add_responsive_control(
            'image_height',
            array(
                'label' => 'Height',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 60,
                        'max' => 600
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-image img,
                     {{WRAPPER}} .rud-crm-customer-card-placeholder'
                        =>
                    'height: {{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'image_fit',
            array(
                'label' => 'Object Fit',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => array(
                    'cover' => 'Cover',
                    'contain' => 'Contain',
                    'fill' => 'Fill'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-image img'
                        =>
                    'object-fit: {{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'image_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-image img,
                     {{WRAPPER}} .rud-crm-customer-card-placeholder'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * NAME STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'name_style',
            array(
                'label' => 'Name',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'name_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-name'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'name_typography',
                'selector' => '{{WRAPPER}} .rud-crm-customer-card-name'
            )
        );


        $this->end_controls_section();


        /*
         * =====================================================
         * BUTTON STYLE
         * =====================================================
         */

        $this->start_controls_section(
            'button_style',
            array(
                'label' => 'Button',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'button_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-button'
                        =>
                    'color: {{VALUE}};'
                )
            )
        );


        $this->add_control(
            'button_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-button'
                        =>
                    'background-color: {{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .rud-crm-customer-card-button'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .rud-crm-customer-card-button'
            )
        );


        $this->add_responsive_control(
            'button_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-button'
                        =>
                    'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'button_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-customer-card-button'
                        =>
                    'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    private function get_contact(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $type
                )
            );
    }


    private function get_primary_image(
        $customer_id
    ) {

        global $wpdb;


        $attachment_id =
            (int)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT attachment_id
                     FROM {$wpdb->prefix}rudcrm_customer_images
                     WHERE customer_id = %d
                     ORDER BY is_primary DESC, sort_order ASC, id ASC
                     LIMIT 1",
                    $customer_id
                )
            );


        if ( ! $attachment_id ) {
            return '';
        }


        $url =
            wp_get_attachment_image_url(
                $attachment_id,
                'large'
            );


        return $url
            ? $url
            : '';
    }


    private function profile_url(
        $customer_id
    ) {

        return add_query_arg(
            'rud_customer_id',
            absint(
                $customer_id
            )
        );
    }


    private function customer_name(
        $customer
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if ( '' !== $name ) {
            return $name;
        }


        if (
            ! empty(
                $customer->company_name
            )
        ) {
            return $customer->company_name;
        }


        return 'Unnamed Customer';
    }


    protected function render() {

        if (
            ! is_user_logged_in() ||
            ! current_user_can(
                'manage_options'
            )
        ) {

            echo '<div>CRM access restricted.</div>';

            return;
        }


        global $wpdb;


        $settings =
            $this->get_settings_for_display();


        $limit =
            max(
                1,
                min(
                    500,
                    absint(
                        $settings['limit']
                    )
                )
            );


        $customers =
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY last_name ASC, first_name ASC, company_name ASC
                     LIMIT %d",
                    $limit
                )
            );


        if (
            empty(
                $customers
            )
        ) {

            echo '<div>No customers found.</div>';

            return;
        }


        echo '<div class="rud-crm-customer-cards-grid">';


        foreach (
            $customers as
            $customer
        ) {

            $name =
                $this->customer_name(
                    $customer
                );


            $image =
                $this->get_primary_image(
                    $customer->id
                );


            $mobile =
                $this->get_contact(
                    $customer->id,
                    'mobile_phone'
                );


            $email =
                $this->get_contact(
                    $customer->id,
                    'private_email'
                );


            if (
                '' === $email
            ) {

                $email =
                    $this->get_contact(
                        $customer->id,
                        'work_email'
                    );
            }


            echo '<article class="rud-crm-customer-card">';


            if (
                'yes' ===
                $settings['show_image']
            ) {

                echo '<div class="rud-crm-customer-card-image">';


                if (
                    $image
                ) {

                    echo '<img
                        src="' .
                        esc_url(
                            $image
                        ) .
                        '"
                        alt="' .
                        esc_attr(
                            $name
                        ) .
                        '"
                        loading="lazy"
                    >';

                } else {

                    echo '<div class="rud-crm-customer-card-placeholder">';

                    echo esc_html(
                        strtoupper(
                            substr(
                                $name,
                                0,
                                1
                            )
                        )
                    );

                    echo '</div>';
                }


                echo '</div>';
            }


            echo '<div class="rud-crm-customer-card-content">';


            if (
                'yes' ===
                $settings['show_status']
            ) {

                echo '<div class="rud-crm-customer-card-status">';

                echo esc_html(
                    ucfirst(
                        $customer->status
                    )
                );

                echo '</div>';
            }


            echo '<h3 class="rud-crm-customer-card-name">';

            echo esc_html(
                $name
            );

            echo '</h3>';


            if (
                'yes' ===
                $settings['show_customer_number']
            ) {

                echo '<div class="rud-crm-customer-card-number">';

                echo esc_html(
                    $customer->customer_number
                );

                echo '</div>';
            }


            if (
                'yes' ===
                $settings['show_company'] &&
                ! empty(
                    $customer->company_name
                )
            ) {

                echo '<div class="rud-crm-customer-card-company">';

                echo esc_html(
                    $customer->company_name
                );

                echo '</div>';
            }


            if (
                'yes' ===
                $settings['show_phone'] &&
                '' !== $mobile
            ) {

                echo '<div class="rud-crm-customer-card-detail">';

                echo '<span>Phone</span>';

                echo '<strong>';

                echo esc_html(
                    $mobile
                );

                echo '</strong>';

                echo '</div>';
            }


            if (
                'yes' ===
                $settings['show_email'] &&
                '' !== $email
            ) {

                echo '<div class="rud-crm-customer-card-detail">';

                echo '<span>Email</span>';

                echo '<strong>';

                echo esc_html(
                    $email
                );

                echo '</strong>';

                echo '</div>';
            }


            echo '<div class="rud-crm-customer-card-actions">';


            echo '<a
                class="rud-crm-customer-card-button"
                href="' .
                esc_url(
                    $this->profile_url(
                        $customer->id
                    )
                ) .
                '"
            >';

            echo esc_html(
                $settings['button_text']
            );

            echo '</a>';


            echo '</div>';


            echo '</div>';

            echo '</article>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-customer-cards-grid {
            display:grid;
            grid-template-columns:repeat(3,minmax(0,1fr));
            gap:20px;
        }

        .rud-crm-customer-card {
            min-width:0;
            overflow:hidden;
        }

        .rud-crm-customer-card-image img,
        .rud-crm-customer-card-placeholder {
            width:100%;
            height:220px;
            display:block;
        }

        .rud-crm-customer-card-image img {
            object-fit:cover;
        }

        .rud-crm-customer-card-placeholder {
            display:flex;
            align-items:center;
            justify-content:center;
            background:#f2f4f7;
            font-size:54px;
            font-weight:700;
        }

        .rud-crm-customer-card-content {
            padding-top:14px;
        }

        .rud-crm-customer-card-status {
            display:inline-block;
            padding:4px 8px;
            border-radius:999px;
            background:#f2f4f7;
            font-size:10px;
            text-transform:uppercase;
            font-weight:700;
        }

        .rud-crm-customer-card-name {
            margin:9px 0 3px;
        }

        .rud-crm-customer-card-number {
            opacity:.6;
            font-size:12px;
        }

        .rud-crm-customer-card-company {
            margin-top:8px;
            font-weight:600;
        }

        .rud-crm-customer-card-detail {
            display:flex;
            flex-direction:column;
            gap:2px;
            margin-top:9px;
            overflow-wrap:anywhere;
        }

        .rud-crm-customer-card-detail span {
            font-size:11px;
            opacity:.6;
            text-transform:uppercase;
        }

        .rud-crm-customer-card-actions {
            margin-top:16px;
        }

        .rud-crm-customer-card-button {
            display:inline-block;
            text-decoration:none;
        }

        </style>

        <?php
    }
}