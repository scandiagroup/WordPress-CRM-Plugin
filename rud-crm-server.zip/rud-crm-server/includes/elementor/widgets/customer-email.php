<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER EMAIL WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Email
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-email';
    }


    public function get_title() {

        return 'Customer Email';
    }


    public function get_icon() {

        return 'eicon-mail';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Email'
            )
        );


        $this->add_control(
            'email_type',
            array(
                'label' => 'Email Type',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'private_email',
                'options' => array(
                    'private_email' => 'Private Email',
                    'work_email'    => 'Work Email'
                )
            )
        );


        $this->add_control(
            'show_label',
            array(
                'label' => 'Show Label',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'custom_label',
            array(
                'label' => 'Custom Label',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => 'Leave empty to use email type name',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'separator',
            array(
                'label' => 'Separator',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ':',
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'clickable',
            array(
                'label' => 'Clickable Email Link',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_icon',
            array(
                'label' => 'Show Icon',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_control(
            'layout',
            array(
                'label' => 'Layout',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'inline',
                'options' => array(
                    'inline'  => 'Inline',
                    'stacked' => 'Stacked'
                )
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(
                'label' => 'Alignment',
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => array(
                    'flex-start' => array(
                        'title' => 'Left',
                        'icon' => 'eicon-h-align-left'
                    ),
                    'center' => array(
                        'title' => 'Center',
                        'icon' => 'eicon-h-align-center'
                    ),
                    'flex-end' => array(
                        'title' => 'Right',
                        'icon' => 'eicon-h-align-right'
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-wrapper' =>
                        'align-items:{{VALUE}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * CONTAINER STYLE
         * =================================================
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-email-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-email-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * ICON STYLE
         * =================================================
         */

        $this->start_controls_section(
            'icon_style',
            array(
                'label' => 'Icon',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_icon' => 'yes'
                )
            )
        );


        $this->add_control(
            'icon_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-icon' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_responsive_control(
            'icon_size',
            array(
                'label' => 'Size',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 8,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-icon' =>
                        'font-size:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LABEL STYLE
         * =================================================
         */

        $this->start_controls_section(
            'label_style',
            array(
                'label' => 'Label',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_label' => 'yes'
                )
            )
        );


        $this->add_control(
            'label_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-label' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'label_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-email-label'
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * EMAIL VALUE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'email_style',
            array(
                'label' => 'Email Address',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'email_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-email-value,
                     {{WRAPPER}} .rud-crm-email-value a' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'email_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-email-value'
            )
        );


        $this->end_controls_section();
    }


    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    private function get_email(
        $customer_id,
        $type
    ) {

        global $wpdb;


        return
            (string)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT contact_value
                     FROM {$wpdb->prefix}rudcrm_contact_methods
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $type
                )
            );
    }


    private function get_label(
        $type
    ) {

        $labels =
            array(
                'private_email' => 'Private Email',
                'work_email'    => 'Work Email'
            );


        return
            isset(
                $labels[
                    $type
                ]
            )
            ? $labels[
                $type
            ]
            : 'Email';
    }


    protected function render() {


        if (
            ! $this->is_editor()
        ) {

            if (
                function_exists(
                    'rud_crm_user_can_view'
                )
            ) {

                if (
                    ! rud_crm_user_can_view()
                ) {
                    return;
                }

            } elseif (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            ) {

                return;
            }
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No CRM customer available for preview.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $email_type =
            sanitize_key(
                $settings['email_type']
            );


        $email =
            trim(
                $this->get_email(
                    $customer_id,
                    $email_type
                )
            );


        if (
            '' ===
            $email
        ) {

            if (
                $this->is_editor()
            ) {

                $email =
                    'No email address saved';

            } else {

                return;
            }
        }


        $label =
            trim(
                (string)
                $settings['custom_label']
            );


        if (
            '' ===
            $label
        ) {

            $label =
                $this->get_label(
                    $email_type
                );
        }


        $layout_class =
            (
                'stacked' ===
                $settings['layout']
            )
            ? 'rud-crm-email-stacked'
            : 'rud-crm-email-inline';


        echo '<div class="rud-crm-email-wrapper ' .
            esc_attr(
                $layout_class
            ) .
            '">';


        if (
            'yes' ===
            $settings['show_icon']
        ) {

            echo '<span class="rud-crm-email-icon-wrap">';

            echo '<i class="fas fa-envelope rud-crm-email-icon" aria-hidden="true"></i>';

            echo '</span>';
        }


        echo '<div class="rud-crm-email-content">';


        if (
            'yes' ===
            $settings['show_label']
        ) {

            echo '<span class="rud-crm-email-label">';

            echo esc_html(
                $label
            );


            if (
                '' !==
                trim(
                    (string)
                    $settings['separator']
                )
            ) {

                echo esc_html(
                    $settings['separator']
                );
            }


            echo '</span>';
        }


        echo '<span class="rud-crm-email-value">';


        if (
            'yes' ===
            $settings['clickable']
            &&
            'No email address saved' !==
            $email
        ) {

            echo '<a href="mailto:' .
                esc_attr(
                    $email
                ) .
                '">';

            echo esc_html(
                $email
            );

            echo '</a>';

        } else {

            echo esc_html(
                $email
            );
        }


        echo '</span>';


        echo '</div>';

        echo '</div>';


        ?>

        <style>

        .rud-crm-email-wrapper {
            display:flex;
            width:100%;
            gap:10px;
        }

        .rud-crm-email-inline {
            flex-direction:row;
            align-items:center;
        }

        .rud-crm-email-stacked {
            flex-direction:column;
        }

        .rud-crm-email-icon-wrap {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            flex:0 0 auto;
        }

        .rud-crm-email-content {
            display:flex;
            gap:5px;
            min-width:0;
        }

        .rud-crm-email-stacked .rud-crm-email-content {
            flex-direction:column;
        }

        .rud-crm-email-label {
            font-weight:600;
        }

        .rud-crm-email-value {
            overflow-wrap:anywhere;
        }

        .rud-crm-email-value a {
            color:inherit;
            text-decoration:inherit;
        }

        </style>

        <?php
    }
}