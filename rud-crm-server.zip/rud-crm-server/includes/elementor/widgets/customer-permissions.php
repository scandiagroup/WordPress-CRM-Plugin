<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER PERMISSIONS WIDGET
 * DATABASE CONNECTED VERSION
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Permissions
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-permissions';
    }


    public function get_title() {

        return 'Customer Permissions';
    }


    public function get_icon() {

        return 'eicon-lock-user';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * =====================================================
     * CONTROLS
     * =====================================================
     */

    protected function register_controls() {


        /*
         * -------------------------------------------------
         * CONTENT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Permissions'
            )
        );


        $this->add_control(
            'show_heading',
            array(
                'label' => 'Show Heading',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'heading',
            array(
                'label' => 'Heading',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Customer Permissions',
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'show_allowed',
            array(
                'label' => 'Show Allowed',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'show_not_allowed',
            array(
                'label' => 'Show Not Allowed',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'allowed_text',
            array(
                'label' => 'Allowed Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Allowed'
            )
        );


        $this->add_control(
            'not_allowed_text',
            array(
                'label' => 'Not Allowed Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Not Allowed'
            )
        );


        $this->add_control(
            'empty_message',
            array(
                'label' => 'Empty Message',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'No customer permissions have been saved yet.'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * LAYOUT
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 80
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-grid' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * CONTAINER STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'container_style',
            array(
                'label' => 'Container',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-wrapper' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-wrapper'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-wrapper'
            )
        );


        $this->add_responsive_control(
            'padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-wrapper' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-wrapper' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * HEADING STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'heading_style',
            array(
                'label' => 'Heading',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_heading' => 'yes'
                )
            )
        );


        $this->add_control(
            'heading_color',
            array(
                'label' => 'Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permissions-heading' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'heading_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permissions-heading'
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * ITEM STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'item_style',
            array(
                'label' => 'Permission Items',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'item_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-item' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'item_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permission-item'
            )
        );


        $this->add_responsive_control(
            'item_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-item' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'item_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-item' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * -------------------------------------------------
         * STATUS STYLE
         * -------------------------------------------------
         */

        $this->start_controls_section(
            'status_style',
            array(
                'label' => 'Status',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'allowed_color',
            array(
                'label' => 'Allowed Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-allowed' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'not_allowed_color',
            array(
                'label' => 'Not Allowed Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-permission-not-allowed' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'status_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-permission-status'
            )
        );


        $this->end_controls_section();
    }


    /*
     * =====================================================
     * EDITOR CHECK
     * =====================================================
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * =====================================================
     * ACCESS
     * =====================================================
     */

    private function can_view() {

        if (
            $this->is_editor()
        ) {

            return true;
        }


        if (
            function_exists(
                'rud_crm_user_can_view'
            )
        ) {

            return rud_crm_user_can_view();
        }


        return
            is_user_logged_in()
            &&
            current_user_can(
                'manage_options'
            );
    }


    /*
     * =====================================================
     * CUSTOMER ID
     * =====================================================
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * =====================================================
     * RENDER
     * =====================================================
     */

    protected function render() {


        if (
            ! $this->can_view()
        ) {

            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>No CRM customer available for preview.</div>';
            }


            return;
        }


        $settings =
            $this->get_settings_for_display();


        /*
         * -------------------------------------------------
         * REAL PERMISSION DEFINITIONS
         * -------------------------------------------------
         */

        if (
            function_exists(
                'rud_crm_customer_permission_definitions'
            )
        ) {

            $definitions =
                rud_crm_customer_permission_definitions();

        } else {

            $definitions =
                array();
        }


        /*
         * -------------------------------------------------
         * REAL CUSTOMER PERMISSION VALUES
         * -------------------------------------------------
         */

        if (
            function_exists(
                'rud_crm_get_customer_permissions'
            )
        ) {

            $permissions =
                rud_crm_get_customer_permissions(
                    $customer_id
                );

        } else {

            $permissions =
                array();
        }


        echo '<div class="rud-crm-permissions-wrapper">';


        /*
         * HEADING
         */

        if (
            'yes' ===
            $settings['show_heading']
        ) {

            echo '<h3 class="rud-crm-permissions-heading">';

            echo esc_html(
                $settings['heading']
            );

            echo '</h3>';
        }


        /*
         * NO DEFINITIONS
         */

        if (
            empty(
                $definitions
            )
        ) {

            echo '<div class="rud-crm-permissions-empty">';

            echo 'Customer permission definitions are not available.';

            echo '</div>';

            echo '</div>';

            return;
        }


        /*
         * -------------------------------------------------
         * PERMISSION GRID
         * -------------------------------------------------
         */

        echo '<div class="rud-crm-permissions-grid">';


        $shown =
            0;


        foreach (
            $definitions as
            $permission_key =>
            $label
        ) {

            $allowed =
                false;


            if (
                isset(
                    $permissions[
                        $permission_key
                    ]
                )
            ) {

                $allowed =
                    ! empty(
                        $permissions[
                            $permission_key
                        ]['value']
                    );
            }


            if (
                $allowed
                &&
                'yes' !==
                $settings['show_allowed']
            ) {

                continue;
            }


            if (
                ! $allowed
                &&
                'yes' !==
                $settings['show_not_allowed']
            ) {

                continue;
            }


            $shown++;


            echo '<div class="rud-crm-permission-item">';


            echo '<div class="rud-crm-permission-main">';


            echo '<div class="rud-crm-permission-name">';

            echo esc_html(
                $label
            );

            echo '</div>';


            /*
             * -------------------------------------------------
             * SOURCE / DATE
             * -------------------------------------------------
             */

            if (
                isset(
                    $permissions[
                        $permission_key
                    ]
                )
            ) {

                $permission_data =
                    $permissions[
                        $permission_key
                    ];


                if (
                    ! empty(
                        $permission_data['source']
                    )
                ) {

                    echo '<div class="rud-crm-permission-source">';

                    echo 'Source: ';

                    echo esc_html(
                        $permission_data['source']
                    );

                    echo '</div>';
                }


                if (
                    $allowed
                    &&
                    ! empty(
                        $permission_data['granted_at']
                    )
                ) {

                    echo '<div class="rud-crm-permission-date">';

                    echo 'Granted: ';

                    echo esc_html(
                        $permission_data['granted_at']
                    );

                    echo '</div>';
                }


                if (
                    ! $allowed
                    &&
                    ! empty(
                        $permission_data['revoked_at']
                    )
                ) {

                    echo '<div class="rud-crm-permission-date">';

                    echo 'Revoked: ';

                    echo esc_html(
                        $permission_data['revoked_at']
                    );

                    echo '</div>';
                }
            }


            echo '</div>';


            /*
             * -------------------------------------------------
             * STATUS
             * -------------------------------------------------
             */

            if (
                $allowed
            ) {

                echo '<div class="rud-crm-permission-status rud-crm-permission-allowed">';

                echo esc_html(
                    $settings['allowed_text']
                );

                echo '</div>';

            } else {

                echo '<div class="rud-crm-permission-status rud-crm-permission-not-allowed">';

                echo esc_html(
                    $settings['not_allowed_text']
                );

                echo '</div>';
            }


            echo '</div>';
        }


        echo '</div>';


        if (
            0 ===
            $shown
        ) {

            echo '<div class="rud-crm-permissions-empty">';

            echo esc_html(
                $settings['empty_message']
            );

            echo '</div>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-permissions-wrapper {
            width:100%;
        }

        .rud-crm-permissions-heading {
            margin-top:0;
            margin-bottom:16px;
        }

        .rud-crm-permissions-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-permission-item {
            display:flex;
            align-items:flex-start;
            justify-content:space-between;
            gap:15px;
            padding:12px;
        }

        .rud-crm-permission-main {
            min-width:0;
        }

        .rud-crm-permission-name {
            font-weight:600;
            overflow-wrap:anywhere;
        }

        .rud-crm-permission-source,
        .rud-crm-permission-date {
            margin-top:3px;
            font-size:11px;
            opacity:.65;
        }

        .rud-crm-permission-status {
            flex:0 0 auto;
            font-weight:600;
        }

        .rud-crm-permission-allowed {
            color:#2e7d32;
        }

        .rud-crm-permission-not-allowed {
            color:#b3261e;
        }

        .rud-crm-permissions-empty {
            margin-top:12px;
            opacity:.7;
        }

        </style>

        <?php
    }
}