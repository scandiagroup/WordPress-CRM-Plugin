<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER GALLERY WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Gallery
    extends \Elementor\Widget_Base {


    public function get_name() {

        return 'rud-crm-customer-gallery';
    }


    public function get_title() {

        return 'Customer Gallery';
    }


    public function get_icon() {

        return 'eicon-gallery-grid';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    protected function register_controls() {


        /*
         * =================================================
         * CONTENT
         * =================================================
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Gallery'
            )
        );


        $this->add_control(
            'image_size',
            array(
                'label' => 'Image Size',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'large',
                'options' => array(
                    'thumbnail' => 'Thumbnail',
                    'medium'    => 'Medium',
                    'large'     => 'Large',
                    'full'      => 'Full'
                )
            )
        );


        $this->add_control(
            'show_primary_badge',
            array(
                'label' => 'Show Primary Badge',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'primary_badge_text',
            array(
                'label' => 'Primary Badge Text',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'Primary',
                'condition' => array(
                    'show_primary_badge' => 'yes'
                )
            )
        );


        $this->add_control(
            'link_full_image',
            array(
                'label' => 'Link to Full Image',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes'
            )
        );


        $this->add_control(
            'open_new_window',
            array(
                'label' => 'Open Full Image in New Window',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => array(
                    'link_full_image' => 'yes'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * LAYOUT
         * =================================================
         */

        $this->start_controls_section(
            'layout_section',
            array(
                'label' => 'Layout'
            )
        );


        $this->add_responsive_control(
            'columns',
            array(
                'label' => 'Columns',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '5',
                'tablet_default' => '3',
                'mobile_default' => '2',
                'options' => array(
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-grid' =>
                        'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));'
                )
            )
        );


        $this->add_responsive_control(
            'gap',
            array(
                'label' => 'Gap',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 0,
                        'max' => 100
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-grid' =>
                        'gap:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * IMAGE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'image_style',
            array(
                'label' => 'Images',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_responsive_control(
            'image_height',
            array(
                'label' => 'Image Height',
                'type' => \Elementor\Controls_Manager::SLIDER,
                'range' => array(
                    'px' => array(
                        'min' => 50,
                        'max' => 1000
                    )
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-image img' =>
                        'height:{{SIZE}}{{UNIT}};'
                )
            )
        );


        $this->add_control(
            'object_fit',
            array(
                'label' => 'Object Fit',
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => array(
                    'cover'   => 'Cover',
                    'contain' => 'Contain',
                    'fill'    => 'Fill'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-image img' =>
                        'object-fit:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            array(
                'name' => 'image_border',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-gallery-image img'
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            array(
                'name' => 'image_shadow',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-gallery-image img'
            )
        );


        $this->add_responsive_control(
            'image_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-image img' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();


        /*
         * =================================================
         * PRIMARY BADGE STYLE
         * =================================================
         */

        $this->start_controls_section(
            'badge_style',
            array(
                'label' => 'Primary Badge',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => array(
                    'show_primary_badge' => 'yes'
                )
            )
        );


        $this->add_control(
            'badge_background',
            array(
                'label' => 'Background',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-primary' =>
                        'background-color:{{VALUE}};'
                )
            )
        );


        $this->add_control(
            'badge_color',
            array(
                'label' => 'Text Color',
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-primary' =>
                        'color:{{VALUE}};'
                )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(
                'name' => 'badge_typography',
                'selector' =>
                    '{{WRAPPER}} .rud-crm-gallery-primary'
            )
        );


        $this->add_responsive_control(
            'badge_padding',
            array(
                'label' => 'Padding',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    'em'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-primary' =>
                        'padding:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->add_responsive_control(
            'badge_radius',
            array(
                'label' => 'Border Radius',
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => array(
                    'px',
                    '%'
                ),
                'selectors' => array(
                    '{{WRAPPER}} .rud-crm-gallery-primary' =>
                        'border-radius:{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};'
                )
            )
        );


        $this->end_controls_section();
    }


    /*
     * -----------------------------------------------------
     * ELEMENTOR EDITOR CHECK
     * -----------------------------------------------------
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * -----------------------------------------------------
     * GET CUSTOMER ID
     * -----------------------------------------------------
     */

    private function get_customer_id() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ? absint(
                $_GET['rud_customer_id']
            )
            : 0;


        if (
            ! $customer_id
            &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        return $customer_id;
    }


    /*
     * -----------------------------------------------------
     * GET CUSTOMER IMAGES
     * -----------------------------------------------------
     */

    private function get_images(
        $customer_id
    ) {

        global $wpdb;


        return
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customer_images
                     WHERE customer_id = %d
                     ORDER BY is_primary DESC,
                              sort_order ASC,
                              id ASC",
                    $customer_id
                )
            );
    }


    /*
     * -----------------------------------------------------
     * RENDER
     * -----------------------------------------------------
     */

    protected function render() {


        /*
         * SECURITY
         */

        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {
            return;
        }


        $customer_id =
            $this->get_customer_id();


        if (
            ! $customer_id
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No customer available for preview.';
            }

            return;
        }


        $images =
            $this->get_images(
                $customer_id
            );


        if (
            empty(
                $images
            )
        ) {

            if (
                $this->is_editor()
            ) {

                echo 'No customer images available.';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        echo '<div class="rud-crm-gallery-grid">';


        foreach (
            $images as
            $image
        ) {

            $image_url =
                wp_get_attachment_image_url(
                    $image->attachment_id,
                    $settings['image_size']
                );


            $full_url =
                wp_get_attachment_image_url(
                    $image->attachment_id,
                    'full'
                );


            if (
                ! $image_url
            ) {
                continue;
            }


            echo '<div class="rud-crm-gallery-image">';


            /*
             * LINK START
             */

            if (
                'yes' ===
                $settings['link_full_image']
                &&
                $full_url
            ) {

                echo '<a
                    href="' .
                    esc_url(
                        $full_url
                    ) .
                    '"';


                if (
                    'yes' ===
                    $settings['open_new_window']
                ) {

                    echo ' target="_blank" rel="noopener noreferrer"';
                }


                echo '>';
            }


            /*
             * IMAGE
             */

            echo '<img
                src="' .
                esc_url(
                    $image_url
                ) .
                '"
                alt=""
                loading="lazy"
            >';


            /*
             * LINK END
             */

            if (
                'yes' ===
                $settings['link_full_image']
                &&
                $full_url
            ) {

                echo '</a>';
            }


            /*
             * PRIMARY BADGE
             */

            if (
                'yes' ===
                $settings['show_primary_badge']
                &&
                (int)
                $image->is_primary === 1
            ) {

                echo '<span class="rud-crm-gallery-primary">';

                echo esc_html(
                    $settings['primary_badge_text']
                );

                echo '</span>';
            }


            echo '</div>';
        }


        echo '</div>';


        ?>

        <style>

        .rud-crm-gallery-grid {
            display:grid;
            grid-template-columns:repeat(5,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-gallery-image {
            position:relative;
            min-width:0;
        }

        .rud-crm-gallery-image img {
            display:block;
            width:100%;
            aspect-ratio:1 / 1;
            object-fit:cover;
        }

        .rud-crm-gallery-image a {
            display:block;
        }

        .rud-crm-gallery-primary {
            position:absolute;
            left:8px;
            bottom:8px;
            display:inline-block;
            background:#ffffff;
            color:#222222;
            padding:4px 8px;
            border-radius:999px;
            font-size:10px;
            font-weight:700;
            line-height:1.2;
        }

        </style>

        <?php
    }
}