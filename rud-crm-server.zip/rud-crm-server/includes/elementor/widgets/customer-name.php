<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * CUSTOMER NAME WIDGET
 * =========================================================
 */

class RUD_CRM_Elementor_Customer_Name extends \Elementor\Widget_Base {


    /*
     * -----------------------------------------------------
     * WIDGET IDENTIFICATION
     * -----------------------------------------------------
     */

    public function get_name() {

        return 'rud-crm-customer-name';
    }


    public function get_title() {

        return 'Customer Name';
    }


    public function get_icon() {

        return 'eicon-person';
    }


    public function get_categories() {

        return array(
            'rud-crm'
        );
    }


    /*
     * -----------------------------------------------------
     * ELEMENTOR CONTROLS
     * -----------------------------------------------------
     */

    protected function register_controls() {


        /*
         * CONTENT
         */

        $this->start_controls_section(
            'content_section',
            array(
                'label' => 'Customer Name'
            )
        );


        $this->add_control(
            'name_format',
            array(
                'label' => 'Name Format',

                'type' =>
                    \Elementor\Controls_Manager::SELECT,

                'default' =>
                    'full',

                'options' =>
                    array(

                        'full' =>
                            'Full Name',

                        'first' =>
                            'First Name',

                        'middle' =>
                            'Middle Name',

                        'last' =>
                            'Last Name',

                        'preferred' =>
                            'Preferred Name',

                        'company' =>
                            'Company Name'
                    )
            )
        );


        $this->add_control(
            'html_tag',
            array(
                'label' =>
                    'HTML Tag',

                'type' =>
                    \Elementor\Controls_Manager::SELECT,

                'default' =>
                    'h2',

                'options' =>
                    array(

                        'h1' => 'H1',
                        'h2' => 'H2',
                        'h3' => 'H3',
                        'h4' => 'H4',
                        'h5' => 'H5',
                        'h6' => 'H6',
                        'div' => 'DIV',
                        'p'   => 'P',
                        'span'=> 'SPAN'
                    )
            )
        );


        $this->end_controls_section();


        /*
         * STYLE
         */

        $this->start_controls_section(
            'style_section',
            array(

                'label' =>
                    'Style',

                'tab' =>
                    \Elementor\Controls_Manager::TAB_STYLE
            )
        );


        $this->add_control(
            'text_color',
            array(

                'label' =>
                    'Text Color',

                'type' =>
                    \Elementor\Controls_Manager::COLOR,

                'selectors' =>
                    array(

                        '{{WRAPPER}} .rud-crm-customer-name' =>
                            'color: {{VALUE}};'
                    )
            )
        );


        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            array(

                'name' =>
                    'typography',

                'selector' =>
                    '{{WRAPPER}} .rud-crm-customer-name'
            )
        );


        $this->add_responsive_control(
            'alignment',
            array(

                'label' =>
                    'Alignment',

                'type' =>
                    \Elementor\Controls_Manager::CHOOSE,

                'options' =>
                    array(

                        'left' =>
                            array(
                                'title' =>
                                    'Left',

                                'icon' =>
                                    'eicon-text-align-left'
                            ),

                        'center' =>
                            array(
                                'title' =>
                                    'Center',

                                'icon' =>
                                    'eicon-text-align-center'
                            ),

                        'right' =>
                            array(
                                'title' =>
                                    'Right',

                                'icon' =>
                                    'eicon-text-align-right'
                            )
                    ),

                'selectors' =>
                    array(

                        '{{WRAPPER}} .rud-crm-customer-name' =>
                            'text-align: {{VALUE}};'
                    )
            )
        );


        $this->end_controls_section();
    }


    /*
     * -----------------------------------------------------
     * CHECK ELEMENTOR EDITOR
     * -----------------------------------------------------
     */

    private function is_editor() {

        return
            isset(
                \Elementor\Plugin::$instance->editor
            )
            &&
            \Elementor\Plugin::$instance
                ->editor
                ->is_edit_mode();
    }


    /*
     * -----------------------------------------------------
     * GET CUSTOMER
     * -----------------------------------------------------
     */

    private function get_customer() {

        global $wpdb;


        $customer_id =
            isset(
                $_GET['rud_customer_id']
            )
            ?
            absint(
                $_GET['rud_customer_id']
            )
            :
            0;


        /*
         * Elementor preview:
         * automatically use first CRM customer.
         */

        if (
            ! $customer_id &&
            $this->is_editor()
        ) {

            $customer_id =
                (int)
                $wpdb->get_var(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id ASC
                     LIMIT 1"
                );
        }


        if (
            ! $customer_id
        ) {

            return null;
        }


        return
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }


    /*
     * -----------------------------------------------------
     * CUSTOMER NAME
     * -----------------------------------------------------
     */

    private function get_customer_name(
        $customer,
        $format
    ) {

        switch (
            $format
        ) {


            case 'first':

                return
                    $customer->first_name ?? '';


            case 'middle':

                return
                    $customer->middle_name ?? '';


            case 'last':

                return
                    $customer->last_name ?? '';


            case 'preferred':

                return
                    $customer->preferred_name ?? '';


            case 'company':

                return
                    $customer->company_name ?? '';


            case 'full':

            default:

                $name =
                    trim(
                        implode(
                            ' ',
                            array_filter(
                                array(
                                    $customer->first_name ?? '',
                                    $customer->middle_name ?? '',
                                    $customer->last_name ?? ''
                                )
                            )
                        )
                    );


                if (
                    '' !==
                    $name
                ) {

                    return
                        $name;
                }


                if (
                    ! empty(
                        $customer->company_name
                    )
                ) {

                    return
                        $customer->company_name;
                }


                return
                    'Unnamed Customer';
        }
    }


    /*
     * -----------------------------------------------------
     * RENDER
     * -----------------------------------------------------
     */

    protected function render() {


        /*
         * SECURITY
         */

        if (
            ! $this->is_editor()
            &&
            (
                ! is_user_logged_in()
                ||
                ! current_user_can(
                    'manage_options'
                )
            )
        ) {

            return;
        }


        $customer =
            $this->get_customer();


        if (
            ! $customer
        ) {

            if (
                $this->is_editor()
            ) {

                echo '<div>';
                echo 'No CRM customer available for preview.';
                echo '</div>';
            }

            return;
        }


        $settings =
            $this->get_settings_for_display();


        $name =
            $this->get_customer_name(
                $customer,
                $settings['name_format']
            );


        if (
            '' ===
            trim(
                (string)
                $name
            )
        ) {

            $name =
                'Not specified';
        }


        $allowed_tags =
            array(
                'h1',
                'h2',
                'h3',
                'h4',
                'h5',
                'h6',
                'div',
                'p',
                'span'
            );


        $tag =
            in_array(
                $settings['html_tag'],
                $allowed_tags,
                true
            )
            ?
            $settings['html_tag']
            :
            'h2';


        echo '<' .
            esc_attr(
                $tag
            ) .
            ' class="rud-crm-customer-name">';


        echo esc_html(
            $name
        );


        echo '</' .
            esc_attr(
                $tag
            ) .
            '>';
    }
}