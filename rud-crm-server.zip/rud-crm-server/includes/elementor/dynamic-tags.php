<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR
 * DYNAMIC TAGS
 * =========================================================
 *
 * Adds CRM data as Elementor Dynamic Tags.
 *
 * Text tags:
 * - Customer Name
 * - Customer Number
 * - Customer Status
 * - Company Name
 * - Organization Number
 * - Job Title
 * - Department
 * - Private Email
 * - Work Email
 * - Mobile Phone
 * - Home Phone
 * - Office Phone
 * - WhatsApp
 * - Address Line 1
 * - Address Line 2
 * - Postal Code
 * - City
 * - State / Region
 * - Country
 * - Notes
 *
 * Image tag:
 * - Primary Customer Image
 *
 * URL tag:
 * - Customer Profile URL
 *
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CURRENT CUSTOMER ID
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_customer_id() {

    global $wpdb;


    $customer_id =
        isset(
            $_GET['rud_customer_id']
        )
        ? absint(
            $_GET['rud_customer_id']
        )
        : 0;


    /*
     * Elementor editor preview:
     * use first customer if no customer is selected.
     */

    if (
        ! $customer_id
        &&
        isset(
            \Elementor\Plugin::$instance->editor
        )
        &&
        \Elementor\Plugin::$instance
            ->editor
            ->is_edit_mode()
    ) {

        $customer_id =
            (int)
            $wpdb->get_var(
                "SELECT id
                 FROM {$wpdb->prefix}rudcrm_customers
                 ORDER BY id ASC
                 LIMIT 1"
            );
    }


    return $customer_id;
}


/*
 * ---------------------------------------------------------
 * GET CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_customer() {

    global $wpdb;


    $customer_id =
        rud_crm_elementor_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return null;
    }


    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customers
             WHERE id = %d
             LIMIT 1",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET DETAILS
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_details() {

    global $wpdb;


    $customer_id =
        rud_crm_elementor_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return null;
    }


    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customer_details
             WHERE customer_id = %d
             LIMIT 1",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET CONTACT
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_contact(
    $type
) {

    global $wpdb;


    $customer_id =
        rud_crm_elementor_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return '';
    }


    return
        (string)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT contact_value
                 FROM {$wpdb->prefix}rudcrm_contact_methods
                 WHERE customer_id = %d
                 AND contact_type = %s
                 ORDER BY is_primary DESC, id ASC
                 LIMIT 1",
                $customer_id,
                $type
            )
        );
}


/*
 * ---------------------------------------------------------
 * GET ADDRESS
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_address() {

    global $wpdb;


    $customer_id =
        rud_crm_elementor_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return null;
    }


    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_addresses
             WHERE customer_id = %d
             AND address_type = 'private'
             ORDER BY is_primary DESC, id ASC
             LIMIT 1",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET PRIMARY IMAGE
 * ---------------------------------------------------------
 */

function rud_crm_elementor_dynamic_primary_image_id() {

    global $wpdb;


    $customer_id =
        rud_crm_elementor_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return 0;
    }


    return
        (int)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT attachment_id
                 FROM {$wpdb->prefix}rudcrm_customer_images
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC, sort_order ASC, id ASC
                 LIMIT 1",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * BASE TEXT TAG
 * =========================================================
 */

abstract class RUD_CRM_Elementor_Dynamic_Text_Tag
    extends \Elementor\Core\DynamicTags\Tag {


    public function get_group() {

        return 'rud-crm';
    }


    public function get_categories() {

        return array(
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY
        );
    }


    protected function register_controls() {
    }
}


/*
 * =========================================================
 * CUSTOMER NAME
 * =========================================================
 */

class RUD_CRM_Dynamic_Customer_Name
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-customer-name';
    }


    public function get_title() {

        return 'CRM Customer Name';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        if (
            '' ===
            $name
            &&
            ! empty(
                $customer->company_name
            )
        ) {

            $name =
                $customer->company_name;
        }


        echo esc_html(
            $name
        );
    }
}


/*
 * =========================================================
 * CUSTOMER NUMBER
 * =========================================================
 */

class RUD_CRM_Dynamic_Customer_Number
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-customer-number';
    }


    public function get_title() {

        return 'CRM Customer Number';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        echo esc_html(
            $customer->customer_number ?? ''
        );
    }
}


/*
 * =========================================================
 * CUSTOMER STATUS
 * =========================================================
 */

class RUD_CRM_Dynamic_Customer_Status
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-customer-status';
    }


    public function get_title() {

        return 'CRM Customer Status';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        $status =
            $customer->status ?? '';


        echo esc_html(
            ucwords(
                str_replace(
                    array(
                        '_',
                        '-'
                    ),
                    ' ',
                    $status
                )
            )
        );
    }
}


/*
 * =========================================================
 * COMPANY NAME
 * =========================================================
 */

class RUD_CRM_Dynamic_Company_Name
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-company-name';
    }


    public function get_title() {

        return 'CRM Company Name';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        echo esc_html(
            $customer->company_name ?? ''
        );
    }
}


/*
 * =========================================================
 * ORGANIZATION NUMBER
 * =========================================================
 */

class RUD_CRM_Dynamic_Organization_Number
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-organization-number';
    }


    public function get_title() {

        return 'CRM Organization Number';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        echo esc_html(
            $customer->organization_number ?? ''
        );
    }
}


/*
 * =========================================================
 * JOB TITLE
 * =========================================================
 */

class RUD_CRM_Dynamic_Job_Title
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-job-title';
    }


    public function get_title() {

        return 'CRM Job Title';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        echo esc_html(
            $customer->job_title ?? ''
        );
    }
}


/*
 * =========================================================
 * DEPARTMENT
 * =========================================================
 */

class RUD_CRM_Dynamic_Department
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-department';
    }


    public function get_title() {

        return 'CRM Department';
    }


    public function render() {

        $customer =
            rud_crm_elementor_dynamic_customer();


        if (
            ! $customer
        ) {
            return;
        }


        echo esc_html(
            $customer->department ?? ''
        );
    }
}


/*
 * =========================================================
 * PRIVATE EMAIL
 * =========================================================
 */

class RUD_CRM_Dynamic_Private_Email
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-private-email';
    }


    public function get_title() {

        return 'CRM Private Email';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'private_email'
            )
        );
    }
}


/*
 * =========================================================
 * WORK EMAIL
 * =========================================================
 */

class RUD_CRM_Dynamic_Work_Email
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-work-email';
    }


    public function get_title() {

        return 'CRM Work Email';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'work_email'
            )
        );
    }
}


/*
 * =========================================================
 * MOBILE PHONE
 * =========================================================
 */

class RUD_CRM_Dynamic_Mobile_Phone
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-mobile-phone';
    }


    public function get_title() {

        return 'CRM Mobile Phone';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'mobile_phone'
            )
        );
    }
}


/*
 * =========================================================
 * HOME PHONE
 * =========================================================
 */

class RUD_CRM_Dynamic_Home_Phone
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-home-phone';
    }


    public function get_title() {

        return 'CRM Home Phone';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'home_phone'
            )
        );
    }
}


/*
 * =========================================================
 * OFFICE PHONE
 * =========================================================
 */

class RUD_CRM_Dynamic_Office_Phone
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-office-phone';
    }


    public function get_title() {

        return 'CRM Office Phone';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'office_phone'
            )
        );
    }
}


/*
 * =========================================================
 * WHATSAPP
 * =========================================================
 */

class RUD_CRM_Dynamic_WhatsApp
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-whatsapp';
    }


    public function get_title() {

        return 'CRM WhatsApp';
    }


    public function render() {

        echo esc_html(
            rud_crm_elementor_dynamic_contact(
                'whatsapp'
            )
        );
    }
}


/*
 * =========================================================
 * ADDRESS TAG BASE
 * =========================================================
 */

abstract class RUD_CRM_Dynamic_Address_Tag
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    protected function address_value(
        $field
    ) {

        $address =
            rud_crm_elementor_dynamic_address();


        if (
            ! $address
        ) {

            return '';
        }


        return
            $address->$field ?? '';
    }
}


/*
 * =========================================================
 * ADDRESS LINE 1
 * =========================================================
 */

class RUD_CRM_Dynamic_Address_Line_1
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-address-line-1';
    }


    public function get_title() {

        return 'CRM Address Line 1';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'address_line_1'
            )
        );
    }
}


/*
 * =========================================================
 * ADDRESS LINE 2
 * =========================================================
 */

class RUD_CRM_Dynamic_Address_Line_2
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-address-line-2';
    }


    public function get_title() {

        return 'CRM Address Line 2';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'address_line_2'
            )
        );
    }
}


/*
 * =========================================================
 * POSTAL CODE
 * =========================================================
 */

class RUD_CRM_Dynamic_Postal_Code
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-postal-code';
    }


    public function get_title() {

        return 'CRM Postal Code';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'postal_code'
            )
        );
    }
}


/*
 * =========================================================
 * CITY
 * =========================================================
 */

class RUD_CRM_Dynamic_City
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-city';
    }


    public function get_title() {

        return 'CRM City';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'city'
            )
        );
    }
}


/*
 * =========================================================
 * STATE / REGION
 * =========================================================
 */

class RUD_CRM_Dynamic_State_Region
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-state-region';
    }


    public function get_title() {

        return 'CRM State / Region';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'state_region'
            )
        );
    }
}


/*
 * =========================================================
 * COUNTRY
 * =========================================================
 */

class RUD_CRM_Dynamic_Country
    extends RUD_CRM_Dynamic_Address_Tag {


    public function get_name() {

        return 'rud-crm-country';
    }


    public function get_title() {

        return 'CRM Country';
    }


    public function render() {

        echo esc_html(
            $this->address_value(
                'country_code'
            )
        );
    }
}


/*
 * =========================================================
 * NOTES
 * =========================================================
 */

class RUD_CRM_Dynamic_Notes
    extends RUD_CRM_Elementor_Dynamic_Text_Tag {


    public function get_name() {

        return 'rud-crm-notes';
    }


    public function get_title() {

        return 'CRM Notes';
    }


    public function render() {

        $details =
            rud_crm_elementor_dynamic_details();


        if (
            ! $details
        ) {
            return;
        }


        echo esc_html(
            $details->notes ?? ''
        );
    }
}


/*
 * =========================================================
 * PRIMARY IMAGE TAG
 * =========================================================
 */

class RUD_CRM_Dynamic_Primary_Image
    extends \Elementor\Core\DynamicTags\Data_Tag {


    public function get_name() {

        return 'rud-crm-primary-image';
    }


    public function get_title() {

        return 'CRM Primary Customer Image';
    }


    public function get_group() {

        return 'rud-crm';
    }


    public function get_categories() {

        return array(
            \Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY
        );
    }


    protected function register_controls() {
    }


    public function get_value(
        array $options = array()
    ) {

        $attachment_id =
            rud_crm_elementor_dynamic_primary_image_id();


        if (
            ! $attachment_id
        ) {

            return array(
                'id'  => 0,
                'url' => ''
            );
        }


        $url =
            wp_get_attachment_image_url(
                $attachment_id,
                'full'
            );


        return array(
            'id' =>
                $attachment_id,

            'url' =>
                $url
                ? $url
                : ''
        );
    }
}


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

class RUD_CRM_Dynamic_Profile_URL
    extends \Elementor\Core\DynamicTags\Tag {


    public function get_name() {

        return 'rud-crm-profile-url';
    }


    public function get_title() {

        return 'CRM Customer Profile URL';
    }


    public function get_group() {

        return 'rud-crm';
    }


    public function get_categories() {

        return array(
            \Elementor\Modules\DynamicTags\Module::URL_CATEGORY
        );
    }


    protected function register_controls() {
    }


    public function render() {

        $customer_id =
            rud_crm_elementor_dynamic_customer_id();


        if (
            ! $customer_id
        ) {
            return;
        }


        echo esc_url(
            add_query_arg(
                'rud_customer_id',
                $customer_id
            )
        );
    }
}


/*
 * =========================================================
 * REGISTER DYNAMIC TAG GROUP
 * =========================================================
 */

function rud_crm_elementor_register_dynamic_tag_group(
    $dynamic_tags_manager
) {

    $dynamic_tags_manager->register_group(
        'rud-crm',
        array(
            'title' =>
                'RUD CRM'
        )
    );
}

add_action(
    'elementor/dynamic_tags/register',
    'rud_crm_elementor_register_dynamic_tag_group',
    5
);


/*
 * =========================================================
 * REGISTER DYNAMIC TAGS
 * =========================================================
 */

function rud_crm_elementor_register_dynamic_tags(
    $dynamic_tags_manager
) {

    $tags =
        array(

            'RUD_CRM_Dynamic_Customer_Name',

            'RUD_CRM_Dynamic_Customer_Number',

            'RUD_CRM_Dynamic_Customer_Status',

            'RUD_CRM_Dynamic_Company_Name',

            'RUD_CRM_Dynamic_Organization_Number',

            'RUD_CRM_Dynamic_Job_Title',

            'RUD_CRM_Dynamic_Department',

            'RUD_CRM_Dynamic_Private_Email',

            'RUD_CRM_Dynamic_Work_Email',

            'RUD_CRM_Dynamic_Mobile_Phone',

            'RUD_CRM_Dynamic_Home_Phone',

            'RUD_CRM_Dynamic_Office_Phone',

            'RUD_CRM_Dynamic_WhatsApp',

            'RUD_CRM_Dynamic_Address_Line_1',

            'RUD_CRM_Dynamic_Address_Line_2',

            'RUD_CRM_Dynamic_Postal_Code',

            'RUD_CRM_Dynamic_City',

            'RUD_CRM_Dynamic_State_Region',

            'RUD_CRM_Dynamic_Country',

            'RUD_CRM_Dynamic_Notes',

            'RUD_CRM_Dynamic_Primary_Image',

            'RUD_CRM_Dynamic_Profile_URL'
        );


    foreach (
        $tags as
        $tag_class
    ) {

        if (
            class_exists(
                $tag_class
            )
        ) {

            $dynamic_tags_manager->register(
                new $tag_class()
            );
        }
    }
}

add_action(
    'elementor/dynamic_tags/register',
    'rud_crm_elementor_register_dynamic_tags',
    20
);