<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM ELEMENTOR INTEGRATION
 * =========================================================
 */


/*
 * =========================================================
 * LOAD V4 DYNAMIC TAG TEST
 * =========================================================
 */

$rud_crm_v4_dynamic_tags_file =
    __DIR__ .
    '/dynamic-tags-v4.php';

if (
    file_exists(
        $rud_crm_v4_dynamic_tags_file
    )
) {

    require_once
        $rud_crm_v4_dynamic_tags_file;
}


/*
 * ---------------------------------------------------------
 * WIDGET DEFINITIONS
 * ---------------------------------------------------------
 */

function rud_crm_elementor_widget_definitions() {

    return array(

        array(
            'name'  => 'Customer Table',
            'file'  => 'customer-table.php',
            'class' => 'RUD_CRM_Elementor_Customer_Table'
        ),

        array(
            'name'  => 'Customer Cards',
            'file'  => 'customer-cards.php',
            'class' => 'RUD_CRM_Elementor_Customer_Cards'
        ),

        array(
            'name'  => 'Customer Profile Block',
            'file'  => 'customer-profile-block.php',
            'class' => 'RUD_CRM_Elementor_Customer_Profile_Block'
        ),

        array(
            'name'  => 'Customer Name',
            'file'  => 'customer-name.php',
            'class' => 'RUD_CRM_Elementor_Customer_Name'
        ),

        array(
            'name'  => 'Customer Number',
            'file'  => 'customer-number.php',
            'class' => 'RUD_CRM_Elementor_Customer_Number'
        ),

        array(
            'name'  => 'Customer Status',
            'file'  => 'customer-status.php',
            'class' => 'RUD_CRM_Elementor_Customer_Status'
        ),

        array(
            'name'  => 'Customer Company',
            'file'  => 'customer-company-widget.php',
            'class' => 'RUD_CRM_Elementor_Company_Widget'
        ),

        array(
            'name'  => 'Customer Details',
            'file'  => 'customer-details.php',
            'class' => 'RUD_CRM_Elementor_Customer_Details'
        ),

        array(
            'name'  => 'Customer Phone',
            'file'  => 'customer-phone.php',
            'class' => 'RUD_CRM_Elementor_Customer_Phone'
        ),

        array(
            'name'  => 'Customer Email',
            'file'  => 'customer-email.php',
            'class' => 'RUD_CRM_Elementor_Customer_Email'
        ),

        array(
            'name'  => 'Customer Search',
            'file'  => 'customer-search.php',
            'class' => 'RUD_CRM_Elementor_Customer_Search'
        ),

        array(
            'name'  => 'CRM Statistics',
            'file'  => 'crm-statistics.php',
            'class' => 'RUD_CRM_Elementor_CRM_Statistics'
        ),

        array(
            'name'  => 'Customer Actions',
            'file'  => 'customer-actions.php',
            'class' => 'RUD_CRM_Elementor_Customer_Actions'
        ),

array(
    'name'  => 'Customer Permissions',
    'file'  => 'customer-permissions.php',
    'class' => 'RUD_CRM_Elementor_Customer_Permissions'
),

array(
    'name'  => 'Customer Permissions Manager',
    'file'  => 'customer-permissions-manager.php',
    'class' => 'RUD_CRM_Elementor_Customer_Permissions_Manager'
),

array(
    'name'  => 'Customer Selector',
    'file'  => 'customer-selector.php',
    'class' => 'RUD_CRM_Elementor_Customer_Selector'
),

array(
    'name'  => 'Customer Header',
    'file'  => 'customer-header.php',
    'class' => 'RUD_CRM_Elementor_Customer_Header'
),

array(
    'name'  => 'Customer Timeline',
    'file'  => 'customer-timeline.php',
    'class' => 'RUD_CRM_Elementor_Customer_Timeline'
),

array(
    'name'  => 'Add Customer Activity',
    'file'  => 'customer-add-activity.php',
    'class' => 'RUD_CRM_Elementor_Customer_Add_Activity'
),

        array(
            'name'  => 'Customer Image',
            'file'  => 'customer-image.php',
            'class' => 'RUD_CRM_Elementor_Customer_Image'
        ),

        array(
            'name'  => 'Contact Information',
            'file'  => 'customer-contact.php',
            'class' => 'RUD_CRM_Elementor_Customer_Contact'
        ),

        array(
            'name'  => 'Customer Address',
            'file'  => 'customer-address.php',
            'class' => 'RUD_CRM_Elementor_Customer_Address'
        ),

        array(
            'name'  => 'Customer Social Media',
            'file'  => 'customer-social.php',
            'class' => 'RUD_CRM_Elementor_Customer_Social'
        ),

        array(
            'name'  => 'Customer Gallery',
            'file'  => 'customer-gallery.php',
            'class' => 'RUD_CRM_Elementor_Customer_Gallery'
        ),

        array(
            'name'  => 'Customer Notes',
            'file'  => 'customer-notes.php',
            'class' => 'RUD_CRM_Elementor_Customer_Notes'
        )
    );
}


/*
 * ---------------------------------------------------------
 * LOAD ONE WIDGET FILE
 * ---------------------------------------------------------
 */

function rud_crm_elementor_load_widget_file(
    $file,
    $class
) {

    if (
        class_exists(
            $class,
            false
        )
    ) {

        return true;
    }


    if (
        ! file_exists(
            $file
        )
    ) {

        return false;
    }


    include_once
        $file;


    return class_exists(
        $class,
        false
    );
}


/*
 * ---------------------------------------------------------
 * REGISTER RUD CRM CATEGORY
 * ---------------------------------------------------------
 */

function rud_crm_elementor_register_category(
    $elements_manager
) {

    $elements_manager->add_category(
        'rud-crm',
        array(
            'title' => 'RUD CRM',
            'icon'  => 'eicon-person'
        )
    );
}

add_action(
    'elementor/elements/categories_registered',
    'rud_crm_elementor_register_category'
);


/*
 * ---------------------------------------------------------
 * REGISTER WIDGETS
 * ---------------------------------------------------------
 */

function rud_crm_elementor_register_widgets(
    $widgets_manager
) {

    $widgets_dir =
        __DIR__ .
        '/widgets/';


    foreach (
        rud_crm_elementor_widget_definitions()
        as
        $widget
    ) {

        $file =
            $widgets_dir .
            $widget['file'];


        $loaded =
            rud_crm_elementor_load_widget_file(
                $file,
                $widget['class']
            );


        if (
            ! $loaded
        ) {

            continue;
        }


        $widgets_manager->register(
            new $widget['class']()
        );
    }
}

add_action(
    'elementor/widgets/register',
    'rud_crm_elementor_register_widgets'
);


/*
 * ---------------------------------------------------------
 * DIAGNOSTIC MENU
 * ---------------------------------------------------------
 */

function rud_crm_elementor_diagnostic_menu() {

    add_submenu_page(
        'rud-crm',
        'Elementor Widgets',
        'Elementor Widgets',
        'manage_options',
        'rud-crm-elementor-widgets',
        'rud_crm_elementor_diagnostic_page'
    );
}

add_action(
    'admin_menu',
    'rud_crm_elementor_diagnostic_menu',
    90
);


/*
 * ---------------------------------------------------------
 * DIAGNOSTIC PAGE
 * ---------------------------------------------------------
 */

function rud_crm_elementor_diagnostic_page() {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return;
    }


    $widgets_dir =
        __DIR__ .
        '/widgets/';


    $dynamic_file =
        __DIR__ .
        '/dynamic-tags-v4.php';


    echo '<div class="wrap">';

    echo '<h1>RUD CRM Elementor Widgets</h1>';

    echo '<p>';
    echo 'RUD CRM Elementor widget and Dynamic Tag status.';
    echo '</p>';


    /*
     * =====================================================
     * WIDGET TABLE
     * =====================================================
     */

    echo '<table class="widefat striped">';

    echo '<thead>';

    echo '<tr>';

    echo '<th>Widget</th>';
    echo '<th>File</th>';
    echo '<th>File Status</th>';
    echo '<th>Class Status</th>';

    echo '</tr>';

    echo '</thead>';

    echo '<tbody>';


    foreach (
        rud_crm_elementor_widget_definitions()
        as
        $widget
    ) {

        $file =
            $widgets_dir .
            $widget['file'];


        $file_exists =
            file_exists(
                $file
            );


        $class_loaded =
            false;


        if (
            $file_exists
        ) {

            $class_loaded =
                rud_crm_elementor_load_widget_file(
                    $file,
                    $widget['class']
                );
        }


        echo '<tr>';


        echo '<td>';

        echo '<strong>';

        echo esc_html(
            $widget['name']
        );

        echo '</strong>';

        echo '</td>';


        echo '<td>';

        echo '<code>';

        echo esc_html(
            $widget['file']
        );

        echo '</code>';

        echo '</td>';


        echo '<td>';


        if (
            $file_exists
        ) {

            echo '<strong style="color:green;">FOUND</strong>';

        } else {

            echo '<strong style="color:red;">MISSING</strong>';
        }


        echo '</td>';


        echo '<td>';


        if (
            $class_loaded
        ) {

            echo '<strong style="color:green;">LOADED</strong>';

        } else {

            echo '<strong style="color:red;">NOT LOADED</strong>';
        }


        echo '</td>';


        echo '</tr>';
    }


    echo '</tbody>';

    echo '</table>';


    /*
     * =====================================================
     * DYNAMIC TAG TEST
     * =====================================================
     */

    echo '<h2 style="margin-top:30px;">';

    echo 'Dynamic Tags V4 Test';

    echo '</h2>';


    echo '<p>';

    echo '<strong>V4 Dynamic Tags File:</strong> ';


    if (
        file_exists(
            $dynamic_file
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">FOUND</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">MISSING</span>';
    }


    echo '</p>';


    echo '<p>';

    echo '<strong>CRM Customer Name Tag Class:</strong> ';


    if (
        class_exists(
            'RUD_CRM_V4_Dynamic_Customer_Name',
            false
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">LOADED</span>';

    } else {

        echo '<span style="color:red;font-weight:bold;">NOT LOADED</span>';
    }


    echo '</p>';


    echo '<p>';

    echo '<strong>Elementor Dynamic Tags Registration Hook:</strong> ';


    if (
        did_action(
            'elementor/dynamic_tags/register'
        )
    ) {

        echo '<span style="color:green;font-weight:bold;">FIRED</span>';

    } else {

        echo '<span style="color:#b36b00;font-weight:bold;">NOT FIRED ON THIS PAGE</span>';
    }


    echo '</p>';


    echo '</div>';
}


/*
 * ---------------------------------------------------------
 * ADMIN STATUS NOTICE
 * ---------------------------------------------------------
 */

function rud_crm_elementor_admin_status_notice() {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return;
    }


    if (
        ! did_action(
            'elementor/loaded'
        )
    ) {

        echo '<div class="notice notice-error">';

        echo '<p>';

        echo '<strong>RUD CRM Elementor:</strong> ';
        echo 'Elementor is not loaded.';

        echo '</p>';

        echo '</div>';

        return;
    }


    echo '<div class="notice notice-success is-dismissible">';

    echo '<p>';

    echo '<strong>RUD CRM Elementor:</strong> ';
    echo 'Integration loader is active.';

    echo '</p>';

    echo '</div>';
}

add_action(
    'admin_notices',
    'rud_crm_elementor_admin_status_notice'
);