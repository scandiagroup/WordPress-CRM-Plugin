<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM
 * ELEMENTOR V4 DYNAMIC TAG TEST
 *
 * TEST TAG:
 * CRM Customer Name
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * GET CURRENT CRM CUSTOMER ID
 * ---------------------------------------------------------
 */

function rud_crm_v4_dynamic_customer_id() {

    global $wpdb;


    $customer_id =
        isset(
            $_GET['rud_customer_id']
        )
        ? absint(
            $_GET['rud_customer_id']
        )
        : 0;


    /*
     * Elementor editor preview.
     * If no customer is selected, use the first
     * customer in the CRM database.
     */

    if (
        ! $customer_id
        &&
        isset(
            \Elementor\Plugin::$instance->editor
        )
        &&
        \Elementor\Plugin::$instance
            ->editor
            ->is_edit_mode()
    ) {

        $customer_id =
            (int)
            $wpdb->get_var(
                "SELECT id
                 FROM {$wpdb->prefix}rudcrm_customers
                 ORDER BY id ASC
                 LIMIT 1"
            );
    }


    return $customer_id;
}


/*
 * ---------------------------------------------------------
 * GET CUSTOMER RECORD
 * ---------------------------------------------------------
 */

function rud_crm_v4_dynamic_customer() {

    global $wpdb;


    $customer_id =
        rud_crm_v4_dynamic_customer_id();


    if (
        ! $customer_id
    ) {

        return null;
    }


    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customers
             WHERE id = %d
             LIMIT 1",
            $customer_id
        )
    );
}


/*
 * =========================================================
 * CUSTOMER NAME DYNAMIC TAG
 * =========================================================
 */

class RUD_CRM_V4_Dynamic_Customer_Name
    extends \Elementor\Core\DynamicTags\Tag {


    /*
     * -----------------------------------------------------
     * INTERNAL TAG NAME
     * -----------------------------------------------------
     */

    public function get_name() {

        return 'rud-crm-v4-customer-name';
    }


    /*
     * -----------------------------------------------------
     * DISPLAY NAME
     * -----------------------------------------------------
     */

    public function get_title() {

        return 'CRM Customer Name';
    }


    /*
     * -----------------------------------------------------
     * DYNAMIC TAG GROUP
     * -----------------------------------------------------
     */

    public function get_group() {

        return 'rud-crm-v4';
    }


    /*
     * -----------------------------------------------------
     * SUPPORTED CATEGORY
     * -----------------------------------------------------
     */

    public function get_categories() {

        return array(
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY
        );
    }


    /*
     * -----------------------------------------------------
     * NO EXTRA CONTROLS REQUIRED
     * -----------------------------------------------------
     */

    protected function register_controls() {
    }


    /*
     * -----------------------------------------------------
     * OUTPUT CUSTOMER NAME
     * -----------------------------------------------------
     */

    public function render() {

        $customer =
            rud_crm_v4_dynamic_customer();


        if (
            ! $customer
        ) {

            return;
        }


        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $customer->first_name ?? '',
                            $customer->middle_name ?? '',
                            $customer->last_name ?? ''
                        )
                    )
                )
            );


        /*
         * Fall back to company name.
         */

        if (
            '' ===
            $name
            &&
            ! empty(
                $customer->company_name
            )
        ) {

            $name =
                $customer->company_name;
        }


        /*
         * Elementor preview fallback.
         */

        if (
            '' ===
            $name
        ) {

            $name =
                'CRM Customer';
        }


        echo esc_html(
            $name
        );
    }
}


/*
 * =========================================================
 * REGISTER RUD CRM GROUP
 * =========================================================
 */

function rud_crm_v4_register_dynamic_group(
    $dynamic_tags_manager
) {

    $dynamic_tags_manager->register_group(
        'rud-crm-v4',
        array(
            'title' => 'RUD CRM'
        )
    );
}

add_action(
    'elementor/dynamic_tags/register',
    'rud_crm_v4_register_dynamic_group',
    5
);


/*
 * =========================================================
 * REGISTER CUSTOMER NAME TAG
 * =========================================================
 */

function rud_crm_v4_register_dynamic_tags(
    $dynamic_tags_manager
) {

    if (
        class_exists(
            'RUD_CRM_V4_Dynamic_Customer_Name'
        )
    ) {

        $dynamic_tags_manager->register(
            new RUD_CRM_V4_Dynamic_Customer_Name()
        );
    }
}

add_action(
    'elementor/dynamic_tags/register',
    'rud_crm_v4_register_dynamic_tags',
    20
);