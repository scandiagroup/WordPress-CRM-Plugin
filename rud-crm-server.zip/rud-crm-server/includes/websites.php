<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM CONNECTED WEBSITES
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CONNECTED WEBSITES SUBMENU
 * ---------------------------------------------------------
 */

function rud_crm_websites_admin_menu() {

    add_submenu_page(
        'rud-crm',
        'Connected Websites',
        'Connected Websites',
        'manage_options',
        'rud-crm-websites',
        'rud_crm_websites_page'
    );
}

add_action(
    'admin_menu',
    'rud_crm_websites_admin_menu',
    30
);


/*
 * ---------------------------------------------------------
 * NEXT SITE NUMBER
 * ---------------------------------------------------------
 */

function rud_crm_next_site_number() {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_sites';

    $highest_id =
        (int) $wpdb->get_var(
            "SELECT MAX(id)
             FROM $table"
        );

    return 'SITE-' .
        str_pad(
            $highest_id + 1,
            6,
            '0',
            STR_PAD_LEFT
        );
}


/*
 * ---------------------------------------------------------
 * CLEAN DOMAIN
 * ---------------------------------------------------------
 */

function rud_crm_clean_domain( $domain ) {

    $domain =
        strtolower(
            trim(
                sanitize_text_field(
                    $domain
                )
            )
        );

    $domain =
        preg_replace(
            '#^https?://#',
            '',
            $domain
        );

    $domain =
        preg_replace(
            '#^www\.#',
            '',
            $domain
        );

    $domain =
        rtrim(
            $domain,
            '/'
        );

    return $domain;
}


/*
 * ---------------------------------------------------------
 * CREATE WEBSITE
 * ---------------------------------------------------------
 */

function rud_crm_create_website() {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_sites';


    $site_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['site_name'] ?? ''
            )
        );


    $domain =
        rud_crm_clean_domain(
            wp_unslash(
                $_POST['domain'] ?? ''
            )
        );


    if (
        '' === $site_name ||
        '' === $domain
    ) {

        return new WP_Error(
            'missing_site',
            'Site name and domain are required.'
        );
    }


    $existing =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM $table
                 WHERE domain = %s",
                $domain
            )
        );


    if ( $existing ) {

        return new WP_Error(
            'duplicate_domain',
            'This domain is already registered in RUD CRM.'
        );
    }


    $now =
        current_time(
            'mysql'
        );


    $result =
        $wpdb->insert(
            $table,
            array(
                'site_uuid' =>
                    wp_generate_uuid4(),

                'site_number' =>
                    rud_crm_next_site_number(),

                'site_name' =>
                    $site_name,

                'domain' =>
                    $domain,

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status'] ?? 'active'
                        )
                    ),

                'allow_create' =>
                    isset(
                        $_POST['allow_create']
                    )
                    ? 1
                    : 0,

                'allow_read' =>
                    isset(
                        $_POST['allow_read']
                    )
                    ? 1
                    : 0,

                'allow_update' =>
                    isset(
                        $_POST['allow_update']
                    )
                    ? 1
                    : 0,

                'allow_delete' =>
                    isset(
                        $_POST['allow_delete']
                    )
                    ? 1
                    : 0,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            )
        );


    if (
        false === $result
    ) {

        return new WP_Error(
            'site_database_error',
            'The website could not be created.'
        );
    }


    return true;
}


/*
 * ---------------------------------------------------------
 * UPDATE WEBSITE
 * ---------------------------------------------------------
 */

function rud_crm_update_website( $site_id ) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_sites';


    $site_id =
        absint(
            $site_id
        );


    $site =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM $table
                 WHERE id = %d",
                $site_id
            )
        );


    if ( ! $site ) {

        return new WP_Error(
            'site_not_found',
            'Website could not be found.'
        );
    }


    $domain =
        rud_crm_clean_domain(
            wp_unslash(
                $_POST['domain'] ?? ''
            )
        );


    $duplicate =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM $table
                 WHERE domain = %s
                 AND id != %d",
                $domain,
                $site_id
            )
        );


    if ( $duplicate ) {

        return new WP_Error(
            'duplicate_domain',
            'Another connected website already uses this domain.'
        );
    }


    $result =
        $wpdb->update(
            $table,
            array(
                'site_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['site_name'] ?? ''
                        )
                    ),

                'domain' =>
                    $domain,

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status'] ?? 'active'
                        )
                    ),

                'allow_create' =>
                    isset(
                        $_POST['allow_create']
                    )
                    ? 1
                    : 0,

                'allow_read' =>
                    isset(
                        $_POST['allow_read']
                    )
                    ? 1
                    : 0,

                'allow_update' =>
                    isset(
                        $_POST['allow_update']
                    )
                    ? 1
                    : 0,

                'allow_delete' =>
                    isset(
                        $_POST['allow_delete']
                    )
                    ? 1
                    : 0,

                'updated_at' =>
                    current_time(
                        'mysql'
                    )
            ),
            array(
                'id' =>
                    $site_id
            )
        );


    if (
        false === $result
    ) {

        return new WP_Error(
            'site_update_error',
            'Website changes could not be saved.'
        );
    }


    return true;
}


/*
 * ---------------------------------------------------------
 * CONNECTED WEBSITES PAGE
 * ---------------------------------------------------------
 */

function rud_crm_websites_page() {

    global $wpdb;


    if (
        ! current_user_can(
            'manage_options'
        )
    ) {
        return;
    }


    $table =
        $wpdb->prefix .
        'rudcrm_sites';


    /*
     * ---------------------------------------------------------
     * CREATE WEBSITE
     * ---------------------------------------------------------
     */

    if (
        isset(
            $_POST['rud_crm_add_site']
        )
    ) {

        check_admin_referer(
            'rud_crm_add_site_action',
            'rud_crm_add_site_nonce'
        );


        $result =
            rud_crm_create_website();


        if (
            is_wp_error(
                $result
            )
        ) {

            echo '<div class="notice notice-error">';

            echo '<p>' .
                esc_html(
                    $result->get_error_message()
                ) .
                '</p>';

            echo '</div>';

        } else {

            echo '<div class="notice notice-success">';

            echo '<p><strong>Connected website added.</strong></p>';

            echo '</div>';
        }
    }


    /*
     * ---------------------------------------------------------
     * UPDATE WEBSITE
     * ---------------------------------------------------------
     */

    if (
        isset(
            $_POST['rud_crm_update_site']
        )
    ) {

        check_admin_referer(
            'rud_crm_update_site_action',
            'rud_crm_update_site_nonce'
        );


        $result =
            rud_crm_update_website(
                absint(
                    $_POST['site_id'] ?? 0
                )
            );


        if (
            is_wp_error(
                $result
            )
        ) {

            echo '<div class="notice notice-error">';

            echo '<p>' .
                esc_html(
                    $result->get_error_message()
                ) .
                '</p>';

            echo '</div>';

        } else {

            echo '<div class="notice notice-success">';

            echo '<p><strong>Website changes saved.</strong></p>';

            echo '</div>';
        }
    }


    /*
     * ---------------------------------------------------------
     * EDIT MODE
     * ---------------------------------------------------------
     */

    $edit_site_id =
        isset(
            $_GET['edit_site']
        )
        ? absint(
            $_GET['edit_site']
        )
        : 0;


    $edit_site =
        null;


    if (
        $edit_site_id >
        0
    ) {

        $edit_site =
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM $table
                     WHERE id = %d",
                    $edit_site_id
                )
            );
    }


    /*
     * ---------------------------------------------------------
     * GET ALL WEBSITES
     * ---------------------------------------------------------
     */

    $sites =
        $wpdb->get_results(
            "SELECT *
             FROM $table
             ORDER BY id ASC"
        );


    /*
     * ---------------------------------------------------------
     * PAGE START
     * ---------------------------------------------------------
     */

    echo '<div class="wrap">';

    echo '<h1>Connected Websites</h1>';

    echo '<p>';

    echo 'Manage websites that are allowed to connect to the central RUD CRM database.';

    echo '</p>';


    /*
     * ---------------------------------------------------------
     * WEBSITE LIST
     * ---------------------------------------------------------
     */

    echo '<h2>Registered Websites</h2>';


    if (
        empty(
            $sites
        )
    ) {

        echo '<p>No websites have been registered yet.</p>';

    } else {

        echo '<table class="widefat striped">';

        echo '<thead>';

        echo '<tr>';

        echo '<th>Site ID</th>';

        echo '<th>Name</th>';

        echo '<th>Domain</th>';

        echo '<th>Status</th>';

        echo '<th>Create</th>';

        echo '<th>Read</th>';

        echo '<th>Update</th>';

        echo '<th>Delete</th>';

        echo '<th>Manage</th>';

        echo '</tr>';

        echo '</thead>';


        echo '<tbody>';


        foreach (
            $sites as
            $site
        ) {

            $edit_url =
                admin_url(
                    'admin.php?page=rud-crm-websites&edit_site=' .
                    absint(
                        $site->id
                    )
                );


            echo '<tr>';


            echo '<td>';

            echo '<strong>' .
                esc_html(
                    $site->site_number
                ) .
                '</strong>';

            echo '</td>';


            echo '<td>' .
                esc_html(
                    $site->site_name
                ) .
                '</td>';


            echo '<td>';

            echo '<code>' .
                esc_html(
                    $site->domain
                ) .
                '</code>';

            echo '</td>';


            echo '<td>';

            if (
                'active' ===
                $site->status
            ) {

                echo '<strong style="color:green;">ACTIVE</strong>';

            } else {

                echo '<strong style="color:#777;">' .
                    esc_html(
                        strtoupper(
                            $site->status
                        )
                    ) .
                    '</strong>';
            }

            echo '</td>';


            echo '<td>';

            echo $site->allow_create
                ? '✓'
                : '—';

            echo '</td>';


            echo '<td>';

            echo $site->allow_read
                ? '✓'
                : '—';

            echo '</td>';


            echo '<td>';

            echo $site->allow_update
                ? '✓'
                : '—';

            echo '</td>';


            echo '<td>';

            echo $site->allow_delete
                ? '✓'
                : '—';

            echo '</td>';


            echo '<td>';

            echo '<a
                class="button"
                href="' .
                esc_url(
                    $edit_url
                ) .
                '"
            >
                Edit
            </a>';

            echo '</td>';


            echo '</tr>';
        }


        echo '</tbody>';

        echo '</table>';
    }


    /*
     * ---------------------------------------------------------
     * EDIT WEBSITE
     * ---------------------------------------------------------
     */

    if (
        $edit_site
    ) {

        echo '<hr style="margin:35px 0;">';

        echo '<h2>Edit Connected Website</h2>';

        echo '<form method="post">';


        wp_nonce_field(
            'rud_crm_update_site_action',
            'rud_crm_update_site_nonce'
        );


        echo '<input
            type="hidden"
            name="site_id"
            value="' .
            esc_attr(
                $edit_site->id
            ) .
            '"
        >';


        echo '<table class="form-table">';


        echo '<tr>';

        echo '<th>Site ID</th>';

        echo '<td>';

        echo '<strong>' .
            esc_html(
                $edit_site->site_number
            ) .
            '</strong>';

        echo '</td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>';

        echo '<label for="site_name">';
        echo 'Website Name';
        echo '</label>';

        echo '</th>';

        echo '<td>';

        echo '<input
            type="text"
            name="site_name"
            id="site_name"
            value="' .
            esc_attr(
                $edit_site->site_name
            ) .
            '"
            class="regular-text"
        >';

        echo '</td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>';

        echo '<label for="domain">';
        echo 'Domain';
        echo '</label>';

        echo '</th>';

        echo '<td>';

        echo '<input
            type="text"
            name="domain"
            id="domain"
            value="' .
            esc_attr(
                $edit_site->domain
            ) .
            '"
            class="regular-text"
        >';

        echo '<p class="description">';
        echo 'Example: rudolfsen.com';
        echo '</p>';

        echo '</td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>Status</th>';

        echo '<td>';

        echo '<select name="status">';

        echo '<option value="active" ' .
            selected(
                $edit_site->status,
                'active',
                false
            ) .
            '>
            Active
        </option>';

        echo '<option value="inactive" ' .
            selected(
                $edit_site->status,
                'inactive',
                false
            ) .
            '>
            Inactive
        </option>';

        echo '<option value="blocked" ' .
            selected(
                $edit_site->status,
                'blocked',
                false
            ) .
            '>
            Blocked
        </option>';

        echo '</select>';

        echo '</td>';

        echo '</tr>';


        echo '</table>';


        /*
         * ACCESS PERMISSIONS
         */

        echo '<h3>Website Access</h3>';

        echo '<p>';

        echo 'These permissions control what this website may eventually do through the RUD CRM API.';

        echo '</p>';


        echo '<table class="form-table">';


        rud_crm_site_permission_checkbox(
            'allow_create',
            'Allow Create',
            $edit_site->allow_create
        );


        rud_crm_site_permission_checkbox(
            'allow_read',
            'Allow Read',
            $edit_site->allow_read
        );


        rud_crm_site_permission_checkbox(
            'allow_update',
            'Allow Update',
            $edit_site->allow_update
        );


        rud_crm_site_permission_checkbox(
            'allow_delete',
            'Allow Delete',
            $edit_site->allow_delete
        );


        echo '</table>';


        echo '<p>';


        echo '<button
            type="button"
            class="button"
            onclick="rudCrmSitePermissions(true);"
        >
            Allow All
        </button> ';


        echo '<button
            type="button"
            class="button"
            onclick="rudCrmSitePermissions(false);"
        >
            Disable All
        </button>';


        echo '</p>';


        submit_button(
            'Save Website Changes',
            'primary',
            'rud_crm_update_site'
        );


        echo '</form>';
    }


    /*
     * ---------------------------------------------------------
     * ADD NEW WEBSITE
     * ---------------------------------------------------------
     */

    echo '<hr style="margin:35px 0;">';

    echo '<h2>Add Connected Website</h2>';

    echo '<form method="post">';


    wp_nonce_field(
        'rud_crm_add_site_action',
        'rud_crm_add_site_nonce'
    );


    echo '<table class="form-table">';


    echo '<tr>';

    echo '<th>';

    echo '<label for="new_site_name">';
    echo 'Website Name';
    echo '</label>';

    echo '</th>';

    echo '<td>';

    echo '<input
        type="text"
        name="site_name"
        id="new_site_name"
        class="regular-text"
        required
    >';

    echo '</td>';

    echo '</tr>';


    echo '<tr>';

    echo '<th>';

    echo '<label for="new_domain">';
    echo 'Domain';
    echo '</label>';

    echo '</th>';

    echo '<td>';

    echo '<input
        type="text"
        name="domain"
        id="new_domain"
        class="regular-text"
        placeholder="example.com"
        required
    >';

    echo '</td>';

    echo '</tr>';


    echo '<tr>';

    echo '<th>Status</th>';

    echo '<td>';

    echo '<select name="status">';

    echo '<option
        value="active"
        selected
    >
        Active
    </option>';

    echo '<option value="inactive">';
    echo 'Inactive';
    echo '</option>';

    echo '<option value="blocked">';
    echo 'Blocked';
    echo '</option>';

    echo '</select>';

    echo '</td>';

    echo '</tr>';


    echo '</table>';


    echo '<h3>Initial Website Access</h3>';


    echo '<table class="form-table">';


    rud_crm_site_permission_checkbox(
        'allow_create',
        'Allow Create',
        0
    );


    rud_crm_site_permission_checkbox(
        'allow_read',
        'Allow Read',
        0
    );


    rud_crm_site_permission_checkbox(
        'allow_update',
        'Allow Update',
        0
    );


    rud_crm_site_permission_checkbox(
        'allow_delete',
        'Allow Delete',
        0
    );


    echo '</table>';


    echo '<p>';


    echo '<button
        type="button"
        class="button"
        onclick="rudCrmSitePermissions(true);"
    >
        Allow All
    </button> ';


    echo '<button
        type="button"
        class="button"
        onclick="rudCrmSitePermissions(false);"
    >
        Disable All
    </button>';


    echo '</p>';


    submit_button(
        'Add Connected Website',
        'primary',
        'rud_crm_add_site'
    );


    echo '</form>';


    /*
     * JAVASCRIPT
     */

    ?>

    <script>

    function rudCrmSitePermissions(state) {

        document
            .querySelectorAll(
                '.rud-crm-site-permission'
            )
            .forEach(
                function(box) {

                    box.checked =
                        state;
                }
            );
    }

    </script>

    <?php


    echo '</div>';
}


/*
 * ---------------------------------------------------------
 * PERMISSION CHECKBOX HELPER
 * ---------------------------------------------------------
 */

function rud_crm_site_permission_checkbox(
    $name,
    $label,
    $checked_value
) {

    echo '<tr>';

    echo '<th>' .
        esc_html(
            $label
        ) .
        '</th>';

    echo '<td>';

    echo '<label>';

    echo '<input
        type="checkbox"
        class="rud-crm-site-permission"
        name="' .
        esc_attr(
            $name
        ) .
        '"
        value="1" ' .
        checked(
            (int) $checked_value,
            1,
            false
        ) .
        '
    > ';

    echo esc_html(
        $label
    );

    echo '</label>';

    echo '</td>';

    echo '</tr>';
}