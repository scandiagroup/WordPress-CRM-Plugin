<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM API / SECURITY
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * API / SECURITY SUBMENU
 * ---------------------------------------------------------
 */

function rud_crm_api_admin_menu() {

    add_submenu_page(
        'rud-crm',
        'API / Security',
        'API / Security',
        'manage_options',
        'rud-crm-api',
        'rud_crm_api_security_page'
    );
}

add_action(
    'admin_menu',
    'rud_crm_api_admin_menu',
    40
);


/*
 * ---------------------------------------------------------
 * GENERATE CLIENT ID
 * ---------------------------------------------------------
 */

function rud_crm_generate_client_id() {

    return 'rud_' .
        strtolower(
            wp_generate_password(
                24,
                false,
                false
            )
        );
}


/*
 * ---------------------------------------------------------
 * GENERATE API SECRET
 * ---------------------------------------------------------
 */

function rud_crm_generate_api_secret() {

    try {

        return bin2hex(
            random_bytes( 32 )
        );

    } catch ( Exception $e ) {

        return wp_generate_password(
            64,
            false,
            false
        );
    }
}


/*
 * ---------------------------------------------------------
 * GET SITE API CREDENTIAL
 * ---------------------------------------------------------
 */

function rud_crm_get_site_api_credential( $site_id ) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_api_credentials
             WHERE site_id = %d
             ORDER BY id DESC
             LIMIT 1",
            absint( $site_id )
        )
    );
}


/*
 * ---------------------------------------------------------
 * GENERATE / REGENERATE CREDENTIALS
 * ---------------------------------------------------------
 */

function rud_crm_generate_site_api_credentials( $site_id ) {

    global $wpdb;

    $sites_table =
        $wpdb->prefix .
        'rudcrm_sites';

    $credentials_table =
        $wpdb->prefix .
        'rudcrm_api_credentials';

    $site =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM $sites_table
                 WHERE id = %d",
                absint( $site_id )
            )
        );

    if ( ! $site ) {

        return new WP_Error(
            'rud_site_not_found',
            'Connected website could not be found.'
        );
    }

    $client_id =
        rud_crm_generate_client_id();

    $plain_secret =
        rud_crm_generate_api_secret();

    $secret_hash =
        wp_hash_password(
            $plain_secret
        );

    $now =
        current_time( 'mysql' );

    $existing =
        rud_crm_get_site_api_credential(
            $site_id
        );

    if ( $existing ) {

        $result =
            $wpdb->update(
                $credentials_table,
                array(
                    'client_id'    => $client_id,
                    'secret_hash'  => $secret_hash,
                    'status'       => 'active',
                    'updated_at'   => $now,
                    'last_used_at' => null
                ),
                array(
                    'id' =>
                        $existing->id
                )
            );

    } else {

        $result =
            $wpdb->insert(
                $credentials_table,
                array(
                    'site_id'      => absint( $site_id ),
                    'client_id'    => $client_id,
                    'secret_hash'  => $secret_hash,
                    'status'       => 'active',
                    'created_at'   => $now,
                    'updated_at'   => $now,
                    'last_used_at' => null
                )
            );
    }

    if ( false === $result ) {

        return new WP_Error(
            'rud_api_credential_error',
            'API credentials could not be created.'
        );
    }

    return array(
        'site_id'   => absint( $site_id ),
        'site_name' => $site->site_name,
        'domain'    => $site->domain,
        'client_id' => $client_id,
        'secret'    => $plain_secret
    );
}


/*
 * ---------------------------------------------------------
 * ACTIVATE / REVOKE
 * ---------------------------------------------------------
 */

function rud_crm_set_api_credential_status(
    $site_id,
    $status
) {

    global $wpdb;

    if (
        ! in_array(
            $status,
            array(
                'active',
                'revoked'
            ),
            true
        )
    ) {
        return false;
    }

    $credential =
        rud_crm_get_site_api_credential(
            $site_id
        );

    if ( ! $credential ) {
        return false;
    }

    return $wpdb->update(
        $wpdb->prefix .
        'rudcrm_api_credentials',
        array(
            'status' =>
                $status,

            'updated_at' =>
                current_time(
                    'mysql'
                )
        ),
        array(
            'id' =>
                $credential->id
        )
    );
}


/*
 * ---------------------------------------------------------
 * FIND CREDENTIAL BY CLIENT ID
 * ---------------------------------------------------------
 */

function rud_crm_get_api_credential_by_client_id(
    $client_id
) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT
                c.*,
                s.site_name,
                s.domain,
                s.status AS site_status,
                s.allow_create,
                s.allow_read,
                s.allow_update,
                s.allow_delete
             FROM {$wpdb->prefix}rudcrm_api_credentials c
             INNER JOIN {$wpdb->prefix}rudcrm_sites s
                ON s.id = c.site_id
             WHERE c.client_id = %s
             LIMIT 1",
            $client_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * VERIFY API CLIENT
 * ---------------------------------------------------------
 */

function rud_crm_verify_api_client(
    $client_id,
    $plain_secret
) {

    global $wpdb;

    $credential =
        rud_crm_get_api_credential_by_client_id(
            $client_id
        );

    if ( ! $credential ) {

        return new WP_Error(
            'rud_api_invalid_client',
            'Invalid API client.',
            array(
                'status' => 401
            )
        );
    }

    if (
        'active' !==
        $credential->status
    ) {

        return new WP_Error(
            'rud_api_revoked',
            'API credentials are not active.',
            array(
                'status' => 403
            )
        );
    }

    if (
        'active' !==
        $credential->site_status
    ) {

        return new WP_Error(
            'rud_api_site_inactive',
            'Connected website is not active.',
            array(
                'status' => 403
            )
        );
    }

    if (
        ! wp_check_password(
            $plain_secret,
            $credential->secret_hash
        )
    ) {

        return new WP_Error(
            'rud_api_invalid_secret',
            'Invalid API secret.',
            array(
                'status' => 401
            )
        );
    }

    $wpdb->update(
        $wpdb->prefix .
        'rudcrm_api_credentials',
        array(
            'last_used_at' =>
                current_time(
                    'mysql'
                )
        ),
        array(
            'id' =>
                $credential->id
        )
    );

    return $credential;
}


/*
 * ---------------------------------------------------------
 * PERMISSION CHECK
 * ---------------------------------------------------------
 */

function rud_crm_api_client_can(
    $credential,
    $action
) {

    if ( ! $credential ) {
        return false;
    }

    switch ( $action ) {

        case 'create':
            return
                (int) $credential->allow_create === 1;

        case 'read':
            return
                (int) $credential->allow_read === 1;

        case 'update':
            return
                (int) $credential->allow_update === 1;

        case 'delete':
            return
                (int) $credential->allow_delete === 1;
    }

    return false;
}


/*
 * =========================================================
 * REST API AUTHENTICATION
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * READ API CREDENTIALS FROM HTTP HEADERS
 *
 * Required:
 * X-RUD-Client-ID
 * X-RUD-API-Secret
 * ---------------------------------------------------------
 */

function rud_crm_rest_authenticate(
    WP_REST_Request $request,
    $required_permission = 'read'
) {

    $client_id =
        sanitize_text_field(
            $request->get_header(
                'x-rud-client-id'
            )
        );

    $secret =
        sanitize_text_field(
            $request->get_header(
                'x-rud-api-secret'
            )
        );

    if (
        '' === $client_id ||
        '' === $secret
    ) {

        return new WP_Error(
            'rud_api_missing_credentials',
            'API credentials are required.',
            array(
                'status' => 401
            )
        );
    }

    $credential =
        rud_crm_verify_api_client(
            $client_id,
            $secret
        );

    if (
        is_wp_error(
            $credential
        )
    ) {
        return $credential;
    }

    if (
        ! rud_crm_api_client_can(
            $credential,
            $required_permission
        )
    ) {

        return new WP_Error(
            'rud_api_permission_denied',
            'This website does not have permission for this API action.',
            array(
                'status' => 403
            )
        );
    }

    return $credential;
}


/*
 * =========================================================
 * CUSTOMER API DATA HELPERS
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * BUILD CUSTOMER API RESPONSE
 * ---------------------------------------------------------
 */

function rud_crm_api_get_customer_data(
    $customer_id
) {

    global $wpdb;

    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d",
                absint( $customer_id )
            )
        );

    if ( ! $customer ) {
        return null;
    }

    $details =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_details
                 WHERE customer_id = %d",
                $customer->id
            )
        );

    $contacts =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    contact_type,
                    contact_label,
                    contact_value,
                    is_primary,
                    is_verified
                 FROM {$wpdb->prefix}rudcrm_contact_methods
                 WHERE customer_id = %d
                 ORDER BY id ASC",
                $customer->id
            )
        );

    $addresses =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_addresses
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC, id ASC",
                $customer->id
            )
        );

    $social =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    platform,
                    is_active,
                    account_name,
                    profile_url
                 FROM {$wpdb->prefix}rudcrm_social_accounts
                 WHERE customer_id = %d
                 ORDER BY platform ASC",
                $customer->id
            )
        );

    $images =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    attachment_id,
                    image_type,
                    is_primary,
                    sort_order
                 FROM {$wpdb->prefix}rudcrm_customer_images
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC, sort_order ASC, id ASC",
                $customer->id
            )
        );

    $image_data =
        array();

    foreach (
        $images as
        $image
    ) {

        $image_data[] =
            array(
                'attachment_id' =>
                    (int) $image->attachment_id,

                'url' =>
                    wp_get_attachment_url(
                        $image->attachment_id
                    ),

                'is_primary' =>
                    (bool) $image->is_primary,

                'sort_order' =>
                    (int) $image->sort_order
            );
    }

    return array(

        'id' =>
            (int) $customer->id,

        'customer_number' =>
            $customer->customer_number,

        'customer_uuid' =>
            $customer->customer_uuid,

        'customer_type' =>
            $customer->customer_type,

        'status' =>
            $customer->status,

        'name' =>
            array(
                'title' =>
                    $customer->title,

                'first_name' =>
                    $customer->first_name,

                'middle_name' =>
                    $customer->middle_name,

                'last_name' =>
                    $customer->last_name,

                'preferred_name' =>
                    $customer->preferred_name
            ),

        'company' =>
            array(
                'company_name' =>
                    $customer->company_name,

                'organization_number' =>
                    $customer->organization_number,

                'job_title' =>
                    $customer->job_title,

                'department' =>
                    $customer->department
            ),

        'personal' =>
            $details
            ? array(
                'birth_date' =>
                    $details->birth_date,

                'birth_year' =>
                    $details->birth_year,

                'gender' =>
                    $details->gender,

                'preferred_language' =>
                    $details->preferred_language,

                'nationality' =>
                    $details->nationality
            )
            : array(),

        'contacts' =>
            $contacts,

        'addresses' =>
            $addresses,

        'social_media' =>
            $social,

        'images' =>
            $image_data,

        'created_at' =>
            $customer->created_at,

        'updated_at' =>
            $customer->updated_at
    );
}


/*
 * =========================================================
 * REST API CALLBACKS
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * GET CUSTOMER LIST
 * ---------------------------------------------------------
 */

function rud_crm_rest_get_customers(
    WP_REST_Request $request
) {

    global $wpdb;

    $auth =
        rud_crm_rest_authenticate(
            $request,
            'read'
        );

    if (
        is_wp_error(
            $auth
        )
    ) {
        return $auth;
    }

    $limit =
        absint(
            $request->get_param(
                'limit'
            )
        );

    if (
        $limit <= 0
    ) {
        $limit = 50;
    }

    $limit =
        min(
            $limit,
            100
        );

    $offset =
        max(
            0,
            absint(
                $request->get_param(
                    'offset'
                )
            )
        );

    $search =
        sanitize_text_field(
            $request->get_param(
                'search'
            )
        );

    if (
        '' !==
        $search
    ) {

        $like =
            '%' .
            $wpdb->esc_like(
                $search
            ) .
            '%';

        $ids =
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE customer_number LIKE %s
                     OR first_name LIKE %s
                     OR middle_name LIKE %s
                     OR last_name LIKE %s
                     OR company_name LIKE %s
                     ORDER BY id DESC
                     LIMIT %d OFFSET %d",
                    $like,
                    $like,
                    $like,
                    $like,
                    $like,
                    $limit,
                    $offset
                )
            );

    } else {

        $ids =
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     ORDER BY id DESC
                     LIMIT %d OFFSET %d",
                    $limit,
                    $offset
                )
            );
    }

    $customers =
        array();

    foreach (
        $ids as
        $customer_id
    ) {

        $data =
            rud_crm_api_get_customer_data(
                $customer_id
            );

        if ( $data ) {
            $customers[] =
                $data;
        }
    }

    return rest_ensure_response(
        array(
            'success' =>
                true,

            'count' =>
                count(
                    $customers
                ),

            'limit' =>
                $limit,

            'offset' =>
                $offset,

            'customers' =>
                $customers
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET ONE CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_rest_get_customer(
    WP_REST_Request $request
) {

    $auth =
        rud_crm_rest_authenticate(
            $request,
            'read'
        );

    if (
        is_wp_error(
            $auth
        )
    ) {
        return $auth;
    }

    $customer_id =
        absint(
            $request[
                'id'
            ]
        );

    $customer =
        rud_crm_api_get_customer_data(
            $customer_id
        );

    if ( ! $customer ) {

        return new WP_Error(
            'rud_customer_not_found',
            'Customer could not be found.',
            array(
                'status' => 404
            )
        );
    }

    return rest_ensure_response(
        array(
            'success' =>
                true,

            'customer' =>
                $customer
        )
    );
}


/*
 * =========================================================
 * REGISTER REST ROUTES
 * =========================================================
 */

function rud_crm_register_rest_routes() {

    register_rest_route(
        'rud-crm/v1',
        '/customers',
        array(
            'methods' =>
                WP_REST_Server::READABLE,

            'callback' =>
                'rud_crm_rest_get_customers',

            'permission_callback' =>
                '__return_true',

            'args' =>
                array(
                    'search' =>
                        array(
                            'required' =>
                                false,

                            'sanitize_callback' =>
                                'sanitize_text_field'
                        ),

                    'limit' =>
                        array(
                            'required' =>
                                false,

                            'default' =>
                                50,

                            'sanitize_callback' =>
                                'absint'
                        ),

                    'offset' =>
                        array(
                            'required' =>
                                false,

                            'default' =>
                                0,

                            'sanitize_callback' =>
                                'absint'
                        )
                )
        )
    );


    register_rest_route(
        'rud-crm/v1',
        '/customers/(?P<id>\d+)',
        array(
            'methods' =>
                WP_REST_Server::READABLE,

            'callback' =>
                'rud_crm_rest_get_customer',

            'permission_callback' =>
                '__return_true',

            'args' =>
                array(
                    'id' =>
                        array(
                            'required' =>
                                true,

                            'sanitize_callback' =>
                                'absint'
                        )
                )
        )
    );
}

add_action(
    'rest_api_init',
    'rud_crm_register_rest_routes'
);


/*
 * =========================================================
 * API / SECURITY ADMIN PAGE
 * =========================================================
 */

function rud_crm_api_security_page() {

    global $wpdb;

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {
        return;
    }

    $sites_table =
        $wpdb->prefix .
        'rudcrm_sites';

    $new_credentials =
        null;


    /*
     * GENERATE / REGENERATE
     */

    if (
        isset(
            $_POST[
                'rud_crm_generate_api_credentials'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_generate_api_credentials_action',
            'rud_crm_generate_api_credentials_nonce'
        );

        $new_credentials =
            rud_crm_generate_site_api_credentials(
                absint(
                    $_POST[
                        'site_id'
                    ] ?? 0
                )
            );

        if (
            is_wp_error(
                $new_credentials
            )
        ) {

            echo '<div class="notice notice-error">';

            echo '<p>' .
                esc_html(
                    $new_credentials
                        ->get_error_message()
                ) .
                '</p>';

            echo '</div>';

            $new_credentials =
                null;
        }
    }


    /*
     * REVOKE
     */

    if (
        isset(
            $_POST[
                'rud_crm_revoke_api_credentials'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_api_status_action',
            'rud_crm_api_status_nonce'
        );

        rud_crm_set_api_credential_status(
            absint(
                $_POST[
                    'site_id'
                ] ?? 0
            ),
            'revoked'
        );

        echo '<div class="notice notice-success">';

        echo '<p><strong>API access revoked.</strong></p>';

        echo '</div>';
    }


    /*
     * ACTIVATE
     */

    if (
        isset(
            $_POST[
                'rud_crm_activate_api_credentials'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_api_status_action',
            'rud_crm_api_status_nonce'
        );

        rud_crm_set_api_credential_status(
            absint(
                $_POST[
                    'site_id'
                ] ?? 0
            ),
            'active'
        );

        echo '<div class="notice notice-success">';

        echo '<p><strong>API access activated.</strong></p>';

        echo '</div>';
    }


    $sites =
        $wpdb->get_results(
            "SELECT *
             FROM $sites_table
             ORDER BY id ASC"
        );


    /*
     * PAGE START
     */

    echo '<div class="wrap">';

    echo '<h1>API / Security</h1>';

    echo '<p>';

    echo 'Manage API credentials and secure access for each connected website.';

    echo '</p>';


    /*
     * REST API INFORMATION
     */

    echo '<div
        style="
            background:#fff;
            border:1px solid #ccd0d4;
            padding:20px;
            margin:20px 0;
            max-width:1100px;
        "
    >';

    echo '<h2>RUD CRM REST API</h2>';

    echo '<p><strong>Read-only API is currently enabled.</strong></p>';

    echo '<p>';

    echo '<code>/wp-json/rud-crm/v1/customers</code>';

    echo '<br>';

    echo '<code>/wp-json/rud-crm/v1/customers/1</code>';

    echo '</p>';

    echo '<p>';

    echo 'Required HTTP headers:';

    echo '</p>';

    echo '<pre style="background:#f6f7f7;padding:12px;">';

    echo 'X-RUD-Client-ID: your-client-id' . "\n";

    echo 'X-RUD-API-Secret: your-api-secret';

    echo '</pre>';

    echo '</div>';


    /*
     * NEW CREDENTIALS
     */

    if (
        is_array(
            $new_credentials
        )
    ) {

        echo '<div
            style="
                background:#fff;
                border:2px solid #d63638;
                padding:20px;
                margin:20px 0;
                max-width:1050px;
            "
        >';

        echo '<h2>New API Credentials</h2>';

        echo '<p>';

        echo '<strong>Important:</strong> Copy the API Secret now. It cannot be displayed again later.';

        echo '</p>';


        echo '<table class="widefat striped">';


        echo '<tr>';

        echo '<th style="width:180px;">Website</th>';

        echo '<td>' .
            esc_html(
                $new_credentials[
                    'site_name'
                ]
            ) .
            '</td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>Domain</th>';

        echo '<td><code>' .
            esc_html(
                $new_credentials[
                    'domain'
                ]
            ) .
            '</code></td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>Client ID</th>';

        echo '<td>';

        echo '<div class="rud-crm-copy-row">';

        echo '<input
            type="text"
            readonly
            id="rud-new-client-id"
            class="large-text code"
            value="' .
            esc_attr(
                $new_credentials[
                    'client_id'
                ]
            ) .
            '"
        >';

        echo '<button
            type="button"
            class="button rud-crm-copy-button"
            data-copy-target="rud-new-client-id"
        >
            Copy
        </button>';

        echo '<span class="rud-crm-copy-status"></span>';

        echo '</div>';

        echo '</td>';

        echo '</tr>';


        echo '<tr>';

        echo '<th>API Secret</th>';

        echo '<td>';

        echo '<div class="rud-crm-copy-row">';

        echo '<input
            type="text"
            readonly
            id="rud-new-api-secret"
            class="large-text code"
            value="' .
            esc_attr(
                $new_credentials[
                    'secret'
                ]
            ) .
            '"
        >';

        echo '<button
            type="button"
            class="button button-primary rud-crm-copy-button"
            data-copy-target="rud-new-api-secret"
        >
            Copy Secret
        </button>';

        echo '<span class="rud-crm-copy-status"></span>';

        echo '</div>';

        echo '</td>';

        echo '</tr>';


        echo '</table>';

        echo '</div>';
    }


    /*
     * WEBSITE CREDENTIALS
     */

    echo '<h2>Connected Website Credentials</h2>';

    if (
        empty(
            $sites
        )
    ) {

        echo '<p>No connected websites exist yet.</p>';

    } else {

        echo '<table class="widefat striped">';

        echo '<thead>';

        echo '<tr>';

        echo '<th>Site ID</th>';

        echo '<th>Website</th>';

        echo '<th>Domain</th>';

        echo '<th>Client ID</th>';

        echo '<th>API Status</th>';

        echo '<th>Last Used</th>';

        echo '<th>Permissions</th>';

        echo '<th>Actions</th>';

        echo '</tr>';

        echo '</thead>';

        echo '<tbody>';


        foreach (
            $sites as
            $site
        ) {

            $credential =
                rud_crm_get_site_api_credential(
                    $site->id
                );

            echo '<tr>';


            echo '<td><strong>' .
                esc_html(
                    $site->site_number
                ) .
                '</strong></td>';


            echo '<td>' .
                esc_html(
                    $site->site_name
                ) .
                '</td>';


            echo '<td><code>' .
                esc_html(
                    $site->domain
                ) .
                '</code></td>';


            echo '<td>';

            if (
                $credential
            ) {

                $client_input_id =
                    'rud-client-' .
                    absint(
                        $site->id
                    );

                echo '<div class="rud-crm-copy-row">';

                echo '<input
                    type="text"
                    readonly
                    id="' .
                    esc_attr(
                        $client_input_id
                    ) .
                    '"
                    class="regular-text code"
                    value="' .
                    esc_attr(
                        $credential->client_id
                    ) .
                    '"
                >';

                echo '<button
                    type="button"
                    class="button rud-crm-copy-button"
                    data-copy-target="' .
                    esc_attr(
                        $client_input_id
                    ) .
                    '"
                >
                    Copy
                </button>';

                echo '<span class="rud-crm-copy-status"></span>';

                echo '</div>';

            } else {

                echo 'Not generated';
            }

            echo '</td>';


            echo '<td>';

            if (
                ! $credential
            ) {

                echo '<span style="color:#777;">NONE</span>';

            } elseif (
                'active' ===
                $credential->status
            ) {

                echo '<strong style="color:green;">ACTIVE</strong>';

            } else {

                echo '<strong style="color:#b32d2e;">REVOKED</strong>';
            }

            echo '</td>';


            echo '<td>';

            if (
                $credential &&
                $credential->last_used_at
            ) {

                echo esc_html(
                    $credential->last_used_at
                );

            } else {

                echo 'Never';
            }

            echo '</td>';


            echo '<td>';

            echo 'C:' .
                (
                    $site->allow_create
                    ? '✓'
                    : '—'
                );

            echo ' &nbsp; R:' .
                (
                    $site->allow_read
                    ? '✓'
                    : '—'
                );

            echo ' &nbsp; U:' .
                (
                    $site->allow_update
                    ? '✓'
                    : '—'
                );

            echo ' &nbsp; D:' .
                (
                    $site->allow_delete
                    ? '✓'
                    : '—'
                );

            echo '</td>';


            echo '<td>';


            echo '<form
                method="post"
                style="display:inline-block;margin-right:5px;"
            >';

            wp_nonce_field(
                'rud_crm_generate_api_credentials_action',
                'rud_crm_generate_api_credentials_nonce'
            );

            echo '<input
                type="hidden"
                name="site_id"
                value="' .
                esc_attr(
                    $site->id
                ) .
                '"
            >';

            echo '<button
                type="submit"
                class="button"
                name="rud_crm_generate_api_credentials"
                onclick="return confirm(\'Generate new API credentials? Existing credentials will stop working.\');"
            >';

            echo $credential
                ? 'Regenerate'
                : 'Generate';

            echo '</button>';

            echo '</form>';


            if (
                $credential
            ) {

                echo '<form
                    method="post"
                    style="display:inline-block;"
                >';

                wp_nonce_field(
                    'rud_crm_api_status_action',
                    'rud_crm_api_status_nonce'
                );

                echo '<input
                    type="hidden"
                    name="site_id"
                    value="' .
                    esc_attr(
                        $site->id
                    ) .
                    '"
                >';

                if (
                    'active' ===
                    $credential->status
                ) {

                    echo '<button
                        type="submit"
                        class="button"
                        name="rud_crm_revoke_api_credentials"
                    >
                        Revoke
                    </button>';

                } else {

                    echo '<button
                        type="submit"
                        class="button button-primary"
                        name="rud_crm_activate_api_credentials"
                    >
                        Activate
                    </button>';
                }

                echo '</form>';
            }

            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody>';

        echo '</table>';
    }


    /*
     * COPY JAVASCRIPT
     */

    ?>

    <script>

    document.addEventListener(
        'DOMContentLoaded',
        function() {

            document
                .querySelectorAll(
                    '.rud-crm-copy-button'
                )
                .forEach(
                    function(button) {

                        button.addEventListener(
                            'click',
                            function() {

                                var targetId =
                                    button.getAttribute(
                                        'data-copy-target'
                                    );

                                var input =
                                    document.getElementById(
                                        targetId
                                    );

                                if (!input) {
                                    return;
                                }

                                var status =
                                    button
                                        .parentElement
                                        .querySelector(
                                            '.rud-crm-copy-status'
                                        );


                                function showCopied() {

                                    if (!status) {
                                        return;
                                    }

                                    status.textContent =
                                        'Copied!';

                                    window.setTimeout(
                                        function() {
                                            status.textContent =
                                                '';
                                        },
                                        1800
                                    );
                                }


                                if (
                                    navigator.clipboard &&
                                    window.isSecureContext
                                ) {

                                    navigator
                                        .clipboard
                                        .writeText(
                                            input.value
                                        )
                                        .then(
                                            showCopied
                                        );

                                } else {

                                    input.focus();

                                    input.select();

                                    document.execCommand(
                                        'copy'
                                    );

                                    showCopied();
                                }
                            }
                        );
                    }
                );
        }
    );

    </script>


    <style>

    .rud-crm-copy-row {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .rud-crm-copy-status {
        font-weight: 600;
        color: #008a20;
        min-width: 60px;
    }

    </style>

    <?php

    echo '</div>';
}