<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * USER ACCESS / DEMO ACCOUNT SYSTEM
 * =========================================================
 *
 * Provides:
 *
 * - CRM Demo User role
 * - Automatic 3-month trial period
 * - Valid From / Valid Until
 * - Trial status
 * - Automatic expiry of CRM access
 * - 35 shared DEMO customers
 * - Access to the demo user's own real customers
 * - Protection against access to other users' customers
 *
 * =========================================================
 */


/*
 * =========================================================
 * DEMO ROLE
 * =========================================================
 */

function rud_crm_register_demo_role() {

    $role =
        get_role(
            'rud_crm_demo'
        );


    if (
        ! $role
    ) {

        $role =
            add_role(

                'rud_crm_demo',

                'CRM Demo User',

                array(

                    'read' => true,

                    'rud_crm_view'   => true,
                    'rud_crm_create' => true,
                    'rud_crm_edit'   => true,

                    'rud_crm_delete' =>
                        false,

                    'rud_crm_export' =>
                        false,

                    'rud_crm_manage_sites' =>
                        false,

                    'rud_crm_manage_api' =>
                        false,

                    'rud_crm_manage_settings' =>
                        false,

                    'manage_options' =>
                        false,

                    'edit_posts' =>
                        false,

                    'publish_posts' =>
                        false,

                    'delete_posts' =>
                        false
                )
            );
    }


    if (
        $role
    ) {

        $role->add_cap(
            'read'
        );

        $role->add_cap(
            'rud_crm_view'
        );

        $role->add_cap(
            'rud_crm_create'
        );

        $role->add_cap(
            'rud_crm_edit'
        );


        /*
         * Make sure restricted capabilities
         * remain disabled for demo users.
         */

        $role->remove_cap(
            'rud_crm_delete'
        );

        $role->remove_cap(
            'rud_crm_export'
        );

        $role->remove_cap(
            'rud_crm_manage_sites'
        );

        $role->remove_cap(
            'rud_crm_manage_api'
        );

        $role->remove_cap(
            'rud_crm_manage_settings'
        );
    }
}


add_action(
    'init',
    'rud_crm_register_demo_role'
);


/*
 * =========================================================
 * DEMO TRIAL LENGTH
 * =========================================================
 */

function rud_crm_demo_trial_months() {

    return 3;
}


/*
 * =========================================================
 * CHECK WHETHER USER IS A DEMO USER
 * =========================================================
 */

function rud_crm_is_demo_user(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    return
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        );
}


/*
 * =========================================================
 * GET ACCESS DATES
 * =========================================================
 */

function rud_crm_user_valid_from(
    $user_id
) {

    return
        get_user_meta(
            absint(
                $user_id
            ),
            'rud_crm_valid_from',
            true
        );
}


function rud_crm_user_valid_until(
    $user_id
) {

    return
        get_user_meta(
            absint(
                $user_id
            ),
            'rud_crm_valid_until',
            true
        );
}


/*
 * =========================================================
 * START DEMO TRIAL
 * =========================================================
 */

function rud_crm_start_demo_trial(
    $user_id,
    $force = false
) {

    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    if (
        ! rud_crm_is_demo_user(
            $user_id
        )
    ) {

        return false;
    }


    $existing_from =
        rud_crm_user_valid_from(
            $user_id
        );


    $existing_until =
        rud_crm_user_valid_until(
            $user_id
        );


    if (
        ! $force
        &&
        ! empty(
            $existing_from
        )
        &&
        ! empty(
            $existing_until
        )
    ) {

        return true;
    }


    $timezone =
        wp_timezone();


    $start =
        new DateTimeImmutable(
            'now',
            $timezone
        );


    $end =
        $start->modify(
            '+' .
            absint(
                rud_crm_demo_trial_months()
            ) .
            ' months'
        );


    $start_value =
        $start->format(
            'Y-m-d H:i:s'
        );


    $end_value =
        $end->format(
            'Y-m-d H:i:s'
        );


    update_user_meta(
        $user_id,
        'rud_crm_valid_from',
        $start_value
    );


    update_user_meta(
        $user_id,
        'rud_crm_valid_until',
        $end_value
    );


    update_user_meta(
        $user_id,
        'rud_crm_trial_started',
        $start_value
    );


    update_user_meta(
        $user_id,
        'rud_crm_trial_status',
        'active'
    );


    return true;
}


/*
 * =========================================================
 * START TRIAL WHEN ROLE CHANGES TO DEMO
 * =========================================================
 */

function rud_crm_demo_role_changed(
    $user_id,
    $role,
    $old_roles
) {

    if (
        'rud_crm_demo' !==
        $role
    ) {

        return;
    }


    rud_crm_start_demo_trial(
        $user_id,
        false
    );
}


add_action(
    'set_user_role',
    'rud_crm_demo_role_changed',
    10,
    3
);


/*
 * =========================================================
 * NEW USER SAFETY
 * =========================================================
 */

function rud_crm_demo_user_registered(
    $user_id
) {

    if (
        rud_crm_is_demo_user(
            $user_id
        )
    ) {

        rud_crm_start_demo_trial(
            $user_id,
            false
        );
    }
}


add_action(
    'user_register',
    'rud_crm_demo_user_registered',
    20
);


/*
 * =========================================================
 * CHECK WHETHER ACCESS PERIOD IS ACTIVE
 * =========================================================
 */

function rud_crm_user_access_is_active(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    /*
     * Administrators are never restricted
     * by CRM access dates.
     */

    if (
        in_array(
            'administrator',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    $valid_from =
        rud_crm_user_valid_from(
            $user_id
        );


    $valid_until =
        rud_crm_user_valid_until(
            $user_id
        );


    /*
     * Existing users without CRM validity dates
     * remain unaffected.
     */

    if (
        empty(
            $valid_from
        )
        &&
        empty(
            $valid_until
        )
    ) {

        return true;
    }


    $timezone =
        wp_timezone();


    $now =
        new DateTimeImmutable(
            'now',
            $timezone
        );


    if (
        ! empty(
            $valid_from
        )
    ) {

        try {

            $from =
                new DateTimeImmutable(
                    $valid_from,
                    $timezone
                );


            if (
                $now <
                $from
            ) {

                return false;
            }

        } catch (
            Exception $e
        ) {

            return false;
        }
    }


    if (
        ! empty(
            $valid_until
        )
    ) {

        try {

            $until =
                new DateTimeImmutable(
                    $valid_until,
                    $timezone
                );


            if (
                $now >
                $until
            ) {

                return false;
            }

        } catch (
            Exception $e
        ) {

            return false;
        }
    }


    return true;
}


/*
 * =========================================================
 * DEMO TRIAL STATUS
 * =========================================================
 */

function rud_crm_demo_trial_status(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! rud_crm_is_demo_user(
            $user_id
        )
    ) {

        return 'not_demo';
    }


    if (
        rud_crm_user_access_is_active(
            $user_id
        )
    ) {

        update_user_meta(
            $user_id,
            'rud_crm_trial_status',
            'active'
        );


        return 'active';
    }


    update_user_meta(
        $user_id,
        'rud_crm_trial_status',
        'expired'
    );


    return 'expired';
}


/*
 * =========================================================
 * DAYS REMAINING
 * =========================================================
 */

function rud_crm_demo_days_remaining(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $valid_until =
        rud_crm_user_valid_until(
            $user_id
        );


    if (
        empty(
            $valid_until
        )
    ) {

        return null;
    }


    try {

        $timezone =
            wp_timezone();


        $now =
            new DateTimeImmutable(
                'now',
                $timezone
            );


        $until =
            new DateTimeImmutable(
                $valid_until,
                $timezone
            );


        if (
            $until <=
            $now
        ) {

            return 0;
        }


        return
            (int)
            $now->diff(
                $until
            )->days;

    } catch (
        Exception $e
    ) {

        return null;
    }
}


/*
 * =========================================================
 * BLOCK EXPIRED CRM CAPABILITIES
 * =========================================================
 */

function rud_crm_block_expired_capabilities(
    $allcaps,
    $caps,
    $args,
    $user
) {

    if (
        ! $user
        ||
        empty(
            $user->ID
        )
    ) {

        return $allcaps;
    }


    if (
        in_array(
            'administrator',
            (array)
            $user->roles,
            true
        )
    ) {

        return $allcaps;
    }


    $valid_from =
        get_user_meta(
            $user->ID,
            'rud_crm_valid_from',
            true
        );


    $valid_until =
        get_user_meta(
            $user->ID,
            'rud_crm_valid_until',
            true
        );


    if (
        empty(
            $valid_from
        )
        &&
        empty(
            $valid_until
        )
    ) {

        return $allcaps;
    }


    $timezone =
        wp_timezone();


    $now =
        new DateTimeImmutable(
            'now',
            $timezone
        );


    $active =
        true;


    if (
        ! empty(
            $valid_from
        )
    ) {

        try {

            $from =
                new DateTimeImmutable(
                    $valid_from,
                    $timezone
                );


            if (
                $now <
                $from
            ) {

                $active =
                    false;
            }

        } catch (
            Exception $e
        ) {

            $active =
                false;
        }
    }


    if (
        $active
        &&
        ! empty(
            $valid_until
        )
    ) {

        try {

            $until =
                new DateTimeImmutable(
                    $valid_until,
                    $timezone
                );


            if (
                $now >
                $until
            ) {

                $active =
                    false;
            }

        } catch (
            Exception $e
        ) {

            $active =
                false;
        }
    }


    if (
        $active
    ) {

        return $allcaps;
    }


    $crm_caps =
        array(

            'rud_crm_view',
            'rud_crm_create',
            'rud_crm_edit',
            'rud_crm_delete',
            'rud_crm_export',
            'rud_crm_manage_sites',
            'rud_crm_manage_api',
            'rud_crm_manage_settings'
        );


    foreach (
        $crm_caps as
        $cap
    ) {

        $allcaps[
            $cap
        ] =
            false;
    }


    return $allcaps;
}


add_filter(
    'user_has_cap',
    'rud_crm_block_expired_capabilities',
    20,
    4
);


/*
 * =========================================================
 * ADMIN USER PROFILE
 * =========================================================
 */

function rud_crm_user_access_profile_fields(
    $user
) {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return;
    }


    $valid_from =
        rud_crm_user_valid_from(
            $user->ID
        );


    $valid_until =
        rud_crm_user_valid_until(
            $user->ID
        );


    ?>

    <h2>
        RUD CRM Access
    </h2>

    <table class="form-table">


        <tr>

            <th>

                <label for="rud_crm_valid_from">
                    Valid From
                </label>

            </th>

            <td>

                <input
                    type="datetime-local"
                    id="rud_crm_valid_from"
                    name="rud_crm_valid_from"
                    value="<?php

                    echo esc_attr(
                        $valid_from
                        ?
                        str_replace(
                            ' ',
                            'T',
                            substr(
                                $valid_from,
                                0,
                                16
                            )
                        )
                        :
                        ''
                    );

                    ?>"
                >

                <p class="description">
                    CRM access begins at this date and time.
                </p>

            </td>

        </tr>


        <tr>

            <th>

                <label for="rud_crm_valid_until">
                    Valid Until
                </label>

            </th>

            <td>

                <input
                    type="datetime-local"
                    id="rud_crm_valid_until"
                    name="rud_crm_valid_until"
                    value="<?php

                    echo esc_attr(
                        $valid_until
                        ?
                        str_replace(
                            ' ',
                            'T',
                            substr(
                                $valid_until,
                                0,
                                16
                            )
                        )
                        :
                        ''
                    );

                    ?>"
                >

                <p class="description">
                    Leave empty for no expiry.
                </p>

            </td>

        </tr>


        <?php

        if (
            rud_crm_is_demo_user(
                $user->ID
            )
        ) {

            $status =
                rud_crm_demo_trial_status(
                    $user->ID
                );


            $days =
                rud_crm_demo_days_remaining(
                    $user->ID
                );


            $trial_limit =
                function_exists(
                    'rud_crm_trial_customer_limit'
                )
                ?
                rud_crm_trial_customer_limit()
                :
                10;


            $trial_used =
                function_exists(
                    'rud_crm_count_user_owned_customers'
                )
                ?
                rud_crm_count_user_owned_customers(
                    $user->ID,
                    'trial'
                )
                :
                0;


            $trial_remaining =
                max(
                    0,
                    $trial_limit -
                    $trial_used
                );

            ?>

            <tr>

                <th>
                    Demo Trial Status
                </th>

                <td>

                    <strong>

                        <?php

                        echo esc_html(
                            ucfirst(
                                $status
                            )
                        );

                        ?>

                    </strong>


                    <?php

                    if (
                        null !==
                        $days
                    ) {

                        ?>

                        <p>

                            <?php

                            echo esc_html(
                                $days .
                                ' day' .
                                (
                                    1 ===
                                    $days
                                    ?
                                    ''
                                    :
                                    's'
                                ) .
                                ' remaining'
                            );

                            ?>

                        </p>

                        <?php
                    }

                    ?>

                </td>

            </tr>


            <tr>

                <th>
                    Trial Customer Limit
                </th>

                <td>

                    <strong>

                        <?php

                        echo esc_html(
                            $trial_used .
                            ' / ' .
                            $trial_limit
                        );

                        ?>

                    </strong>

                    <p>

                        <?php

                        echo esc_html(
                            $trial_remaining .
                            ' customer slot' .
                            (
                                1 ===
                                $trial_remaining
                                ?
                                ''
                                :
                                's'
                            ) .
                            ' remaining'
                        );

                        ?>

                    </p>

                    <p class="description">
                        The 35 shared DEMO customers do not count toward this limit.
                    </p>

                </td>

            </tr>

            <?php
        }

        ?>

    </table>

    <?php
}


add_action(
    'show_user_profile',
    'rud_crm_user_access_profile_fields'
);


add_action(
    'edit_user_profile',
    'rud_crm_user_access_profile_fields'
);


/*
 * =========================================================
 * SAVE ACCESS DATES
 * =========================================================
 */

function rud_crm_save_user_access_profile_fields(
    $user_id
) {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return;
    }


    /*
     * VALID FROM
     */

    if (
        isset(
            $_POST['rud_crm_valid_from']
        )
    ) {

        $value =
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_valid_from']
                )
            );


        if (
            '' ===
            $value
        ) {

            delete_user_meta(
                $user_id,
                'rud_crm_valid_from'
            );

        } else {

            $value =
                str_replace(
                    'T',
                    ' ',
                    $value
                );


            if (
                16 ===
                strlen(
                    $value
                )
            ) {

                $value .=
                    ':00';
            }


            update_user_meta(
                $user_id,
                'rud_crm_valid_from',
                $value
            );
        }
    }


    /*
     * VALID UNTIL
     */

    if (
        isset(
            $_POST['rud_crm_valid_until']
        )
    ) {

        $value =
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_valid_until']
                )
            );


        if (
            '' ===
            $value
        ) {

            delete_user_meta(
                $user_id,
                'rud_crm_valid_until'
            );

        } else {

            $value =
                str_replace(
                    'T',
                    ' ',
                    $value
                );


            if (
                16 ===
                strlen(
                    $value
                )
            ) {

                $value .=
                    ':00';
            }


            update_user_meta(
                $user_id,
                'rud_crm_valid_until',
                $value
            );
        }
    }


    if (
        rud_crm_is_demo_user(
            $user_id
        )
    ) {

        rud_crm_demo_trial_status(
            $user_id
        );
    }
}


add_action(
    'personal_options_update',
    'rud_crm_save_user_access_profile_fields'
);


add_action(
    'edit_user_profile_update',
    'rud_crm_save_user_access_profile_fields'
);


/*
 * =========================================================
 * INITIALIZE EXISTING DEMO USERS
 * =========================================================
 */

function rud_crm_initialize_existing_demo_trials() {

    $users =
        get_users(
            array(

                'role' =>
                    'rud_crm_demo',

                'fields' =>
                    'ID'
            )
        );


    foreach (
        $users as
        $user_id
    ) {

        $valid_from =
            rud_crm_user_valid_from(
                $user_id
            );


        $valid_until =
            rud_crm_user_valid_until(
                $user_id
            );


        if (
            empty(
                $valid_from
            )
            ||
            empty(
                $valid_until
            )
        ) {

            rud_crm_start_demo_trial(
                $user_id,
                true
            );
        }
    }
}


add_action(
    'admin_init',
    'rud_crm_initialize_existing_demo_trials',
    20
);


/*
 * =========================================================
 * DEMO CUSTOMER ACCESS SYSTEM
 * =========================================================
 *
 * CRM Demo Users may access:
 *
 * 1. The 35 shared DEMO- customers
 * 2. Their own real trial customers
 *
 * They may NOT access:
 *
 * - another trial user's customers
 * - normal real CRM customers
 *
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * SHARED DEMO CUSTOMER PREFIX
 * ---------------------------------------------------------
 */

function rud_crm_demo_customer_prefix() {

    return 'DEMO-';
}


/*
 * ---------------------------------------------------------
 * CHECK WHETHER CUSTOMER IS SHARED DEMO CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_is_demo_customer(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    $customer_number =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT customer_number
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    if (
        empty(
            $customer_number
        )
    ) {

        return false;
    }


    $prefix =
        rud_crm_demo_customer_prefix();


    return
        0 ===
        strpos(
            strtoupper(
                $customer_number
            ),
            strtoupper(
                $prefix
            )
        );
}


/*
 * ---------------------------------------------------------
 * CHECK WHETHER USER MAY ACCESS CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_user_can_access_customer(
    $customer_id,
    $user_id = 0
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    /*
     * Administrators may access everything.
     */

    if (
        in_array(
            'administrator',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    /*
     * CRM Demo User.
     */

    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        /*
         * Trial must still be active.
         */

        if (
            ! rud_crm_user_access_is_active(
                $user_id
            )
        ) {

            return false;
        }


        /*
         * The 35 shared DEMO customers.
         */

        if (
            rud_crm_is_demo_customer(
                $customer_id
            )
        ) {

            return true;
        }


        /*
         * User's own real trial customers.
         */

        if (
            function_exists(
                'rud_crm_user_owns_customer'
            )
            &&
            rud_crm_user_owns_customer(
                $customer_id,
                $user_id
            )
        ) {

            return true;
        }


        /*
         * Everything else is blocked.
         */

        return false;
    }


    /*
     * Normal CRM roles are not restricted
     * by demo ownership rules.
     */

    return true;
}


/*
 * ---------------------------------------------------------
 * CHECK ACCESS BY CUSTOMER NUMBER
 * ---------------------------------------------------------
 */

function rud_crm_user_can_access_customer_number(
    $customer_number,
    $user_id = 0
) {

    global $wpdb;


    $customer_number =
        trim(
            (string)
            $customer_number
        );


    if (
        '' ===
        $customer_number
    ) {

        return false;
    }


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    /*
     * Administrator.
     */

    if (
        in_array(
            'administrator',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    /*
     * CRM Demo User.
     */

    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        if (
            ! rud_crm_user_access_is_active(
                $user_id
            )
        ) {

            return false;
        }


        /*
         * Shared DEMO customer number.
         */

        $prefix =
            rud_crm_demo_customer_prefix();


        if (
            0 ===
            strpos(
                strtoupper(
                    $customer_number
                ),
                strtoupper(
                    $prefix
                )
            )
        ) {

            return true;
        }


        /*
         * Real customer.
         *
         * Find the customer ID first.
         */

        $customer_id =
            (int)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE customer_number = %s
                     LIMIT 1",
                    $customer_number
                )
            );


        if (
            ! $customer_id
        ) {

            return false;
        }


        /*
         * Only the user's own real customer.
         */

        if (
            function_exists(
                'rud_crm_user_owns_customer'
            )
        ) {

            return
                rud_crm_user_owns_customer(
                    $customer_id,
                    $user_id
                );
        }


        return false;
    }


    return true;
}


/*
 * ---------------------------------------------------------
 * SQL CONDITION FOR CUSTOMER LISTS
 * ---------------------------------------------------------
 *
 * IMPORTANT:
 *
 * For Demo Users this returns an SQL condition allowing:
 *
 * - shared DEMO- customers
 * - user's owned customers
 *
 * Other users receive no extra restriction.
 *
 * The customer table alias may be supplied.
 *
 * ---------------------------------------------------------
 */

function rud_crm_customer_access_sql_condition(
    $table_alias = ''
) {

    global $wpdb;


    if (
        ! rud_crm_is_demo_user()
    ) {

        return '';
    }


    $user_id =
        get_current_user_id();


    if (
        ! $user_id
    ) {

        return
            ' AND 1 = 0 ';
    }


    if (
        ! rud_crm_user_access_is_active(
            $user_id
        )
    ) {

        return
            ' AND 1 = 0 ';
    }


    $prefix =
        rud_crm_demo_customer_prefix();


    $customer_number_column =
        'customer_number';


    $customer_id_column =
        'id';


    if (
        '' !==
        $table_alias
    ) {

        $table_alias =
            preg_replace(
                '/[^a-zA-Z0-9_]/',
                '',
                $table_alias
            );


        if (
            '' !==
            $table_alias
        ) {

            $customer_number_column =
                $table_alias .
                '.customer_number';


            $customer_id_column =
                $table_alias .
                '.id';
        }
    }


    /*
     * If ownership module is unavailable,
     * fail safely by allowing only shared DEMO customers.
     */

    if (
        ! function_exists(
            'rud_crm_customer_ownership_table'
        )
    ) {

        return
            $wpdb->prepare(
                " AND {$customer_number_column} LIKE %s ",
                $wpdb->esc_like(
                    $prefix
                ) .
                '%'
            );
    }


    $ownership_table =
        rud_crm_customer_ownership_table();


    return
        $wpdb->prepare(
            "
            AND
            (
                {$customer_number_column} LIKE %s

                OR

                {$customer_id_column} IN
                (
                    SELECT customer_id
                    FROM {$ownership_table}
                    WHERE user_id = %d
                )
            )
            ",
            $wpdb->esc_like(
                $prefix
            ) .
            '%',
            $user_id
        );
}


/*
 * ---------------------------------------------------------
 * PROTECT DIRECT CUSTOMER URL ACCESS
 * ---------------------------------------------------------
 *
 * Prevents a Demo User from changing:
 *
 * ?rud_customer_id=123
 *
 * and opening a customer they do not own.
 *
 * ---------------------------------------------------------
 */

function rud_crm_protect_demo_customer_request() {

    /*
     * Do not interfere with WordPress admin.
     */

    if (
        is_admin()
    ) {

        return;
    }


    /*
     * Only Demo Users need this restriction.
     */

    if (
        ! rud_crm_is_demo_user()
    ) {

        return;
    }


    /*
     * No customer selected.
     */

    if (
        ! isset(
            $_GET['rud_customer_id']
        )
    ) {

        return;
    }


    $customer_id =
        absint(
            $_GET['rud_customer_id']
        );


    if (
        ! $customer_id
    ) {

        return;
    }


    /*
     * Customer is allowed.
     */

    if (
        rud_crm_user_can_access_customer(
            $customer_id
        )
    ) {

        return;
    }


    /*
     * Block access.
     */

    wp_die(

        esc_html__(
            'This customer is not available in your CRM account.',
            'rud-crm-server'
        ),

        esc_html__(
            'CRM Access Restricted',
            'rud-crm-server'
        ),

        array(

            'response' =>
                403,

            'back_link' =>
                true
        )
    );
}


add_action(
    'template_redirect',
    'rud_crm_protect_demo_customer_request',
    5
);