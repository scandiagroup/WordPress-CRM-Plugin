<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END COMPANY CONTACT PERSONS / EMPLOYEES
 * Version 1.2
 * =========================================================
 *
 * Provides:
 * - Add Contact Person / Employee
 * - Multiple contacts per company
 * - Edit existing contacts
 * - Delete contacts
 * - Primary Contact
 * - Personal Contact Notes
 *
 * Requires:
 * includes/company-contacts.php
 *
 * =========================================================
 */


/*
 * =========================================================
 * PERMISSION CHECK
 * =========================================================
 */

function rud_crm_frontend_company_contacts_can_edit_customer(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        function_exists(
            'rud_crm_frontend_edit_can_edit'
        )
    ) {

        return (bool)
            rud_crm_frontend_edit_can_edit(
                $customer_id
            );
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_user_owns_customer'
        )
    ) {

        return (bool)
            rud_crm_user_owns_customer(
                get_current_user_id(),
                $customer_id
            );
    }

    return false;
}


/*
 * =========================================================
 * CUSTOMER EDIT URL
 * =========================================================
 */

function rud_crm_frontend_company_contacts_edit_url(
    $customer_id,
    $args = array()
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        function_exists(
            'rud_crm_frontend_edit_customer_url'
        )
    ) {

        $url =
            rud_crm_frontend_edit_customer_url(
                $customer_id
            );

    } elseif (
        function_exists(
            'rud_crm_customer_frontend_url'
        )
    ) {

        $url =
            add_query_arg(
                array(
                    'rud_crm_action' =>
                        'edit_customer',

                    'rud_customer_id' =>
                        $customer_id,
                ),
                rud_crm_customer_frontend_url()
            );

    } else {

        $url =
            add_query_arg(
                array(
                    'rud_crm_action' =>
                        'edit_customer',

                    'rud_customer_id' =>
                        $customer_id,
                ),
                home_url(
                    '/customer-crm/'
                )
            );
    }

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * VERIFY CONTACT BELONGS TO CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_company_contact_belongs_to_customer(
    $contact_id,
    $customer_id
) {

    if (
        ! function_exists(
            'rud_crm_get_company_contact'
        )
    ) {
        return false;
    }

    $contact =
        rud_crm_get_company_contact(
            $contact_id
        );

    if (
        ! $contact
    ) {
        return false;
    }

    return
        absint(
            $contact->customer_id
        )
        ===
        absint(
            $customer_id
        );
}


/*
 * =========================================================
 * REQUEST DATA
 * =========================================================
 */

function rud_crm_frontend_company_contact_request_data() {

    return array(

        'first_name' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['first_name']
                    ?? ''
                )
            ),

        'middle_name' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['middle_name']
                    ?? ''
                )
            ),

        'last_name' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['last_name']
                    ?? ''
                )
            ),

        'job_title' =>
            sanitize_key(
                wp_unslash(
                    $_POST['job_title']
                    ?? ''
                )
            ),

        'job_title_custom' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['job_title_custom']
                    ?? ''
                )
            ),

        'department' =>
            sanitize_key(
                wp_unslash(
                    $_POST['department']
                    ?? ''
                )
            ),

        'department_custom' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['department_custom']
                    ?? ''
                )
            ),

        'direct_office_phone' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['direct_office_phone']
                    ?? ''
                )
            ),

        'mobile_phone' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['mobile_phone']
                    ?? ''
                )
            ),

        'work_email' =>
            sanitize_email(
                wp_unslash(
                    $_POST['work_email']
                    ?? ''
                )
            ),

        'private_email' =>
            sanitize_email(
                wp_unslash(
                    $_POST['private_email']
                    ?? ''
                )
            ),

        'whatsapp' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['whatsapp']
                    ?? ''
                )
            ),

        'is_primary' =>
            ! empty(
                $_POST['is_primary']
            )
            ? 1
            : 0,

        'personal_notes' =>
            sanitize_textarea_field(
                wp_unslash(
                    $_POST['personal_notes']
                    ?? ''
                )
            ),
    );
}


/*
 * =========================================================
 * ADD CONTACT PERSON
 * =========================================================
 */

function rud_crm_frontend_process_add_company_contact() {

    if (
        empty(
            $_POST['rud_crm_company_contact_action']
        )
        ||
        'add_contact' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_company_contact_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_company_contacts_can_edit_customer(
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'You do not have permission to add a contact person to this company.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_company_contact_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_company_contact_nonce']
                )
            ),
            'rud_crm_add_company_contact_' .
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    if (
        ! function_exists(
            'rud_crm_create_company_contact'
        )
    ) {

        wp_die(
            esc_html__(
                'The company contact module is not available.',
                'rud-crm-server'
            )
        );
    }

    $result =
        rud_crm_create_company_contact(
            $customer_id,
            rud_crm_frontend_company_contact_request_data()
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_company_contacts_edit_url(
                $customer_id,
                array(
                    'rud_crm_contact_error' =>
                        $result->get_error_code(),
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        rud_crm_frontend_company_contacts_edit_url(
            $customer_id,
            array(
                'rud_crm_contact_message' =>
                    'added',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_add_company_contact',
    31
);


/*
 * =========================================================
 * UPDATE CONTACT PERSON
 * =========================================================
 */

function rud_crm_frontend_process_update_company_contact() {

    if (
        empty(
            $_POST['rud_crm_company_contact_action']
        )
        ||
        'update_contact' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_company_contact_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $contact_id =
        absint(
            $_POST['rud_contact_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_company_contacts_can_edit_customer(
            $customer_id
        )
        ||
        ! rud_crm_frontend_company_contact_belongs_to_customer(
            $contact_id,
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'You do not have permission to edit this contact person.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_company_contact_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_company_contact_nonce']
                )
            ),
            'rud_crm_update_company_contact_' .
            $customer_id .
            '_' .
            $contact_id
        )
    ) {

        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    $result =
        rud_crm_update_company_contact(
            $contact_id,
            rud_crm_frontend_company_contact_request_data()
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_company_contacts_edit_url(
                $customer_id,
                array(
                    'rud_crm_contact_error' =>
                        $result->get_error_code(),

                    'rud_crm_edit_contact' =>
                        $contact_id,
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        rud_crm_frontend_company_contacts_edit_url(
            $customer_id,
            array(
                'rud_crm_contact_message' =>
                    'updated',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_update_company_contact',
    32
);


/*
 * =========================================================
 * DELETE CONTACT PERSON
 * =========================================================
 */

function rud_crm_frontend_process_delete_company_contact() {

    if (
        empty(
            $_POST['rud_crm_company_contact_action']
        )
        ||
        'delete_contact' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_company_contact_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $contact_id =
        absint(
            $_POST['rud_contact_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_company_contacts_can_edit_customer(
            $customer_id
        )
        ||
        ! rud_crm_frontend_company_contact_belongs_to_customer(
            $contact_id,
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'You do not have permission to delete this contact person.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_company_contact_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_company_contact_nonce']
                )
            ),
            'rud_crm_delete_company_contact_' .
            $customer_id .
            '_' .
            $contact_id
        )
    ) {

        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    rud_crm_delete_company_contact(
        $contact_id
    );

    wp_safe_redirect(
        rud_crm_frontend_company_contacts_edit_url(
            $customer_id,
            array(
                'rud_crm_contact_message' =>
                    'deleted',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_delete_company_contact',
    33
);


/*
 * =========================================================
 * JOB TITLE SELECT
 * =========================================================
 */

function rud_crm_frontend_company_contact_job_title_select(
    $selected = ''
) {

    $options =
        rud_crm_company_contact_job_titles();

    ob_start();

    ?>

    <select
        name="job_title"
        data-rud-contact-job-title
    >

        <?php foreach ( $options as $value => $label ) : ?>

            <option
                value="<?php echo esc_attr( $value ); ?>"
                <?php selected( $selected, $value ); ?>
            >
                <?php echo esc_html( $label ); ?>
            </option>

        <?php endforeach; ?>

    </select>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * DEPARTMENT SELECT
 * =========================================================
 */

function rud_crm_frontend_company_contact_department_select(
    $selected = ''
) {

    $options =
        rud_crm_company_contact_departments();

    ob_start();

    ?>

    <select
        name="department"
        data-rud-contact-department
    >

        <?php foreach ( $options as $value => $label ) : ?>

            <option
                value="<?php echo esc_attr( $value ); ?>"
                <?php selected( $selected, $value ); ?>
            >
                <?php echo esc_html( $label ); ?>
            </option>

        <?php endforeach; ?>

    </select>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CONTACT FORM FIELDS
 * =========================================================
 */

function rud_crm_frontend_company_contact_fields(
    $contact = null
) {

    $value =
        function(
            $field
        ) use (
            $contact
        ) {

            if (
                ! $contact
                ||
                ! isset(
                    $contact->{$field}
                )
            ) {

                return '';
            }

            return
                (string)
                $contact->{$field};
        };

    ob_start();

    ?>

    <div class="rud-crm-company-contact-grid">

        <div>

            <label>
                First Name
            </label>

            <input
                type="text"
                name="first_name"
                value="<?php echo esc_attr( $value( 'first_name' ) ); ?>"
            >

        </div>

        <div>

            <label>
                Middle Name
            </label>

            <input
                type="text"
                name="middle_name"
                value="<?php echo esc_attr( $value( 'middle_name' ) ); ?>"
            >

        </div>

        <div>

            <label>
                Last Name
            </label>

            <input
                type="text"
                name="last_name"
                value="<?php echo esc_attr( $value( 'last_name' ) ); ?>"
            >

        </div>

        <div>

            <label>
                Job Title / Position
            </label>

            <?php
            echo rud_crm_frontend_company_contact_job_title_select(
                $value(
                    'job_title'
                )
            );
            ?>

        </div>

        <div
            data-rud-contact-job-title-custom-wrap
            <?php
            if (
                'other' !==
                $value(
                    'job_title'
                )
            ) {
                echo ' style="display:none;"';
            }
            ?>
        >

            <label>
                Other Job Title / Position
            </label>

            <input
                type="text"
                name="job_title_custom"
                value="<?php echo esc_attr( $value( 'job_title_custom' ) ); ?>"
                placeholder="Enter custom job title"
            >

        </div>

        <div>

            <label>
                Department
            </label>

            <?php
            echo rud_crm_frontend_company_contact_department_select(
                $value(
                    'department'
                )
            );
            ?>

        </div>

        <div
            data-rud-contact-department-custom-wrap
            <?php
            if (
                'other' !==
                $value(
                    'department'
                )
            ) {
                echo ' style="display:none;"';
            }
            ?>
        >

            <label>
                Other Department
            </label>

            <input
                type="text"
                name="department_custom"
                value="<?php echo esc_attr( $value( 'department_custom' ) ); ?>"
                placeholder="Enter custom department"
            >

        </div>

        <div>

            <label>
                Direct Office Number
            </label>

            <?php

            if (
                function_exists(
                    'rud_crm_render_phone_field'
                )
            ) {

                echo wp_kses(
                    rud_crm_render_phone_field(
                        'direct_office_phone',
                        $value(
                            'direct_office_phone'
                        ),
                        array(
                            'id' =>
                                'rud_crm_contact_direct_office_phone_' .
                                (
                                    $contact
                                    ? absint(
                                        $contact->id
                                    )
                                    : 'new'
                                ),

                            'description' =>
                                'Select the country flag and enter the direct office number.'
                        )
                    ),
                    rud_crm_phone_allowed_html()
                );

            } else {

                ?>

                <input
                    type="tel"
                    name="direct_office_phone"
                    value="<?php echo esc_attr( $value( 'direct_office_phone' ) ); ?>"
                    autocomplete="tel"
                >

                <?php
            }

            ?>

        </div>

        <div>

            <label>
                Mobile Number
            </label>

            <?php

            if (
                function_exists(
                    'rud_crm_render_phone_field'
                )
            ) {

                echo wp_kses(
                    rud_crm_render_phone_field(
                        'mobile_phone',
                        $value(
                            'mobile_phone'
                        ),
                        array(
                            'id' =>
                                'rud_crm_contact_mobile_phone_' .
                                (
                                    $contact
                                    ? absint(
                                        $contact->id
                                    )
                                    : 'new'
                                ),

                            'description' =>
                                'Select the country flag and enter the mobile number.'
                        )
                    ),
                    rud_crm_phone_allowed_html()
                );

            } else {

                ?>

                <input
                    type="tel"
                    name="mobile_phone"
                    value="<?php echo esc_attr( $value( 'mobile_phone' ) ); ?>"
                    autocomplete="tel"
                >

                <?php
            }

            ?>

        </div>

        <div>

            <label>
                Work Email
            </label>

            <input
                type="email"
                name="work_email"
                value="<?php echo esc_attr( $value( 'work_email' ) ); ?>"
                autocomplete="email"
            >

        </div>

        <div>

            <label>
                Private Email
            </label>

            <input
                type="email"
                name="private_email"
                value="<?php echo esc_attr( $value( 'private_email' ) ); ?>"
                autocomplete="email"
            >

        </div>

        <div>

            <label>
                WhatsApp
            </label>

            <?php

            if (
                function_exists(
                    'rud_crm_render_phone_field'
                )
            ) {

                echo wp_kses(
                    rud_crm_render_phone_field(
                        'whatsapp',
                        $value(
                            'whatsapp'
                        ),
                        array(
                            'id' =>
                                'rud_crm_contact_whatsapp_' .
                                (
                                    $contact
                                    ? absint(
                                        $contact->id
                                    )
                                    : 'new'
                                ),

                            'description' =>
                                'Select the country flag and enter the WhatsApp number.'
                        )
                    ),
                    rud_crm_phone_allowed_html()
                );

            } else {

                ?>

                <input
                    type="tel"
                    name="whatsapp"
                    value="<?php echo esc_attr( $value( 'whatsapp' ) ); ?>"
                    autocomplete="tel"
                >

                <?php
            }

            ?>

        </div>

        <div class="rud-crm-company-contact-primary">

            <label>

                <input
                    type="checkbox"
                    name="is_primary"
                    value="1"
                    <?php
                    checked(
                        absint(
                            $value(
                                'is_primary'
                            )
                        ),
                        1
                    );
                    ?>
                >

                Primary Contact

            </label>

            <small>
                The Primary Contact is the main person for this company.
            </small>

        </div>

        <div class="rud-crm-company-contact-wide">

            <label>
                Personal Contact Notes
            </label>

            <textarea
                name="personal_notes"
                rows="6"
                placeholder="Notes connected only to this contact person / employee."
            ><?php echo esc_textarea( $value( 'personal_notes' ) ); ?></textarea>

        </div>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_frontend_company_contacts_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_crm_contact_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_crm_contact_error']
                ?? ''
            )
        );

    if (
        'added' ===
        $message
    ) {

        return
            '<div class="rud-crm-company-contact-success">' .
            '<strong>Contact Person Added</strong>' .
            '<span>The new contact person / employee was saved.</span>' .
            '</div>';
    }

    if (
        'updated' ===
        $message
    ) {

        return
            '<div class="rud-crm-company-contact-success">' .
            '<strong>Contact Person Updated</strong>' .
            '<span>The contact information was saved.</span>' .
            '</div>';
    }

    if (
        'deleted' ===
        $message
    ) {

        return
            '<div class="rud-crm-company-contact-success">' .
            '<strong>Contact Person Deleted</strong>' .
            '<span>The contact person / employee was removed.</span>' .
            '</div>';
    }

    if (
        'contact_name_required' ===
        $error
    ) {

        return
            '<div class="rud-crm-company-contact-error">' .
            '<strong>Name Required</strong>' .
            '<span>Enter at least a first name or last name.</span>' .
            '</div>';
    }

    if (
        $error
    ) {

        return
            '<div class="rud-crm-company-contact-error">' .
            '<strong>Could Not Save Contact</strong>' .
            '<span>Please check the information and try again.</span>' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * MAIN FRONT-END SECTION
 * =========================================================
 */

function rud_crm_frontend_company_contacts_section(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! rud_crm_frontend_company_contacts_can_edit_customer(
            $customer_id
        )
    ) {
        return '';
    }

    if (
        ! function_exists(
            'rud_crm_get_company_contacts'
        )
    ) {
        return '';
    }

    /*
     * Load the same international phone field used by
     * the main Customer Edit form.
     */
    if (
        function_exists(
            'rud_crm_enqueue_phone_assets'
        )
    ) {
        rud_crm_enqueue_phone_assets();
    }

    global $wpdb;

    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, customer_type, company_name
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );

    if (
        ! $customer
        ||
        'company' !==
        $customer->customer_type
    ) {
        return '';
    }

    $contacts =
        rud_crm_get_company_contacts(
            $customer_id
        );

    $edit_contact_id =
        absint(
            $_GET['rud_crm_edit_contact']
            ?? 0
        );

    $edit_contact =
        null;

    if (
        $edit_contact_id
        &&
        rud_crm_frontend_company_contact_belongs_to_customer(
            $edit_contact_id,
            $customer_id
        )
    ) {

        $edit_contact =
            rud_crm_get_company_contact(
                $edit_contact_id
            );
    }

    ob_start();

    ?>

    <div class="rud-crm-company-contacts-section">

        <h3>
            Contact Persons / Employees
        </h3>

        <p class="rud-crm-company-contacts-intro">
            Add and manage the people connected to this company. You can add more than one contact person.
        </p>

        <?php
        echo rud_crm_frontend_company_contacts_message_html();
        ?>


        <?php if ( ! empty( $contacts ) ) : ?>

            <div class="rud-crm-company-contact-list">

                <?php foreach ( $contacts as $contact ) : ?>

                    <?php

                    $name =
                        trim(
                            (
                                $contact->first_name
                                ?? ''
                            )
                            .
                            ' '
                            .
                            (
                                $contact->middle_name
                                ?? ''
                            )
                            .
                            ' '
                            .
                            (
                                $contact->last_name
                                ?? ''
                            )
                        );

                    $job_title =
                        rud_crm_company_contact_job_title_label(
                            $contact
                        );

                    $department =
                        rud_crm_company_contact_department_label(
                            $contact
                        );

                    ?>

                    <div class="rud-crm-company-contact-row">

                        <div class="rud-crm-company-contact-summary">

                            <div class="rud-crm-company-contact-name">

                                <?php echo esc_html( $name ); ?>

                                <?php if ( $contact->is_primary ) : ?>

                                    <span class="rud-crm-company-contact-primary-badge">
                                        Primary Contact
                                    </span>

                                <?php endif; ?>

                            </div>

                            <?php if ( $job_title ) : ?>

                                <div class="rud-crm-company-contact-meta">
                                    <?php echo esc_html( $job_title ); ?>
                                </div>

                            <?php endif; ?>

                            <?php if ( $department ) : ?>

                                <div class="rud-crm-company-contact-meta">
                                    <?php echo esc_html( $department ); ?>
                                </div>

                            <?php endif; ?>

                            <?php if ( $contact->mobile_phone ) : ?>

                                <div class="rud-crm-company-contact-meta">
                                    Mobile:
                                    <?php echo esc_html( $contact->mobile_phone ); ?>
                                </div>

                            <?php endif; ?>

                            <?php if ( $contact->work_email ) : ?>

                                <div class="rud-crm-company-contact-meta">
                                    <?php echo esc_html( $contact->work_email ); ?>
                                </div>

                            <?php endif; ?>

                        </div>

                        <div class="rud-crm-company-contact-row-actions">

                            <a
                                href="<?php
                                echo esc_url(
                                    rud_crm_frontend_company_contacts_edit_url(
                                        $customer_id,
                                        array(
                                            'rud_crm_edit_contact' =>
                                                $contact->id,
                                        )
                                    )
                                );
                                ?>"
                                class="rud-crm-company-contact-edit-button"
                            >
                                EDIT
                            </a>

                            <form method="post">

                                <?php

                                wp_nonce_field(
                                    'rud_crm_delete_company_contact_' .
                                    $customer_id .
                                    '_' .
                                    $contact->id,
                                    'rud_crm_company_contact_nonce'
                                );

                                ?>

                                <input
                                    type="hidden"
                                    name="rud_crm_company_contact_action"
                                    value="delete_contact"
                                >

                                <input
                                    type="hidden"
                                    name="rud_customer_id"
                                    value="<?php echo esc_attr( $customer_id ); ?>"
                                >

                                <input
                                    type="hidden"
                                    name="rud_contact_id"
                                    value="<?php echo esc_attr( $contact->id ); ?>"
                                >

                                <button
                                    type="submit"
                                    class="rud-crm-company-contact-delete-button"
                                    onclick="return confirm('Delete this contact person / employee?');"
                                >
                                    DELETE
                                </button>

                            </form>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else : ?>

            <div class="rud-crm-company-contact-empty">
                No contact persons / employees have been added yet.
            </div>

        <?php endif; ?>


        <?php if ( $edit_contact ) : ?>

            <div class="rud-crm-company-contact-form-card">

                <div class="rud-crm-company-contact-form-heading">

                    <h4>
                        Edit Contact Person / Employee
                    </h4>

                    <a
                        href="<?php
                        echo esc_url(
                            rud_crm_frontend_company_contacts_edit_url(
                                $customer_id
                            )
                        );
                        ?>"
                    >
                        Cancel
                    </a>

                </div>

                <form method="post">

                    <?php

                    wp_nonce_field(
                        'rud_crm_update_company_contact_' .
                        $customer_id .
                        '_' .
                        $edit_contact->id,
                        'rud_crm_company_contact_nonce'
                    );

                    ?>

                    <input
                        type="hidden"
                        name="rud_crm_company_contact_action"
                        value="update_contact"
                    >

                    <input
                        type="hidden"
                        name="rud_customer_id"
                        value="<?php echo esc_attr( $customer_id ); ?>"
                    >

                    <input
                        type="hidden"
                        name="rud_contact_id"
                        value="<?php echo esc_attr( $edit_contact->id ); ?>"
                    >

                    <?php
                    echo rud_crm_frontend_company_contact_fields(
                        $edit_contact
                    );
                    ?>

                    <button
                        type="submit"
                        class="rud-crm-company-contact-save-button"
                    >
                        SAVE CONTACT PERSON
                    </button>

                </form>

            </div>

        <?php else : ?>

            <details class="rud-crm-company-contact-add-panel">

                <summary>
                    + Add Contact Person / Employee
                </summary>

                <div class="rud-crm-company-contact-form-card">

                    <form method="post">

                        <?php

                        wp_nonce_field(
                            'rud_crm_add_company_contact_' .
                            $customer_id,
                            'rud_crm_company_contact_nonce'
                        );

                        ?>

                        <input
                            type="hidden"
                            name="rud_crm_company_contact_action"
                            value="add_contact"
                        >

                        <input
                            type="hidden"
                            name="rud_customer_id"
                            value="<?php echo esc_attr( $customer_id ); ?>"
                        >

                        <?php
                        echo rud_crm_frontend_company_contact_fields();
                        ?>

                        <button
                            type="submit"
                            class="rud-crm-company-contact-save-button"
                        >
                            ADD CONTACT PERSON
                        </button>

                    </form>

                </div>

            </details>

        <?php endif; ?>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * STYLES + OTHER FIELD TOGGLE
 * =========================================================
 */

function rud_crm_frontend_company_contacts_assets() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-company-contacts-section {
        width:100%;
    }

    .rud-crm-company-contacts-section > h3 {
        margin-top:0;
    }

    .rud-crm-company-contacts-intro {
        margin-bottom:18px;
        color:#667085;
    }

    .rud-crm-company-contact-list {
        margin-bottom:20px;
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-company-contact-row {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:18px;
        padding:14px 16px;
        border-bottom:1px solid #eaecf0;
        background:#fff;
    }

    .rud-crm-company-contact-row:last-child {
        border-bottom:0;
    }

    .rud-crm-company-contact-name {
        font-weight:700;
    }

    .rud-crm-company-contact-primary-badge {
        display:inline-flex;
        margin-left:7px;
        padding:3px 7px;
        border-radius:999px;
        background:#eef7ef;
        color:#187a2f;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-company-contact-meta {
        margin-top:3px;
        color:#667085;
        font-size:13px;
    }

    .rud-crm-company-contact-row-actions {
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
    }

    .rud-crm-company-contact-row-actions form {
        margin:0;
    }

    .rud-crm-company-contact-edit-button,
    .rud-crm-company-contact-delete-button,
    .rud-crm-company-contact-save-button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:38px;
        padding:9px 14px;
        border-radius:7px;
        text-decoration:none !important;
        font-weight:700;
        cursor:pointer;
    }

    .rud-crm-company-contact-edit-button,
    .rud-crm-company-contact-save-button {
        border:1px solid #1d2939;
        background:#1d2939;
        color:#fff !important;
    }

    .rud-crm-company-contact-delete-button {
        border:1px solid #b42318;
        background:#fff;
        color:#b42318;
    }

    .rud-crm-company-contact-empty {
        margin-bottom:18px;
        padding:14px 16px;
        border:1px solid #eaecf0;
        border-radius:8px;
        background:#fff;
        color:#667085;
    }

    .rud-crm-company-contact-add-panel {
        border:1px solid #eaecf0;
        border-radius:9px;
        background:#fff;
        overflow:hidden;
    }

    .rud-crm-company-contact-add-panel summary {
        padding:14px 16px;
        cursor:pointer;
        font-weight:700;
        list-style:none;
    }

    .rud-crm-company-contact-add-panel summary::-webkit-details-marker {
        display:none;
    }

    .rud-crm-company-contact-form-card {
        padding:18px;
        border-top:1px solid #eaecf0;
        background:#f9fafb;
    }

    .rud-crm-company-contact-form-heading {
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:14px;
        margin-bottom:16px;
    }

    .rud-crm-company-contact-form-heading h4 {
        margin:0;
    }

    .rud-crm-company-contact-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-company-contact-wide {
        grid-column:1 / -1;
    }

    .rud-crm-company-contact-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-company-contact-grid input,
    .rud-crm-company-contact-grid select,
    .rud-crm-company-contact-grid textarea {
        width:100%;
        box-sizing:border-box;
        padding:11px 13px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-company-contact-primary {
        display:flex;
        flex-direction:column;
        justify-content:flex-end;
    }

    .rud-crm-company-contact-primary label {
        display:flex;
        align-items:center;
        gap:8px;
    }

    .rud-crm-company-contact-primary input {
        width:auto;
    }

    .rud-crm-company-contact-primary small {
        margin-top:5px;
        color:#667085;
    }

    .rud-crm-company-contact-save-button {
        margin-top:18px;
    }

    .rud-crm-company-contact-success,
    .rud-crm-company-contact-error {
        display:flex;
        flex-direction:column;
        gap:4px;
        margin-bottom:16px;
        padding:12px 14px;
        border-radius:8px;
    }

    .rud-crm-company-contact-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-company-contact-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:700px) {

        .rud-crm-company-contact-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-company-contact-wide {
            grid-column:auto;
        }

        .rud-crm-company-contact-row {
            align-items:flex-start;
            flex-direction:column;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-company-contacts',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-company-contacts'
    );

    wp_add_inline_style(
        'rud-crm-frontend-company-contacts',
        $css
    );


    $js = <<<'JS'
document.addEventListener('change', function(event) {

    if (
        event.target
        &&
        event.target.matches(
            '[data-rud-contact-job-title]'
        )
    ) {

        var form =
            event.target.closest('form');

        if (!form) {
            return;
        }

        var customWrap =
            form.querySelector(
                '[data-rud-contact-job-title-custom-wrap]'
            );

        if (customWrap) {

            customWrap.style.display =
                event.target.value === 'other'
                ? ''
                : 'none';
        }
    }


    if (
        event.target
        &&
        event.target.matches(
            '[data-rud-contact-department]'
        )
    ) {

        var form =
            event.target.closest('form');

        if (!form) {
            return;
        }

        var customWrap =
            form.querySelector(
                '[data-rud-contact-department-custom-wrap]'
            );

        if (customWrap) {

            customWrap.style.display =
                event.target.value === 'other'
                ? ''
                : 'none';
        }
    }

});
JS;

    wp_register_script(
        'rud-crm-frontend-company-contacts',
        '',
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0',
        true
    );

    wp_enqueue_script(
        'rud-crm-frontend-company-contacts'
    );

    wp_add_inline_script(
        'rud-crm-frontend-company-contacts',
        $js
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_company_contacts_assets',
    31
);
