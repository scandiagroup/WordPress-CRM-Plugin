<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SOCIAL MEDIA
 * SAFE CENTRAL SOCIAL MEDIA MODULE
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * SUPPORTED SOCIAL PLATFORMS
 * ---------------------------------------------------------
 */

if (
    ! function_exists(
        'rud_crm_social_platforms'
    )
) {

    function rud_crm_social_platforms() {

        return array(

            'facebook'          => 'Facebook',
            'instagram'         => 'Instagram',
            'tiktok'            => 'TikTok',
            'youtube'           => 'YouTube',
            'x'                 => 'X / Twitter',
            'threads'           => 'Threads',
            'linkedin'          => 'LinkedIn',
            'pinterest'         => 'Pinterest',
            'snapchat'          => 'Snapchat',

            'whatsapp'          => 'WhatsApp',
            'telegram'          => 'Telegram',
            'messenger'         => 'Facebook Messenger',
            'signal'            => 'Signal',
            'viber'             => 'Viber',
            'wechat'            => 'WeChat',
            'line'              => 'LINE',
            'kakao'             => 'KakaoTalk',

            'skype'             => 'Skype',
            'discord'           => 'Discord',
            'twitch'            => 'Twitch',

            'linkedin_company'  => 'LinkedIn Company',
            'xing'              => 'XING',

            'reddit'            => 'Reddit',
            'tumblr'            => 'Tumblr',
            'medium'            => 'Medium',
            'quora'             => 'Quora',

            'truth_social'      => 'Truth Social',
            'bluesky'           => 'Bluesky',
            'mastodon'          => 'Mastodon',
            'gab'               => 'Gab',
            'parler'            => 'Parler',

            'spotify'           => 'Spotify',
            'soundcloud'        => 'SoundCloud',
            'vimeo'             => 'Vimeo',

            'website'           => 'Personal Website',
            'other'             => 'Other'
        );
    }
}


/*
 * ---------------------------------------------------------
 * PLATFORM LABEL
 * ---------------------------------------------------------
 */

if (
    ! function_exists(
        'rud_crm_social_platform_label'
    )
) {

    function rud_crm_social_platform_label(
        $platform
    ) {

        $platforms =
            rud_crm_social_platforms();


        if (
            isset(
                $platforms[
                    $platform
                ]
            )
        ) {

            return $platforms[
                $platform
            ];
        }


        return ucfirst(
            str_replace(
                array(
                    '_',
                    '-'
                ),
                ' ',
                $platform
            )
        );
    }
}


/*
 * ---------------------------------------------------------
 * CHECK VALID PLATFORM
 * ---------------------------------------------------------
 */

if (
    ! function_exists(
        'rud_crm_social_platform_exists'
    )
) {

    function rud_crm_social_platform_exists(
        $platform
    ) {

        $platforms =
            rud_crm_social_platforms();


        return isset(
            $platforms[
                $platform
            ]
        );
    }
}


/*
 * ---------------------------------------------------------
 * SANITIZE PLATFORM
 * ---------------------------------------------------------
 */

if (
    ! function_exists(
        'rud_crm_social_sanitize_platform'
    )
) {

    function rud_crm_social_sanitize_platform(
        $platform
    ) {

        $platform =
            sanitize_key(
                $platform
            );


        if (
            rud_crm_social_platform_exists(
                $platform
            )
        ) {

            return $platform;
        }


        return 'other';
    }
}