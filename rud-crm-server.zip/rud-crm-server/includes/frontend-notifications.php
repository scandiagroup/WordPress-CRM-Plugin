<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END CRM NOTIFICATIONS
 * Version 1.0
 * =========================================================
 *
 * Provides:
 * - Unread notification count
 * - Notification list for logged-in user
 * - Mark notification as read
 * - Link back to related Customer / Open Profile
 *
 * =========================================================
 */


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

function rud_crm_frontend_notification_customer_url(
    $customer_id
) {

    return add_query_arg(
        array(
            'rud_customer_id' =>
                absint(
                    $customer_id
                ),
        ),
        home_url(
            '/customer-crm/'
        )
    );
}


/*
 * =========================================================
 * MARK NOTIFICATION READ
 * =========================================================
 */

function rud_crm_frontend_process_notification_read() {

    if (
        empty(
            $_POST['rud_crm_notification_action']
        )
        ||
        'mark_read' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_notification_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $notification_id =
        absint(
            $_POST['rud_notification_id']
            ?? 0
        );

    if (
        ! $notification_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_notification_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_notification_nonce']
                )
            ),
            'rud_crm_notification_read_' .
            $notification_id
        )
    ) {
        return;
    }

    if (
        function_exists(
            'rud_crm_mark_notification_read'
        )
    ) {

        rud_crm_mark_notification_read(
            $notification_id,
            get_current_user_id()
        );
    }

    $redirect =
        wp_get_referer();

    if (
        ! $redirect
    ) {
        $redirect =
            home_url(
                '/customer-crm/'
            );
    }

    wp_safe_redirect(
        $redirect
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_notification_read',
    55
);


/*
 * =========================================================
 * NOTIFICATION CENTER
 * =========================================================
 */

function rud_crm_frontend_notification_center() {

    if (
        ! is_user_logged_in()
        ||
        ! function_exists(
            'rud_crm_get_user_notifications'
        )
    ) {
        return '';
    }

    $user_id =
        get_current_user_id();

    $notifications =
        rud_crm_get_user_notifications(
            $user_id,
            array(
                'limit' =>
                    50,
            )
        );

    $unread_count =
        function_exists(
            'rud_crm_get_unread_notification_count'
        )
        ? rud_crm_get_unread_notification_count(
            $user_id
        )
        : 0;

    ob_start();

    ?>

    <section class="rud-crm-notification-center">

        <div class="rud-crm-notification-header">

            <div>

                <h2>
                    CRM NOTIFICATIONS
                </h2>

                <p>
                    Task reminders and CRM alerts assigned to you.
                </p>

            </div>

            <div class="rud-crm-notification-count">
                <?php echo esc_html( $unread_count ); ?>
                unread
            </div>

        </div>


        <?php if ( ! empty( $notifications ) ) : ?>

            <div class="rud-crm-notification-list">

                <?php foreach ( $notifications as $notification ) : ?>

                    <?php

                    $is_unread =
                        'unread' ===
                        (
                            $notification->status
                            ?? ''
                        );

                    $created_label = '';

                    if (
                        ! empty(
                            $notification->created_at
                        )
                    ) {

                        $timestamp =
                            strtotime(
                                $notification->created_at
                            );

                        if (
                            $timestamp
                        ) {

                            $created_label =
                                wp_date(
                                    'd M Y - H:i',
                                    $timestamp
                                );
                        }
                    }

                    ?>

                    <article
                        class="rud-crm-notification-item<?php echo $is_unread ? ' is-unread' : ''; ?>"
                    >

                        <div class="rud-crm-notification-main">

                            <div class="rud-crm-notification-title-row">

                                <strong>
                                    <?php echo esc_html( $notification->title ); ?>
                                </strong>

                                <?php if ( $is_unread ) : ?>

                                    <span class="rud-crm-notification-unread-badge">
                                        NEW
                                    </span>

                                <?php endif; ?>

                            </div>

                            <?php if ( ! empty( $notification->message ) ) : ?>

                                <div class="rud-crm-notification-message">
                                    <?php echo nl2br( esc_html( $notification->message ) ); ?>
                                </div>

                            <?php endif; ?>

                            <?php if ( $created_label ) : ?>

                                <div class="rud-crm-notification-date">
                                    <?php echo esc_html( $created_label ); ?>
                                </div>

                            <?php endif; ?>

                        </div>


                        <div class="rud-crm-notification-actions">

                            <?php if ( ! empty( $notification->customer_id ) ) : ?>

                                <a
                                    href="<?php
                                    echo esc_url(
                                        rud_crm_frontend_notification_customer_url(
                                            $notification->customer_id
                                        )
                                    );
                                    ?>"
                                    class="rud-crm-notification-open"
                                >
                                    OPEN CUSTOMER
                                </a>

                            <?php endif; ?>


                            <?php if ( $is_unread ) : ?>

                                <form method="post">

                                    <?php

                                    wp_nonce_field(
                                        'rud_crm_notification_read_' .
                                        $notification->id,
                                        'rud_crm_notification_nonce'
                                    );

                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_notification_action"
                                        value="mark_read"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_notification_id"
                                        value="<?php echo esc_attr( $notification->id ); ?>"
                                    >

                                    <button type="submit">
                                        MARK READ
                                    </button>

                                </form>

                            <?php endif; ?>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else : ?>

            <div class="rud-crm-notification-empty">
                No CRM notifications yet.
            </div>

        <?php endif; ?>

    </section>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_frontend_notifications_shortcode() {

    return
        rud_crm_frontend_notification_center();
}


add_shortcode(
    'rud_crm_notifications',
    'rud_crm_frontend_notifications_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_notifications_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-notification-center {
        width:100%;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
        box-sizing:border-box;
    }

    .rud-crm-notification-center * {
        box-sizing:border-box;
    }

    .rud-crm-notification-header {
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:18px;
        margin-bottom:18px;
    }

    .rud-crm-notification-header h2 {
        margin:0 0 5px !important;
    }

    .rud-crm-notification-header p {
        margin:0;
        color:#667085;
    }

    .rud-crm-notification-count {
        display:inline-flex;
        align-items:center;
        min-height:34px;
        padding:6px 10px;
        border-radius:999px;
        background:#f2f4f7;
        font-size:12px;
        font-weight:700;
        white-space:nowrap;
    }

    .rud-crm-notification-list {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-notification-item {
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:18px;
        padding:16px;
        border-bottom:1px solid #eaecf0;
        background:#fff;
    }

    .rud-crm-notification-item:last-child {
        border-bottom:0;
    }

    .rud-crm-notification-item.is-unread {
        background:#f8fbff;
    }

    .rud-crm-notification-main {
        min-width:0;
        flex:1 1 auto;
    }

    .rud-crm-notification-title-row {
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
    }

    .rud-crm-notification-unread-badge {
        display:inline-flex;
        padding:3px 7px;
        border-radius:999px;
        background:#eaf2ff;
        font-size:10px;
        font-weight:700;
    }

    .rud-crm-notification-message {
        margin-top:7px;
        line-height:1.55;
    }

    .rud-crm-notification-date {
        margin-top:7px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-notification-actions {
        display:flex;
        align-items:center;
        gap:7px;
        flex-wrap:wrap;
    }

    .rud-crm-notification-actions form {
        margin:0;
    }

    .rud-crm-notification-open,
    .rud-crm-notification-actions button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:36px;
        padding:7px 11px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff !important;
        text-decoration:none !important;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-notification-empty {
        padding:14px 16px;
        border:1px solid #eaecf0;
        border-radius:8px;
        color:#667085;
    }

    @media (max-width:700px) {

        .rud-crm-notification-header,
        .rud-crm-notification-item {
            flex-direction:column;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-notifications',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-notifications'
    );

    wp_add_inline_style(
        'rud-crm-frontend-notifications',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_notifications_styles',
    60
);
