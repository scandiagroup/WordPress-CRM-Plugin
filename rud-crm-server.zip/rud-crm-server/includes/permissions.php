<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM PERMISSIONS
 * =========================================================
 *
 * SYSTEM A
 * WordPress staff permissions:
 *
 * - Administrator
 * - CRM Manager
 * - CRM Editor
 * - CRM Viewer
 *
 *
 * SYSTEM B
 * Individual customer permissions / consent:
 *
 * - Email marketing
 * - SMS marketing
 * - WhatsApp marketing
 * - Newsletter
 * - Telephone contact
 * - Data sharing with connected RUD websites
 *
 * =========================================================
 */


/*
 * =========================================================
 * SYSTEM A
 * STAFF / CRM CAPABILITIES
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CRM CAPABILITIES
 * ---------------------------------------------------------
 */

function rud_crm_permission_capabilities() {

    return array(

        'rud_crm_view' =>
            'View CRM',

        'rud_crm_create' =>
            'Create Customers',

        'rud_crm_edit' =>
            'Edit Customers',

        'rud_crm_delete' =>
            'Delete Customers',

        'rud_crm_export' =>
            'Export Customers',

        'rud_crm_manage_sites' =>
            'Manage Connected Websites',

        'rud_crm_manage_api' =>
            'Manage API',

        'rud_crm_manage_settings' =>
            'Manage CRM Settings'
    );
}


/*
 * ---------------------------------------------------------
 * ADMINISTRATOR FULL ACCESS
 * ---------------------------------------------------------
 */

function rud_crm_permissions_add_to_administrator() {

    $role =
        get_role(
            'administrator'
        );


    if (
        ! $role
    ) {
        return;
    }


    foreach (
        rud_crm_permission_capabilities()
        as
        $capability =>
        $label
    ) {

        $role->add_cap(
            $capability
        );
    }
}

add_action(
    'admin_init',
    'rud_crm_permissions_add_to_administrator'
);


/*
 * ---------------------------------------------------------
 * CREATE CRM MANAGER ROLE
 * ---------------------------------------------------------
 */

function rud_crm_permissions_create_manager_role() {

    $role =
        get_role(
            'rud_crm_manager'
        );


    if (
        ! $role
    ) {

        add_role(
            'rud_crm_manager',
            'CRM Manager',
            array(

                'read' => true,

                'rud_crm_view' => true,

                'rud_crm_create' => true,

                'rud_crm_edit' => true,

                'rud_crm_delete' => false,

                'rud_crm_export' => true,

                'rud_crm_manage_sites' => false,

                'rud_crm_manage_api' => false,

                'rud_crm_manage_settings' => false
            )
        );
    }
}

add_action(
    'admin_init',
    'rud_crm_permissions_create_manager_role'
);


/*
 * ---------------------------------------------------------
 * CREATE CRM EDITOR ROLE
 * ---------------------------------------------------------
 */

function rud_crm_permissions_create_editor_role() {

    $role =
        get_role(
            'rud_crm_editor'
        );


    if (
        ! $role
    ) {

        add_role(
            'rud_crm_editor',
            'CRM Editor',
            array(

                'read' => true,

                'rud_crm_view' => true,

                'rud_crm_create' => true,

                'rud_crm_edit' => true,

                'rud_crm_delete' => false,

                'rud_crm_export' => false,

                'rud_crm_manage_sites' => false,

                'rud_crm_manage_api' => false,

                'rud_crm_manage_settings' => false
            )
        );
    }
}

add_action(
    'admin_init',
    'rud_crm_permissions_create_editor_role'
);


/*
 * ---------------------------------------------------------
 * CREATE CRM VIEWER ROLE
 * ---------------------------------------------------------
 */

function rud_crm_permissions_create_viewer_role() {

    $role =
        get_role(
            'rud_crm_viewer'
        );


    if (
        ! $role
    ) {

        add_role(
            'rud_crm_viewer',
            'CRM Viewer',
            array(

                'read' => true,

                'rud_crm_view' => true,

                'rud_crm_create' => false,

                'rud_crm_edit' => false,

                'rud_crm_delete' => false,

                'rud_crm_export' => false,

                'rud_crm_manage_sites' => false,

                'rud_crm_manage_api' => false,

                'rud_crm_manage_settings' => false
            )
        );
    }
}

add_action(
    'admin_init',
    'rud_crm_permissions_create_viewer_role'
);


/*
 * ---------------------------------------------------------
 * GENERAL CRM ACCESS
 * ---------------------------------------------------------
 */

function rud_crm_user_can_view() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_view'
        );
}


/*
 * ---------------------------------------------------------
 * CREATE CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_user_can_create() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_create'
        );
}


/*
 * ---------------------------------------------------------
 * EDIT CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_user_can_edit() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_edit'
        );
}


/*
 * ---------------------------------------------------------
 * DELETE CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_user_can_delete() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_delete'
        );
}


/*
 * ---------------------------------------------------------
 * EXPORT
 * ---------------------------------------------------------
 */

function rud_crm_user_can_export() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_export'
        );
}


/*
 * ---------------------------------------------------------
 * CONNECTED WEBSITES
 * ---------------------------------------------------------
 */

function rud_crm_user_can_manage_sites() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_manage_sites'
        );
}


/*
 * ---------------------------------------------------------
 * API MANAGEMENT
 * ---------------------------------------------------------
 */

function rud_crm_user_can_manage_api() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_manage_api'
        );
}


/*
 * ---------------------------------------------------------
 * SETTINGS
 * ---------------------------------------------------------
 */

function rud_crm_user_can_manage_settings() {

    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_manage_settings'
        );
}


/*
 * =========================================================
 * SYSTEM B
 * CUSTOMER PERMISSIONS / CONSENT
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CUSTOMER PERMISSION DEFINITIONS
 * ---------------------------------------------------------
 */

function rud_crm_customer_permission_definitions() {

    return array(

        'email_marketing' =>
            'Email Marketing',

        'sms_marketing' =>
            'SMS Marketing',

        'whatsapp_marketing' =>
            'WhatsApp Marketing',

        'newsletter' =>
            'Newsletter',

        'telephone_contact' =>
            'Telephone Contact',

        'connected_websites' =>
            'Share Data with Connected Websites'
    );
}


/*
 * ---------------------------------------------------------
 * CUSTOMER PERMISSION TABLE NAME
 * ---------------------------------------------------------
 */

function rud_crm_customer_permissions_table() {

    global $wpdb;


    return
        $wpdb->prefix .
        'rudcrm_customer_permissions';
}


/*
 * ---------------------------------------------------------
 * CREATE / UPDATE CUSTOMER PERMISSIONS TABLE
 * ---------------------------------------------------------
 */

function rud_crm_customer_permissions_install() {

    global $wpdb;


    $table =
        rud_crm_customer_permissions_table();


    $charset_collate =
        $wpdb->get_charset_collate();


    $sql =
        "CREATE TABLE {$table} (

            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,

            customer_id bigint(20) unsigned NOT NULL,

            permission_key varchar(100) NOT NULL,

            permission_value tinyint(1) NOT NULL DEFAULT 0,

            source varchar(100) NOT NULL DEFAULT '',

            notes text NULL,

            granted_at datetime NULL,

            revoked_at datetime NULL,

            updated_at datetime NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY customer_permission (
                customer_id,
                permission_key
            ),

            KEY customer_id (
                customer_id
            ),

            KEY permission_key (
                permission_key
            )

        ) {$charset_collate};";


    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';


    dbDelta(
        $sql
    );


    update_option(
        'rud_crm_customer_permissions_db_version',
        '1.0.0'
    );
}


/*
 * ---------------------------------------------------------
 * CHECK CUSTOMER PERMISSIONS TABLE
 * ---------------------------------------------------------
 */

function rud_crm_customer_permissions_maybe_install() {

    $version =
        get_option(
            'rud_crm_customer_permissions_db_version',
            ''
        );


    if (
        '1.0.0' !==
        $version
    ) {

        rud_crm_customer_permissions_install();
    }
}

add_action(
    'admin_init',
    'rud_crm_customer_permissions_maybe_install',
    5
);


/*
 * ---------------------------------------------------------
 * VALID CUSTOMER PERMISSION
 * ---------------------------------------------------------
 */

function rud_crm_customer_permission_exists(
    $permission_key
) {

    $definitions =
        rud_crm_customer_permission_definitions();


    return isset(
        $definitions[
            $permission_key
        ]
    );
}


/*
 * ---------------------------------------------------------
 * GET ONE CUSTOMER PERMISSION
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_permission(
    $customer_id,
    $permission_key
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    $permission_key =
        sanitize_key(
            $permission_key
        );


    if (
        ! $customer_id
        ||
        ! rud_crm_customer_permission_exists(
            $permission_key
        )
    ) {

        return false;
    }


    $table =
        rud_crm_customer_permissions_table();


    $value =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT permission_value
                 FROM {$table}
                 WHERE customer_id = %d
                 AND permission_key = %s
                 LIMIT 1",
                $customer_id,
                $permission_key
            )
        );


    if (
        null ===
        $value
    ) {

        return false;
    }


    return
        (bool)
        $value;
}


/*
 * ---------------------------------------------------------
 * GET ALL CUSTOMER PERMISSIONS
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_permissions(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return array();
    }


    $table =
        rud_crm_customer_permissions_table();


    $rows =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 WHERE customer_id = %d
                 ORDER BY permission_key ASC",
                $customer_id
            )
        );


    $permissions =
        array();


    foreach (
        $rows as
        $row
    ) {

        $permissions[
            $row->permission_key
        ] =
            array(

                'value' =>
                    (bool)
                    $row->permission_value,

                'source' =>
                    $row->source,

                'notes' =>
                    $row->notes,

                'granted_at' =>
                    $row->granted_at,

                'revoked_at' =>
                    $row->revoked_at,

                'updated_at' =>
                    $row->updated_at
            );
    }


    return $permissions;
}


/*
 * ---------------------------------------------------------
 * SET CUSTOMER PERMISSION
 * ---------------------------------------------------------
 */

function rud_crm_set_customer_permission(
    $customer_id,
    $permission_key,
    $allowed,
    $source = '',
    $notes = ''
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    $permission_key =
        sanitize_key(
            $permission_key
        );


    if (
        ! $customer_id
        ||
        ! rud_crm_customer_permission_exists(
            $permission_key
        )
    ) {

        return false;
    }


    $allowed =
        $allowed
        ? 1
        : 0;


    $source =
        sanitize_text_field(
            $source
        );


    $notes =
        sanitize_textarea_field(
            $notes
        );


    $table =
        rud_crm_customer_permissions_table();


    $existing =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 WHERE customer_id = %d
                 AND permission_key = %s
                 LIMIT 1",
                $customer_id,
                $permission_key
            )
        );


    $now =
        current_time(
            'mysql'
        );


    /*
     * -----------------------------------------------------
     * UPDATE EXISTING
     * -----------------------------------------------------
     */

    if (
        $existing
    ) {

        $data =
            array(

                'permission_value' =>
                    $allowed,

                'source' =>
                    $source,

                'notes' =>
                    $notes,

                'updated_at' =>
                    $now
            );


        /*
         * Newly granted.
         */

        if (
            $allowed
            &&
            ! (bool)
            $existing->permission_value
        ) {

            $data[
                'granted_at'
            ] =
                $now;


            $data[
                'revoked_at'
            ] =
                null;
        }


        /*
         * Newly revoked.
         */

        if (
            ! $allowed
            &&
            (bool)
            $existing->permission_value
        ) {

            $data[
                'revoked_at'
            ] =
                $now;
        }


        $result =
            $wpdb->update(

                $table,

                $data,

                array(
                    'id' =>
                        (int)
                        $existing->id
                )
            );


        return
            false !==
            $result;
    }


    /*
     * -----------------------------------------------------
     * CREATE NEW
     * -----------------------------------------------------
     */

    $granted_at =
        $allowed
        ? $now
        : null;


    $revoked_at =
        $allowed
        ? null
        : $now;


    $result =
        $wpdb->insert(

            $table,

            array(

                'customer_id' =>
                    $customer_id,

                'permission_key' =>
                    $permission_key,

                'permission_value' =>
                    $allowed,

                'source' =>
                    $source,

                'notes' =>
                    $notes,

                'granted_at' =>
                    $granted_at,

                'revoked_at' =>
                    $revoked_at,

                'updated_at' =>
                    $now
            )
        );


    return
        false !==
        $result;
}


/*
 * ---------------------------------------------------------
 * INITIALIZE CUSTOMER PERMISSIONS
 * ---------------------------------------------------------
 *
 * Creates a YES/NO row for every known permission.
 *
 * Default is NO.
 * ---------------------------------------------------------
 */

function rud_crm_initialize_customer_permissions(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    $definitions =
        rud_crm_customer_permission_definitions();


    foreach (
        $definitions as
        $permission_key =>
        $label
    ) {

        rud_crm_set_customer_permission(
            $customer_id,
            $permission_key,
            false,
            'CRM'
        );
    }


    return true;
}


/*
 * ---------------------------------------------------------
 * ALLOW ALL CUSTOMER PERMISSIONS
 * ---------------------------------------------------------
 */

function rud_crm_allow_all_customer_permissions(
    $customer_id,
    $source = 'CRM'
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    foreach (
        rud_crm_customer_permission_definitions()
        as
        $permission_key =>
        $label
    ) {

        rud_crm_set_customer_permission(
            $customer_id,
            $permission_key,
            true,
            $source
        );
    }


    return true;
}


/*
 * ---------------------------------------------------------
 * DENY ALL CUSTOMER PERMISSIONS
 * ---------------------------------------------------------
 */

function rud_crm_deny_all_customer_permissions(
    $customer_id,
    $source = 'CRM'
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    foreach (
        rud_crm_customer_permission_definitions()
        as
        $permission_key =>
        $label
    ) {

        rud_crm_set_customer_permission(
            $customer_id,
            $permission_key,
            false,
            $source
        );
    }


    return true;
}