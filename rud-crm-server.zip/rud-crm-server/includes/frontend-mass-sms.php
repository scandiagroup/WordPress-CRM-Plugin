<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END MASS SMS
 * Version 1.1
 * =========================================================
 *
 * Shortcode:
 * [rud_crm_mass_sms]
 *
 * Provides:
 * - Select multiple Customers / Contact Persons
 * - Search and filter recipient list
 * - Choose SMS Template
 * - Optional custom SMS
 * - Duplicate-number protection
 * - Invalid-number skipping
 * - Send confirmation
 * - Per-recipient SMS Log via rud_crm_send_sms()
 * - Summary: sent / failed / skipped
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_mass_sms_can_manage() {

    if (
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_frontend_is_crm_admin'
        )
        &&
        rud_crm_frontend_is_crm_admin()
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            get_current_user_id()
        )
    ) {
        return true;
    }

    return false;
}


/*
 * =========================================================
 * PAGE URL
 * =========================================================
 */

function rud_crm_mass_sms_page_url(
    $args = array()
) {

    $url =
        home_url(
            '/multi-sms/'
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * NORMALIZE PHONE
 * =========================================================
 */

function rud_crm_mass_sms_normalize_phone(
    $number
) {

    $number =
        trim(
            (string)
            $number
        );

    if (
        '' ===
        $number
    ) {
        return '';
    }

    $number =
        preg_replace(
            '/[^\d+]/',
            '',
            $number
        );

    if (
        str_starts_with(
            $number,
            '00'
        )
    ) {

        $number =
            '+' .
            substr(
                $number,
                2
            );
    }

    return
        $number;
}


/*
 * =========================================================
 * CUSTOMER NAME
 * =========================================================
 */

function rud_crm_mass_sms_customer_name(
    $customer
) {

    $name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $customer->first_name ?? '',
                        $customer->middle_name ?? '',
                        $customer->last_name ?? '',
                    )
                )
            )
        );

    if (
        '' ===
        $name
    ) {

        $name =
            trim(
                (string)
                (
                    $customer->company_name
                    ?? ''
                )
            );
    }

    if (
        '' ===
        $name
    ) {

        $name =
            'Customer #' .
            absint(
                $customer->id
                ?? 0
            );
    }

    return
        $name;
}


/*
 * =========================================================
 * GET AVAILABLE RECIPIENTS
 * =========================================================
 */

function rud_crm_mass_sms_get_recipients() {

    global $wpdb;

    $recipients =
        array();

    $customers =
        $wpdb->get_results(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customers
             ORDER BY
                company_name ASC,
                last_name ASC,
                first_name ASC,
                id ASC"
        );


    foreach (
        $customers
        as
        $customer
    ) {

        $customer_id =
            absint(
                $customer->id
            );

        $customer_name =
            rud_crm_mass_sms_customer_name(
                $customer
            );


        /*
         * Main Customer / Company mobile.
         */
        $main_number = '';

        if (
            function_exists(
                'rud_crm_frontend_contact'
            )
        ) {

            $main_number =
                rud_crm_frontend_contact(
                    $customer_id,
                    'mobile_phone'
                );

            if (
                ! $main_number
            ) {

                $main_number =
                    rud_crm_frontend_contact(
                        $customer_id,
                        'whatsapp'
                    );
            }
        }


        $main_number =
            rud_crm_mass_sms_normalize_phone(
                $main_number
            );

        if (
            '' !==
            $main_number
        ) {

            $recipients[] =
                array(

                    'key' =>
                        'customer:' .
                        $customer_id,

                    'customer_id' =>
                        $customer_id,

                    'contact_id' =>
                        0,

                    'name' =>
                        $customer_name,

                    'company' =>
                        trim(
                            (string)
                            (
                                $customer->company_name
                                ?? ''
                            )
                        ),

                    'number' =>
                        $main_number,

                    'type' =>
                        'Customer',
                );
        }


        /*
         * Company Contact Persons.
         */
        if (
            function_exists(
                'rud_crm_get_company_contacts'
            )
        ) {

            $contacts =
                rud_crm_get_company_contacts(
                    $customer_id
                );


            foreach (
                $contacts
                as
                $contact
            ) {

                $number =
                    rud_crm_mass_sms_normalize_phone(
                        $contact->mobile_number
                        ?: $contact->whatsapp
                    );

                if (
                    '' ===
                    $number
                ) {
                    continue;
                }


                $contact_name =
                    trim(
                        implode(
                            ' ',
                            array_filter(
                                array(
                                    $contact->first_name ?? '',
                                    $contact->middle_name ?? '',
                                    $contact->last_name ?? '',
                                )
                            )
                        )
                    );

                if (
                    '' ===
                    $contact_name
                ) {

                    $contact_name =
                        'Contact #' .
                        absint(
                            $contact->id
                        );
                }


                $recipients[] =
                    array(

                        'key' =>
                            'contact:' .
                            absint(
                                $contact->id
                            ),

                        'customer_id' =>
                            $customer_id,

                        'contact_id' =>
                            absint(
                                $contact->id
                            ),

                        'name' =>
                            $contact_name,

                        'company' =>
                            $customer_name,

                        'number' =>
                            $number,

                        'type' =>
                            'Contact Person',
                    );
            }
        }
    }


    return
        $recipients;
}


/*
 * =========================================================
 * PROCESS MASS SMS
 * =========================================================
 */

function rud_crm_mass_sms_process_form() {

    if (
        empty(
            $_POST['rud_crm_mass_sms_action']
        )
        ||
        'send_mass_sms' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_mass_sms_action']
            )
        )
    ) {
        return;
    }


    if (
        ! rud_crm_mass_sms_can_manage()
    ) {
        return;
    }


    if (
        empty(
            $_POST['rud_crm_mass_sms_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_mass_sms_nonce']
                )
            ),
            'rud_crm_mass_sms'
        )
    ) {
        return;
    }


    if (
        ! function_exists(
            'rud_crm_send_sms'
        )
    ) {

        wp_safe_redirect(
            rud_crm_mass_sms_page_url(
                array(
                    'rud_mass_sms_error' =>
                        'sms_sender_unavailable',
                )
            )
        );

        exit;
    }


    $selected =
        isset(
            $_POST['recipients']
        )
        &&
        is_array(
            $_POST['recipients']
        )
        ? array_map(
            'sanitize_text_field',
            wp_unslash(
                $_POST['recipients']
            )
        )
        : array();


    if (
        empty(
            $selected
        )
    ) {

        wp_safe_redirect(
            rud_crm_mass_sms_page_url(
                array(
                    'rud_mass_sms_error' =>
                        'no_recipients',
                )
            )
        );

        exit;
    }


    $template_id =
        absint(
            $_POST['template_id']
            ?? 0
        );


    $custom_message =
        sanitize_textarea_field(
            wp_unslash(
                $_POST['message']
                ?? ''
            )
        );


    if (
        ! $template_id
        &&
        '' ===
        trim(
            $custom_message
        )
    ) {

        wp_safe_redirect(
            rud_crm_mass_sms_page_url(
                array(
                    'rud_mass_sms_error' =>
                        'message_required',
                )
            )
        );

        exit;
    }


    $available =
        rud_crm_mass_sms_get_recipients();

    $indexed =
        array();

    foreach (
        $available
        as
        $recipient
    ) {

        $indexed[
            $recipient['key']
        ] =
            $recipient;
    }


    $sent =
        0;

    $failed =
        0;

    $skipped =
        0;

    $first_error_message =
        '';

    $seen_numbers =
        array();


    foreach (
        $selected
        as
        $key
    ) {

        if (
            ! isset(
                $indexed[
                    $key
                ]
            )
        ) {

            $skipped++;

            continue;
        }


        $recipient =
            $indexed[
                $key
            ];


        $number =
            rud_crm_mass_sms_normalize_phone(
                $recipient['number']
            );


        if (
            '' ===
            $number
        ) {

            $skipped++;

            continue;
        }


        $number_key =
            preg_replace(
                '/\D/',
                '',
                $number
            );


        if (
            isset(
                $seen_numbers[
                    $number_key
                ]
            )
        ) {

            $skipped++;

            continue;
        }


        $seen_numbers[
            $number_key
        ] =
            true;


        $result =
            rud_crm_send_sms(
                array(

                    'customer_id' =>
                        $recipient['customer_id'],

                    'contact_id' =>
                        $recipient['contact_id'],

                    'project_id' =>
                        0,

                    'task_id' =>
                        0,

                    'template_id' =>
                        $template_id,

                    'message' =>
                        $custom_message,
                )
            );


        if (
            is_wp_error(
                $result
            )
        ) {

            $failed++;

            if (
                '' ===
                $first_error_message
            ) {

                $first_error_message =
                    $result->get_error_message();
            }

        } else {

            $sent++;
        }
    }


    if (
        '' !==
        $first_error_message
    ) {

        set_transient(
            'rud_crm_mass_sms_error_' .
            get_current_user_id(),
            $first_error_message,
            5 * MINUTE_IN_SECONDS
        );
    }

    wp_safe_redirect(
        rud_crm_mass_sms_page_url(
            array(

                'rud_mass_sms_message' =>
                    'completed',

                'sent' =>
                    $sent,

                'failed' =>
                    $failed,

                'skipped' =>
                    $skipped,
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_mass_sms_process_form',
    87
);


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_mass_sms_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_mass_sms_message']
                ?? ''
            )
        );


    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_mass_sms_error']
                ?? ''
            )
        );


    if (
        'completed' ===
        $message
    ) {

        $sent =
            absint(
                $_GET['sent']
                ?? 0
            );

        $failed =
            absint(
                $_GET['failed']
                ?? 0
            );

        $skipped =
            absint(
                $_GET['skipped']
                ?? 0
            );


        $detail =
            '';

        if (
            $failed > 0
        ) {

            $provider_error =
                get_transient(
                    'rud_crm_mass_sms_error_' .
                    get_current_user_id()
                );

            if (
                $provider_error
            ) {

                delete_transient(
                    'rud_crm_mass_sms_error_' .
                    get_current_user_id()
                );

                $detail =
                    '<div class="rud-crm-mass-sms-provider-error">' .
                    '<strong>Provider error:</strong> ' .
                    esc_html(
                        $provider_error
                    ) .
                    '</div>';
            }
        }

        return
            '<div class="rud-crm-mass-sms-message rud-crm-mass-sms-success">' .
            '<strong>Multi SMS completed.</strong> ' .
            esc_html(
                $sent
            ) .
            ' sent / ' .
            esc_html(
                $failed
            ) .
            ' failed / ' .
            esc_html(
                $skipped
            ) .
            ' skipped.' .
            $detail .
            '</div>';
    }


    if (
        $error
    ) {

        $text =
            'Multi SMS could not be started.';


        if (
            'no_recipients' ===
            $error
        ) {

            $text =
                'Select at least one recipient.';
        }


        if (
            'message_required' ===
            $error
        ) {

            $text =
                'Select an SMS Template or enter a custom SMS message.';
        }


        if (
            'sms_sender_unavailable' ===
            $error
        ) {

            $text =
                'The SMS Sender module is not available.';
        }


        return
            '<div class="rud-crm-mass-sms-message rud-crm-mass-sms-error">' .
            esc_html(
                $text
            ) .
            '</div>';
    }


    return '';
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_mass_sms_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return
            '<p>You must be logged in to use Multi SMS.</p>';
    }


    if (
        ! rud_crm_mass_sms_can_manage()
    ) {

        return
            '<p>You do not have permission to use Multi SMS.</p>';
    }


    if (
        ! function_exists(
            'rud_crm_get_sms_templates'
        )
    ) {

        return
            '<p>The SMS System module is not available.</p>';
    }


    $recipients =
        rud_crm_mass_sms_get_recipients();


    $templates =
        rud_crm_get_sms_templates(
            'active'
        );


    ob_start();

    ?>

    <div class="rud-crm-mass-sms">

        <h1>
            Multi SMS
        </h1>

        <p class="rud-crm-mass-sms-intro">
            Send one SMS message to multiple selected Customers and Contact Persons.
            Duplicate mobile numbers are automatically skipped.
            <strong>Multi SMS v1.1</strong>
        </p>


        <?php
        echo rud_crm_mass_sms_message_html();
        ?>


        <form
            method="post"
            id="rud-crm-mass-sms-form"
        >

            <?php
            wp_nonce_field(
                'rud_crm_mass_sms',
                'rud_crm_mass_sms_nonce'
            );
            ?>

            <input
                type="hidden"
                name="rud_crm_mass_sms_action"
                value="send_mass_sms"
            >


            <section class="rud-crm-mass-sms-panel">

                <h2>
                    Message
                </h2>


                <div class="rud-crm-mass-sms-grid">

                    <div>

                        <label>
                            SMS Template
                        </label>

                        <select
                            name="template_id"
                            data-rud-mass-sms-template
                        >

                            <option value="0">
                                Custom SMS
                            </option>


                            <?php foreach ( $templates as $template ) : ?>

                                <option
                                    value="<?php echo esc_attr( $template->id ); ?>"
                                    data-message="<?php echo esc_attr( $template->message ); ?>"
                                >
                                    <?php echo esc_html( $template->template_name ); ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="rud-crm-mass-sms-wide">

                        <label>
                            SMS Message
                        </label>

                        <textarea
                            name="message"
                            rows="6"
                            maxlength="1600"
                            data-rud-mass-sms-message
                            placeholder="Write a custom SMS or select an SMS Template."
                        ></textarea>

                        <small>
                            Template variables are replaced separately for each recipient.
                        </small>

                    </div>

                </div>

            </section>


            <section class="rud-crm-mass-sms-panel">

                <div class="rud-crm-mass-sms-recipient-header">

                    <div>

                        <h2>
                            Recipients
                        </h2>

                        <p>
                            Select the Customers and Contact Persons who should receive this SMS.
                        </p>

                    </div>


                    <div class="rud-crm-mass-sms-selected-count">

                        Selected:
                        <strong data-rud-mass-sms-selected-count>
                            0
                        </strong>

                    </div>

                </div>


                <div class="rud-crm-mass-sms-toolbar">

                    <input
                        type="search"
                        placeholder="Search name, company or phone number"
                        data-rud-mass-sms-search
                    >


                    <button
                        type="button"
                        class="rud-crm-mass-sms-secondary-button"
                        data-rud-mass-sms-select-visible
                    >
                        SELECT VISIBLE
                    </button>


                    <button
                        type="button"
                        class="rud-crm-mass-sms-secondary-button"
                        data-rud-mass-sms-clear
                    >
                        CLEAR
                    </button>

                </div>


                <?php if ( ! empty( $recipients ) ) : ?>

                    <div class="rud-crm-mass-sms-recipient-list">

                        <?php foreach ( $recipients as $recipient ) : ?>

                            <label
                                class="rud-crm-mass-sms-recipient-row"
                                data-rud-mass-sms-row
                                data-search="<?php
                                echo esc_attr(
                                    strtolower(
                                        implode(
                                            ' ',
                                            array(
                                                $recipient['name'],
                                                $recipient['company'],
                                                $recipient['number'],
                                                $recipient['type'],
                                            )
                                        )
                                    )
                                );
                                ?>"
                            >

                                <input
                                    type="checkbox"
                                    name="recipients[]"
                                    value="<?php echo esc_attr( $recipient['key'] ); ?>"
                                    data-rud-mass-sms-checkbox
                                >


                                <span class="rud-crm-mass-sms-recipient-main">

                                    <strong>
                                        <?php echo esc_html( $recipient['name'] ); ?>
                                    </strong>

                                    <?php if ( $recipient['company'] ) : ?>

                                        <span>
                                            <?php echo esc_html( $recipient['company'] ); ?>
                                        </span>

                                    <?php endif; ?>

                                </span>


                                <span class="rud-crm-mass-sms-recipient-type">
                                    <?php echo esc_html( $recipient['type'] ); ?>
                                </span>


                                <span class="rud-crm-mass-sms-recipient-number">
                                    <?php echo esc_html( $recipient['number'] ); ?>
                                </span>

                            </label>

                        <?php endforeach; ?>

                    </div>

                <?php else : ?>

                    <p>
                        No Customers or Contact Persons with mobile numbers were found.
                    </p>

                <?php endif; ?>

            </section>


            <div class="rud-crm-mass-sms-sendbar">

                <div>
                    The system removes duplicate phone numbers before sending.
                </div>

                <button
                    type="submit"
                    class="rud-crm-mass-sms-primary-button"
                    onclick="return confirm('Send this SMS to all selected recipients?');"
                >
                    SEND MULTI SMS
                </button>

            </div>

        </form>

    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_mass_sms',
    'rud_crm_mass_sms_shortcode'
);


/*
 * =========================================================
 * ASSETS
 * =========================================================
 */

function rud_crm_mass_sms_assets() {

    if (
        is_admin()
    ) {
        return;
    }


    $css = '

    .rud-crm-mass-sms {
        width:100%;
        max-width:1180px;
        margin:0 auto;
    }

    .rud-crm-mass-sms-intro {
        margin-bottom:24px;
        color:#667085;
    }

    .rud-crm-mass-sms-panel {
        margin-bottom:24px;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
    }

    .rud-crm-mass-sms-panel * {
        box-sizing:border-box;
    }

    .rud-crm-mass-sms-panel h2 {
        margin-top:0 !important;
    }

    .rud-crm-mass-sms-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-mass-sms-wide {
        grid-column:1 / -1;
    }

    .rud-crm-mass-sms-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-mass-sms-grid select,
    .rud-crm-mass-sms-grid textarea,
    .rud-crm-mass-sms-toolbar input {
        width:100%;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-mass-sms-grid small {
        display:block;
        margin-top:5px;
        color:#667085;
        font-size:11px;
    }

    .rud-crm-mass-sms-recipient-header {
        display:flex;
        justify-content:space-between;
        align-items:flex-start;
        gap:20px;
    }

    .rud-crm-mass-sms-recipient-header p {
        margin-bottom:0;
        color:#667085;
    }

    .rud-crm-mass-sms-selected-count {
        white-space:nowrap;
        padding:8px 12px;
        border:1px solid #eaecf0;
        border-radius:7px;
        background:#f9fafb;
    }

    .rud-crm-mass-sms-toolbar {
        display:grid;
        grid-template-columns:minmax(0,1fr) auto auto;
        gap:10px;
        margin:18px 0;
    }

    .rud-crm-mass-sms-recipient-list {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
        max-height:560px;
        overflow-y:auto;
    }

    .rud-crm-mass-sms-recipient-row {
        display:grid;
        grid-template-columns:auto minmax(0,1fr) 140px 170px;
        gap:12px;
        align-items:center;
        padding:12px 14px;
        margin:0;
        border-bottom:1px solid #eaecf0;
        cursor:pointer;
    }

    .rud-crm-mass-sms-recipient-row:last-child {
        border-bottom:0;
    }

    .rud-crm-mass-sms-recipient-row:hover {
        background:#f9fafb;
    }

    .rud-crm-mass-sms-recipient-main {
        display:flex;
        flex-direction:column;
        min-width:0;
    }

    .rud-crm-mass-sms-recipient-main span {
        margin-top:2px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-mass-sms-recipient-type {
        color:#475467;
        font-size:12px;
    }

    .rud-crm-mass-sms-recipient-number {
        text-align:right;
        font-variant-numeric:tabular-nums;
    }

    .rud-crm-mass-sms-sendbar {
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:20px;
        margin-top:8px;
        padding:18px 20px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
    }

    .rud-crm-mass-sms-primary-button,
    .rud-crm-mass-sms-secondary-button {
        min-height:38px;
        padding:8px 13px;
        border-radius:7px;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-mass-sms-primary-button {
        border:1px solid #1d2939;
        background:#1d2939;
        color:#fff;
    }

    .rud-crm-mass-sms-secondary-button {
        border:1px solid #98a2b3;
        background:#fff;
        color:#1d2939;
    }

    .rud-crm-mass-sms-message {
        margin-bottom:18px;
        padding:11px 13px;
        border-radius:7px;
    }

    .rud-crm-mass-sms-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-mass-sms-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    .rud-crm-mass-sms-provider-error {
        margin-top:8px;
        color:#b42318;
    }

    @media (max-width:800px) {

        .rud-crm-mass-sms-grid,
        .rud-crm-mass-sms-toolbar {
            grid-template-columns:1fr;
        }

        .rud-crm-mass-sms-wide {
            grid-column:auto;
        }

        .rud-crm-mass-sms-recipient-header,
        .rud-crm-mass-sms-sendbar {
            display:block;
        }

        .rud-crm-mass-sms-selected-count {
            display:inline-block;
            margin-top:12px;
        }

        .rud-crm-mass-sms-recipient-row {
            grid-template-columns:auto minmax(0,1fr);
        }

        .rud-crm-mass-sms-recipient-type,
        .rud-crm-mass-sms-recipient-number {
            grid-column:2;
            text-align:left;
        }

        .rud-crm-mass-sms-primary-button {
            width:100%;
            margin-top:14px;
        }
    }

    ';


    wp_register_style(
        'rud-crm-mass-sms',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );


    wp_enqueue_style(
        'rud-crm-mass-sms'
    );


    wp_add_inline_style(
        'rud-crm-mass-sms',
        $css
    );


    $js = <<<'JS'
document.addEventListener('DOMContentLoaded', function () {

    var form =
        document.getElementById(
            'rud-crm-mass-sms-form'
        );

    if (!form) {
        return;
    }

    var search =
        form.querySelector(
            '[data-rud-mass-sms-search]'
        );

    var rows =
        Array.prototype.slice.call(
            form.querySelectorAll(
                '[data-rud-mass-sms-row]'
            )
        );

    var checkboxes =
        Array.prototype.slice.call(
            form.querySelectorAll(
                '[data-rud-mass-sms-checkbox]'
            )
        );

    var count =
        form.querySelector(
            '[data-rud-mass-sms-selected-count]'
        );

    var selectVisible =
        form.querySelector(
            '[data-rud-mass-sms-select-visible]'
        );

    var clear =
        form.querySelector(
            '[data-rud-mass-sms-clear]'
        );

    var template =
        form.querySelector(
            '[data-rud-mass-sms-template]'
        );

    var message =
        form.querySelector(
            '[data-rud-mass-sms-message]'
        );


    function updateCount() {

        var selected =
            checkboxes.filter(
                function (checkbox) {
                    return checkbox.checked;
                }
            ).length;

        if (count) {
            count.textContent = selected;
        }
    }


    if (search) {

        search.addEventListener(
            'input',
            function () {

                var query =
                    search.value
                        .toLowerCase()
                        .trim();

                rows.forEach(
                    function (row) {

                        var haystack =
                            row.getAttribute(
                                'data-search'
                            )
                            || '';

                        var visible =
                            ! query
                            ||
                            haystack.indexOf(
                                query
                            )
                            !== -1;

                        row.style.display =
                            visible
                            ? ''
                            : 'none';
                    }
                );
            }
        );
    }


    checkboxes.forEach(
        function (checkbox) {

            checkbox.addEventListener(
                'change',
                updateCount
            );
        }
    );


    if (selectVisible) {

        selectVisible.addEventListener(
            'click',
            function () {

                rows.forEach(
                    function (row) {

                        if (
                            row.style.display
                            ===
                            'none'
                        ) {
                            return;
                        }

                        var checkbox =
                            row.querySelector(
                                '[data-rud-mass-sms-checkbox]'
                            );

                        if (checkbox) {
                            checkbox.checked = true;
                        }
                    }
                );

                updateCount();
            }
        );
    }


    if (clear) {

        clear.addEventListener(
            'click',
            function () {

                checkboxes.forEach(
                    function (checkbox) {
                        checkbox.checked = false;
                    }
                );

                updateCount();
            }
        );
    }


    if (
        template
        &&
        message
    ) {

        template.addEventListener(
            'change',
            function () {

                var option =
                    template.options[
                        template.selectedIndex
                    ];

                if (
                    template.value
                    ===
                    '0'
                ) {
                    message.value = '';
                    return;
                }

                message.value =
                    option.getAttribute(
                        'data-message'
                    )
                    || '';
            }
        );
    }


    updateCount();
});
JS;


    wp_register_script(
        'rud-crm-mass-sms',
        '',
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0',
        true
    );


    wp_enqueue_script(
        'rud-crm-mass-sms'
    );


    wp_add_inline_script(
        'rud-crm-mass-sms',
        $js
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_mass_sms_assets',
    92
);


/*
 * =========================================================
 * RENAME MASS SMS MENU LABEL
 * =========================================================
 */

function rud_crm_frontend_access_multi_sms_menu_label( $items, $args ) {

    return str_replace(
        '>Mass SMS</a>',
        '>Multi SMS</a>',
        $items
    );
}

add_filter(
    'wp_nav_menu_items',
    'rud_crm_frontend_access_multi_sms_menu_label',
    20000,
    2
);
