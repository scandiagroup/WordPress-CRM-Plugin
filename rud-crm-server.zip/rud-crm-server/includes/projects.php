<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * PROJECTS
 * Version 1.0
 * =========================================================
 *
 * Foundation functions for:
 * - Creating projects
 * - Reading projects
 * - Updating projects
 * - Deleting projects
 * - Connecting customers to projects
 * - Removing customer/project connections
 *
 * Front-end UI will be added in the next step.
 *
 * =========================================================
 */


/*
 * =========================================================
 * TABLE NAMES
 * =========================================================
 */

function rud_crm_projects_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_projects';
}


function rud_crm_project_customers_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_project_customers';
}


/*
 * =========================================================
 * PROJECT STATUS OPTIONS
 * =========================================================
 */

function rud_crm_project_statuses() {

    return array(
        'planning'  => 'Planning',
        'active'    => 'Active',
        'on_hold'   => 'On Hold',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled',
        'archived'  => 'Archived',
    );
}


/*
 * =========================================================
 * GENERATE PROJECT UUID
 * =========================================================
 */

function rud_crm_generate_project_uuid() {

    return wp_generate_uuid4();
}


/*
 * =========================================================
 * GENERATE PROJECT NUMBER
 * =========================================================
 *
 * Format:
 * PROJECT-YY-0001
 *
 * Example:
 * PROJECT-26-0001
 *
 * =========================================================
 */

function rud_crm_generate_project_number() {

    global $wpdb;

    $table =
        rud_crm_projects_table();

    $year =
        wp_date(
            'y'
        );

    $prefix =
        'PROJECT-' .
        $year .
        '-';

    $latest =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT project_number
                 FROM {$table}
                 WHERE project_number LIKE %s
                 ORDER BY id DESC
                 LIMIT 1",
                $prefix . '%'
            )
        );

    $next =
        1;

    if (
        is_string(
            $latest
        )
        &&
        preg_match(
            '/^PROJECT-\d{2}-(\d+)$/',
            $latest,
            $matches
        )
    ) {

        $next =
            absint(
                $matches[1]
            )
            + 1;
    }

    return
        $prefix .
        str_pad(
            (string)
            $next,
            4,
            '0',
            STR_PAD_LEFT
        );
}


/*
 * =========================================================
 * CREATE PROJECT
 * =========================================================
 */

function rud_crm_create_project(
    $data = array()
) {

    global $wpdb;

    $title =
        sanitize_text_field(
            $data['project_title']
            ?? ''
        );

    if (
        '' ===
        trim(
            $title
        )
    ) {

        return new WP_Error(
            'rud_crm_project_title_required',
            'Project title is required.'
        );
    }

    $statuses =
        rud_crm_project_statuses();

    $status =
        sanitize_key(
            $data['status']
            ?? 'planning'
        );

    if (
        ! isset(
            $statuses[
                $status
            ]
        )
    ) {

        $status =
            'planning';
    }

    $project_uuid =
        rud_crm_generate_project_uuid();

    $project_number =
        rud_crm_generate_project_number();

    $created_by =
        isset(
            $data['created_by']
        )
        ? absint(
            $data['created_by']
        )
        : get_current_user_id();

    $now =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->insert(
            rud_crm_projects_table(),
            array(
                'project_uuid' =>
                    $project_uuid,

                'project_number' =>
                    $project_number,

                'project_title' =>
                    $title,

                'project_type' =>
                    sanitize_text_field(
                        $data['project_type']
                        ?? ''
                    ),

                'status' =>
                    $status,

                'start_date' =>
                    ! empty(
                        $data['start_date']
                    )
                    ? sanitize_text_field(
                        $data['start_date']
                    )
                    : null,

                'end_date' =>
                    ! empty(
                        $data['end_date']
                    )
                    ? sanitize_text_field(
                        $data['end_date']
                    )
                    : null,

                'description' =>
                    sanitize_textarea_field(
                        $data['description']
                        ?? ''
                    ),

                'internal_notes' =>
                    sanitize_textarea_field(
                        $data['internal_notes']
                        ?? ''
                    ),

                'created_by' =>
                    $created_by
                    ? $created_by
                    : null,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'rud_crm_project_create_failed',
            'The project could not be created.'
        );
    }

    return absint(
        $wpdb->insert_id
    );
}


/*
 * =========================================================
 * GET PROJECT
 * =========================================================
 */

function rud_crm_get_project(
    $project_id
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    if (
        ! $project_id
    ) {

        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_projects_table() .
                "
                 WHERE id = %d
                 LIMIT 1",
                $project_id
            )
        );
}


/*
 * =========================================================
 * GET PROJECTS
 * =========================================================
 */

function rud_crm_get_projects(
    $args = array()
) {

    global $wpdb;

    $defaults =
        array(
            'status'  => '',
            'search'  => '',
            'orderby' => 'project_title',
            'order'   => 'ASC',
            'limit'   => 0,
        );

    $args =
        wp_parse_args(
            $args,
            $defaults
        );

    $where =
        array(
            '1=1'
        );

    $values =
        array();

    $status =
        sanitize_key(
            $args['status']
        );

    if (
        '' !==
        $status
        &&
        isset(
            rud_crm_project_statuses()[
                $status
            ]
        )
    ) {

        $where[] =
            'status = %s';

        $values[] =
            $status;
    }

    $search =
        sanitize_text_field(
            $args['search']
        );

    if (
        '' !==
        $search
    ) {

        $like =
            '%' .
            $wpdb->esc_like(
                $search
            ) .
            '%';

        $where[] =
            '(
                project_title LIKE %s
                OR project_number LIKE %s
                OR project_type LIKE %s
            )';

        $values[] =
            $like;

        $values[] =
            $like;

        $values[] =
            $like;
    }

    $allowed_orderby =
        array(
            'id',
            'project_number',
            'project_title',
            'project_type',
            'status',
            'start_date',
            'created_at',
            'updated_at',
        );

    $orderby =
        sanitize_key(
            $args['orderby']
        );

    if (
        ! in_array(
            $orderby,
            $allowed_orderby,
            true
        )
    ) {

        $orderby =
            'project_title';
    }

    $order =
        strtoupper(
            sanitize_text_field(
                $args['order']
            )
        );

    if (
        ! in_array(
            $order,
            array(
                'ASC',
                'DESC'
            ),
            true
        )
    ) {

        $order =
            'ASC';
    }

    $sql =
        "SELECT *
         FROM " .
        rud_crm_projects_table() .
        "
         WHERE " .
        implode(
            ' AND ',
            $where
        ) .
        "
         ORDER BY {$orderby} {$order}";

    $limit =
        absint(
            $args['limit']
        );

    if (
        $limit >
        0
    ) {

        $sql .=
            ' LIMIT ' .
            $limit;
    }

    if (
        ! empty(
            $values
        )
    ) {

        $sql =
            $wpdb->prepare(
                $sql,
                $values
            );
    }

    return
        $wpdb->get_results(
            $sql
        );
}


/*
 * =========================================================
 * UPDATE PROJECT
 * =========================================================
 */

function rud_crm_update_project(
    $project_id,
    $data = array()
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    if (
        ! $project_id
        ||
        ! rud_crm_get_project(
            $project_id
        )
    ) {

        return new WP_Error(
            'rud_crm_project_not_found',
            'Project could not be found.'
        );
    }

    $update =
        array();

    if (
        array_key_exists(
            'project_title',
            $data
        )
    ) {

        $title =
            sanitize_text_field(
                $data['project_title']
            );

        if (
            '' ===
            trim(
                $title
            )
        ) {

            return new WP_Error(
                'rud_crm_project_title_required',
                'Project title is required.'
            );
        }

        $update['project_title'] =
            $title;
    }

    if (
        array_key_exists(
            'project_type',
            $data
        )
    ) {

        $update['project_type'] =
            sanitize_text_field(
                $data['project_type']
            );
    }

    if (
        array_key_exists(
            'status',
            $data
        )
    ) {

        $status =
            sanitize_key(
                $data['status']
            );

        if (
            ! isset(
                rud_crm_project_statuses()[
                    $status
                ]
            )
        ) {

            $status =
                'planning';
        }

        $update['status'] =
            $status;
    }

    if (
        array_key_exists(
            'start_date',
            $data
        )
    ) {

        $update['start_date'] =
            ! empty(
                $data['start_date']
            )
            ? sanitize_text_field(
                $data['start_date']
            )
            : null;
    }

    if (
        array_key_exists(
            'end_date',
            $data
        )
    ) {

        $update['end_date'] =
            ! empty(
                $data['end_date']
            )
            ? sanitize_text_field(
                $data['end_date']
            )
            : null;
    }

    if (
        array_key_exists(
            'description',
            $data
        )
    ) {

        $update['description'] =
            sanitize_textarea_field(
                $data['description']
            );
    }

    if (
        array_key_exists(
            'internal_notes',
            $data
        )
    ) {

        $update['internal_notes'] =
            sanitize_textarea_field(
                $data['internal_notes']
            );
    }

    if (
        empty(
            $update
        )
    ) {

        return true;
    }

    $update['updated_at'] =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->update(
            rud_crm_projects_table(),
            $update,
            array(
                'id' =>
                    $project_id,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'rud_crm_project_update_failed',
            'The project could not be updated.'
        );
    }

    return true;
}


/*
 * =========================================================
 * DELETE PROJECT
 * =========================================================
 */

function rud_crm_delete_project(
    $project_id
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    if (
        ! $project_id
    ) {

        return false;
    }

    /*
     * Remove project/customer links first.
     */

    $wpdb->delete(
        rud_crm_project_customers_table(),
        array(
            'project_id' =>
                $project_id,
        )
    );

    $result =
        $wpdb->delete(
            rud_crm_projects_table(),
            array(
                'id' =>
                    $project_id,
            )
        );

    return
        false !==
        $result;
}


/*
 * =========================================================
 * CONNECT CUSTOMER TO PROJECT
 * =========================================================
 */

function rud_crm_connect_customer_to_project(
    $project_id,
    $customer_id,
    $data = array()
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $project_id
        ||
        ! $customer_id
    ) {

        return new WP_Error(
            'rud_crm_project_customer_invalid',
            'Project and customer are required.'
        );
    }

    if (
        ! rud_crm_get_project(
            $project_id
        )
    ) {

        return new WP_Error(
            'rud_crm_project_not_found',
            'Project could not be found.'
        );
    }

    /*
     * Avoid duplicate links.
     */

    $existing_id =
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM " .
                    rud_crm_project_customers_table() .
                    "
                     WHERE project_id = %d
                     AND customer_id = %d
                     LIMIT 1",
                    $project_id,
                    $customer_id
                )
            )
        );

    if (
        $existing_id
    ) {

        return $existing_id;
    }

    $created_by =
        isset(
            $data['created_by']
        )
        ? absint(
            $data['created_by']
        )
        : get_current_user_id();

    $now =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->insert(
            rud_crm_project_customers_table(),
            array(
                'project_id' =>
                    $project_id,

                'customer_id' =>
                    $customer_id,

                'relationship_role' =>
                    sanitize_text_field(
                        $data['relationship_role']
                        ?? ''
                    ),

                'relationship_status' =>
                    sanitize_key(
                        $data['relationship_status']
                        ?? 'active'
                    ),

                'notes' =>
                    sanitize_textarea_field(
                        $data['notes']
                        ?? ''
                    ),

                'created_by' =>
                    $created_by
                    ? $created_by
                    : null,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'rud_crm_project_customer_create_failed',
            'The customer could not be connected to the project.'
        );
    }

    return absint(
        $wpdb->insert_id
    );
}


/*
 * =========================================================
 * REMOVE CUSTOMER FROM PROJECT
 * =========================================================
 */

function rud_crm_disconnect_customer_from_project(
    $project_id,
    $customer_id
) {

    global $wpdb;

    $result =
        $wpdb->delete(
            rud_crm_project_customers_table(),
            array(
                'project_id' =>
                    absint(
                        $project_id
                    ),

                'customer_id' =>
                    absint(
                        $customer_id
                    ),
            )
        );

    return
        false !==
        $result;
}


/*
 * =========================================================
 * GET PROJECTS FOR CUSTOMER
 * =========================================================
 */

function rud_crm_get_customer_projects(
    $customer_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
    ) {

        return array();
    }

    $projects_table =
        rud_crm_projects_table();

    $links_table =
        rud_crm_project_customers_table();

    return
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    p.*,
                    pc.relationship_role,
                    pc.relationship_status,
                    pc.notes AS relationship_notes
                 FROM {$links_table} pc
                 INNER JOIN {$projects_table} p
                    ON p.id = pc.project_id
                 WHERE pc.customer_id = %d
                 ORDER BY p.project_title ASC",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * GET CUSTOMERS FOR PROJECT
 * =========================================================
 */

function rud_crm_get_project_customers(
    $project_id
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    if (
        ! $project_id
    ) {

        return array();
    }

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    $links_table =
        rud_crm_project_customers_table();

    return
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT
                    c.*,
                    pc.relationship_role,
                    pc.relationship_status,
                    pc.notes AS relationship_notes
                 FROM {$links_table} pc
                 INNER JOIN {$customers_table} c
                    ON c.id = pc.customer_id
                 WHERE pc.project_id = %d
                 ORDER BY
                    c.company_name ASC,
                    c.last_name ASC,
                    c.first_name ASC",
                $project_id
            )
        );
}


/*
 * =========================================================
 * CUSTOMER CONNECTED TO PROJECT?
 * =========================================================
 */

function rud_crm_customer_is_connected_to_project(
    $project_id,
    $customer_id
) {

    global $wpdb;

    return (bool)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM " .
                rud_crm_project_customers_table() .
                "
                 WHERE project_id = %d
                 AND customer_id = %d
                 LIMIT 1",
                absint(
                    $project_id
                ),
                absint(
                    $customer_id
                )
            )
        );
}


/*
 * =========================================================
 * PROJECT CUSTOMER COUNT
 * =========================================================
 */

function rud_crm_project_customer_count(
    $project_id
) {

    global $wpdb;

    return absint(
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM " .
                rud_crm_project_customers_table() .
                "
                 WHERE project_id = %d",
                absint(
                    $project_id
                )
            )
        )
    );
}
