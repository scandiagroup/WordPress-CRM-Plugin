<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * ALARM / REMINDER ENGINE
 * Version 1.3
 * =========================================================
 *
 * Purpose:
 * - Process due task reminders
 * - Create internal CRM notifications
 * - Prepare for Email and SMS delivery
 * - Keep the system domain-independent
 *
 * IMPORTANT:
 * WordPress WP-Cron is used as the built-in fallback.
 * For production reliability, a real server cron job can
 * later trigger wp-cron.php on a fixed schedule.
 *
 * =========================================================
 */


/*
 * =========================================================
 * NOTIFICATIONS TABLE
 * =========================================================
 */

function rud_crm_notifications_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_notifications';
}


/*
 * =========================================================
 * ENSURE NOTIFICATIONS TABLE
 * =========================================================
 */

function rud_crm_ensure_notifications_table() {

    global $wpdb;

    $table =
        rud_crm_notifications_table();

    $charset_collate =
        $wpdb->get_charset_collate();

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $sql =
        "CREATE TABLE {$table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            notification_uuid CHAR(36) NOT NULL,

            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            task_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            notification_type VARCHAR(50) NOT NULL DEFAULT 'task_reminder',

            title VARCHAR(255) NOT NULL DEFAULT '',
            message LONGTEXT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'unread',

            created_at DATETIME NOT NULL,
            read_at DATETIME NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY notification_uuid (notification_uuid),

            KEY user_id (user_id),
            KEY customer_id (customer_id),
            KEY task_id (task_id),
            KEY status (status),
            KEY created_at (created_at)

        ) {$charset_collate};";

    dbDelta(
        $sql
    );
}


add_action(
    'admin_init',
    'rud_crm_ensure_notifications_table'
);


add_action(
    'init',
    'rud_crm_ensure_notifications_table',
    28
);


/*
 * =========================================================
 * ENSURE REMINDER TRACKING COLUMNS
 * =========================================================
 */

function rud_crm_ensure_task_reminder_columns() {

    global $wpdb;

    if (
        ! function_exists(
            'rud_crm_tasks_table'
        )
    ) {
        return;
    }

    $table =
        rud_crm_tasks_table();

    $columns =
        $wpdb->get_col(
            "SHOW COLUMNS FROM {$table}",
            0
        );

    if (
        ! is_array(
            $columns
        )
    ) {
        return;
    }

    if (
        ! in_array(
            'reminder_processed_at',
            $columns,
            true
        )
    ) {

        $wpdb->query(
            "ALTER TABLE {$table}
             ADD reminder_processed_at DATETIME NULL
             AFTER reminder_at"
        );
    }

    if (
        ! in_array(
            'crm_notification_sent_at',
            $columns,
            true
        )
    ) {

        $wpdb->query(
            "ALTER TABLE {$table}
             ADD crm_notification_sent_at DATETIME NULL
             AFTER reminder_processed_at"
        );
    }

    if (
        ! in_array(
            'email_notification_sent_at',
            $columns,
            true
        )
    ) {

        $wpdb->query(
            "ALTER TABLE {$table}
             ADD email_notification_sent_at DATETIME NULL
             AFTER crm_notification_sent_at"
        );
    }

    if (
        ! in_array(
            'sms_notification_sent_at',
            $columns,
            true
        )
    ) {

        $wpdb->query(
            "ALTER TABLE {$table}
             ADD sms_notification_sent_at DATETIME NULL
             AFTER email_notification_sent_at"
        );
    }
}


add_action(
    'init',
    'rud_crm_ensure_task_reminder_columns',
    29
);


/*
 * =========================================================
 * CREATE CRM NOTIFICATION
 * =========================================================
 */

function rud_crm_create_notification(
    $data
) {

    global $wpdb;

    $defaults =
        array(

            'user_id' =>
                0,

            'customer_id' =>
                0,

            'contact_id' =>
                0,

            'project_id' =>
                0,

            'task_id' =>
                0,

            'notification_type' =>
                'task_reminder',

            'title' =>
                '',

            'message' =>
                '',
        );

    $data =
        wp_parse_args(
            $data,
            $defaults
        );

    if (
        '' ===
        trim(
            (string)
            $data['title']
        )
    ) {
        return false;
    }

    $result =
        $wpdb->insert(
            rud_crm_notifications_table(),
            array(

                'notification_uuid' =>
                    wp_generate_uuid4(),

                'user_id' =>
                    absint(
                        $data['user_id']
                    ),

                'customer_id' =>
                    absint(
                        $data['customer_id']
                    ),

                'contact_id' =>
                    absint(
                        $data['contact_id']
                    ),

                'project_id' =>
                    absint(
                        $data['project_id']
                    ),

                'task_id' =>
                    absint(
                        $data['task_id']
                    ),

                'notification_type' =>
                    sanitize_key(
                        $data['notification_type']
                    ),

                'title' =>
                    sanitize_text_field(
                        $data['title']
                    ),

                'message' =>
                    sanitize_textarea_field(
                        $data['message']
                    ),

                'status' =>
                    'unread',

                'created_at' =>
                    current_time(
                        'mysql'
                    ),

                'read_at' =>
                    null,
            )
        );

    if (
        false ===
        $result
    ) {
        return false;
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * GET USER NOTIFICATIONS
 * =========================================================
 */

function rud_crm_get_user_notifications(
    $user_id,
    $args = array()
) {

    global $wpdb;

    $user_id =
        absint(
            $user_id
        );

    if (
        ! $user_id
    ) {
        return array();
    }

    $args =
        wp_parse_args(
            $args,
            array(

                'status' =>
                    '',

                'limit' =>
                    50,
            )
        );

    $where =
        array(
            'user_id = %d'
        );

    $values =
        array(
            $user_id
        );

    if (
        $args['status']
    ) {

        $where[] =
            'status = %s';

        $values[] =
            sanitize_key(
                $args['status']
            );
    }

    $limit =
        max(
            1,
            min(
                200,
                absint(
                    $args['limit']
                )
            )
        );

    $sql =
        "SELECT *
         FROM " .
        rud_crm_notifications_table() .
        "
         WHERE " .
        implode(
            ' AND ',
            $where
        ) .
        "
         ORDER BY created_at DESC, id DESC
         LIMIT {$limit}";

    $sql =
        $wpdb->prepare(
            $sql,
            $values
        );

    return
        $wpdb->get_results(
            $sql
        );
}


/*
 * =========================================================
 * UNREAD COUNT
 * =========================================================
 */

function rud_crm_get_unread_notification_count(
    $user_id
) {

    global $wpdb;

    return
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*)
                     FROM " .
                    rud_crm_notifications_table() .
                    "
                     WHERE user_id = %d
                     AND status = 'unread'",
                    absint(
                        $user_id
                    )
                )
            )
        );
}


/*
 * =========================================================
 * MARK NOTIFICATION READ
 * =========================================================
 */

function rud_crm_mark_notification_read(
    $notification_id,
    $user_id = 0
) {

    global $wpdb;

    $notification_id =
        absint(
            $notification_id
        );

    $user_id =
        absint(
            $user_id
        );

    if (
        ! $notification_id
    ) {
        return false;
    }

    $where =
        array(
            'id' =>
                $notification_id,
        );

    if (
        $user_id
    ) {

        $where['user_id'] =
            $user_id;
    }

    return
        false !==
        $wpdb->update(
            rud_crm_notifications_table(),
            array(

                'status' =>
                    'read',

                'read_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            $where
        );
}


/*
 * =========================================================
 * CUSTOM CRON SCHEDULE
 * =========================================================
 */

function rud_crm_alarm_cron_schedules(
    $schedules
) {

    if (
        ! isset(
            $schedules['rud_crm_five_minutes']
        )
    ) {

        $schedules['rud_crm_five_minutes'] =
            array(

                'interval' =>
                    5 *
                    MINUTE_IN_SECONDS,

                'display' =>
                    'Every 5 Minutes',
            );
    }

    return $schedules;
}


add_filter(
    'cron_schedules',
    'rud_crm_alarm_cron_schedules'
);


/*
 * =========================================================
 * SCHEDULE ALARM PROCESSOR
 * =========================================================
 */

function rud_crm_schedule_alarm_processor() {

    if (
        ! wp_next_scheduled(
            'rud_crm_process_due_reminders'
        )
    ) {

        wp_schedule_event(
            time() +
            60,
            'rud_crm_five_minutes',
            'rud_crm_process_due_reminders'
        );
    }
}


add_action(
    'init',
    'rud_crm_schedule_alarm_processor',
    40
);


/*
 * =========================================================
 * DUE REMINDER PROCESSOR
 * =========================================================
 */

function rud_crm_process_due_reminders_now() {

    global $wpdb;

    if (
        ! function_exists(
            'rud_crm_tasks_table'
        )
    ) {
        return 0;
    }

    $table =
        rud_crm_tasks_table();

    $now =
        current_time(
            'mysql'
        );

    $tasks =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 WHERE reminder_at IS NOT NULL
                 AND reminder_at <= %s
                 AND reminder_processed_at IS NULL
                 AND status NOT IN ('completed','cancelled')
                 ORDER BY reminder_at ASC
                 LIMIT 100",
                $now
            )
        );

    if (
        empty(
            $tasks
        )
    ) {
        return 0;
    }

    $processed = 0;

    foreach (
        $tasks
        as
        $task
    ) {

        $task_id =
            absint(
                $task->id
            );

        if (
            ! $task_id
        ) {
            continue;
        }

        $user_id =
            absint(
                $task->assigned_user_id
            );

        if (
            ! $user_id
        ) {

            $user_id =
                absint(
                    $task->created_by
                );
        }

        /*
         * Internal CRM Notification
         */

        if (
            ! empty(
                $task->notify_crm
            )
            &&
            empty(
                $task->crm_notification_sent_at
            )
            &&
            $user_id
        ) {

            $created =
                rud_crm_create_notification(
                    array(

                        'user_id' =>
                            $user_id,

                        'customer_id' =>
                            $task->customer_id,

                        'contact_id' =>
                            $task->contact_id,

                        'project_id' =>
                            $task->project_id,

                        'task_id' =>
                            $task_id,

                        'notification_type' =>
                            'task_reminder',

                        'title' =>
                            'Task Reminder: ' .
                            $task->title,

                        'message' =>
                            $task->description
                            ? $task->description
                            : 'A CRM task reminder is due.',
                    )
                );

            if (
                $created
            ) {

                $wpdb->update(
                    $table,
                    array(
                        'crm_notification_sent_at' =>
                            $now,
                    ),
                    array(
                        'id' =>
                            $task_id,
                    )
                );
            }
        }

        /*
         * Automatic Email Reminder
         */

        if (
            ! empty(
                $task->notify_email
            )
            &&
            empty(
                $task->email_notification_sent_at
            )
        ) {

            if (
                ! function_exists(
                    'rud_crm_send_email'
                )
            ) {

                if (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'email_reminder_failed',

                            'title' =>
                                'Automatic Email Failed: ' .
                                $task->title,

                            'message' =>
                                'The Email Sender module is not available.',
                        )
                    );
                }

            } elseif (
                empty(
                    $task->email_template_id
                )
            ) {

                if (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'email_reminder_failed',

                            'title' =>
                                'Automatic Email Not Sent: ' .
                                $task->title,

                            'message' =>
                                'Email delivery was enabled, but no Email Template was selected for this task.',
                        )
                    );
                }

            } else {

                $email_result =
                    rud_crm_send_email(
                        array(

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'template_id' =>
                                $task->email_template_id,
                        )
                    );

                if (
                    ! is_wp_error(
                        $email_result
                    )
                ) {

                    $wpdb->update(
                        $table,
                        array(
                            'email_notification_sent_at' =>
                                $now,
                        ),
                        array(
                            'id' =>
                                $task_id,
                        )
                    );

                } elseif (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'email_reminder_failed',

                            'title' =>
                                'Automatic Email Failed: ' .
                                $task->title,

                            'message' =>
                                $email_result->get_error_message(),
                        )
                    );
                }
            }
        }


        /*
         * Automatic SMS Reminder
         */

        if (
            ! empty(
                $task->notify_sms
            )
            &&
            empty(
                $task->sms_notification_sent_at
            )
        ) {

            if (
                ! function_exists(
                    'rud_crm_send_sms'
                )
            ) {

                if (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'sms_reminder_failed',

                            'title' =>
                                'Automatic SMS Failed: ' .
                                $task->title,

                            'message' =>
                                'The SMS Sender module is not available.',
                        )
                    );
                }

            } elseif (
                empty(
                    $task->sms_template_id
                )
            ) {

                if (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'sms_reminder_failed',

                            'title' =>
                                'Automatic SMS Not Sent: ' .
                                $task->title,

                            'message' =>
                                'SMS delivery was enabled, but no SMS Template was selected for this task.',
                        )
                    );
                }

            } else {

                $sms_result =
                    rud_crm_send_sms(
                        array(

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'template_id' =>
                                $task->sms_template_id,
                        )
                    );

                if (
                    ! is_wp_error(
                        $sms_result
                    )
                ) {

                    $wpdb->update(
                        $table,
                        array(
                            'sms_notification_sent_at' =>
                                $now,
                        ),
                        array(
                            'id' =>
                                $task_id,
                        )
                    );

                } elseif (
                    $user_id
                ) {

                    rud_crm_create_notification(
                        array(

                            'user_id' =>
                                $user_id,

                            'customer_id' =>
                                $task->customer_id,

                            'contact_id' =>
                                $task->contact_id,

                            'project_id' =>
                                $task->project_id,

                            'task_id' =>
                                $task_id,

                            'notification_type' =>
                                'sms_reminder_failed',

                            'title' =>
                                'Automatic SMS Failed: ' .
                                $task->title,

                            'message' =>
                                $sms_result->get_error_message(),
                        )
                    );
                }
            }
        }


        /*
         * Mark this reminder run as processed.
         * CRM, Email and SMS channels keep their own sent-at fields.
         */

        $wpdb->update(
            $table,
            array(
                'reminder_processed_at' =>
                    $now,
            ),
            array(
                'id' =>
                    $task_id,
            )
        );

        $processed++;
    }

    return $processed;
}



/*
 * =========================================================
 * FRONT-END FALLBACK PROCESSOR
 * =========================================================
 *
 * WP-Cron can be delayed when the site has little traffic.
 * This fallback processes due reminders whenever a logged-in
 * CRM user loads a frontend page.
 *
 * A short transient lock prevents repeated processing on
 * every single request.
 */

function rud_crm_frontend_process_due_reminders_fallback() {

    if (
        is_admin()
        ||
        ! is_user_logged_in()
        ||
        ! function_exists(
            'rud_crm_process_due_reminders_now'
        )
    ) {
        return;
    }

    $lock_key =
        'rud_crm_alarm_frontend_lock';

    if (
        get_transient(
            $lock_key
        )
    ) {
        return;
    }

    set_transient(
        $lock_key,
        1,
        MINUTE_IN_SECONDS
    );

    rud_crm_process_due_reminders_now();
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_due_reminders_fallback',
    5
);


/*
 * =========================================================
 * CRON CALLBACK
 * =========================================================
 */

function rud_crm_process_due_reminders() {

    rud_crm_process_due_reminders_now();
}


add_action(
    'rud_crm_process_due_reminders',
    'rud_crm_process_due_reminders'
);
