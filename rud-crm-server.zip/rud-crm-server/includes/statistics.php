<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * STATISTICS
 * =========================================================
 *
 * Shortcode:
 *
 * [rud_crm_statistics]
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_statistics_can_access() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    $user =
        wp_get_current_user();


    if (
        ! $user
        ||
        ! $user->exists()
    ) {

        return false;
    }


    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    if (
        in_array(
            'rud_crm_client',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            $user->ID
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * ACCOUNT TYPE
 * =========================================================
 */

function rud_crm_statistics_account_type(
    $user
) {

    if (
        ! (
            $user instanceof WP_User
        )
    ) {

        return 'RUD CRM Account';
    }


    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        return 'Demo Account';
    }


    if (
        in_array(
            'rud_crm_client',
            (array)
            $user->roles,
            true
        )
    ) {

        return 'Full CRM Account';
    }


    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
    ) {

        $level =
            rud_crm_get_admin_level(
                $user->ID
            );


        if (
            $level
        ) {

            return sprintf(
                'ADMIN-LEVEL-%03d',
                absint(
                    $level
                )
            );
        }
    }


    return 'RUD CRM Account';
}


/*
 * =========================================================
 * FORMAT DATE
 * =========================================================
 */

function rud_crm_statistics_format_date(
    $date
) {

    if (
        ! $date
    ) {

        return '—';
    }


    $timestamp =
        strtotime(
            $date
        );


    if (
        ! $timestamp
    ) {

        return esc_html(
            $date
        );
    }


    return wp_date(
        get_option(
            'date_format'
        ),
        $timestamp
    );
}


/*
 * =========================================================
 * DAYS REMAINING
 * =========================================================
 */

function rud_crm_statistics_days_remaining(
    $date
) {

    if (
        ! $date
    ) {

        return null;
    }


    $timestamp =
        strtotime(
            $date
        );


    if (
        ! $timestamp
    ) {

        return null;
    }


    $remaining =
        $timestamp -
        current_time(
            'timestamp'
        );


    if (
        $remaining <= 0
    ) {

        return 0;
    }


    return (int)
        ceil(
            $remaining /
            DAY_IN_SECONDS
        );
}


/*
 * =========================================================
 * CUSTOMER COUNT
 * =========================================================
 */

function rud_crm_statistics_customer_count(
    $user_id
) {

    if (
        function_exists(
            'rud_crm_count_owned_customers'
        )
    ) {

        return absint(
            rud_crm_count_owned_customers(
                $user_id,
                'trial'
            )
        );
    }


    return 0;
}


/*
 * =========================================================
 * CUSTOMER LIMIT
 * =========================================================
 */

function rud_crm_statistics_customer_limit(
    $user
) {

    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        if (
            function_exists(
                'rud_crm_trial_customer_limit'
            )
        ) {

            return absint(
                rud_crm_trial_customer_limit()
            );
        }


        return 10;
    }


    return null;
}


/*
 * =========================================================
 * EMAIL VERIFICATION
 * =========================================================
 */

function rud_crm_statistics_email_verified(
    $user_id
) {

    if (
        function_exists(
            'rud_crm_email_is_verified'
        )
    ) {

        return (bool)
            rud_crm_email_is_verified(
                $user_id
            );
    }


    return true;
}


/*
 * =========================================================
 * CUSTOMER ACTIVITY COUNT
 * =========================================================
 */

function rud_crm_statistics_activity_count(
    $user_id
) {

    global $wpdb;


    if (
        ! function_exists(
            'rud_crm_get_owned_customer_ids'
        )
    ) {

        return 0;
    }


    $customer_ids =
        rud_crm_get_owned_customer_ids(
            $user_id
        );


    if (
        empty(
            $customer_ids
        )
    ) {

        return 0;
    }


    $customer_ids =
        array_map(
            'absint',
            $customer_ids
        );


    $customer_ids =
        array_filter(
            $customer_ids
        );


    if (
        empty(
            $customer_ids
        )
    ) {

        return 0;
    }


    $table =
        $wpdb->prefix .
        'rudcrm_customer_activity';


    $table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        );


    if (
        $table_exists !==
        $table
    ) {

        return 0;
    }


    $placeholders =
        implode(
            ',',
            array_fill(
                0,
                count(
                    $customer_ids
                ),
                '%d'
            )
        );


    $sql =
        "
        SELECT COUNT(*)
        FROM {$table}
        WHERE customer_id IN ({$placeholders})
        ";


    $prepared =
        $wpdb->prepare(
            $sql,
            $customer_ids
        );


    return absint(
        $wpdb->get_var(
            $prepared
        )
    );
}


/*
 * =========================================================
 * STATISTICS SHORTCODE
 * =========================================================
 */

function rud_crm_statistics_shortcode() {

    if (
        ! rud_crm_statistics_can_access()
    ) {

        return
            '<div class="rud-crm-statistics-message">' .
            'You must be logged in to view your CRM statistics.' .
            '</div>';
    }


    $user =
        wp_get_current_user();


    $user_id =
        $user->ID;


    $account_type =
        rud_crm_statistics_account_type(
            $user
        );


    $is_demo =
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        );


    $valid_from =
        get_user_meta(
            $user_id,
            'rud_crm_valid_from',
            true
        );


    $valid_until =
        get_user_meta(
            $user_id,
            'rud_crm_valid_until',
            true
        );


    $days_remaining =
        rud_crm_statistics_days_remaining(
            $valid_until
        );


    $customer_count =
        rud_crm_statistics_customer_count(
            $user_id
        );


    $customer_limit =
        rud_crm_statistics_customer_limit(
            $user
        );


    $remaining_slots =
        null;


    if (
        null !==
        $customer_limit
    ) {

        $remaining_slots =
            max(
                0,
                $customer_limit -
                $customer_count
            );
    }


    $email_verified =
        rud_crm_statistics_email_verified(
            $user_id
        );


    $activity_count =
        rud_crm_statistics_activity_count(
            $user_id
        );


    ob_start();

    ?>

    <div class="rud-crm-statistics-wrap">


        <div class="rud-crm-statistics-header">

            <h2>
                CRM Statistics
            </h2>

            <p>
                Overview of your RUD CRM account and current CRM usage.
            </p>

        </div>


        <div class="rud-crm-statistics-grid">


            <div class="rud-crm-stat-card">

                <span>
                    Account Type
                </span>

                <strong>
                    <?php
                    echo esc_html(
                        $account_type
                    );
                    ?>
                </strong>

            </div>


            <div class="rud-crm-stat-card">

                <span>
                    Email Verification
                </span>

                <strong>

                    <?php

                    echo esc_html(
                        $email_verified
                        ? 'VERIFIED'
                        : 'NOT VERIFIED'
                    );

                    ?>

                </strong>

            </div>


            <div class="rud-crm-stat-card">

                <span>
                    My Customers
                </span>

                <strong>
                    <?php
                    echo esc_html(
                        $customer_count
                    );
                    ?>
                </strong>

            </div>


            <div class="rud-crm-stat-card">

                <span>
                    Customer Activities
                </span>

                <strong>
                    <?php
                    echo esc_html(
                        $activity_count
                    );
                    ?>
                </strong>

            </div>


            <?php if ( $is_demo ) : ?>


                <div class="rud-crm-stat-card">

                    <span>
                        Customer Limit
                    </span>

                    <strong>

                        <?php

                        echo esc_html(
                            $customer_limit
                        );

                        ?>

                    </strong>

                </div>


                <div class="rud-crm-stat-card">

                    <span>
                        Remaining Customer Slots
                    </span>

                    <strong>

                        <?php

                        echo esc_html(
                            $remaining_slots
                        );

                        ?>

                    </strong>

                </div>


                <div class="rud-crm-stat-card">

                    <span>
                        Demo Started
                    </span>

                    <strong>

                        <?php

                        echo esc_html(
                            rud_crm_statistics_format_date(
                                $valid_from
                            )
                        );

                        ?>

                    </strong>

                </div>


                <div class="rud-crm-stat-card">

                    <span>
                        Demo Valid Until
                    </span>

                    <strong>

                        <?php

                        echo esc_html(
                            rud_crm_statistics_format_date(
                                $valid_until
                            )
                        );

                        ?>

                    </strong>

                </div>


                <div class="rud-crm-stat-card">

                    <span>
                        Days Remaining
                    </span>

                    <strong>

                        <?php

                        echo esc_html(
                            null ===
                            $days_remaining
                            ? '—'
                            : $days_remaining
                        );

                        ?>

                    </strong>

                </div>


            <?php endif; ?>


        </div>


        <?php if ( $is_demo ) : ?>


            <div class="rud-crm-statistics-upgrade">

                <h3>
                    Need More?
                </h3>

                <p>
                    Upgrade your Demo account to a Full RUD CRM package.
                </p>

                <a
                    href="<?php
                    echo esc_url(
                        home_url(
                            '/upgrade-account/'
                        )
                    );
                    ?>"
                >
                    UPGRADE TO FULL VERSION
                </a>

            </div>


        <?php endif; ?>


        <div class="rud-crm-statistics-actions">

            <a
                href="<?php
                echo esc_url(
                    function_exists(
                        'rud_crm_my_account_page_url'
                    )
                    ? rud_crm_my_account_page_url()
                    : home_url(
                        '/my-account/'
                    )
                );
                ?>"
            >
                ← Back to My Account
            </a>

        </div>


    </div>


    <style>

        .rud-crm-statistics-wrap {
            width:100%;
            max-width:1000px;
            margin:0 auto;
        }


        .rud-crm-statistics-header {
            margin-bottom:25px;
        }


        .rud-crm-statistics-header h2 {
            margin-top:0;
        }


        .rud-crm-statistics-grid {
            display:grid;
            grid-template-columns:repeat(3,minmax(0,1fr));
            gap:18px;
        }


        .rud-crm-stat-card {
            padding:20px;
            border:1px solid #dddddd;
            border-radius:8px;
            background:#ffffff;
        }


        .rud-crm-stat-card span {
            display:block;
            margin-bottom:7px;
            font-size:13px;
            opacity:.7;
        }


        .rud-crm-stat-card strong {
            font-size:20px;
        }


        .rud-crm-statistics-upgrade {
            margin-top:25px;
            padding:22px;
            border:1px solid #dddddd;
            border-radius:8px;
            text-align:center;
        }


        .rud-crm-statistics-upgrade h3 {
            margin-top:0;
        }


        .rud-crm-statistics-upgrade a {
            display:inline-block;
            margin-top:8px;
            padding:13px 22px;
            background:#1d2327;
            color:#ffffff;
            text-decoration:none;
            border-radius:5px;
            font-weight:700;
        }


        .rud-crm-statistics-actions {
            margin-top:25px;
        }


        .rud-crm-statistics-actions a {
            text-decoration:none;
        }


        .rud-crm-statistics-message {
            padding:18px;
            border:1px solid #dddddd;
            border-radius:6px;
        }


        @media (max-width:850px) {

            .rud-crm-statistics-grid {
                grid-template-columns:repeat(2,minmax(0,1fr));
            }
        }


        @media (max-width:550px) {

            .rud-crm-statistics-grid {
                grid-template-columns:1fr;
            }
        }

    </style>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_statistics',
    'rud_crm_statistics_shortcode'
);