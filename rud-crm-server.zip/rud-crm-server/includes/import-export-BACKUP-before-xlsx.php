<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * EXCEL IMPORT / EXPORT SYSTEM
 * =========================================================
 *
 * Planned workbook sheets:
 *
 * - Customers
 * - Details
 * - Addresses
 * - Contacts
 * - Social Media
 * - Permissions
 * - Activity
 * - Ownership
 *
 * Character support requirement:
 *
 * Æ Ø Å
 * æ ø å
 *
 * =========================================================
 */


/*
 * =========================================================
 * IMPORT / EXPORT RULES
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * STANDARD USER IMPORT LIMIT
 * ---------------------------------------------------------
 */

function rud_crm_excel_standard_import_limit() {

    return 1000;
}


/*
 * ---------------------------------------------------------
 * STANDARD USER EXPORT LIMIT
 * ---------------------------------------------------------
 */

function rud_crm_excel_standard_export_limit() {

    return 5000;
}


/*
 * ---------------------------------------------------------
 * DEMO USER LIMIT
 * ---------------------------------------------------------
 *
 * Demo users may only work with their own
 * maximum 10 real customers.
 *
 * ---------------------------------------------------------
 */

function rud_crm_excel_demo_customer_limit() {

    if (
        function_exists(
            'rud_crm_trial_customer_limit'
        )
    ) {

        return
            rud_crm_trial_customer_limit();
    }


    return 10;
}


/*
 * =========================================================
 * USER ACCESS LEVEL
 * =========================================================
 */

function rud_crm_excel_access_level(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return 'none';
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return 'none';
    }


    $roles =
        (array)
        $user->roles;


    /*
     * Administrator:
     *
     * Unlimited import/export.
     */

    if (
        in_array(
            'administrator',
            $roles,
            true
        )
    ) {

        return 'unlimited';
    }


    /*
     * CRM Manager:
     *
     * Unlimited import/export.
     */

    if (
        in_array(
            'rud_crm_manager',
            $roles,
            true
        )
    ) {

        return 'unlimited';
    }


    /*
     * Demo account.
     */

    if (
        in_array(
            'rud_crm_demo',
            $roles,
            true
        )
    ) {

        return 'demo';
    }


    /*
     * Other CRM users.
     */

    if (
        current_user_can(
            'rud_crm_view'
        )
    ) {

        return 'standard';
    }


    return 'none';
}


/*
 * =========================================================
 * IMPORT LIMIT FOR CURRENT USER
 * =========================================================
 *
 * NULL means unlimited.
 *
 * =========================================================
 */

function rud_crm_excel_import_limit(
    $user_id = 0
) {

    $level =
        rud_crm_excel_access_level(
            $user_id
        );


    if (
        'unlimited' ===
        $level
    ) {

        return null;
    }


    if (
        'demo' ===
        $level
    ) {

        return
            rud_crm_excel_demo_customer_limit();
    }


    if (
        'standard' ===
        $level
    ) {

        return
            rud_crm_excel_standard_import_limit();
    }


    return 0;
}


/*
 * =========================================================
 * EXPORT LIMIT FOR CURRENT USER
 * =========================================================
 *
 * NULL means unlimited.
 *
 * =========================================================
 */

function rud_crm_excel_export_limit(
    $user_id = 0
) {

    $level =
        rud_crm_excel_access_level(
            $user_id
        );


    if (
        'unlimited' ===
        $level
    ) {

        return null;
    }


    if (
        'demo' ===
        $level
    ) {

        return
            rud_crm_excel_demo_customer_limit();
    }


    if (
        'standard' ===
        $level
    ) {

        return
            rud_crm_excel_standard_export_limit();
    }


    return 0;
}


/*
 * =========================================================
 * PHPSPREADSHEET DETECTION
 * =========================================================
 */

function rud_crm_excel_library_loaded() {

    return
        class_exists(
            '\PhpOffice\PhpSpreadsheet\Spreadsheet'
        )
        &&
        class_exists(
            '\PhpOffice\PhpSpreadsheet\IOFactory'
        );
}


/*
 * =========================================================
 * POSSIBLE COMPOSER AUTOLOAD LOCATIONS
 * =========================================================
 */

function rud_crm_excel_load_library() {

    /*
     * Already loaded.
     */

    if (
        rud_crm_excel_library_loaded()
    ) {

        return true;
    }


    $possible_files =
        array(

            RUD_CRM_PLUGIN_DIR .
            'vendor/autoload.php',

            RUD_CRM_PLUGIN_DIR .
            'includes/vendor/autoload.php'
        );


    foreach (
        $possible_files as
        $autoload_file
    ) {

        if (
            file_exists(
                $autoload_file
            )
        ) {

            require_once
                $autoload_file;


            if (
                rud_crm_excel_library_loaded()
            ) {

                return true;
            }
        }
    }


    return false;
}


/*
 * Try to load library.
 */

rud_crm_excel_load_library();


/*
 * =========================================================
 * REQUIRED WORKBOOK SHEETS
 * =========================================================
 */

function rud_crm_excel_sheet_definitions() {

    return array(

        'Customers' =>
            'Main customer information',

        'Details' =>
            'Customer details and notes',

        'Addresses' =>
            'Private, business, billing and delivery addresses',

        'Contacts' =>
            'Email, telephone and WhatsApp',

        'Social Media' =>
            'Social media accounts',

        'Permissions' =>
            'Customer consent and permissions',

        'Activity' =>
            'Customer timeline and activity history',

        'Ownership' =>
            'CRM customer ownership information'
    );
}


/*
 * =========================================================
 * UNICODE / NORWEGIAN CHARACTER TEST
 * =========================================================
 */

function rud_crm_excel_unicode_test_text() {

    return
        'ÆØÅ æøå – Bjørn Ødegård – Åse Håland – Ægir AS';
}


/*
 * =========================================================
 * FORMAT LIMIT
 * =========================================================
 */

function rud_crm_excel_format_limit(
    $limit
) {

    if (
        null ===
        $limit
    ) {

        return 'Unlimited';
    }


    return
        number_format_i18n(
            absint(
                $limit
            )
        );
}


/*
 * =========================================================
 * ADMIN PAGE
 * =========================================================
 */

function rud_crm_import_export_admin_page() {

    if (
        ! current_user_can(
            'manage_options'
        )
        &&
        ! current_user_can(
            'rud_crm_view'
        )
    ) {

        wp_die(
            esc_html__(
                'You are not allowed to access CRM Import / Export.',
                'rud-crm-server'
            )
        );
    }


    $access_level =
        rud_crm_excel_access_level();


    $import_limit =
        rud_crm_excel_import_limit();


    $export_limit =
        rud_crm_excel_export_limit();


    $library_ready =
        rud_crm_excel_load_library();


    ?>

    <div class="wrap">

        <h1>
            RUD CRM Excel Import / Export
        </h1>


        <p>
            Import and export complete CRM customer data using
            Microsoft Excel .xlsx workbooks.
        </p>


        <hr>


        <h2>
            System Status
        </h2>


        <table class="widefat striped"
               style="max-width:900px;">

            <tbody>


            <tr>

                <td style="width:280px;">
                    <strong>
                        Access Level
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        ucfirst(
                            $access_level
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Import Limit
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_format_limit(
                            $import_limit
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Export Limit
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_format_limit(
                            $export_limit
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Excel Library
                    </strong>
                </td>

                <td>

                    <?php

                    if (
                        $library_ready
                    ) {

                        ?>

                        <span style="color:green;font-weight:bold;">
                            READY
                        </span>

                        <?php

                    } else {

                        ?>

                        <span style="color:#b32d2e;font-weight:bold;">
                            NOT INSTALLED
                        </span>

                        <?php
                    }

                    ?>

                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Excel Format
                    </strong>
                </td>

                <td>
                    .xlsx
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Norwegian Character Test
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_unicode_test_text()
                    );
                    ?>
                </td>

            </tr>


            </tbody>

        </table>


        <br>


        <h2>
            Excel Workbook Structure
        </h2>


        <table class="widefat striped"
               style="max-width:900px;">

            <thead>

            <tr>

                <th>
                    Sheet
                </th>

                <th>
                    Content
                </th>

            </tr>

            </thead>

            <tbody>

            <?php

            foreach (
                rud_crm_excel_sheet_definitions()
                as
                $sheet =>
                $description
            ) {

                ?>

                <tr>

                    <td>
                        <strong>
                            <?php
                            echo esc_html(
                                $sheet
                            );
                            ?>
                        </strong>
                    </td>

                    <td>
                        <?php
                        echo esc_html(
                            $description
                        );
                        ?>
                    </td>

                </tr>

                <?php
            }

            ?>

            </tbody>

        </table>


        <br>


        <h2>
            Export Customers
        </h2>


        <?php

        if (
            ! $library_ready
        ) {

            ?>

            <div class="notice notice-warning inline">

                <p>
                    Excel support is not installed yet.
                    The next step will install/connect the
                    PhpSpreadsheet library.
                </p>

            </div>

            <?php

        } else {

            ?>

            <p>
                Excel library is ready.
            </p>

            <?php
        }

        ?>


        <button
            type="button"
            class="button button-primary"
            disabled
        >
            Export Customers to .xlsx
        </button>


        <br><br>


        <h2>
            Import Customers
        </h2>


        <input
            type="file"
            accept=".xlsx"
            disabled
        >


        <button
            type="button"
            class="button"
            disabled
        >
            Preview Import
        </button>


        <p class="description">
            Import will be activated after the Excel library
            and validation system are connected.
        </p>


    </div>

    <?php
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_import_export_admin_menu() {

    add_submenu_page(

        'rud-crm',

        'Import / Export',

        'Import / Export',

        'read',

        'rud-crm-import-export',

        'rud_crm_import_export_admin_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_import_export_admin_menu',
    40
);