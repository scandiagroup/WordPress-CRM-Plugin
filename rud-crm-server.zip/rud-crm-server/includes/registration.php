<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * PUBLIC CRM ACCOUNT REGISTRATION
 * =========================================================
 *
 * Shortcode:
 *
 * [rud_crm_register]
 *
 * GLOBAL LOGIN RULE:
 *
 * EMAIL ADDRESS = USERNAME / LOGIN
 *
 * Registration flow:
 *
 * 1. Complete form
 * 2. Pass CAPTCHA
 * 3. Create CRM Demo / Client account
 * 4. Send verification email
 * 5. User verifies email
 * 6. Redirect to CRM Account / Login page
 *
 * =========================================================
 */


/*
 * =========================================================
 * REGISTRATION ROLE
 * =========================================================
 */

function rud_crm_registration_role() {

    /*
     * Keep the existing demo role during migration.
     *
     * Later Demo / Paid / Expired should become
     * account-plan status rather than the permanent role.
     */

    return 'rud_crm_demo';
}


/*
 * =========================================================
 * REGISTRATION ENABLED
 * =========================================================
 */

function rud_crm_public_registration_enabled() {

    return true;
}


/*
 * =========================================================
 * MINIMUM PASSWORD LENGTH
 * =========================================================
 */

function rud_crm_registration_min_password_length() {

    return 8;
}


/*
 * =========================================================
 * CURRENT URL
 * =========================================================
 */

function rud_crm_registration_current_url() {

    $scheme =
        is_ssl()
        ? 'https://'
        : 'http://';


    $host =
        isset( $_SERVER['HTTP_HOST'] )
        ? sanitize_text_field(
            wp_unslash(
                $_SERVER['HTTP_HOST']
            )
        )
        : '';


    $uri =
        isset( $_SERVER['REQUEST_URI'] )
        ? wp_unslash(
            $_SERVER['REQUEST_URI']
        )
        : '/';


    $url =
        $scheme .
        $host .
        $uri;


    return esc_url_raw(
        remove_query_arg(
            array(
                'rud_crm_registered',
                'rud_crm_registration',
                'rud_crm_email_verification'
            ),
            $url
        )
    );
}


/*
 * =========================================================
 * ACCOUNT / LOGIN PAGE URL
 * =========================================================
 */

function rud_crm_registration_account_url() {

    if (
        function_exists(
            'rud_crm_account_page_url'
        )
    ) {

        return rud_crm_account_page_url();
    }


    return home_url(
        '/crm-account/'
    );
}


/*
 * =========================================================
 * ERROR STORAGE
 * =========================================================
 */

function rud_crm_registration_errors() {

    static $errors = null;


    if (
        null ===
        $errors
    ) {

        $errors =
            new WP_Error();
    }


    return $errors;
}


function rud_crm_registration_add_error(
    $code,
    $message
) {

    rud_crm_registration_errors()
        ->add(
            $code,
            $message
        );
}


/*
 * =========================================================
 * POST VALUE
 * =========================================================
 */

function rud_crm_registration_post_value(
    $key
) {

    if (
        ! isset(
            $_POST[ $key ]
        )
    ) {

        return '';
    }


    return sanitize_text_field(
        wp_unslash(
            $_POST[ $key ]
        )
    );
}


/*
 * =========================================================
 * CLIENT IP
 * =========================================================
 */

function rud_crm_registration_remote_ip() {

    if (
        ! empty(
            $_SERVER['HTTP_CF_CONNECTING_IP']
        )
    ) {

        return sanitize_text_field(
            wp_unslash(
                $_SERVER['HTTP_CF_CONNECTING_IP']
            )
        );
    }


    if (
        ! empty(
            $_SERVER['REMOTE_ADDR']
        )
    ) {

        return sanitize_text_field(
            wp_unslash(
                $_SERVER['REMOTE_ADDR']
            )
        );
    }


    return '';
}


/*
 * =========================================================
 * CAPTCHA PROVIDER
 * =========================================================
 */

function rud_crm_registration_captcha_provider() {

    if (
        function_exists(
            'rud_crm_security_provider'
        )
    ) {

        return rud_crm_security_provider();
    }


    return 'disabled';
}


/*
 * =========================================================
 * CAPTCHA CONFIGURED
 * =========================================================
 */

function rud_crm_registration_captcha_configured() {

    $provider =
        rud_crm_registration_captcha_provider();


    if (
        'disabled' ===
        $provider
    ) {

        return true;
    }


    if (
        function_exists(
            'rud_crm_security_provider_configured'
        )
    ) {

        return
            rud_crm_security_provider_configured(
                $provider
            );
    }


    return false;
}


/*
 * =========================================================
 * CLOUDFLARE TURNSTILE VALIDATION
 * =========================================================
 */

function rud_crm_registration_validate_turnstile() {

    if (
        ! function_exists(
            'rud_crm_turnstile_secret_key'
        )
    ) {

        return new WP_Error(
            'turnstile_missing',
            'Cloudflare Turnstile is not configured.'
        );
    }


    $secret =
        rud_crm_turnstile_secret_key();


    $token =
        isset(
            $_POST['cf-turnstile-response']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['cf-turnstile-response']
            )
        )
        : '';


    if (
        '' === $secret
        ||
        '' === $token
    ) {

        return new WP_Error(
            'turnstile_required',
            'Please complete the Cloudflare security check.'
        );
    }


    $body =
        array(

            'secret' =>
                $secret,

            'response' =>
                $token
        );


    $remote_ip =
        rud_crm_registration_remote_ip();


    if (
        $remote_ip
    ) {

        $body['remoteip'] =
            $remote_ip;
    }


    $response =
        wp_remote_post(
            'https://challenges.cloudflare.com/turnstile/v0/siteverify',
            array(

                'timeout' =>
                    15,

                'body' =>
                    $body
            )
        );


    if (
        is_wp_error(
            $response
        )
    ) {

        return new WP_Error(
            'turnstile_connection',
            'The Cloudflare security check could not be verified. Please try again.'
        );
    }


    $status_code =
        wp_remote_retrieve_response_code(
            $response
        );


    $data =
        json_decode(
            wp_remote_retrieve_body(
                $response
            ),
            true
        );


    if (
        200 !==
        absint(
            $status_code
        )
        ||
        ! is_array(
            $data
        )
        ||
        empty(
            $data['success']
        )
    ) {

        return new WP_Error(
            'turnstile_failed',
            'Cloudflare verification failed. Please complete the security check again.'
        );
    }


    return true;
}


/*
 * =========================================================
 * GOOGLE RECAPTCHA VALIDATION
 * =========================================================
 */

function rud_crm_registration_validate_recaptcha() {

    if (
        ! function_exists(
            'rud_crm_recaptcha_secret_key'
        )
    ) {

        return new WP_Error(
            'recaptcha_missing',
            'Google reCAPTCHA is not configured.'
        );
    }


    $secret =
        rud_crm_recaptcha_secret_key();


    $token =
        isset(
            $_POST['g-recaptcha-response']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['g-recaptcha-response']
            )
        )
        : '';


    if (
        '' === $secret
        ||
        '' === $token
    ) {

        return new WP_Error(
            'recaptcha_required',
            'Please complete the Google reCAPTCHA security check.'
        );
    }


    $body =
        array(

            'secret' =>
                $secret,

            'response' =>
                $token
        );


    $remote_ip =
        rud_crm_registration_remote_ip();


    if (
        $remote_ip
    ) {

        $body['remoteip'] =
            $remote_ip;
    }


    $response =
        wp_remote_post(
            'https://www.google.com/recaptcha/api/siteverify',
            array(

                'timeout' =>
                    15,

                'body' =>
                    $body
            )
        );


    if (
        is_wp_error(
            $response
        )
    ) {

        return new WP_Error(
            'recaptcha_connection',
            'Google reCAPTCHA could not be verified. Please try again.'
        );
    }


    $status_code =
        wp_remote_retrieve_response_code(
            $response
        );


    $data =
        json_decode(
            wp_remote_retrieve_body(
                $response
            ),
            true
        );


    if (
        200 !==
        absint(
            $status_code
        )
        ||
        ! is_array(
            $data
        )
        ||
        empty(
            $data['success']
        )
    ) {

        return new WP_Error(
            'recaptcha_failed',
            'Google reCAPTCHA verification failed. Please complete the security check again.'
        );
    }


    return true;
}


/*
 * =========================================================
 * VALIDATE ACTIVE CAPTCHA
 * =========================================================
 */

function rud_crm_registration_validate_captcha() {

    $provider =
        rud_crm_registration_captcha_provider();


    /*
     * Disabled is intentionally supported for
     * administration/testing.
     */

    if (
        'disabled' ===
        $provider
    ) {

        return true;
    }


    /*
     * Fail closed if selected but not configured.
     */

    if (
        ! rud_crm_registration_captcha_configured()
    ) {

        return new WP_Error(
            'captcha_not_configured',
            'CRM registration security is not configured correctly. Please contact the administrator.'
        );
    }


    if (
        'turnstile' ===
        $provider
    ) {

        return
            rud_crm_registration_validate_turnstile();
    }


    if (
        'recaptcha' ===
        $provider
    ) {

        return
            rud_crm_registration_validate_recaptcha();
    }


    return new WP_Error(
        'captcha_invalid_provider',
        'CRM registration security is not configured correctly.'
    );
}


/*
 * =========================================================
 * PROCESS REGISTRATION
 * =========================================================
 */

function rud_crm_process_public_registration() {

    if (
        ! isset(
            $_POST['rud_crm_registration_action']
        )
    ) {

        return;
    }


    if (
        'register' !==
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_registration_action']
            )
        )
    ) {

        return;
    }


    if (
        ! rud_crm_public_registration_enabled()
    ) {

        rud_crm_registration_add_error(
            'registration_disabled',
            'CRM account registration is currently closed.'
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * NONCE
     * -----------------------------------------------------
     */

    if (
        ! isset(
            $_POST['rud_crm_registration_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_registration_nonce']
                )
            ),
            'rud_crm_public_registration'
        )
    ) {

        rud_crm_registration_add_error(
            'security',
            'Security verification failed. Please reload the page and try again.'
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * HONEYPOT
     * -----------------------------------------------------
     */

    if (
        ! empty(
            $_POST['rud_crm_website']
        )
    ) {

        rud_crm_registration_add_error(
            'spam',
            'Registration could not be completed.'
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * CAPTCHA
     * -----------------------------------------------------
     */

    $captcha_result =
        rud_crm_registration_validate_captcha();


    if (
        is_wp_error(
            $captcha_result
        )
    ) {

        rud_crm_registration_add_error(
            $captcha_result->get_error_code(),
            $captcha_result->get_error_message()
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * FORM VALUES
     * -----------------------------------------------------
     */

    $first_name =
        rud_crm_registration_post_value(
            'rud_crm_first_name'
        );


    $last_name =
        rud_crm_registration_post_value(
            'rud_crm_last_name'
        );


    $company =
        rud_crm_registration_post_value(
            'rud_crm_company'
        );


$phone =
    rud_crm_registration_post_value(
        'rud_crm_phone'
    );


if (
    function_exists(
        'rud_crm_sanitize_phone_number'
    )
) {

    $phone =
        rud_crm_sanitize_phone_number(
            $phone
        );
}


    $email =
        isset(
            $_POST['rud_crm_email']
        )
        ? sanitize_email(
            wp_unslash(
                $_POST['rud_crm_email']
            )
        )
        : '';


    $password =
        isset(
            $_POST['rud_crm_password']
        )
        ? (string)
        wp_unslash(
            $_POST['rud_crm_password']
        )
        : '';


    $password_confirm =
        isset(
            $_POST['rud_crm_password_confirm']
        )
        ? (string)
        wp_unslash(
            $_POST['rud_crm_password_confirm']
        )
        : '';


    $terms_accepted =
        ! empty(
            $_POST['rud_crm_terms']
        );


    /*
     * -----------------------------------------------------
     * VALIDATION
     * -----------------------------------------------------
     */

    if (
        '' ===
        $first_name
    ) {

        rud_crm_registration_add_error(
            'first_name',
            'Please enter your first name.'
        );
    }


    if (
        '' ===
        $last_name
    ) {

        rud_crm_registration_add_error(
            'last_name',
            'Please enter your last name.'
        );
    }


    if (
        ! is_email(
            $email
        )
    ) {

        rud_crm_registration_add_error(
            'email',
            'Please enter a valid email address.'
        );
    }


    if (
        $email
        &&
        email_exists(
            $email
        )
    ) {

        rud_crm_registration_add_error(
            'email_exists',
            'An account already exists with this email address.'
        );
    }


    /*
     * -----------------------------------------------------
     * EMAIL = USERNAME
     * -----------------------------------------------------
     */

    if (
        function_exists(
            'rud_crm_username_from_email'
        )
    ) {

        $username =
            rud_crm_username_from_email(
                $email
            );

    } else {

        $username =
            strtolower(
                trim(
                    $email
                )
            );
    }


    if (
        '' ===
        $username
    ) {

        rud_crm_registration_add_error(
            'username_invalid',
            'Your email address could not be used as a CRM username.'
        );
    }


    if (
        $username
        &&
        username_exists(
            $username
        )
    ) {

        rud_crm_registration_add_error(
            'username_exists',
            'An account already exists with this email address.'
        );
    }


    if (
        strlen(
            $password
        )
        <
        rud_crm_registration_min_password_length()
    ) {

        rud_crm_registration_add_error(
            'password_length',
            sprintf(
                'Password must contain at least %d characters.',
                rud_crm_registration_min_password_length()
            )
        );
    }


    if (
        $password !==
        $password_confirm
    ) {

        rud_crm_registration_add_error(
            'password_match',
            'The two passwords do not match.'
        );
    }


    if (
        ! $terms_accepted
    ) {

        rud_crm_registration_add_error(
            'terms',
            'You must accept the Terms and Privacy Policy.'
        );
    }


    $errors =
        rud_crm_registration_errors();


    if (
        $errors->has_errors()
    ) {

        return;
    }


    /*
     * -----------------------------------------------------
     * CRM ROLE
     * -----------------------------------------------------
     */

    $role =
        rud_crm_registration_role();


    if (
        ! get_role(
            $role
        )
    ) {

        rud_crm_registration_add_error(
            'role_missing',
            'CRM Demo User role is not available. Please contact the administrator.'
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * CREATE USER
     * -----------------------------------------------------
     */

    $display_name =
        trim(
            $first_name .
            ' ' .
            $last_name
        );


    $user_id =
        wp_insert_user(
            array(

                'user_login' =>
                    $username,

                'user_email' =>
                    $email,

                'user_pass' =>
                    $password,

                'first_name' =>
                    $first_name,

                'last_name' =>
                    $last_name,

                'display_name' =>
                    $display_name,

                'role' =>
                    $role
            )
        );


    if (
        is_wp_error(
            $user_id
        )
    ) {

        rud_crm_registration_add_error(
            'user_creation',
            $user_id->get_error_message()
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * CRM ACCOUNT INFORMATION
     * -----------------------------------------------------
     */

    update_user_meta(
        $user_id,
        'rud_crm_company',
        $company
    );


/*
 * -----------------------------------------------------
 * PHONE INFORMATION
 * -----------------------------------------------------
 */

update_user_meta(
    $user_id,
    'rud_crm_phone',
    $phone
);


$phone_country =
    isset(
        $_POST['rud_crm_phone_country']
    )
    ? strtoupper(
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_phone_country']
            )
        )
    )
    : '';


$phone_dial_code =
    isset(
        $_POST['rud_crm_phone_dial_code']
    )
    ? sanitize_text_field(
        wp_unslash(
            $_POST['rud_crm_phone_dial_code']
        )
    )
    : '';


update_user_meta(
    $user_id,
    'rud_crm_phone_country',
    $phone_country
);


update_user_meta(
    $user_id,
    'rud_crm_phone_dial_code',
    $phone_dial_code
);


/*
 * Store a dedicated full international number as well.
 */

update_user_meta(
    $user_id,
    'rud_crm_phone_full',
    $phone
);


    update_user_meta(
        $user_id,
        'rud_crm_registration_source',
        'public_registration'
    );


    update_user_meta(
        $user_id,
        'rud_crm_terms_accepted',
        '1'
    );


    update_user_meta(
        $user_id,
        'rud_crm_terms_accepted_at',
        current_time(
            'mysql'
        )
    );


    /*
     * -----------------------------------------------------
     * OTHER CRM MODULES
     * -----------------------------------------------------
     *
     * This currently triggers:
     *
     * - CRM Client number assignment
     * - Email verification
     * - Existing trial initialization hooks
     *
     * -----------------------------------------------------
     */

    do_action(
        'rud_crm_public_user_registered',
        $user_id
    );


    /*
     * -----------------------------------------------------
     * DO NOT AUTO-LOGIN BEFORE EMAIL VERIFICATION
     * -----------------------------------------------------
     *
     * The previous registration system automatically
     * logged the user in here.
     *
     * That behavior is intentionally removed.
     *
     * -----------------------------------------------------
     */


    /*
     * -----------------------------------------------------
     * REDIRECT TO LOGIN / ACCOUNT PAGE
     * -----------------------------------------------------
     */

    $redirect_url =
        add_query_arg(
            'rud_crm_registration',
            'check_email',
            rud_crm_registration_account_url()
        );


    wp_safe_redirect(
        $redirect_url
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_process_public_registration',
    5
);


/*
 * =========================================================
 * LOAD CAPTCHA JAVASCRIPT
 * =========================================================
 */

function rud_crm_registration_enqueue_security_scripts() {

    if (
        ! is_singular()
    ) {
        return;
    }


    global $post;


    if (
        ! $post
        ||
        ! has_shortcode(
            $post->post_content,
            'rud_crm_register'
        )
    ) {
        return;
    }


    $provider =
        rud_crm_registration_captcha_provider();


    if (
        'turnstile' ===
        $provider
        &&
        rud_crm_registration_captcha_configured()
    ) {

        wp_enqueue_script(
            'rud-crm-turnstile',
            'https://challenges.cloudflare.com/turnstile/v0/api.js',
            array(),
            null,
            true
        );
    }


    if (
        'recaptcha' ===
        $provider
        &&
        rud_crm_registration_captcha_configured()
    ) {

        wp_enqueue_script(
            'rud-crm-google-recaptcha',
            'https://www.google.com/recaptcha/api.js',
            array(),
            null,
            true
        );
    }
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_registration_enqueue_security_scripts'
);


/*
 * =========================================================
 * CAPTCHA WIDGET
 * =========================================================
 */

function rud_crm_registration_captcha_html() {

    $provider =
        rud_crm_registration_captcha_provider();


    if (
        'disabled' ===
        $provider
    ) {

        return '';
    }


    if (
        ! rud_crm_registration_captcha_configured()
    ) {

        return
            '<div class="rud-crm-registration-security-error">' .
            '<strong>Registration security is not configured.</strong>' .
            '</div>';
    }


    if (
        'turnstile' ===
        $provider
    ) {

        $site_key =
            function_exists(
                'rud_crm_turnstile_site_key'
            )
            ? rud_crm_turnstile_site_key()
            : '';


        return
            '<div class="rud-crm-registration-captcha">' .
            '<div class="cf-turnstile" data-sitekey="' .
            esc_attr(
                $site_key
            ) .
            '"></div>' .
            '</div>';
    }


    if (
        'recaptcha' ===
        $provider
    ) {

        $site_key =
            function_exists(
                'rud_crm_recaptcha_site_key'
            )
            ? rud_crm_recaptcha_site_key()
            : '';


        return
            '<div class="rud-crm-registration-captcha">' .
            '<div class="g-recaptcha" data-sitekey="' .
            esc_attr(
                $site_key
            ) .
            '"></div>' .
            '</div>';
    }


    return '';
}


/*
 * =========================================================
 * REGISTRATION FORM
 * =========================================================
 */

function rud_crm_public_registration_shortcode() {

    /*
     * Already logged in.
     */

    if (
        is_user_logged_in()
    ) {

        return
            '<div class="rud-crm-registration-message">' .
            '<p>You are already logged in.</p>' .
            '<p><a href="' .
            esc_url(
                rud_crm_registration_account_url()
            ) .
            '">Go to My RUD CRM Account</a></p>' .
            '</div>';
    }


    if (
        ! rud_crm_public_registration_enabled()
    ) {

        return
            '<div class="rud-crm-registration-message">' .
            '<p>CRM account registration is currently closed.</p>' .
            '</div>';
    }


    $errors =
        rud_crm_registration_errors();


    $first_name =
        rud_crm_registration_post_value(
            'rud_crm_first_name'
        );


    $last_name =
        rud_crm_registration_post_value(
            'rud_crm_last_name'
        );


    $company =
        rud_crm_registration_post_value(
            'rud_crm_company'
        );


    $phone =
        rud_crm_registration_post_value(
            'rud_crm_phone'
        );


    $email =
        isset(
            $_POST['rud_crm_email']
        )
        ? sanitize_email(
            wp_unslash(
                $_POST['rud_crm_email']
            )
        )
        : '';


    ob_start();

    ?>

    <div class="rud-crm-registration-wrap">


        <style>

            .rud-crm-registration-wrap {
                width: 100%;
                max-width: 700px;
                margin: 0 auto;
            }

            .rud-crm-registration-form {
                width: 100%;
            }

            .rud-crm-registration-row {
                margin-bottom: 18px;
            }

            .rud-crm-registration-row label {
                display: block;
                font-weight: 600;
                margin-bottom: 6px;
            }

            .rud-crm-registration-row input[type="text"],
            .rud-crm-registration-row input[type="email"],
            .rud-crm-registration-row input[type="tel"],
            .rud-crm-registration-row input[type="password"] {
                width: 100%;
                box-sizing: border-box;
                padding: 12px 14px;
                border: 1px solid #cccccc;
                border-radius: 4px;
                font-size: 16px;
            }

            .rud-crm-registration-name-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 18px;
            }

            .rud-crm-registration-submit {
                width: 100%;
                padding: 14px 20px;
                border: 0;
                border-radius: 4px;
                cursor: pointer;
                font-size: 16px;
                font-weight: 600;
            }

            .rud-crm-registration-errors {
                margin-bottom: 20px;
                padding: 15px 18px;
                border-left: 4px solid #b32d2e;
                background: #fff5f5;
            }

            .rud-crm-registration-errors ul {
                margin: 0;
                padding-left: 20px;
            }

            .rud-crm-registration-description {
                margin-bottom: 24px;
            }

            .rud-crm-registration-terms {
                display: flex !important;
                gap: 8px;
                align-items: flex-start;
            }

            .rud-crm-registration-honeypot {
                position: absolute !important;
                left: -9999px !important;
                width: 1px !important;
                height: 1px !important;
                overflow: hidden !important;
            }

            .rud-crm-registration-captcha {
                margin: 24px 0;
            }

            .rud-crm-registration-security-error {
                margin: 20px 0;
                padding: 14px 16px;
                border-left: 4px solid #b32d2e;
                background: #fff5f5;
            }

            @media
            (
                max-width: 600px
            ) {

                .rud-crm-registration-name-grid {
                    grid-template-columns: 1fr;
                    gap: 0;
                }
            }

        </style>


        <div class="rud-crm-registration-description">

            <h2>
                Register Your CRM Account
            </h2>

            <p>
                Create your RUD CRM demo account and start exploring the CRM.
            </p>

        </div>


        <?php

        if (
            $errors->has_errors()
        ) :

        ?>

            <div class="rud-crm-registration-errors">

                <strong>
                    Please check the following:
                </strong>

                <ul>

                    <?php

                    foreach (
                        $errors->get_error_messages()
                        as
                        $error_message
                    ) :

                    ?>

                        <li>
                            <?php
                            echo esc_html(
                                $error_message
                            );
                            ?>
                        </li>

                    <?php endforeach; ?>

                </ul>

            </div>

        <?php endif; ?>


        <form
            method="post"
            class="rud-crm-registration-form"
            autocomplete="on"
        >


            <?php

            wp_nonce_field(
                'rud_crm_public_registration',
                'rud_crm_registration_nonce'
            );

            ?>


            <input
                type="hidden"
                name="rud_crm_registration_action"
                value="register"
            >


            <div class="rud-crm-registration-honeypot">

                <label>
                    Website

                    <input
                        type="text"
                        name="rud_crm_website"
                        value=""
                        tabindex="-1"
                        autocomplete="off"
                    >

                </label>

            </div>


            <div class="rud-crm-registration-name-grid">


                <div class="rud-crm-registration-row">

                    <label for="rud_crm_first_name">
                        First Name *
                    </label>

                    <input
                        type="text"
                        id="rud_crm_first_name"
                        name="rud_crm_first_name"
                        value="<?php echo esc_attr( $first_name ); ?>"
                        required
                        autocomplete="given-name"
                    >

                </div>


                <div class="rud-crm-registration-row">

                    <label for="rud_crm_last_name">
                        Last Name *
                    </label>

                    <input
                        type="text"
                        id="rud_crm_last_name"
                        name="rud_crm_last_name"
                        value="<?php echo esc_attr( $last_name ); ?>"
                        required
                        autocomplete="family-name"
                    >

                </div>


            </div>


            <div class="rud-crm-registration-row">

                <label for="rud_crm_company">
                    Company
                </label>

                <input
                    type="text"
                    id="rud_crm_company"
                    name="rud_crm_company"
                    value="<?php echo esc_attr( $company ); ?>"
                    autocomplete="organization"
                >

            </div>


            <div class="rud-crm-registration-row">

                <label for="rud_crm_email">
                    Email Address *
                </label>

                <input
                    type="email"
                    id="rud_crm_email"
                    name="rud_crm_email"
                    value="<?php echo esc_attr( $email ); ?>"
                    required
                    autocomplete="email"
                >

                <small>
                    Your email address is also your username and will be used to log in to RUD CRM.
                </small>

            </div>


<div class="rud-crm-registration-row">

    <label for="rud_crm_phone">
        Mobile Phone
    </label>

    <?php

    if (
        function_exists(
            'rud_crm_render_phone_field'
        )
    ) {

        echo wp_kses(
            rud_crm_render_phone_field(
                'rud_crm_phone',
                $phone,
                array(

                    'id' =>
                        'rud_crm_phone',

                    'required' =>
                        false,

                    'country_field' =>
                        'rud_crm_phone_country',

                    'dial_code_field' =>
                        'rud_crm_phone_dial_code',

                    'description' =>
                        'Select your country flag and enter your mobile phone number.'
                )
            ),
            rud_crm_phone_allowed_html()
        );

    } else {

        ?>

        <input
            type="tel"
            id="rud_crm_phone"
            name="rud_crm_phone"
            value="<?php echo esc_attr( $phone ); ?>"
            autocomplete="tel"
        >

        <?php

    }

    ?>

    <input
        type="hidden"
        name="rud_crm_phone_country"
        value=""
    >

    <input
        type="hidden"
        name="rud_crm_phone_dial_code"
        value=""
    >

</div>


            <div class="rud-crm-registration-row">

                <label for="rud_crm_password">
                    Password *
                </label>

                <input
                    type="password"
                    id="rud_crm_password"
                    name="rud_crm_password"
                    required
                    minlength="<?php
                    echo esc_attr(
                        rud_crm_registration_min_password_length()
                    );
                    ?>"
                    autocomplete="new-password"
                >

                <small>
                    Minimum
                    <?php
                    echo esc_html(
                        rud_crm_registration_min_password_length()
                    );
                    ?>
                    characters.
                </small>

            </div>


            <div class="rud-crm-registration-row">

                <label for="rud_crm_password_confirm">
                    Confirm Password *
                </label>

                <input
                    type="password"
                    id="rud_crm_password_confirm"
                    name="rud_crm_password_confirm"
                    required
                    minlength="<?php
                    echo esc_attr(
                        rud_crm_registration_min_password_length()
                    );
                    ?>"
                    autocomplete="new-password"
                >

            </div>


            <div class="rud-crm-registration-row">

                <label class="rud-crm-registration-terms">

                    <input
                        type="checkbox"
                        name="rud_crm_terms"
                        value="1"
                        required
                    >

                    <span>
                        I accept the Terms and Privacy Policy. *
                    </span>

                </label>

            </div>


            <?php

            /*
             * CAPTCHA directly above the submit button.
             */

            echo rud_crm_registration_captcha_html();

            ?>


            <div class="rud-crm-registration-row">

                <button
                    type="submit"
                    class="rud-crm-registration-submit"
                >
                    Create My CRM Account
                </button>

            </div>


        </form>


    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

add_shortcode(
    'rud_crm_register',
    'rud_crm_public_registration_shortcode'
);