<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * CUSTOMER SERVICE AREAS
 * Version 1.0
 * =========================================================
 *
 * Initial framework only.
 *
 * No database changes.
 * No customer data changes.
 * No WHM synchronization.
 *
 * Administrator access:
 *
 * ADMIN-LEVEL-001
 * ADMIN-LEVEL-002
 * ADMIN-LEVEL-003
 *
 * =========================================================
 */


/*
 * =========================================================
 * GET CURRENT ADMIN LEVEL
 * =========================================================
 */

function rud_crm_service_areas_admin_level() {

    $user_id =
        get_current_user_id();


    if (
        ! $user_id
    ) {

        return 0;
    }


    /*
     * Preferred RUD CRM hierarchy system.
     */

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
    ) {

        return absint(
            rud_crm_get_admin_level(
                $user_id
            )
        );
    }


    /*
     * Fallback directly to RUD CRM roles.
     */

    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return 0;
    }


    $roles =
        (array)
        $user->roles;


    if (
        in_array(
            'rud_crm_admin_level_001',
            $roles,
            true
        )
    ) {

        return 1;
    }


    if (
        in_array(
            'rud_crm_admin_level_002',
            $roles,
            true
        )
    ) {

        return 2;
    }


    if (
        in_array(
            'rud_crm_admin_level_003',
            $roles,
            true
        )
    ) {

        return 3;
    }


    return 0;
}


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_service_areas_can_access() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    $level =
        rud_crm_service_areas_admin_level();


    return in_array(
        $level,
        array(
            1,
            2,
            3
        ),
        true
    );
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_service_areas_admin_menu() {

    if (
        ! rud_crm_service_areas_can_access()
    ) {

        return;
    }


    add_submenu_page(
        'rud-crm',
        'Customer Services',
        'Customer Services',
        'read',
        'rud-crm-customer-services',
        'rud_crm_service_areas_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_service_areas_admin_menu',
    40
);


/*
 * =========================================================
 * SERVICE AREA DEFINITIONS
 * =========================================================
 */

function rud_crm_service_area_definitions() {

    return array(

        'status' =>
            array(
                'title' =>
                    'Status',

                'description' =>
                    'Customer relationship and current customer status.'
            ),

        'customer_information' =>
            array(
                'title' =>
                    'Customer Information',

                'description' =>
                    'Private person, company or organization information.'
            ),

        'web_services' =>
            array(
                'title' =>
                    'Web Services',

                'description' =>
                    'Domains, webhotels, subdomains, email, SMS and other web services.'
            ),

        'film_production' =>
            array(
                'title' =>
                    'Film Production',

                'description' =>
                    'Film productions, projects and related production services.'
            ),

        'communication' =>
            array(
                'title' =>
                    'Communication',

                'description' =>
                    'Customer communication, email, SMS and communication history.'
            ),

        'billing' =>
            array(
                'title' =>
                    'Billing',

                'description' =>
                    'Future invoices, recurring services, payments and billing history.'
            ),

        'notes' =>
            array(
                'title' =>
                    'Notes',

                'description' =>
                    'Internal CRM notes and customer-related information.'
            ),

        'history' =>
            array(
                'title' =>
                    'History',

                'description' =>
                    'Permanent chronological history of customer and service changes.'
            )
    );
}


/*
 * =========================================================
 * WEB SERVICE DEFINITIONS
 * =========================================================
 */

function rud_crm_web_service_definitions() {

    return array(

        'domains' =>
            array(
                'title' =>
                    'Domains',

                'description' =>
                    'Registered and historical domains.'
            ),

        'webhotels' =>
            array(
                'title' =>
                    'Webhotel / Hosting',

                'description' =>
                    'WHM and cPanel hosting accounts and webhotel services.'
            ),

        'subdomains' =>
            array(
                'title' =>
                    'Subdomains',

                'description' =>
                    'Active and historical subdomains.'
            ),

        'email' =>
            array(
                'title' =>
                    'Email Services',

                'description' =>
                    'Customer email services and related accounts.'
            ),

        'sms' =>
            array(
                'title' =>
                    'SMS Services',

                'description' =>
                    'Customer SMS services and related accounts.'
            ),

        'other' =>
            array(
                'title' =>
                    'Other Web Services',

                'description' =>
                    'Additional web-related services.'
            )
    );
}


/*
 * =========================================================
 * ADMIN PAGE
 * =========================================================
 */

function rud_crm_service_areas_page() {

    if (
        ! rud_crm_service_areas_can_access()
    ) {

        wp_die(
            esc_html__(
                'You are not allowed to access Customer Services.',
                'rud-crm-server'
            )
        );
    }


    $admin_level =
        rud_crm_service_areas_admin_level();


    $service_areas =
        rud_crm_service_area_definitions();


    $web_services =
        rud_crm_web_service_definitions();

    ?>

    <div class="wrap">

        <h1>
            Customer Services
        </h1>

        <p>
            RUD CRM customer and business service structure.
        </p>

        <p>
            <strong>
                Administrator Access:
            </strong>

            <?php

            echo esc_html(
                sprintf(
                    'ADMIN-LEVEL-%03d',
                    $admin_level
                )
            );

            ?>
        </p>

        <hr>


        <h2>
            Customer Structure
        </h2>


        <div
            style="
                display:grid;
                grid-template-columns:
                    repeat(
                        auto-fit,
                        minmax(260px,1fr)
                    );
                gap:18px;
                max-width:1200px;
                margin-top:20px;
            "
        >

            <?php
            foreach (
                $service_areas
                as
                $key =>
                $area
            ) :
            ?>

                <div
                    style="
                        background:#ffffff;
                        border:1px solid #dcdcde;
                        border-radius:6px;
                        padding:20px;
                        box-shadow:
                            0 1px 2px
                            rgba(0,0,0,0.04);
                    "
                >

                    <h2
                        style="
                            margin-top:0;
                        "
                    >
                        <?php
                        echo esc_html(
                            $area[
                                'title'
                            ]
                        );
                        ?>
                    </h2>


                    <p>
                        <?php
                        echo esc_html(
                            $area[
                                'description'
                            ]
                        );
                        ?>
                    </p>


                    <?php
                    if (
                        'web_services'
                        ===
                        $key
                    ) :
                    ?>

                        <p>
                            <strong>
                                Framework Ready
                            </strong>
                        </p>

                    <?php
                    else :
                    ?>

                        <p
                            style="
                                color:#646970;
                            "
                        >
                            Planned
                        </p>

                    <?php endif; ?>

                </div>

            <?php endforeach; ?>

        </div>


        <hr
            style="
                margin-top:35px;
                margin-bottom:30px;
            "
        >


        <h2>
            Web Services
        </h2>

        <p>
            This will be the first service area we build.
        </p>


        <div
            style="
                display:grid;
                grid-template-columns:
                    repeat(
                        auto-fit,
                        minmax(240px,1fr)
                    );
                gap:16px;
                max-width:1200px;
                margin-top:20px;
            "
        >

            <?php
            foreach (
                $web_services
                as
                $service
            ) :
            ?>

                <div
                    style="
                        background:#f6f7f7;
                        border:1px solid #dcdcde;
                        border-radius:6px;
                        padding:18px;
                    "
                >

                    <h3
                        style="
                            margin-top:0;
                        "
                    >
                        <?php
                        echo esc_html(
                            $service[
                                'title'
                            ]
                        );
                        ?>
                    </h3>

                    <p>
                        <?php
                        echo esc_html(
                            $service[
                                'description'
                            ]
                        );
                        ?>
                    </p>

                    <p
                        style="
                            color:#646970;
                            margin-bottom:0;
                        "
                    >
                        Not activated yet
                    </p>

                </div>

            <?php endforeach; ?>

        </div>


        <hr
            style="
                margin-top:35px;
            "
        >


        <p>
            <strong>
                Current development stage:
            </strong>
            Structure only — no database records are created or changed.
        </p>

    </div>

    <?php
}