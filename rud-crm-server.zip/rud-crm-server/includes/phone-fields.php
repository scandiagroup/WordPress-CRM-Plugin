<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * GLOBAL INTERNATIONAL PHONE SYSTEM
 * =========================================================
 *
 * ONE PHONE SYSTEM FOR THE ENTIRE CRM.
 *
 * Used by:
 *
 * - Public Registration
 * - CRM Client Accounts
 * - Administrator Accounts
 * - Customer Profiles
 * - Mobile Phone
 * - Home Phone
 * - Office Phone
 * - WhatsApp
 * - Contact Persons
 * - Future CRM forms
 *
 * Phone numbers should be stored in international
 * E.164 format whenever possible.
 *
 * Example:
 *
 * Display:
 * 🇳🇴 +47 912 34 567
 *
 * Stored:
 * +4791234567
 *
 * =========================================================
 */


/*
 * =========================================================
 * LIBRARY VERSION
 * =========================================================
 */

function rud_crm_phone_library_version() {

    return '25.12.2';
}


/*
 * =========================================================
 * DETECT DEFAULT COUNTRY
 * =========================================================
 */

function rud_crm_phone_default_country() {

    /*
     * Cloudflare normally provides CF-IPCountry
     * when IP Geolocation is available.
     *
     * Example:
     *
     * NO = Norway
     * SE = Sweden
     * DK = Denmark
     * FI = Finland
     * US = United States
     */

    if (
        ! empty(
            $_SERVER['HTTP_CF_IPCOUNTRY']
        )
    ) {

        $country =
            strtolower(
                sanitize_text_field(
                    wp_unslash(
                        $_SERVER['HTTP_CF_IPCOUNTRY']
                    )
                )
            );


        /*
         * Cloudflare can occasionally return
         * special values such as XX or T1.
         */

        if (
            preg_match(
                '/^[a-z]{2}$/',
                $country
            )
            &&
            ! in_array(
                $country,
                array(
                    'xx',
                    't1'
                ),
                true
            )
        ) {

            return $country;
        }
    }


    /*
     * RUD CRM fallback country.
     */

    return 'no';
}


/*
 * =========================================================
 * SANITIZE PHONE NUMBER
 * =========================================================
 */

function rud_crm_sanitize_phone_number(
    $phone
) {

    $phone =
        trim(
            (string)
            $phone
        );


    if (
        '' ===
        $phone
    ) {

        return '';
    }


    /*
     * Keep:
     *
     * +
     * digits
     *
     * Remove spaces, dashes, brackets, etc.
     */

    $phone =
        preg_replace(
            '/[^\d+]/',
            '',
            $phone
        );


    /*
     * Only allow + at the beginning.
     */

    if (
        false !==
        strpos(
            substr(
                $phone,
                1
            ),
            '+'
        )
    ) {

        $phone =
            substr(
                $phone,
                0,
                1
            )
            .
            str_replace(
                '+',
                '',
                substr(
                    $phone,
                    1
                )
            );
    }


    return sanitize_text_field(
        $phone
    );
}


/*
 * =========================================================
 * REGISTER PHONE ASSETS
 * =========================================================
 */

function rud_crm_register_phone_assets() {

    $version =
        rud_crm_phone_library_version();


    wp_register_style(
        'rud-crm-intl-tel-input',
        'https://cdn.jsdelivr.net/npm/intl-tel-input@' .
        rawurlencode(
            $version
        ) .
        '/build/css/intlTelInput.css',
        array(),
        $version
    );


    wp_register_script(
        'rud-crm-intl-tel-input',
        'https://cdn.jsdelivr.net/npm/intl-tel-input@' .
        rawurlencode(
            $version
        ) .
        '/build/js/intlTelInput.min.js',
        array(),
        $version,
        true
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_register_phone_assets',
    5
);


add_action(
    'admin_enqueue_scripts',
    'rud_crm_register_phone_assets',
    5
);


/*
 * =========================================================
 * ENQUEUE PHONE ASSETS
 * =========================================================
 *
 * This function can safely be called by ANY RUD CRM
 * form or Elementor widget that contains a phone field.
 *
 * =========================================================
 */

function rud_crm_enqueue_phone_assets() {

    static $already_loaded = false;


    if (
        $already_loaded
    ) {

        return;
    }


    $already_loaded = true;


    /*
     * Make sure assets are registered even if called
     * unusually early.
     */

    rud_crm_register_phone_assets();


    wp_enqueue_style(
        'rud-crm-intl-tel-input'
    );


    wp_enqueue_script(
        'rud-crm-intl-tel-input'
    );


    $default_country =
        rud_crm_phone_default_country();


    $version =
        rud_crm_phone_library_version();


    /*
     * =====================================================
     * JAVASCRIPT INITIALIZATION
     * =====================================================
     */

    $script = "

(function() {

    function rudCrmInitPhoneFields(context) {

        if (
            typeof window.intlTelInput ===
            'undefined'
        ) {
            return;
        }


        if (
            ! context
        ) {
            context =
                document;
        }


        var phoneInputs =
            context.querySelectorAll(
                '.rud-crm-phone-field'
            );


        phoneInputs.forEach(
            function(input) {

                if (
                    input.dataset.rudPhoneReady ===
                    '1'
                ) {
                    return;
                }


                input.dataset.rudPhoneReady =
                    '1';


                var iti =
                    window.intlTelInput(
                        input,
                        {

                            initialCountry:
                                '" .
                                esc_js(
                                    $default_country
                                ) .
                                "',

                            separateDialCode:
                                true,

                            nationalMode:
                                false,

                            formatAsYouType:
                                true,

                            formatOnDisplay:
                                true,

                            autoPlaceholder:
                                'polite',

                            countrySearch:
                                true,

                            fixDropdownWidth:
                                false,

                            strictMode:
                                false,

                            loadUtils:
                                function() {

                                    return import(
                                        'https://cdn.jsdelivr.net/npm/intl-tel-input@" .
                                        esc_js(
                                            $version
                                        ) .
                                        "/build/js/utils.js'
                                    );
                                }
                        }
                    );


                /*
                 * Restore an existing international number.
                 *
                 * intl-tel-input will automatically detect
                 * the appropriate country from an E.164
                 * number.
                 */

                if (
                    input.value &&
                    input.value.charAt(0) === '+'
                ) {

                    iti.setNumber(
                        input.value
                    );
                }


                /*
                 * Store instance on the actual input.
                 */

                input.rudIntlTelInput =
                    iti;


                /*
                 * Update hidden country field whenever
                 * the selected country changes.
                 */

                var countryFieldName =
                    input.dataset.countryField;


                var dialCodeFieldName =
                    input.dataset.dialCodeField;


                function updateCountryData() {

                    var data =
                        iti.getSelectedCountryData();


                    if (
                        countryFieldName
                    ) {

                        var countryField =
                            input.form
                            ?
                            input.form.querySelector(
                                '[name=\"' +
                                countryFieldName +
                                '\"]'
                            )
                            :
                            null;


                        if (
                            countryField
                        ) {

                            countryField.value =
                                data.iso2
                                ?
                                data.iso2.toUpperCase()
                                :
                                '';
                        }
                    }


                    if (
                        dialCodeFieldName
                    ) {

                        var dialCodeField =
                            input.form
                            ?
                            input.form.querySelector(
                                '[name=\"' +
                                dialCodeFieldName +
                                '\"]'
                            )
                            :
                            null;


                        if (
                            dialCodeField
                        ) {

                            dialCodeField.value =
                                data.dialCode
                                ?
                                '+' +
                                data.dialCode
                                :
                                '';
                        }
                    }
                }


                input.addEventListener(
                    'countrychange',
                    updateCountryData
                );


                updateCountryData();

            }
        );
    }


    /*
     * Convert phone fields to complete international
     * numbers immediately before form submission.
     */

    function rudCrmPreparePhoneForm(form) {

        var fields =
            form.querySelectorAll(
                '.rud-crm-phone-field'
            );


        fields.forEach(
            function(field) {

                if (
                    ! field.rudIntlTelInput
                ) {
                    return;
                }


                if (
                    ! field.value.trim()
                ) {
                    return;
                }


                var number =
                    field
                        .rudIntlTelInput
                        .getNumber();


                if (
                    number
                ) {

                    field.value =
                        number;
                }


                var data =
                    field
                        .rudIntlTelInput
                        .getSelectedCountryData();


                var countryFieldName =
                    field.dataset.countryField;


                var dialCodeFieldName =
                    field.dataset.dialCodeField;


                if (
                    countryFieldName
                ) {

                    var countryField =
                        form.querySelector(
                            '[name=\"' +
                            countryFieldName +
                            '\"]'
                        );


                    if (
                        countryField
                    ) {

                        countryField.value =
                            data.iso2
                            ?
                            data.iso2.toUpperCase()
                            :
                            '';
                    }
                }


                if (
                    dialCodeFieldName
                ) {

                    var dialField =
                        form.querySelector(
                            '[name=\"' +
                            dialCodeFieldName +
                            '\"]'
                        );


                    if (
                        dialField
                    ) {

                        dialField.value =
                            data.dialCode
                            ?
                            '+' +
                            data.dialCode
                            :
                            '';
                    }
                }
            }
        );
    }


    document.addEventListener(
        'DOMContentLoaded',
        function() {

            rudCrmInitPhoneFields(
                document
            );


            document.addEventListener(
                'submit',
                function(event) {

                    if (
                        event.target &&
                        event.target.tagName ===
                        'FORM'
                    ) {

                        rudCrmPreparePhoneForm(
                            event.target
                        );
                    }
                },
                true
            );
        }
    );


    /*
     * Public API for Elementor / dynamic CRM forms.
     */

    window.rudCrmInitPhoneFields =
        rudCrmInitPhoneFields;

})();
";


    wp_add_inline_script(
        'rud-crm-intl-tel-input',
        $script,
        'after'
    );


    /*
     * =====================================================
     * GLOBAL PHONE FIELD CSS
     * =====================================================
     */

    $css = "

        .rud-crm-phone-wrap {
            width: 100%;
        }


        .rud-crm-phone-field {
            width: 100%;
            box-sizing: border-box;
        }


        .iti {
            width: 100%;
        }


        .iti input {
            width: 100%;
            box-sizing: border-box;
        }


        .iti__country-container {
            z-index: 10;
        }


        .iti__dropdown-content {
            z-index: 100000;
        }


        .rud-crm-phone-description {
            display: block;
            margin-top: 6px;
            opacity: .75;
        }


        .rud-crm-admin-phone-field {
            max-width: 500px;
        }

    ";


    wp_add_inline_style(
        'rud-crm-intl-tel-input',
        $css
    );
}


/*
 * =========================================================
 * AUTOMATIC ADMIN LOADING
 * =========================================================
 */

function rud_crm_load_admin_phone_field_assets() {

    if (
        empty(
            $_GET['page']
        )
    ) {

        return;
    }


    $page =
        sanitize_key(
            wp_unslash(
                $_GET['page']
            )
        );


    if (
        0 !==
        strpos(
            $page,
            'rud-crm'
        )
    ) {

        return;
    }


    rud_crm_enqueue_phone_assets();
}


add_action(
    'admin_enqueue_scripts',
    'rud_crm_load_admin_phone_field_assets',
    20
);


/*
 * =========================================================
 * AUTOMATIC PUBLIC CRM LOADING
 * =========================================================
 *
 * Loads on known public RUD CRM shortcode pages.
 *
 * Individual CRM widgets/forms can also call:
 *
 * rud_crm_enqueue_phone_assets();
 *
 * =========================================================
 */

function rud_crm_load_public_phone_field_assets() {

    if (
        ! is_singular()
    ) {

        return;
    }


    global $post;


    if (
        ! $post
        ||
        empty(
            $post->post_content
        )
    ) {

        return;
    }


    $shortcodes =
        array(
            'rud_crm_register',
            'rud_crm_account',
            'rud_crm_frontend'
        );


    foreach (
        $shortcodes
        as
        $shortcode
    ) {

        if (
            has_shortcode(
                $post->post_content,
                $shortcode
            )
        ) {

            rud_crm_enqueue_phone_assets();

            return;
        }
    }
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_load_public_phone_field_assets',
    20
);


/*
 * =========================================================
 * GENERIC SMART PHONE FIELD
 * =========================================================
 *
 * This is the MASTER reusable field.
 *
 * Example:
 *
 * echo rud_crm_render_phone_field(
 *     'rud_crm_phone',
 *     '+4791234567',
 *     array(
 *         'id'       => 'rud_crm_phone',
 *         'required' => false
 *     )
 * );
 *
 * =========================================================
 */

function rud_crm_render_phone_field(
    $name,
    $value = '',
    $args = array()
) {

    rud_crm_enqueue_phone_assets();


    $defaults =
        array(

            'id' =>
                $name,

            'class' =>
                '',

            'required' =>
                false,

            'autocomplete' =>
                'tel',

            'placeholder' =>
                '',

            'country_field' =>
                '',

            'dial_code_field' =>
                '',

            'description' =>
                'Select the country flag or enter the international phone number.'
        );


    $args =
        wp_parse_args(
            $args,
            $defaults
        );


    $classes =
        trim(
            'rud-crm-phone-field ' .
            $args['class']
        );


    $html =
        '<div class="rud-crm-phone-wrap">';


    $html .=
        '<input' .
        ' type="tel"' .
        ' name="' .
        esc_attr(
            $name
        ) .
        '"' .
        ' id="' .
        esc_attr(
            $args['id']
        ) .
        '"' .
        ' value="' .
        esc_attr(
            $value
        ) .
        '"' .
        ' class="' .
        esc_attr(
            $classes
        ) .
        '"' .
        ' autocomplete="' .
        esc_attr(
            $args['autocomplete']
        ) .
        '"';


    if (
        $args['placeholder']
    ) {

        $html .=
            ' placeholder="' .
            esc_attr(
                $args['placeholder']
            ) .
            '"';
    }


    if (
        $args['country_field']
    ) {

        $html .=
            ' data-country-field="' .
            esc_attr(
                $args['country_field']
            ) .
            '"';
    }


    if (
        $args['dial_code_field']
    ) {

        $html .=
            ' data-dial-code-field="' .
            esc_attr(
                $args['dial_code_field']
            ) .
            '"';
    }


    if (
        $args['required']
    ) {

        $html .=
            ' required';
    }


    $html .=
        '>';


    if (
        $args['description']
    ) {

        $html .=
            '<span class="rud-crm-phone-description">' .
            esc_html(
                $args['description']
            ) .
            '</span>';
    }


    $html .=
        '</div>';


    return $html;
}


/*
 * =========================================================
 * ADMIN TABLE PHONE INPUT
 * =========================================================
 *
 * BACKWARD COMPATIBILITY
 *
 * Existing modules using:
 *
 * rud_crm_phone_input(...)
 *
 * continue working.
 *
 * =========================================================
 */

function rud_crm_phone_input(
    $name,
    $label,
    $value = '',
    $args = array()
) {

    rud_crm_enqueue_phone_assets();


    echo '<tr>';


    echo '<th scope="row">';


    echo '<label for="' .
        esc_attr(
            $name
        ) .
        '">';


    echo esc_html(
        $label
    );


    echo '</label>';


    echo '</th>';


    echo '<td>';


    echo wp_kses(
        rud_crm_render_phone_field(
            $name,
            $value,
            wp_parse_args(
                $args,
                array(
                    'class' =>
                        'regular-text rud-crm-admin-phone-field'
                )
            )
        ),
        rud_crm_phone_allowed_html()
    );


    echo '</td>';


    echo '</tr>';
}


/*
 * =========================================================
 * ALLOWED FIELD HTML
 * =========================================================
 */

function rud_crm_phone_allowed_html() {

    return array(

        'div' =>
            array(
                'class' =>
                    true
            ),

        'input' =>
            array(
                'type' =>
                    true,

                'name' =>
                    true,

                'id' =>
                    true,

                'value' =>
                    true,

                'class' =>
                    true,

                'autocomplete' =>
                    true,

                'placeholder' =>
                    true,

                'data-country-field' =>
                    true,

                'data-dial-code-field' =>
                    true,

                'required' =>
                    true
            ),

        'span' =>
            array(
                'class' =>
                    true
            )
    );
}