<?php
/**
 * RUD CRM Server
 * Web Services - Domains
 *
 * Version: 1.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/*
 * =========================================================
 * VERSION
 * =========================================================
 */

define( 'RUD_CRM_DOMAINS_DB_VERSION', '1.4.0' );


/*
 * =========================================================
 * ACCESS
 * ADMIN-LEVEL-001 / 002 / 003
 * =========================================================
 */

function rud_crm_domains_can_access() {

    if ( function_exists( 'rud_crm_service_areas_can_access' ) ) {
        return rud_crm_service_areas_can_access();
    }

    if ( function_exists( 'rud_crm_get_admin_level' ) ) {

        $level = (int) rud_crm_get_admin_level( get_current_user_id() );

        if ( in_array( $level, array( 1, 2, 3 ), true ) ) {
            return true;
        }
    }

    /*
     * Development / WordPress Administrator fallback.
     */
    return current_user_can( 'manage_options' );
}


/*
 * =========================================================
 * TABLE NAMES
 * =========================================================
 */

function rud_crm_domains_table() {
    global $wpdb;
    return $wpdb->prefix . 'rudcrm_domains';
}

function rud_crm_domain_history_table() {
    global $wpdb;
    return $wpdb->prefix . 'rudcrm_domain_history';
}

function rud_crm_hosting_accounts_table() {
    global $wpdb;
    return $wpdb->prefix . 'rudcrm_hosting_accounts';
}

function rud_crm_hosting_history_table() {
    global $wpdb;
    return $wpdb->prefix . 'rudcrm_hosting_history';
}


/*
 * =========================================================
 * DATABASE INSTALL / UPGRADE
 * =========================================================
 */

function rud_crm_domains_install() {

    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();

    $domains_table = rud_crm_domains_table();
    $history_table = rud_crm_domain_history_table();
    $hosting_table = rud_crm_hosting_accounts_table();
    $hosting_history_table = rud_crm_hosting_history_table();


    /*
     * =====================================================
     * DOMAINS
     * =====================================================
     */

    $sql_domains = "
        CREATE TABLE {$domains_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            domain_name VARCHAR(255) NOT NULL,
            tld VARCHAR(50) NULL,

            domain_type VARCHAR(50) NOT NULL DEFAULT 'domain',
            status VARCHAR(50) NOT NULL DEFAULT 'unknown',

            registrar VARCHAR(100) NULL,
            registrar_account VARCHAR(190) NULL,

            registration_source VARCHAR(100) NULL,
            source_reference VARCHAR(255) NULL,

            hosted_on_whm TINYINT(1) NOT NULL DEFAULT 0,
            whm_account VARCHAR(100) NULL,
            whm_main_domain TINYINT(1) NOT NULL DEFAULT 0,
            whm_package VARCHAR(190) NULL,

            dns_provider VARCHAR(100) NULL,

            cloudflare_enabled TINYINT(1) NOT NULL DEFAULT 0,
            cloudflare_account VARCHAR(190) NULL,
            cloudflare_zone_id VARCHAR(190) NULL,
            cloudflare_status VARCHAR(100) NULL,

            nameserver_1 VARCHAR(255) NULL,
            nameserver_2 VARCHAR(255) NULL,
            last_cloudflare_check DATETIME NULL,

            ssl_status VARCHAR(50) NOT NULL DEFAULT 'not_checked',
            ssl_issuer VARCHAR(255) NULL,
            ssl_valid_from DATETIME NULL,
            ssl_valid_until DATETIME NULL,
            ssl_autossl_status VARCHAR(100) NULL,
            last_ssl_check DATETIME NULL,

            registration_date DATE NULL,
            expiry_date DATE NULL,
            deleted_date DATE NULL,

            last_checked_at DATETIME NULL,

            notes LONGTEXT NULL,

            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY domain_name (domain_name),

            KEY customer_id (customer_id),
            KEY tld (tld),
            KEY domain_type (domain_type),
            KEY status (status),
            KEY registrar (registrar),
            KEY whm_account (whm_account),
            KEY hosted_on_whm (hosted_on_whm),
            KEY dns_provider (dns_provider),
            KEY ssl_status (ssl_status)

        ) {$charset_collate};
    ";

    dbDelta( $sql_domains );


    /*
     * =====================================================
     * DOMAIN HISTORY
     * =====================================================
     */

    $sql_history = "
        CREATE TABLE {$history_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            domain_id BIGINT UNSIGNED NOT NULL,
            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            event_type VARCHAR(100) NOT NULL,

            old_status VARCHAR(100) NULL,
            new_status VARCHAR(100) NULL,

            event_source VARCHAR(100) NULL,
            event_reference VARCHAR(255) NULL,

            details LONGTEXT NULL,

            changed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            event_date DATETIME NOT NULL,

            PRIMARY KEY  (id),

            KEY domain_id (domain_id),
            KEY customer_id (customer_id),
            KEY event_type (event_type),
            KEY event_date (event_date)

        ) {$charset_collate};
    ";

    dbDelta( $sql_history );


    /*
     * =====================================================
     * WHM / HOSTING ACCOUNTS
     *
     * Suspension belongs to the hosting account,
     * NOT directly to an individual domain.
     * =====================================================
     */

    $sql_hosting = "
        CREATE TABLE {$hosting_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            whm_account VARCHAR(100) NOT NULL,
            main_domain VARCHAR(255) NULL,

            account_status VARCHAR(50) NOT NULL DEFAULT 'unknown',

            whm_package VARCHAR(190) NULL,
            server_name VARCHAR(190) NULL,
            server_ip VARCHAR(100) NULL,

            account_created_date DATETIME NULL,

            suspended_from DATETIME NULL,
            suspended_until DATETIME NULL,
            unsuspended_at DATETIME NULL,

            suspension_reason TEXT NULL,

            disk_quota BIGINT NULL,
            disk_used BIGINT NULL,

            last_whm_check DATETIME NULL,

            notes LONGTEXT NULL,

            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY whm_account (whm_account),

            KEY customer_id (customer_id),
            KEY main_domain (main_domain),
            KEY account_status (account_status)

        ) {$charset_collate};
    ";

    dbDelta( $sql_hosting );


    /*
     * =====================================================
     * HOSTING ACCOUNT HISTORY
     *
     * Keeps every suspension / unsuspension period.
     * =====================================================
     */

    $sql_hosting_history = "
        CREATE TABLE {$hosting_history_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            hosting_account_id BIGINT UNSIGNED NOT NULL,

            whm_account VARCHAR(100) NOT NULL,

            event_type VARCHAR(100) NOT NULL,

            old_status VARCHAR(100) NULL,
            new_status VARCHAR(100) NULL,

            suspended_from DATETIME NULL,
            suspended_until DATETIME NULL,
            unsuspended_at DATETIME NULL,

            reason TEXT NULL,

            event_source VARCHAR(100) NULL,
            event_reference VARCHAR(255) NULL,

            changed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            event_date DATETIME NOT NULL,

            PRIMARY KEY  (id),

            KEY hosting_account_id (hosting_account_id),
            KEY whm_account (whm_account),
            KEY event_type (event_type),
            KEY event_date (event_date)

        ) {$charset_collate};
    ";

    dbDelta( $sql_hosting_history );

    update_option(
        'rud_crm_domains_db_version',
        RUD_CRM_DOMAINS_DB_VERSION
    );
}


/*
 * =========================================================
 * ENSURE DATABASE
 * =========================================================
 */

function rud_crm_domains_ensure_database() {

    $installed_version =
        get_option( 'rud_crm_domains_db_version', '' );

    if (
        $installed_version !==
        RUD_CRM_DOMAINS_DB_VERSION
    ) {
        rud_crm_domains_install();
    }
}

add_action(
    'admin_init',
    'rud_crm_domains_ensure_database',
    10
);


/*
 * =========================================================
 * NORMALIZE DOMAIN
 * =========================================================
 */

function rud_crm_domain_normalize( $domain_name ) {

    $domain_name = trim( strtolower( $domain_name ) );

    $domain_name = preg_replace(
        '#^https?://#i',
        '',
        $domain_name
    );

    $domain_name = preg_replace(
        '#/.*$#',
        '',
        $domain_name
    );

    $domain_name = rtrim(
        $domain_name,
        '.'
    );

    return $domain_name;
}


/*
 * =========================================================
 * TLD
 * =========================================================
 */

function rud_crm_domain_get_tld( $domain_name ) {

    $domain_name =
        rud_crm_domain_normalize( $domain_name );

    if ( empty( $domain_name ) ) {
        return '';
    }

    $parts = explode(
        '.',
        $domain_name
    );

    if ( count( $parts ) < 2 ) {
        return '';
    }

    return strtoupper(
        end( $parts )
    );
}


/*
 * =========================================================
 * DOMAIN TYPE LABELS
 * =========================================================
 */

function rud_crm_domain_type_label( $type ) {

    $types = array(

        'main_domain'
            => 'Main Domain',

        'addon_domain'
            => 'Addon Domain',

        'subdomain'
            => 'Subdomain',

        'alias_domain'
            => 'Alias / Parked Domain',

        'registered_only'
            => 'Registered Only',

        'external_hosting'
            => 'External Hosting',

        'domain'
            => 'Domain',

    );

    return isset( $types[ $type ] )
        ? $types[ $type ]
        : ucfirst(
            str_replace(
                '_',
                ' ',
                $type
            )
        );
}


/*
 * =========================================================
 * DOMAIN STATUS LABEL
 * =========================================================
 */

function rud_crm_domain_status_label( $status ) {

    $statuses = array(

        'active'
            => 'Active',

        'pending_registration'
            => 'Pending Registration',

        'pending_transfer'
            => 'Pending Transfer',

        'expiring'
            => 'Expiring',

        'expired'
            => 'Expired',

        'suspended'
            => 'Suspended',

        'deleted'
            => 'Deleted / Cancelled',

        'transferred_away'
            => 'Transferred Away',

        'unknown'
            => 'Unknown',

    );

    return isset( $statuses[ $status ] )
        ? $statuses[ $status ]
        : ucfirst(
            str_replace(
                '_',
                ' ',
                $status
            )
        );
}


/*
 * =========================================================
 * SSL STATUS
 * =========================================================
 */

function rud_crm_domain_ssl_status_label( $status ) {

    $statuses = array(

        'valid'
            => 'Valid SSL',

        'expiring'
            => 'Expiring Soon',

        'expired'
            => 'Expired SSL',

        'invalid'
            => 'Invalid SSL',

        'none'
            => 'No SSL',

        'not_checked'
            => 'Not Checked',

        'unknown'
            => 'Unknown',

    );

    return isset( $statuses[ $status ] )
        ? $statuses[ $status ]
        : ucfirst(
            str_replace(
                '_',
                ' ',
                $status
            )
        );
}


function rud_crm_domain_ssl_status_html( $status ) {

    $status = $status ?: 'not_checked';

    $label =
        rud_crm_domain_ssl_status_label( $status );

    switch ( $status ) {

        case 'valid':
            $color = '#1e8e3e';
            break;

        case 'expiring':
            $color = '#f9ab00';
            break;

        case 'expired':
        case 'invalid':
            $color = '#d93025';
            break;

        case 'none':
        case 'not_checked':
        case 'unknown':
        default:
            $color = '#80868b';
            break;
    }

    return sprintf(
        '<span style="white-space:nowrap;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%%;background:%1$s;margin-right:6px;"></span>%2$s</span>',
        esc_attr( $color ),
        esc_html( $label )
    );
}


/*
 * =========================================================
 * HOSTING STATUS
 * =========================================================
 */

function rud_crm_hosting_status_label( $status ) {

    $statuses = array(

        'active'
            => 'Active',

        'suspended'
            => 'Suspended',

        'terminated'
            => 'Terminated',

        'migrated'
            => 'Migrated',

        'unknown'
            => 'Unknown',

    );

    return isset( $statuses[ $status ] )
        ? $statuses[ $status ]
        : ucfirst(
            str_replace(
                '_',
                ' ',
                $status
            )
        );
}


function rud_crm_hosting_status_html( $status ) {

    $status = $status ?: 'unknown';

    $label =
        rud_crm_hosting_status_label( $status );

    switch ( $status ) {

        case 'active':
            $color = '#1e8e3e';
            break;

        case 'suspended':
            $color = '#d93025';
            break;

        case 'terminated':
            $color = '#5f6368';
            break;

        case 'migrated':
            $color = '#1a73e8';
            break;

        case 'unknown':
        default:
            $color = '#80868b';
            break;
    }

    return sprintf(
        '<span style="white-space:nowrap;"><span style="display:inline-block;width:10px;height:10px;border-radius:50%%;background:%1$s;margin-right:6px;"></span>%2$s</span>',
        esc_attr( $color ),
        esc_html( $label )
    );
}


/*
 * =========================================================
 * DOMAIN HISTORY
 * =========================================================
 */

function rud_crm_domain_add_history(
    $domain_id,
    $event_type,
    $old_status = '',
    $new_status = '',
    $event_source = '',
    $event_reference = '',
    $details = '',
    $customer_id = 0
) {

    global $wpdb;

    $table =
        rud_crm_domain_history_table();

    $wpdb->insert(

        $table,

        array(

            'domain_id'
                => (int) $domain_id,

            'customer_id'
                => (int) $customer_id,

            'event_type'
                => sanitize_key( $event_type ),

            'old_status'
                => sanitize_text_field( $old_status ),

            'new_status'
                => sanitize_text_field( $new_status ),

            'event_source'
                => sanitize_text_field( $event_source ),

            'event_reference'
                => sanitize_text_field( $event_reference ),

            'details'
                => sanitize_textarea_field( $details ),

            'changed_by'
                => get_current_user_id(),

            'event_date'
                => current_time( 'mysql' ),

        ),

        array(
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
            '%s',
        )
    );
}


/*
 * =========================================================
 * ENSURE HOSTING ACCOUNT
 * =========================================================
 */

function rud_crm_hosting_account_ensure(
    $whm_account,
    $main_domain = ''
) {

    global $wpdb;

    $whm_account =
        sanitize_text_field(
            trim( $whm_account )
        );

    if ( empty( $whm_account ) ) {
        return 0;
    }

    $table =
        rud_crm_hosting_accounts_table();

    $existing =
        $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$table}
                WHERE whm_account = %s
                LIMIT 1
                ",
                $whm_account
            )
        );

    $now = current_time( 'mysql' );

    if ( $existing ) {

        $updates = array(
            'last_whm_check' => $now,
            'updated_at'     => $now,
        );

        if (
            ! empty( $main_domain ) &&
            empty( $existing->main_domain )
        ) {
            $updates['main_domain'] =
                rud_crm_domain_normalize(
                    $main_domain
                );
        }

        $wpdb->update(
            $table,
            $updates,
            array(
                'id' => (int) $existing->id,
            )
        );

        return (int) $existing->id;
    }

    $wpdb->insert(

        $table,

        array(

            'customer_id'
                => 0,

            'whm_account'
                => $whm_account,

            'main_domain'
                => rud_crm_domain_normalize(
                    $main_domain
                ),

            'account_status'
                => 'unknown',

            'last_whm_check'
                => $now,

            'created_at'
                => $now,

            'updated_at'
                => $now,

        )
    );

    return (int) $wpdb->insert_id;
}


/*
 * =========================================================
 * HOSTING HISTORY
 * =========================================================
 */

function rud_crm_hosting_add_history(
    $hosting_account_id,
    $whm_account,
    $event_type,
    $old_status = '',
    $new_status = '',
    $suspended_from = null,
    $suspended_until = null,
    $unsuspended_at = null,
    $reason = '',
    $event_source = '',
    $event_reference = ''
) {

    global $wpdb;

    $table =
        rud_crm_hosting_history_table();

    $wpdb->insert(

        $table,

        array(

            'hosting_account_id'
                => (int) $hosting_account_id,

            'whm_account'
                => sanitize_text_field(
                    $whm_account
                ),

            'event_type'
                => sanitize_key(
                    $event_type
                ),

            'old_status'
                => sanitize_text_field(
                    $old_status
                ),

            'new_status'
                => sanitize_text_field(
                    $new_status
                ),

            'suspended_from'
                => $suspended_from,

            'suspended_until'
                => $suspended_until,

            'unsuspended_at'
                => $unsuspended_at,

            'reason'
                => sanitize_textarea_field(
                    $reason
                ),

            'event_source'
                => sanitize_text_field(
                    $event_source
                ),

            'event_reference'
                => sanitize_text_field(
                    $event_reference
                ),

            'changed_by'
                => get_current_user_id(),

            'event_date'
                => current_time( 'mysql' ),

        )
    );
}


/*
 * =========================================================
 * PROGRAMMATIC HOSTING SUSPENSION
 *
 * Ready for future WHM synchronization.
 * =========================================================
 */

function rud_crm_hosting_set_suspended(
    $whm_account,
    $suspended_from = null,
    $suspended_until = null,
    $reason = '',
    $source = 'WHM'
) {

    global $wpdb;

    $hosting_id =
        rud_crm_hosting_account_ensure(
            $whm_account
        );

    if ( ! $hosting_id ) {
        return false;
    }

    $table =
        rud_crm_hosting_accounts_table();

    $current =
        $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$table}
                WHERE id = %d
                ",
                $hosting_id
            )
        );

    if ( ! $current ) {
        return false;
    }

    if ( empty( $suspended_from ) ) {
        $suspended_from =
            current_time( 'mysql' );
    }

    $old_status =
        $current->account_status;

    $wpdb->update(

        $table,

        array(

            'account_status'
                => 'suspended',

            'suspended_from'
                => $suspended_from,

            'suspended_until'
                => $suspended_until,

            'unsuspended_at'
                => null,

            'suspension_reason'
                => sanitize_textarea_field(
                    $reason
                ),

            'updated_at'
                => current_time( 'mysql' ),

        ),

        array(
            'id' => $hosting_id,
        )
    );

    if ( $old_status !== 'suspended' ) {

        rud_crm_hosting_add_history(
            $hosting_id,
            $whm_account,
            'account_suspended',
            $old_status,
            'suspended',
            $suspended_from,
            $suspended_until,
            null,
            $reason,
            $source
        );
    }

    return true;
}


/*
 * =========================================================
 * PROGRAMMATIC HOSTING UNSUSPENSION
 * =========================================================
 */

function rud_crm_hosting_set_active(
    $whm_account,
    $unsuspended_at = null,
    $source = 'WHM'
) {

    global $wpdb;

    $table =
        rud_crm_hosting_accounts_table();

    $current =
        $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$table}
                WHERE whm_account = %s
                LIMIT 1
                ",
                $whm_account
            )
        );

    if ( ! $current ) {
        return false;
    }

    if ( empty( $unsuspended_at ) ) {
        $unsuspended_at =
            current_time( 'mysql' );
    }

    $old_status =
        $current->account_status;

    $wpdb->update(

        $table,

        array(

            'account_status'
                => 'active',

            'unsuspended_at'
                => $unsuspended_at,

            'updated_at'
                => current_time( 'mysql' ),

        ),

        array(
            'id' => (int) $current->id,
        )
    );

    if ( $old_status !== 'active' ) {

        rud_crm_hosting_add_history(
            (int) $current->id,
            $whm_account,
            'account_unsuspended',
            $old_status,
            'active',
            $current->suspended_from,
            $current->suspended_until,
            $unsuspended_at,
            $current->suspension_reason,
            $source
        );
    }

    return true;
}


/*
 * =========================================================
 * PROGRAMMATIC SSL UPDATE
 *
 * Ready for future WHM / AutoSSL scan.
 * =========================================================
 */

function rud_crm_domain_set_ssl_status(
    $domain_name,
    $ssl_status,
    $issuer = '',
    $valid_from = null,
    $valid_until = null,
    $autossl_status = ''
) {

    global $wpdb;

    $domain_name =
        rud_crm_domain_normalize(
            $domain_name
        );

    if ( empty( $domain_name ) ) {
        return false;
    }

    $allowed = array(
        'valid',
        'expiring',
        'expired',
        'invalid',
        'none',
        'not_checked',
        'unknown',
    );

    if (
        ! in_array(
            $ssl_status,
            $allowed,
            true
        )
    ) {
        $ssl_status = 'unknown';
    }

    $table =
        rud_crm_domains_table();

    $domain =
        $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$table}
                WHERE domain_name = %s
                LIMIT 1
                ",
                $domain_name
            )
        );

    if ( ! $domain ) {
        return false;
    }

    $old_status =
        $domain->ssl_status;

    $wpdb->update(

        $table,

        array(

            'ssl_status'
                => $ssl_status,

            'ssl_issuer'
                => sanitize_text_field(
                    $issuer
                ),

            'ssl_valid_from'
                => $valid_from,

            'ssl_valid_until'
                => $valid_until,

            'ssl_autossl_status'
                => sanitize_text_field(
                    $autossl_status
                ),

            'last_ssl_check'
                => current_time( 'mysql' ),

            'updated_at'
                => current_time( 'mysql' ),

        ),

        array(
            'id' => (int) $domain->id,
        )
    );

    if ( $old_status !== $ssl_status ) {

        rud_crm_domain_add_history(
            (int) $domain->id,
            'ssl_status_changed',
            $old_status,
            $ssl_status,
            'SSL',
            '',
            'SSL status updated.',
            (int) $domain->customer_id
        );
    }

    return true;
}


/*
 * =========================================================
 * WHM OUTPUT PARSER
 * =========================================================
 */

function rud_crm_domains_parse_whm_output(
    $raw_text
) {

    $raw_text =
        str_replace(
            array( "\r\n", "\r" ),
            "\n",
            $raw_text
        );

    $lines =
        explode(
            "\n",
            $raw_text
        );

    $records = array();

    $current_account = '';
    $current_section = '';

    foreach ( $lines as $line ) {

        $trimmed = trim( $line );

        /*
         * Account header
         */
        if (
            preg_match(
                '/^===== ACCOUNT:\s*(.+?)\s*=====$/',
                $trimmed,
                $matches
            )
        ) {

            $current_account =
                sanitize_text_field(
                    trim( $matches[1] )
                );

            $current_section = '';

            continue;
        }


        if ( empty( $current_account ) ) {
            continue;
        }


        /*
         * Main domain
         */
        if (
            preg_match(
                '/^main_domain:\s*(.+)$/',
                $trimmed,
                $matches
            )
        ) {

            $domain =
                rud_crm_domain_normalize(
                    $matches[1]
                );

            if ( $domain ) {

                $records[] = array(

                    'domain_name'
                        => $domain,

                    'domain_type'
                        => 'main_domain',

                    'whm_account'
                        => $current_account,

                    'whm_main_domain'
                        => 1,

                );
            }

            $current_section = '';

            continue;
        }


        /*
         * Sections
         */
        if (
            preg_match(
                '/^addon_domains:\s*(.*)$/',
                $trimmed,
                $matches
            )
        ) {

            $current_section =
                'addon_domain';

            if (
                trim( $matches[1] ) === '[]'
            ) {
                $current_section = '';
            }

            continue;
        }


        if (
            preg_match(
                '/^parked_domains:\s*(.*)$/',
                $trimmed,
                $matches
            )
        ) {

            $current_section =
                'alias_domain';

            if (
                trim( $matches[1] ) === '[]'
            ) {
                $current_section = '';
            }

            continue;
        }


        if (
            preg_match(
                '/^sub_domains:\s*(.*)$/',
                $trimmed,
                $matches
            )
        ) {

            $current_section =
                'subdomain';

            if (
                trim( $matches[1] ) === '[]'
            ) {
                $current_section = '';
            }

            continue;
        }


        /*
         * YAML list item
         */
        if (
            ! empty( $current_section ) &&
            preg_match(
                '/^-\s*(.+)$/',
                $trimmed,
                $matches
            )
        ) {

            $domain =
                rud_crm_domain_normalize(
                    $matches[1]
                );

            if ( $domain ) {

                $records[] = array(

                    'domain_name'
                        => $domain,

                    'domain_type'
                        => $current_section,

                    'whm_account'
                        => $current_account,

                    'whm_main_domain'
                        => 0,

                );
            }
        }
    }


    /*
     * Remove duplicates.
     *
     * Main Domain has priority.
     */
    $unique = array();

    foreach ( $records as $record ) {

        $domain =
            $record['domain_name'];

        if (
            ! isset( $unique[ $domain ] )
        ) {

            $unique[ $domain ] =
                $record;

            continue;
        }

        if (
            $record['domain_type']
            ===
            'main_domain'
        ) {
            $unique[ $domain ] =
                $record;
        }
    }

    return array_values( $unique );
}


/*
 * =========================================================
 * IMPORT ONE WHM DOMAIN
 * =========================================================
 */

function rud_crm_domains_import_whm_record(
    $record
) {

    global $wpdb;

    $table =
        rud_crm_domains_table();

    $domain_name =
        rud_crm_domain_normalize(
            $record['domain_name']
        );

    $domain_type =
        sanitize_key(
            $record['domain_type']
        );

    $whm_account =
        sanitize_text_field(
            $record['whm_account']
        );

    $whm_main_domain =
        ! empty(
            $record['whm_main_domain']
        )
        ? 1
        : 0;

    if ( empty( $domain_name ) ) {

        return array(
            'status' => 'error',
            'message' => 'Empty domain name.',
        );
    }

    $tld =
        rud_crm_domain_get_tld(
            $domain_name
        );

    $now =
        current_time( 'mysql' );


    /*
     * Ensure WHM hosting account exists.
     */
    rud_crm_hosting_account_ensure(

        $whm_account,

        $whm_main_domain
            ? $domain_name
            : ''
    );


    /*
     * Existing domain
     */
    $existing =
        $wpdb->get_row(
            $wpdb->prepare(
                "
                SELECT *
                FROM {$table}
                WHERE domain_name = %s
                LIMIT 1
                ",
                $domain_name
            )
        );

    if ( $existing ) {

        $changed = false;

        if (
            $existing->domain_type
            !==
            $domain_type
        ) {
            $changed = true;
        }

        if (
            $existing->whm_account
            !==
            $whm_account
        ) {
            $changed = true;
        }

        if (
            (int) $existing->hosted_on_whm
            !== 1
        ) {
            $changed = true;
        }

        if (
            (int) $existing->whm_main_domain
            !==
            $whm_main_domain
        ) {
            $changed = true;
        }

        if (
            strtoupper(
                (string) $existing->tld
            )
            !==
            strtoupper( $tld )
        ) {
            $changed = true;
        }


        $wpdb->update(

            $table,

            array(

                'tld'
                    => $tld,

                'domain_type'
                    => $domain_type,

                'hosted_on_whm'
                    => 1,

                'whm_account'
                    => $whm_account,

                'whm_main_domain'
                    => $whm_main_domain,

                'last_checked_at'
                    => $now,

                'updated_at'
                    => $now,

            ),

            array(
                'id' => (int) $existing->id,
            )
        );


        if ( $changed ) {

            rud_crm_domain_add_history(

                (int) $existing->id,

                'whm_import_updated',

                $existing->status,

                $existing->status,

                'WHM',

                $whm_account,

                'WHM domain information updated.',

                (int) $existing->customer_id
            );

            return array(
                'status' => 'updated',
            );
        }


        return array(
            'status' => 'unchanged',
        );
    }


    /*
     * New domain
     */
    $inserted =
        $wpdb->insert(

            $table,

            array(

                'customer_id'
                    => 0,

                'domain_name'
                    => $domain_name,

                'tld'
                    => $tld,

                'domain_type'
                    => $domain_type,

                'status'
                    => 'active',

                'registration_source'
                    => 'WHM',

                'source_reference'
                    => $whm_account,

                'hosted_on_whm'
                    => 1,

                'whm_account'
                    => $whm_account,

                'whm_main_domain'
                    => $whm_main_domain,

                'ssl_status'
                    => 'not_checked',

                'last_checked_at'
                    => $now,

                'created_at'
                    => $now,

                'updated_at'
                    => $now,

            )
        );

    if ( ! $inserted ) {

        return array(

            'status'
                => 'error',

            'message'
                => $wpdb->last_error,

        );
    }

    $domain_id =
        (int) $wpdb->insert_id;

    rud_crm_domain_add_history(

        $domain_id,

        'whm_import_created',

        '',

        'active',

        'WHM',

        $whm_account,

        'Domain created from WHM import.',

        0
    );

    return array(
        'status' => 'created',
    );
}


/*
 * =========================================================
 * IMPORT COMPLETE WHM TEXT
 * =========================================================
 */

function rud_crm_domains_import_whm_text(
    $raw_text
) {

    $records =
        rud_crm_domains_parse_whm_output(
            $raw_text
        );

    $result = array(

        'parsed'
            => count( $records ),

        'created'
            => 0,

        'updated'
            => 0,

        'unchanged'
            => 0,

        'errors'
            => 0,

        'error_messages'
            => array(),

    );

    foreach ( $records as $record ) {

        $import =
            rud_crm_domains_import_whm_record(
                $record
            );

        if (
            empty( $import['status'] )
        ) {
            continue;
        }

        switch (
            $import['status']
        ) {

            case 'created':
                $result['created']++;
                break;

            case 'updated':
                $result['updated']++;
                break;

            case 'unchanged':
                $result['unchanged']++;
                break;

            case 'error':

                $result['errors']++;

                if (
                    ! empty(
                        $import['message']
                    )
                ) {
                    $result[
                        'error_messages'
                    ][] =
                        $import['message'];
                }

                break;
        }
    }

    return $result;
}


/*
 * =========================================================
 * WHM IMPORT POST HANDLER
 * =========================================================
 */

function rud_crm_domains_handle_whm_import() {

    if (
        empty(
            $_POST[
                'rud_crm_whm_import_submit'
            ]
        )
    ) {
        return;
    }

    if (
        ! rud_crm_domains_can_access()
    ) {
        wp_die(
            'You do not have permission to access this function.'
        );
    }

    check_admin_referer(
        'rud_crm_whm_import'
    );

    $raw_text =
        isset(
            $_POST[
                'rud_crm_whm_import_text'
            ]
        )
        ? wp_unslash(
            $_POST[
                'rud_crm_whm_import_text'
            ]
        )
        : '';

    $result =
        rud_crm_domains_import_whm_text(
            $raw_text
        );

    set_transient(

        'rud_crm_whm_import_result_'
        .
        get_current_user_id(),

        $result,

        300
    );

    wp_safe_redirect(

        admin_url(
            'admin.php?page=rud-crm-domains'
        )
    );

    exit;
}

add_action(
    'admin_init',
    'rud_crm_domains_handle_whm_import',
    30
);


/*
 * =========================================================
 * AVAILABLE TLDs
 * =========================================================
 */

function rud_crm_domains_available_tlds() {

    global $wpdb;

    $table =
        rud_crm_domains_table();

    return $wpdb->get_col(
        "
        SELECT DISTINCT tld
        FROM {$table}
        WHERE tld IS NOT NULL
        AND tld <> ''
        ORDER BY tld ASC
        "
    );
}


/*
 * =========================================================
 * FILTERED DOMAIN LIST
 * =========================================================
 */

function rud_crm_domains_get_filtered(
    $view = 'all',
    $tld = '',
    $registrar = '',
    $dns_provider = '',
    $hosting = '',
    $ssl_status = '',
    $hosting_status = '',
    $problems_only = false,
    $search = '',
    $sort = 'domain'
) {

    global $wpdb;

    $domains_table =
        rud_crm_domains_table();

    $hosting_table =
        rud_crm_hosting_accounts_table();

    $where = array(
        '1=1'
    );

    $args = array();


    /*
     * Domain Type View
     */
    $view_types = array(

        'main'
            => 'main_domain',

        'addon'
            => 'addon_domain',

        'subdomain'
            => 'subdomain',

        'alias'
            => 'alias_domain',

    );

    if (
        isset(
            $view_types[ $view ]
        )
    ) {

        $where[] =
            'd.domain_type = %s';

        $args[] =
            $view_types[ $view ];
    }


    /*
     * TLD
     */
    if ( $tld !== '' ) {

        $where[] =
            'd.tld = %s';

        $args[] =
            strtoupper( $tld );
    }


    /*
     * Registrar
     */
    if ( $registrar !== '' ) {

        $where[] =
            'd.registrar = %s';

        $args[] =
            $registrar;
    }


    /*
     * DNS
     */
    if ( $dns_provider !== '' ) {

        $where[] =
            'd.dns_provider = %s';

        $args[] =
            $dns_provider;
    }


    /*
     * Hosting
     */
    if ( $hosting === 'whm' ) {

        $where[] =
            'd.hosted_on_whm = 1';
    }

    elseif (
        $hosting === 'external'
    ) {

        $where[] =
            'd.hosted_on_whm = 0';
    }


    /*
     * SSL
     */
    if ( $ssl_status !== '' ) {

        $where[] =
            'd.ssl_status = %s';

        $args[] =
            $ssl_status;
    }


    /*
     * Hosting Account Status
     */
    if ( $hosting_status !== '' ) {

        $where[] =
            'h.account_status = %s';

        $args[] =
            $hosting_status;
    }


    /*
     * Search
     */
    if ( $search !== '' ) {

        $where[] =
            'd.domain_name LIKE %s';

        $args[] =
            '%' .
            $wpdb->esc_like(
                $search
            ) .
            '%';
    }


    /*
     * Problems Only
     *
     * Current operational problems:
     *
     * - SSL Expiring
     * - SSL Expired
     * - SSL Invalid
     * - Hosting Suspended
     * - Domain Expiring
     * - Domain Expired
     * - Customer Unassigned
     */
    if ( $problems_only ) {

        $where[] = "
            (
                d.ssl_status IN (
                    'expiring',
                    'expired',
                    'invalid'
                )

                OR h.account_status = 'suspended'

                OR d.status IN (
                    'expiring',
                    'expired'
                )

                OR d.customer_id = 0
            )
        ";
    }


    /*
     * Sorting
     */
    switch ( $sort ) {

        case 'type':
            $order =
                'd.domain_type ASC, d.domain_name ASC';
            break;

        case 'tld':
            $order =
                'd.tld ASC, d.domain_name ASC';
            break;

        case 'status':
            $order =
                'd.status ASC, d.domain_name ASC';
            break;

        case 'ssl':
            $order =
                'd.ssl_status ASC, d.domain_name ASC';
            break;

        case 'hosting':
            $order =
                'h.account_status ASC, d.domain_name ASC';
            break;

        case 'domain':
        default:
            $order =
                'd.domain_name ASC';
            break;
    }


    $sql = "
        SELECT

            d.*,

            h.account_status AS hosting_account_status,

            h.suspended_from AS hosting_suspended_from,

            h.suspended_until AS hosting_suspended_until,

            h.unsuspended_at AS hosting_unsuspended_at,

            h.suspension_reason AS hosting_suspension_reason

        FROM {$domains_table} d

        LEFT JOIN {$hosting_table} h
            ON h.whm_account = d.whm_account

        WHERE
        "
        .
        implode(
            ' AND ',
            $where
        )
        .
        "
        ORDER BY {$order}
        ";


    if ( ! empty( $args ) ) {

        $sql =
            $wpdb->prepare(
                $sql,
                $args
            );
    }

    return $wpdb->get_results(
        $sql
    );
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_domains_admin_menu() {

    if (
        ! rud_crm_domains_can_access()
    ) {
        return;
    }

    add_submenu_page(

        'rud-crm',

        'Domains',

        'Domains',

        'read',

        'rud-crm-domains',

        'rud_crm_domains_admin_page'
    );
}

add_action(
    'admin_menu',
    'rud_crm_domains_admin_menu',
    30
);


/*
 * =========================================================
 * ADMIN PAGE
 * =========================================================
 */

function rud_crm_domains_admin_page() {

    if (
        ! rud_crm_domains_can_access()
    ) {

        wp_die(
            'You do not have permission to access this page.'
        );
    }


    $view =
        isset( $_GET['view'] )
        ? sanitize_key(
            $_GET['view']
        )
        : 'all';

    $tld =
        isset( $_GET['tld'] )
        ? sanitize_text_field(
            $_GET['tld']
        )
        : '';

    $registrar =
        isset( $_GET['registrar'] )
        ? sanitize_text_field(
            $_GET['registrar']
        )
        : '';

    $dns_provider =
        isset( $_GET['dns_provider'] )
        ? sanitize_text_field(
            $_GET['dns_provider']
        )
        : '';

    $hosting =
        isset( $_GET['hosting'] )
        ? sanitize_key(
            $_GET['hosting']
        )
        : '';

    $ssl_status =
        isset( $_GET['ssl_status'] )
        ? sanitize_key(
            $_GET['ssl_status']
        )
        : '';

    $hosting_status =
        isset(
            $_GET[
                'hosting_status'
            ]
        )
        ? sanitize_key(
            $_GET[
                'hosting_status'
            ]
        )
        : '';

    $problems_only =
        ! empty(
            $_GET[
                'problems_only'
            ]
        );

    $search =
        isset( $_GET['s'] )
        ? sanitize_text_field(
            $_GET['s']
        )
        : '';

    $sort =
        isset( $_GET['sort'] )
        ? sanitize_key(
            $_GET['sort']
        )
        : 'domain';


    $domains =
        rud_crm_domains_get_filtered(
            $view,
            $tld,
            $registrar,
            $dns_provider,
            $hosting,
            $ssl_status,
            $hosting_status,
            $problems_only,
            $search,
            $sort
        );

    $tlds =
        rud_crm_domains_available_tlds();


    /*
     * Import Result
     */
    $transient_key =
        'rud_crm_whm_import_result_'
        .
        get_current_user_id();

    $import_result =
        get_transient(
            $transient_key
        );

    if ( $import_result ) {
        delete_transient(
            $transient_key
        );
    }

    ?>

    <div class="wrap">

        <h1>Domains</h1>

        <p>
            Master domain register for WHM/cPanel, NORID,
            OnlineNIC, Cloudflare, SSL and hosting information.
        </p>


        <?php if ( $import_result ) : ?>

            <div class="notice notice-success">

                <p>
                    <strong>WHM Import Result</strong>
                </p>

                <p>
                    Parsed:
                    <strong>
                        <?php
                        echo esc_html(
                            $import_result['parsed']
                        );
                        ?>
                    </strong>

                    &nbsp; | &nbsp;

                    New:
                    <strong>
                        <?php
                        echo esc_html(
                            $import_result['created']
                        );
                        ?>
                    </strong>

                    &nbsp; | &nbsp;

                    Updated:
                    <strong>
                        <?php
                        echo esc_html(
                            $import_result['updated']
                        );
                        ?>
                    </strong>

                    &nbsp; | &nbsp;

                    Unchanged:
                    <strong>
                        <?php
                        echo esc_html(
                            $import_result['unchanged']
                        );
                        ?>
                    </strong>

                    &nbsp; | &nbsp;

                    Errors:
                    <strong>
                        <?php
                        echo esc_html(
                            $import_result['errors']
                        );
                        ?>
                    </strong>
                </p>

            </div>

        <?php endif; ?>


        <!-- ============================================= -->
        <!-- WHM IMPORT                                    -->
        <!-- ============================================= -->

        <div
            style="
                background:#fff;
                border:1px solid #ccd0d4;
                padding:20px;
                margin:20px 0;
            "
        >

            <h2>WHM / cPanel Import</h2>

            <p>
                Paste the read-only WHM DomainInfo output here.
                Existing domains are updated safely.
                No domains are physically deleted.
            </p>

            <form method="post">

                <?php
                wp_nonce_field(
                    'rud_crm_whm_import'
                );
                ?>

                <textarea
                    name="rud_crm_whm_import_text"
                    rows="8"
                    style="width:100%;font-family:monospace;"
                    placeholder="Paste WHM domain output here..."
                ></textarea>

                <p>

                    <button
                        type="submit"
                        name="rud_crm_whm_import_submit"
                        value="1"
                        class="button button-primary"
                    >
                        Import WHM Domains
                    </button>

                </p>

            </form>

        </div>


        <!-- ============================================= -->
        <!-- DOMAIN TYPE VIEWS                             -->
        <!-- ============================================= -->

        <h2>Domain Views</h2>

        <?php

        $views = array(

            'all'
                => 'View All Domains',

            'main'
                => 'View Main Domains',

            'addon'
                => 'View Addon Domains',

            'subdomain'
                => 'View Subdomains',

            'alias'
                => 'View Alias Domains',

        );

        foreach (
            $views
            as
            $view_key => $view_label
        ) {

            $url =
                add_query_arg(
                    array(
                        'page'
                            => 'rud-crm-domains',
                        'view'
                            => $view_key,
                    ),
                    admin_url(
                        'admin.php'
                    )
                );

            $class =
                $view === $view_key
                ? 'button button-primary'
                : 'button';

            ?>

            <a
                href="<?php echo esc_url( $url ); ?>"
                class="<?php echo esc_attr( $class ); ?>"
                style="margin-right:5px;margin-bottom:5px;"
            >
                <?php
                echo esc_html(
                    $view_label
                );
                ?>
            </a>

            <?php
        }

        ?>


        <!-- ============================================= -->
        <!-- FILTERS                                       -->
        <!-- ============================================= -->

        <form
            method="get"
            style="
                margin:20px 0;
                padding:15px;
                background:#fff;
                border:1px solid #ccd0d4;
            "
        >

            <input
                type="hidden"
                name="page"
                value="rud-crm-domains"
            >

            <input
                type="hidden"
                name="view"
                value="<?php echo esc_attr( $view ); ?>"
            >


            <!-- TLD -->

            <select name="tld">

                <option value="">
                    All TLDs
                </option>

                <?php foreach ( $tlds as $item ) : ?>

                    <option
                        value="<?php echo esc_attr( $item ); ?>"
                        <?php
                        selected(
                            $tld,
                            $item
                        );
                        ?>
                    >
                        .<?php
                        echo esc_html(
                            $item
                        );
                        ?>
                    </option>

                <?php endforeach; ?>

            </select>


            <!-- REGISTRAR -->

            <select name="registrar">

                <option value="">
                    All Registrars
                </option>

                <option
                    value="NORID"
                    <?php selected( $registrar, 'NORID' ); ?>
                >
                    NORID
                </option>

                <option
                    value="OnlineNIC"
                    <?php selected( $registrar, 'OnlineNIC' ); ?>
                >
                    OnlineNIC
                </option>

                <option
                    value="Other"
                    <?php selected( $registrar, 'Other' ); ?>
                >
                    Other
                </option>

            </select>


            <!-- HOSTING -->

            <select name="hosting">

                <option value="">
                    All Hosting
                </option>

                <option
                    value="whm"
                    <?php selected( $hosting, 'whm' ); ?>
                >
                    Hosted on WHM
                </option>

                <option
                    value="external"
                    <?php selected( $hosting, 'external' ); ?>
                >
                    External / Not WHM
                </option>

            </select>


            <!-- DNS -->

            <select name="dns_provider">

                <option value="">
                    All DNS Providers
                </option>

                <option
                    value="Cloudflare"
                    <?php selected( $dns_provider, 'Cloudflare' ); ?>
                >
                    Cloudflare
                </option>

                <option
                    value="WHM/cPanel"
                    <?php selected( $dns_provider, 'WHM/cPanel' ); ?>
                >
                    WHM / cPanel
                </option>

                <option
                    value="Other"
                    <?php selected( $dns_provider, 'Other' ); ?>
                >
                    Other
                </option>

            </select>


            <!-- SSL -->

            <select name="ssl_status">

                <option value="">
                    All SSL
                </option>

                <option
                    value="valid"
                    <?php selected( $ssl_status, 'valid' ); ?>
                >
                    Valid SSL
                </option>

                <option
                    value="expiring"
                    <?php selected( $ssl_status, 'expiring' ); ?>
                >
                    Expiring Soon
                </option>

                <option
                    value="expired"
                    <?php selected( $ssl_status, 'expired' ); ?>
                >
                    Expired SSL
                </option>

                <option
                    value="invalid"
                    <?php selected( $ssl_status, 'invalid' ); ?>
                >
                    Invalid SSL
                </option>

                <option
                    value="none"
                    <?php selected( $ssl_status, 'none' ); ?>
                >
                    No SSL
                </option>

                <option
                    value="not_checked"
                    <?php selected( $ssl_status, 'not_checked' ); ?>
                >
                    Not Checked
                </option>

            </select>


            <!-- HOSTING STATUS -->

            <select name="hosting_status">

                <option value="">
                    All Account Statuses
                </option>

                <option
                    value="active"
                    <?php selected( $hosting_status, 'active' ); ?>
                >
                    Active Account
                </option>

                <option
                    value="suspended"
                    <?php selected( $hosting_status, 'suspended' ); ?>
                >
                    Suspended Account
                </option>

                <option
                    value="terminated"
                    <?php selected( $hosting_status, 'terminated' ); ?>
                >
                    Terminated Account
                </option>

                <option
                    value="unknown"
                    <?php selected( $hosting_status, 'unknown' ); ?>
                >
                    Unknown
                </option>

            </select>


            <!-- SORT -->

            <select name="sort">

                <option
                    value="domain"
                    <?php selected( $sort, 'domain' ); ?>
                >
                    Sort: Domain
                </option>

                <option
                    value="type"
                    <?php selected( $sort, 'type' ); ?>
                >
                    Sort: Domain Type
                </option>

                <option
                    value="tld"
                    <?php selected( $sort, 'tld' ); ?>
                >
                    Sort: TLD
                </option>

                <option
                    value="status"
                    <?php selected( $sort, 'status' ); ?>
                >
                    Sort: Domain Status
                </option>

                <option
                    value="ssl"
                    <?php selected( $sort, 'ssl' ); ?>
                >
                    Sort: SSL
                </option>

                <option
                    value="hosting"
                    <?php selected( $sort, 'hosting' ); ?>
                >
                    Sort: Hosting Status
                </option>

            </select>


            <!-- SEARCH -->

            <input
                type="search"
                name="s"
                value="<?php echo esc_attr( $search ); ?>"
                placeholder="Search domain..."
            >


            <!-- PROBLEMS -->

            <label
                style="
                    margin-left:10px;
                    white-space:nowrap;
                "
            >

                <input
                    type="checkbox"
                    name="problems_only"
                    value="1"
                    <?php
                    checked(
                        $problems_only,
                        true
                    );
                    ?>
                >

                <strong>
                    Show Only Problems
                </strong>

            </label>


            <button
                type="submit"
                class="button"
            >
                Apply Filters
            </button>

        </form>


        <!-- ============================================= -->
        <!-- DOMAIN TABLE                                  -->
        <!-- ============================================= -->

        <h2>
            Domains
            (<?php echo esc_html( count( $domains ) ); ?>)
        </h2>


        <table
            class="widefat striped"
        >

            <thead>

                <tr>

                    <th>Domain</th>

                    <th>Domain Type</th>

                    <th>TLD</th>

                    <th>Customer</th>

                    <th>Domain Status</th>

                    <th>SSL</th>

                    <th>Registrar</th>

                    <th>DNS</th>

                    <th>WHM</th>

                    <th>WHM Account</th>

                    <th>Hosting Status</th>

                    <th>Suspended</th>

                </tr>

            </thead>


            <tbody>

            <?php if ( empty( $domains ) ) : ?>

                <tr>

                    <td colspan="12">

                        No domains found.

                    </td>

                </tr>

            <?php else : ?>


                <?php foreach ( $domains as $domain ) : ?>

                    <tr>

                        <td>

                            <strong>
                                <?php
                                echo esc_html(
                                    $domain->domain_name
                                );
                                ?>
                            </strong>

                        </td>


                        <td>

                            <?php
                            echo esc_html(
                                rud_crm_domain_type_label(
                                    $domain->domain_type
                                )
                            );
                            ?>

                        </td>


                        <td>

                            <?php

                            if ( $domain->tld ) {

                                echo '.' .
                                    esc_html(
                                        $domain->tld
                                    );

                            } else {

                                echo '—';
                            }

                            ?>

                        </td>


                        <td>

                            <?php

                            if (
                                (int) $domain->customer_id
                                > 0
                            ) {

                                echo '#' .
                                    esc_html(
                                        $domain->customer_id
                                    );

                            } else {

                                echo '<span style="color:#d93025;">Unassigned</span>';
                            }

                            ?>

                        </td>


                        <td>

                            <?php
                            echo esc_html(
                                rud_crm_domain_status_label(
                                    $domain->status
                                )
                            );
                            ?>

                        </td>


                        <td>

                            <?php
                            echo wp_kses_post(
                                rud_crm_domain_ssl_status_html(
                                    $domain->ssl_status
                                )
                            );
                            ?>

                            <?php
                            if (
                                ! empty(
                                    $domain->ssl_valid_until
                                )
                            ) :
                            ?>

                                <br>

                                <small>
                                    Until:
                                    <?php
                                    echo esc_html(
                                        $domain->ssl_valid_until
                                    );
                                    ?>
                                </small>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?php

                            echo $domain->registrar
                                ? esc_html(
                                    $domain->registrar
                                )
                                : '—';

                            ?>

                        </td>


                        <td>

                            <?php

                            echo $domain->dns_provider
                                ? esc_html(
                                    $domain->dns_provider
                                )
                                : '—';

                            ?>

                        </td>


                        <td>

                            <?php

                            echo
                                (int) $domain->hosted_on_whm
                                === 1
                                ? 'Yes'
                                : 'No';

                            ?>

                        </td>


                        <td>

                            <?php

                            echo $domain->whm_account
                                ? esc_html(
                                    $domain->whm_account
                                )
                                : '—';

                            ?>

                        </td>


                        <td>

                            <?php

                            $hosting_status_value =
                                $domain->hosting_account_status
                                    ?: 'unknown';

                            echo wp_kses_post(
                                rud_crm_hosting_status_html(
                                    $hosting_status_value
                                )
                            );

                            ?>

                        </td>


                        <td>

                            <?php

                            if (
                                $domain->hosting_account_status
                                ===
                                'suspended'
                            ) {

                                echo '<strong style="color:#d93025;">Suspended</strong>';

                                if (
                                    ! empty(
                                        $domain->hosting_suspended_from
                                    )
                                ) {

                                    echo '<br><small>From: ' .
                                        esc_html(
                                            $domain->hosting_suspended_from
                                        )
                                        .
                                        '</small>';
                                }

                                if (
                                    ! empty(
                                        $domain->hosting_suspended_until
                                    )
                                ) {

                                    echo '<br><small>Until: ' .
                                        esc_html(
                                            $domain->hosting_suspended_until
                                        )
                                        .
                                        '</small>';
                                }

                            } else {

                                echo '—';
                            }

                            ?>

                        </td>

                    </tr>

                <?php endforeach; ?>


            <?php endif; ?>

            </tbody>

        </table>


        <!-- ============================================= -->
        <!-- STATUS LEGEND                                 -->
        <!-- ============================================= -->

        <div
            style="
                margin-top:20px;
                padding:15px;
                background:#fff;
                border:1px solid #ccd0d4;
            "
        >

            <h2>SSL Status</h2>

            <p>
                🟢 <strong>Valid SSL</strong>
                &nbsp;&nbsp;
                🟡 <strong>Expiring Soon</strong>
                &nbsp;&nbsp;
                🔴 <strong>Expired / Invalid</strong>
                &nbsp;&nbsp;
                ⚪ <strong>Not Checked / No SSL</strong>
            </p>


            <h2>Hosting Account Status</h2>

            <p>
                🟢 <strong>Active</strong>
                &nbsp;&nbsp;
                🔴 <strong>Suspended</strong>
                &nbsp;&nbsp;
                ⚫ <strong>Terminated</strong>
                &nbsp;&nbsp;
                ⚪ <strong>Unknown</strong>
            </p>

        </div>


        <!-- ============================================= -->
        <!-- SOURCES                                       -->
        <!-- ============================================= -->

        <div
            style="
                margin-top:20px;
                padding:15px;
                background:#fff;
                border:1px solid #ccd0d4;
            "
        >

            <h2>Domain Data Sources</h2>

            <table class="widefat striped">

                <thead>

                    <tr>

                        <th>Source</th>

                        <th>Purpose</th>

                        <th>Status</th>

                    </tr>

                </thead>

                <tbody>

                    <tr>

                        <td>
                            <strong>
                                WHM / cPanel
                            </strong>
                        </td>

                        <td>
                            Hosting accounts,
                            Main Domains,
                            Addon Domains,
                            Subdomains,
                            Alias / Parked Domains,
                            hosting status,
                            SSL / AutoSSL.
                        </td>

                        <td>
                            Manual Domain Import Available
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>
                                NORID
                            </strong>
                        </td>

                        <td>
                            Norwegian .NO
                            registration information.
                        </td>

                        <td>
                            Not imported yet
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>
                                OnlineNIC
                            </strong>
                        </td>

                        <td>
                            International domain
                            registration information.
                        </td>

                        <td>
                            Not imported yet
                        </td>

                    </tr>


                    <tr>

                        <td>
                            <strong>
                                Cloudflare
                            </strong>
                        </td>

                        <td>
                            DNS,
                            nameservers,
                            zone status
                            and Cloudflare information.
                        </td>

                        <td>
                            Not imported yet
                        </td>

                    </tr>

                </tbody>

            </table>

        </div>

    </div>

    <?php
}