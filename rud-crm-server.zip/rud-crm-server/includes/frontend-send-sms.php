<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END SEND SMS
 * Version 1.0
 * =========================================================
 *
 * Provides:
 * - Send SMS panel on Customer Open Profile
 * - Select Customer / Contact Person
 * - Select SMS Template
 * - Compose custom SMS
 * - Send through RUD CRM SMS Sender
 * - Success / error messages
 *
 * =========================================================
 */


/*
 * =========================================================
 * PERMISSION
 * =========================================================
 */

function rud_crm_frontend_sms_can_send_for_customer(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        function_exists(
            'rud_crm_frontend_edit_can_edit'
        )
    ) {

        return (bool)
            rud_crm_frontend_edit_can_edit(
                $customer_id
            );
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_user_owns_customer'
        )
    ) {

        return (bool)
            rud_crm_user_owns_customer(
                get_current_user_id(),
                $customer_id
            );
    }

    return false;
}


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

function rud_crm_frontend_sms_customer_url(
    $customer_id,
    $args = array()
) {

    $url =
        add_query_arg(
            array(
                'rud_customer_id' =>
                    absint(
                        $customer_id
                    ),
            ),
            home_url(
                '/customer-crm/'
            )
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * PROCESS SEND SMS
 * =========================================================
 */

function rud_crm_frontend_process_send_sms() {

    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_sms_send_action']
                ?? ''
            )
        );

    if (
        'send_sms' !==
        $action
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_sms_can_send_for_customer(
            $customer_id
        )
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_sms_send_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_sms_send_nonce']
                )
            ),
            'rud_crm_send_sms_' .
            $customer_id
        )
    ) {
        return;
    }

    if (
        ! function_exists(
            'rud_crm_send_sms'
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_sms_customer_url(
                $customer_id,
                array(
                    'rud_sms_send_error' =>
                        'sms_sender_unavailable',
                )
            )
        );

        exit;
    }

    $result =
        rud_crm_send_sms(
            array(

                'customer_id' =>
                    $customer_id,

                'contact_id' =>
                    absint(
                        $_POST['contact_id']
                        ?? 0
                    ),

                'project_id' =>
                    absint(
                        $_POST['project_id']
                        ?? 0
                    ),

                'task_id' =>
                    absint(
                        $_POST['task_id']
                        ?? 0
                    ),

                'template_id' =>
                    absint(
                        $_POST['template_id']
                        ?? 0
                    ),

                'message' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['message']
                            ?? ''
                        )
                    ),
            )
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_sms_customer_url(
                $customer_id,
                array(
                    'rud_sms_send_error' =>
                        $result->get_error_code(),
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        rud_crm_frontend_sms_customer_url(
            $customer_id,
            array(
                'rud_sms_send_message' =>
                    'sent',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_send_sms',
    86
);


/*
 * =========================================================
 * MESSAGE
 * =========================================================
 */

function rud_crm_frontend_sms_send_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_sms_send_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_sms_send_error']
                ?? ''
            )
        );

    if (
        'sent' ===
        $message
    ) {

        return
            '<div class="rud-crm-sms-send-message rud-crm-sms-send-success">' .
            'SMS sent successfully.' .
            '</div>';
    }

    if (
        $error
    ) {

        $text =
            'SMS could not be sent.';

        $messages =
            array(

                'sms_sender_unavailable' =>
                    'The SMS Sender module is not available.',

                'sms_recipient_missing' =>
                    'No mobile number is saved for the selected recipient.',

                'sms_twilio_credentials_missing' =>
                    'Twilio Account SID and Auth Token are required.',

                'sms_sender_missing' =>
                    'A Sender Number / Sender ID or Messaging Service SID is required.',

                'sms_template_unavailable' =>
                    'The selected SMS Template is not available.',

                'sms_message_required' =>
                    'SMS Message is required.',

                'sms_twilio_send_failed' =>
                    'Twilio could not send the SMS.',
            );

        if (
            isset(
                $messages[
                    $error
                ]
            )
        ) {

            $text =
                $messages[
                    $error
                ];
        }

        return
            '<div class="rud-crm-sms-send-message rud-crm-sms-send-error">' .
            esc_html(
                $text
            ) .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * CONTACT OPTIONS
 * =========================================================
 */

function rud_crm_frontend_sms_contact_options(
    $customer_id
) {

    $options =
        array(
            0 =>
                'Main Customer / Company Mobile',
        );

    if (
        ! function_exists(
            'rud_crm_get_company_contacts'
        )
    ) {
        return $options;
    }

    $contacts =
        rud_crm_get_company_contacts(
            $customer_id
        );

    foreach (
        $contacts
        as
        $contact
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $contact->first_name ?? '',
                            $contact->middle_name ?? '',
                            $contact->last_name ?? '',
                        )
                    )
                )
            );

        if (
            '' ===
            $name
        ) {
            continue;
        }

        $number =
            trim(
                (string)
                (
                    $contact->mobile_number
                    ?: $contact->whatsapp
                )
            );

        $label =
            $name;

        if (
            $number
        ) {

            $label .=
                ' — ' .
                $number;
        }

        $options[
            absint(
                $contact->id
            )
        ] =
            $label;
    }

    return $options;
}


/*
 * =========================================================
 * SEND SMS PANEL
 * =========================================================
 */

function rud_crm_frontend_customer_sms_panel(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! rud_crm_frontend_sms_can_send_for_customer(
            $customer_id
        )
        ||
        ! function_exists(
            'rud_crm_get_sms_templates'
        )
    ) {
        return '';
    }

    $templates =
        rud_crm_get_sms_templates(
            'active'
        );

    $contact_options =
        rud_crm_frontend_sms_contact_options(
            $customer_id
        );

    $project_options =
        function_exists(
            'rud_crm_frontend_email_project_options'
        )
        ? rud_crm_frontend_email_project_options(
            $customer_id
        )
        : array(
            0 => 'No Project',
        );

    $task_options =
        function_exists(
            'rud_crm_frontend_email_task_options'
        )
        ? rud_crm_frontend_email_task_options(
            $customer_id
        )
        : array(
            0 => 'No Task',
        );

    ob_start();

    ?>

    <section class="rud-crm-send-sms-section">

        <div class="rud-crm-send-sms-header">

            <h2>
                SEND SMS
            </h2>

            <p>
                Send an SMS to the customer or a connected contact person.
            </p>

        </div>

        <?php
        echo rud_crm_frontend_sms_send_message_html();
        ?>

        <details class="rud-crm-send-sms-panel">

            <summary>
                + COMPOSE SMS
            </summary>

            <div class="rud-crm-send-sms-form-wrap">

                <form method="post">

                    <?php
                    wp_nonce_field(
                        'rud_crm_send_sms_' .
                        $customer_id,
                        'rud_crm_sms_send_nonce'
                    );
                    ?>

                    <input
                        type="hidden"
                        name="rud_crm_sms_send_action"
                        value="send_sms"
                    >

                    <input
                        type="hidden"
                        name="rud_customer_id"
                        value="<?php echo esc_attr( $customer_id ); ?>"
                    >

                    <div class="rud-crm-send-sms-grid">

                        <div>

                            <label>
                                Recipient
                            </label>

                            <select name="contact_id">

                                <?php foreach ( $contact_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                SMS Template
                            </label>

                            <select
                                name="template_id"
                                data-rud-sms-template-select
                            >

                                <option value="0">
                                    Custom SMS
                                </option>

                                <?php foreach ( $templates as $template ) : ?>

                                    <option
                                        value="<?php echo esc_attr( $template->id ); ?>"
                                        data-message="<?php echo esc_attr( $template->message ); ?>"
                                    >
                                        <?php echo esc_html( $template->template_name ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                Project
                            </label>

                            <select name="project_id">

                                <?php foreach ( $project_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                Task
                            </label>

                            <select name="task_id">

                                <?php foreach ( $task_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="rud-crm-send-sms-wide">

                            <label>
                                SMS Message
                            </label>

                            <textarea
                                name="message"
                                rows="6"
                                maxlength="1600"
                                data-rud-sms-message
                                placeholder="Write your SMS here or select a template."
                            ></textarea>

                        </div>

                    </div>

                    <div class="rud-crm-send-sms-note">
                        Template variables are replaced automatically when the SMS is sent.
                    </div>

                    <button
                        type="submit"
                        class="rud-crm-send-sms-button"
                        onclick="return confirm('Send this SMS now?');"
                    >
                        SEND SMS
                    </button>

                </form>

            </div>

        </details>

    </section>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * STYLES + TEMPLATE PREVIEW
 * =========================================================
 */

function rud_crm_frontend_send_sms_assets() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-send-sms-section {
        width:100%;
        margin-top:28px;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
        box-sizing:border-box;
    }

    .rud-crm-send-sms-section * {
        box-sizing:border-box;
    }

    .rud-crm-send-sms-header h2 {
        margin:0 0 5px !important;
    }

    .rud-crm-send-sms-header p {
        margin:0 0 18px;
        color:#667085;
    }

    .rud-crm-send-sms-panel {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-send-sms-panel summary {
        padding:14px 16px;
        cursor:pointer;
        font-weight:700;
        list-style:none;
    }

    .rud-crm-send-sms-panel summary::-webkit-details-marker {
        display:none;
    }

    .rud-crm-send-sms-form-wrap {
        padding:18px;
        border-top:1px solid #eaecf0;
        background:#f9fafb;
    }

    .rud-crm-send-sms-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-send-sms-wide {
        grid-column:1 / -1;
    }

    .rud-crm-send-sms-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-send-sms-grid select,
    .rud-crm-send-sms-grid textarea {
        width:100%;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-send-sms-note {
        margin-top:10px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-send-sms-button {
        min-height:38px;
        margin-top:16px;
        padding:8px 13px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-sms-send-message {
        margin-bottom:16px;
        padding:11px 13px;
        border-radius:7px;
    }

    .rud-crm-sms-send-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-sms-send-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:700px) {

        .rud-crm-send-sms-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-send-sms-wide {
            grid-column:auto;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-send-sms',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-send-sms'
    );

    wp_add_inline_style(
        'rud-crm-frontend-send-sms',
        $css
    );


    $js = <<<'JS'
document.addEventListener('change', function (event) {

    if (
        ! event.target.matches(
            '[data-rud-sms-template-select]'
        )
    ) {
        return;
    }

    var option =
        event.target.options[
            event.target.selectedIndex
        ];

    var form =
        event.target.closest('form');

    if (!form) {
        return;
    }

    var message =
        form.querySelector(
            '[data-rud-sms-message]'
        );

    if (!message) {
        return;
    }

    if (
        event.target.value === '0'
    ) {
        message.value = '';
        return;
    }

    message.value =
        option.getAttribute(
            'data-message'
        )
        || '';
});
JS;

    wp_register_script(
        'rud-crm-frontend-send-sms',
        '',
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0',
        true
    );

    wp_enqueue_script(
        'rud-crm-frontend-send-sms'
    );

    wp_add_inline_script(
        'rud-crm-frontend-send-sms',
        $js
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_send_sms_assets',
    91
);
