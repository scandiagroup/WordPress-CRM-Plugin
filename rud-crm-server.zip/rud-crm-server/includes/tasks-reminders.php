<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * TASKS / REMINDERS / TO DO
 * Version 1.2
 * =========================================================
 *
 * Foundation for:
 * - TO DO LIST
 * - Reminders / Alarms
 * - Customer tasks
 * - Company tasks
 * - Contact Person tasks
 * - Project tasks
 * - Future email reminders
 * - Future SMS reminders
 *
 * =========================================================
 */


/*
 * =========================================================
 * TABLE NAME
 * =========================================================
 */

function rud_crm_tasks_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_tasks';
}


/*
 * =========================================================
 * TASK STATUS OPTIONS
 * =========================================================
 */

function rud_crm_task_statuses() {

    return array(

        'inactive' =>
            'Inactive',

        'active' =>
            'Active',

        'in_progress' =>
            'In Progress',

        'waiting' =>
            'Waiting',

        'on_hold' =>
            'On Hold',

        'completed' =>
            'Completed',

        'cancelled' =>
            'Cancelled',
    );
}


/*
 * =========================================================
 * TASK TYPE OPTIONS
 * =========================================================
 */

function rud_crm_task_types() {

    return array(

        'general' =>
            'General',

        'call' =>
            'Call',

        'email' =>
            'Email',

        'meeting' =>
            'Meeting',

        'follow_up' =>
            'Follow-up',

        'send_document' =>
            'Send Document',

        'proposal' =>
            'Proposal',

        'invoice' =>
            'Invoice',

        'payment' =>
            'Payment',

        'project' =>
            'Project',

        'other' =>
            'Other',
    );
}


/*
 * =========================================================
 * PRIORITY OPTIONS
 * =========================================================
 */

function rud_crm_task_priorities() {

    return array(

        'low' =>
            'Low',

        'normal' =>
            'Normal',

        'high' =>
            'High',

        'urgent' =>
            'Urgent',
    );
}


/*
 * =========================================================
 * REMINDER OPTIONS
 * =========================================================
 */

function rud_crm_task_reminder_options() {

    return array(

        'none' =>
            'No Reminder',

        'at_due_time' =>
            'At Due Time',

        '5_minutes' =>
            '5 Minutes Before',

        '15_minutes' =>
            '15 Minutes Before',

        '30_minutes' =>
            '30 Minutes Before',

        '1_hour' =>
            '1 Hour Before',

        '2_hours' =>
            '2 Hours Before',

        '4_hours' =>
            '4 Hours Before',

        '1_day' =>
            '1 Day Before',

        '2_days' =>
            '2 Days Before',

        '1_week' =>
            '1 Week Before',

        'custom' =>
            'Custom',
    );
}


/*
 * =========================================================
 * NOTIFICATION CHANNEL OPTIONS
 * =========================================================
 */

function rud_crm_task_notification_channels() {

    return array(

        'crm' =>
            'CRM Notification',

        'email' =>
            'Email',

        'sms' =>
            'SMS',
    );
}


/*
 * =========================================================
 * CREATE / ENSURE TABLE
 * =========================================================
 */

function rud_crm_ensure_tasks_table() {

    global $wpdb;

    $table =
        rud_crm_tasks_table();

    $charset_collate =
        $wpdb->get_charset_collate();

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $sql =
        "CREATE TABLE {$table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            task_uuid CHAR(36) NOT NULL,

            title VARCHAR(255) NOT NULL DEFAULT '',
            description LONGTEXT NULL,

            task_type VARCHAR(50) NOT NULL DEFAULT 'general',
            status VARCHAR(50) NOT NULL DEFAULT 'active',
            priority VARCHAR(30) NOT NULL DEFAULT 'normal',

            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            assigned_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            due_date DATE NULL,
            due_time TIME NULL,
            due_at DATETIME NULL,

            reminder_type VARCHAR(50) NOT NULL DEFAULT 'none',
            reminder_at DATETIME NULL,
            reminder_custom_minutes INT UNSIGNED NOT NULL DEFAULT 0,

            notify_crm TINYINT(1) NOT NULL DEFAULT 1,
            notify_email TINYINT(1) NOT NULL DEFAULT 0,
            notify_sms TINYINT(1) NOT NULL DEFAULT 0,

            email_template_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            completed_at DATETIME NULL,
            completed_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            snoozed_until DATETIME NULL,

            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,

            PRIMARY KEY  (id),
            UNIQUE KEY task_uuid (task_uuid),

            KEY customer_id (customer_id),
            KEY contact_id (contact_id),
            KEY project_id (project_id),
            KEY assigned_user_id (assigned_user_id),
            KEY created_by (created_by),

            KEY status (status),
            KEY task_type (task_type),
            KEY priority (priority),

            KEY due_at (due_at),
            KEY reminder_at (reminder_at),
            KEY completed_at (completed_at)

        ) {$charset_collate};";

    dbDelta(
        $sql
    );
}


add_action(
    'admin_init',
    'rud_crm_ensure_tasks_table'
);


add_action(
    'init',
    'rud_crm_ensure_tasks_table',
    25
);


/*
 * =========================================================
 * UUID
 * =========================================================
 */

function rud_crm_generate_task_uuid() {

    return
        wp_generate_uuid4();
}


/*
 * =========================================================
 * SANITIZE TASK DATA
 * =========================================================
 */

function rud_crm_sanitize_task_data(
    $data
) {

    $statuses =
        rud_crm_task_statuses();

    $types =
        rud_crm_task_types();

    $priorities =
        rud_crm_task_priorities();

    $reminders =
        rud_crm_task_reminder_options();

    $status =
        sanitize_key(
            $data['status']
            ?? 'active'
        );

    if (
        ! isset(
            $statuses[
                $status
            ]
        )
    ) {
        $status =
            'active';
    }

    $task_type =
        sanitize_key(
            $data['task_type']
            ?? 'general'
        );

    if (
        ! isset(
            $types[
                $task_type
            ]
        )
    ) {
        $task_type =
            'general';
    }

    $priority =
        sanitize_key(
            $data['priority']
            ?? 'normal'
        );

    if (
        ! isset(
            $priorities[
                $priority
            ]
        )
    ) {
        $priority =
            'normal';
    }

    $reminder_type =
        sanitize_key(
            $data['reminder_type']
            ?? 'none'
        );

    if (
        ! isset(
            $reminders[
                $reminder_type
            ]
        )
    ) {
        $reminder_type =
            'none';
    }

    $due_date =
        sanitize_text_field(
            $data['due_date']
            ?? ''
        );

    $due_time =
        sanitize_text_field(
            $data['due_time']
            ?? ''
        );

    $due_date =
        preg_match(
            '/^\d{4}-\d{2}-\d{2}$/',
            $due_date
        )
        ? $due_date
        : '';

    $due_time =
        preg_match(
            '/^\d{2}:\d{2}(:\d{2})?$/',
            $due_time
        )
        ? $due_time
        : '';

    if (
        $due_time
        &&
        5 ===
        strlen(
            $due_time
        )
    ) {
        $due_time .= ':00';
    }

    $due_at =
        null;

    if (
        $due_date
    ) {

        $due_at =
            $due_date .
            ' ' .
            (
                $due_time
                ? $due_time
                : '23:59:59'
            );
    }

    return array(

        'title' =>
            sanitize_text_field(
                $data['title']
                ?? ''
            ),

        'description' =>
            sanitize_textarea_field(
                $data['description']
                ?? ''
            ),

        'task_type' =>
            $task_type,

        'status' =>
            $status,

        'priority' =>
            $priority,

        'customer_id' =>
            absint(
                $data['customer_id']
                ?? 0
            ),

        'contact_id' =>
            absint(
                $data['contact_id']
                ?? 0
            ),

        'project_id' =>
            absint(
                $data['project_id']
                ?? 0
            ),

        'assigned_user_id' =>
            absint(
                $data['assigned_user_id']
                ?? 0
            ),

        'due_date' =>
            $due_date
            ? $due_date
            : null,

        'due_time' =>
            $due_time
            ? $due_time
            : null,

        'due_at' =>
            $due_at,

        'reminder_type' =>
            $reminder_type,

        'reminder_custom_minutes' =>
            absint(
                $data['reminder_custom_minutes']
                ?? 0
            ),

        'notify_crm' =>
            ! empty(
                $data['notify_crm']
            )
            ? 1
            : 0,

        'notify_email' =>
            ! empty(
                $data['notify_email']
            )
            ? 1
            : 0,

        'notify_sms' =>
            ! empty(
                $data['notify_sms']
            )
            ? 1
            : 0,

        'email_template_id' =>
            absint(
                $data['email_template_id']
                ?? 0
            ),
    );
}


/*
 * =========================================================
 * CALCULATE REMINDER DATE/TIME
 * =========================================================
 */

function rud_crm_task_calculate_reminder_at(
    $due_at,
    $reminder_type,
    $custom_minutes = 0
) {

    if (
        ! $due_at
        ||
        'none' ===
        $reminder_type
    ) {
        return null;
    }

    /*
     * Interpret the task date/time in the WordPress timezone.
     * This is important when the site uses Europe/Oslo.
     */
    try {

        $due_datetime =
            new DateTimeImmutable(
                $due_at,
                wp_timezone()
            );

    } catch ( Exception $e ) {

        return null;
    }

    $minutes = 0;

    switch (
        $reminder_type
    ) {

        case '5_minutes':
            $minutes = 5;
            break;

        case '15_minutes':
            $minutes = 15;
            break;

        case '30_minutes':
            $minutes = 30;
            break;

        case '1_hour':
            $minutes = 60;
            break;

        case '2_hours':
            $minutes = 120;
            break;

        case '4_hours':
            $minutes = 240;
            break;

        case '1_day':
            $minutes = 1440;
            break;

        case '2_days':
            $minutes = 2880;
            break;

        case '1_week':
            $minutes = 10080;
            break;

        case 'custom':
            $minutes =
                absint(
                    $custom_minutes
                );
            break;

        case 'at_due_time':
        default:
            $minutes = 0;
            break;
    }

    if (
        $minutes > 0
    ) {

        $due_datetime =
            $due_datetime->modify(
                '-' .
                $minutes .
                ' minutes'
            );
    }

    return
        $due_datetime->format(
            'Y-m-d H:i:s'
        );
}


/*
 * =========================================================
 * CREATE TASK
 * =========================================================
 */

function rud_crm_create_task(
    $data
) {

    global $wpdb;

    $data =
        rud_crm_sanitize_task_data(
            $data
        );

    if (
        '' ===
        trim(
            $data['title']
        )
    ) {

        return new WP_Error(
            'task_title_required',
            'Task title is required.'
        );
    }

    if (
        ! $data['assigned_user_id']
    ) {
        $data['assigned_user_id'] =
            get_current_user_id();
    }

    $data['reminder_at'] =
        rud_crm_task_calculate_reminder_at(
            $data['due_at'],
            $data['reminder_type'],
            $data['reminder_custom_minutes']
        );

    $now =
        current_time(
            'mysql'
        );

    $insert =
        array_merge(
            $data,
            array(

                'task_uuid' =>
                    rud_crm_generate_task_uuid(),

                'created_by' =>
                    get_current_user_id(),

                'completed_at' =>
                    null,

                'completed_by' =>
                    0,

                'snoozed_until' =>
                    null,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    $result =
        $wpdb->insert(
            rud_crm_tasks_table(),
            $insert
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'task_create_failed',
            'The task could not be created.'
        );
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * GET ONE TASK
 * =========================================================
 */

function rud_crm_get_task(
    $task_id
) {

    global $wpdb;

    $task_id =
        absint(
            $task_id
        );

    if (
        ! $task_id
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_tasks_table() .
                "
                 WHERE id = %d
                 LIMIT 1",
                $task_id
            )
        );
}


/*
 * =========================================================
 * GET TASKS
 * =========================================================
 */

function rud_crm_get_tasks(
    $args = array()
) {

    global $wpdb;

    $defaults =
        array(

            'customer_id' =>
                0,

            'contact_id' =>
                0,

            'project_id' =>
                0,

            'assigned_user_id' =>
                0,

            'status' =>
                '',

            'include_completed' =>
                true,

            'limit' =>
                100,
        );

    $args =
        wp_parse_args(
            $args,
            $defaults
        );

    $where =
        array(
            '1=1'
        );

    $values =
        array();

    if (
        $args['customer_id']
    ) {

        $where[] =
            'customer_id = %d';

        $values[] =
            absint(
                $args['customer_id']
            );
    }

    if (
        $args['contact_id']
    ) {

        $where[] =
            'contact_id = %d';

        $values[] =
            absint(
                $args['contact_id']
            );
    }

    if (
        $args['project_id']
    ) {

        $where[] =
            'project_id = %d';

        $values[] =
            absint(
                $args['project_id']
            );
    }

    if (
        $args['assigned_user_id']
    ) {

        $where[] =
            'assigned_user_id = %d';

        $values[] =
            absint(
                $args['assigned_user_id']
            );
    }

    if (
        $args['status']
    ) {

        $where[] =
            'status = %s';

        $values[] =
            sanitize_key(
                $args['status']
            );
    }

    if (
        ! $args['include_completed']
    ) {

        $where[] =
            "status NOT IN ('completed','cancelled')";
    }

    $limit =
        max(
            1,
            min(
                500,
                absint(
                    $args['limit']
                )
            )
        );

    $sql =
        "SELECT *
         FROM " .
        rud_crm_tasks_table() .
        "
         WHERE " .
        implode(
            ' AND ',
            $where
        ) .
        "
         ORDER BY
            CASE status
                WHEN 'in_progress' THEN 1
                WHEN 'active' THEN 2
                WHEN 'waiting' THEN 3
                WHEN 'on_hold' THEN 4
                WHEN 'inactive' THEN 5
                WHEN 'completed' THEN 6
                WHEN 'cancelled' THEN 7
                ELSE 8
            END,
            CASE priority
                WHEN 'urgent' THEN 1
                WHEN 'high' THEN 2
                WHEN 'normal' THEN 3
                WHEN 'low' THEN 4
                ELSE 5
            END,
            due_at IS NULL,
            due_at ASC,
            id DESC
         LIMIT {$limit}";

    if (
        ! empty(
            $values
        )
    ) {

        $sql =
            $wpdb->prepare(
                $sql,
                $values
            );
    }

    return
        $wpdb->get_results(
            $sql
        );
}


/*
 * =========================================================
 * UPDATE TASK
 * =========================================================
 */

function rud_crm_update_task(
    $task_id,
    $data
) {

    global $wpdb;

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
    ) {

        return new WP_Error(
            'task_not_found',
            'Task could not be found.'
        );
    }

    $data =
        rud_crm_sanitize_task_data(
            array_merge(
                (array)
                $task,
                $data
            )
        );

    if (
        '' ===
        trim(
            $data['title']
        )
    ) {

        return new WP_Error(
            'task_title_required',
            'Task title is required.'
        );
    }

    $data['reminder_at'] =
        rud_crm_task_calculate_reminder_at(
            $data['due_at'],
            $data['reminder_type'],
            $data['reminder_custom_minutes']
        );

    $data['updated_at'] =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->update(
            rud_crm_tasks_table(),
            $data,
            array(
                'id' =>
                    absint(
                        $task_id
                    ),
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'task_update_failed',
            'The task could not be updated.'
        );
    }

    return true;
}


/*
 * =========================================================
 * MARK TASK COMPLETED
 * =========================================================
 */

function rud_crm_complete_task(
    $task_id
) {

    global $wpdb;

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
    ) {
        return false;
    }

    return
        false !==
        $wpdb->update(
            rud_crm_tasks_table(),
            array(

                'status' =>
                    'completed',

                'completed_at' =>
                    current_time(
                        'mysql'
                    ),

                'completed_by' =>
                    get_current_user_id(),

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    absint(
                        $task_id
                    ),
            )
        );
}


/*
 * =========================================================
 * REOPEN TASK
 * =========================================================
 */

function rud_crm_reopen_task(
    $task_id
) {

    global $wpdb;

    return
        false !==
        $wpdb->update(
            rud_crm_tasks_table(),
            array(

                'status' =>
                    'active',

                'completed_at' =>
                    null,

                'completed_by' =>
                    0,

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    absint(
                        $task_id
                    ),
            )
        );
}


/*
 * =========================================================
 * SNOOZE TASK
 * =========================================================
 */

function rud_crm_snooze_task(
    $task_id,
    $until
) {

    global $wpdb;

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
    ) {
        return false;
    }

    $timestamp =
        strtotime(
            $until
        );

    if (
        ! $timestamp
    ) {
        return false;
    }

    $snoozed_until =
        wp_date(
            'Y-m-d H:i:s',
            $timestamp
        );

    return
        false !==
        $wpdb->update(
            rud_crm_tasks_table(),
            array(

                'status' =>
                    'on_hold',

                'snoozed_until' =>
                    $snoozed_until,

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    absint(
                        $task_id
                    ),
            )
        );
}


/*
 * =========================================================
 * DELETE TASK
 * =========================================================
 */

function rud_crm_delete_task(
    $task_id
) {

    global $wpdb;

    return
        false !==
        $wpdb->delete(
            rud_crm_tasks_table(),
            array(
                'id' =>
                    absint(
                        $task_id
                    ),
            ),
            array(
                '%d',
            )
        );
}


/*
 * =========================================================
 * OVERDUE CHECK
 * =========================================================
 */

function rud_crm_task_is_overdue(
    $task
) {

    if (
        ! $task
        ||
        empty(
            $task->due_at
        )
        ||
        in_array(
            $task->status,
            array(
                'completed',
                'cancelled',
            ),
            true
        )
    ) {
        return false;
    }

    $due =
        strtotime(
            $task->due_at
        );

    if (
        ! $due
    ) {
        return false;
    }

    return
        $due <
        current_time(
            'timestamp'
        );
}


/*
 * =========================================================
 * DISPLAY STATUS
 * =========================================================
 */

function rud_crm_task_display_status(
    $task
) {

    if (
        rud_crm_task_is_overdue(
            $task
        )
    ) {
        return 'Overdue';
    }

    $statuses =
        rud_crm_task_statuses();

    return
        $statuses[
            $task->status
        ]
        ??
        ucfirst(
            str_replace(
                '_',
                ' ',
                $task->status
            )
        );
}
