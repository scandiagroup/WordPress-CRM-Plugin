<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * SMS SENDER
 * Version 1.0
 * =========================================================
 *
 * Twilio SMS delivery via WordPress HTTP API.
 *
 * Provides:
 * - Resolve Customer / Contact Person mobile number
 * - Send custom SMS
 * - Send SMS from saved template
 * - Apply template variables
 * - SMS delivery log
 *
 * =========================================================
 */


/*
 * =========================================================
 * RESOLVE RECIPIENT
 * =========================================================
 */

function rud_crm_sms_resolve_recipient(
    $customer_id,
    $contact_id = 0
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    $contact_id =
        absint(
            $contact_id
        );


    /*
     * Contact Person has priority.
     */
    if (
        $contact_id
        &&
        function_exists(
            'rud_crm_get_company_contact'
        )
    ) {

        $contact =
            rud_crm_get_company_contact(
                $contact_id
            );

        if (
            $contact
            &&
            absint(
                $contact->customer_id
            )
            ===
            $customer_id
        ) {

            $number =
                trim(
                    (string)
                    (
                        $contact->mobile_number
                        ?: $contact->whatsapp
                    )
                );

            if (
                '' !==
                $number
            ) {

                $name =
                    trim(
                        implode(
                            ' ',
                            array_filter(
                                array(
                                    $contact->first_name ?? '',
                                    $contact->middle_name ?? '',
                                    $contact->last_name ?? '',
                                )
                            )
                        )
                    );

                return array(

                    'name' =>
                        $name,

                    'number' =>
                        $number,

                    'contact_id' =>
                        $contact_id,
                );
            }
        }
    }


    /*
     * Main Customer / Company mobile number.
     */
    if (
        ! $customer_id
    ) {

        return new WP_Error(
            'sms_recipient_missing',
            'No customer or contact recipient was selected.'
        );
    }


    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );

    if (
        ! $customer
    ) {

        return new WP_Error(
            'sms_customer_not_found',
            'Customer could not be found.'
        );
    }


    $number = '';

    if (
        function_exists(
            'rud_crm_frontend_contact'
        )
    ) {

        $number =
            trim(
                (string)
                rud_crm_frontend_contact(
                    $customer_id,
                    'mobile_phone'
                )
            );

        if (
            '' ===
            $number
        ) {

            $number =
                trim(
                    (string)
                    rud_crm_frontend_contact(
                        $customer_id,
                        'whatsapp'
                    )
                );
        }
    }


    if (
        '' ===
        $number
    ) {

        return new WP_Error(
            'sms_recipient_missing',
            'No mobile number is saved for this customer or contact person.'
        );
    }


    $name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $customer->first_name ?? '',
                        $customer->middle_name ?? '',
                        $customer->last_name ?? '',
                    )
                )
            )
        );

    if (
        '' ===
        $name
    ) {

        $name =
            trim(
                (string)
                (
                    $customer->company_name
                    ?? ''
                )
            );
    }


    return array(

        'name' =>
            $name,

        'number' =>
            $number,

        'contact_id' =>
            0,
    );
}


/*
 * =========================================================
 * UPDATE SMS LOG RESULT
 * =========================================================
 */

function rud_crm_update_sms_log_result(
    $log_id,
    $status,
    $provider_message_id = '',
    $error_message = ''
) {

    global $wpdb;

    $log_id =
        absint(
            $log_id
        );

    if (
        ! $log_id
        ||
        ! function_exists(
            'rud_crm_sms_log_table'
        )
    ) {
        return false;
    }

    $data =
        array(

            'status' =>
                sanitize_key(
                    $status
                ),

            'provider_message_id' =>
                sanitize_text_field(
                    $provider_message_id
                ),

            'error_message' =>
                sanitize_textarea_field(
                    $error_message
                ),
        );

    if (
        'sent' ===
        $status
    ) {

        $data['sent_at'] =
            current_time(
                'mysql'
            );
    }

    return
        false !==
        $wpdb->update(
            rud_crm_sms_log_table(),
            $data,
            array(
                'id' =>
                    $log_id,
            )
        );
}


/*
 * =========================================================
 * TWILIO SEND
 * =========================================================
 */

function rud_crm_sms_send_via_twilio(
    $to_number,
    $message,
    $settings
) {

    $account_sid =
        trim(
            (string)
            (
                $settings['account_sid']
                ?? ''
            )
        );

    $auth_token =
        trim(
            (string)
            (
                $settings['auth_token']
                ?? ''
            )
        );

    $sender_id =
        trim(
            (string)
            (
                $settings['sender_id']
                ?? ''
            )
        );

    $messaging_service_sid =
        trim(
            (string)
            (
                $settings['messaging_service_sid']
                ?? ''
            )
        );


    if (
        '' ===
        $account_sid
        ||
        '' ===
        $auth_token
    ) {

        return new WP_Error(
            'sms_twilio_credentials_missing',
            'Twilio Account SID and Auth Token are required.'
        );
    }


    if (
        '' ===
        $messaging_service_sid
        &&
        '' ===
        $sender_id
    ) {

        return new WP_Error(
            'sms_sender_missing',
            'A Sender Number / Sender ID or Messaging Service SID is required.'
        );
    }


    $endpoint =
        'https://api.twilio.com/2010-04-01/Accounts/' .
        rawurlencode(
            $account_sid
        ) .
        '/Messages.json';


    $body =
        array(

            'To' =>
                $to_number,

            'Body' =>
                $message,
        );


    if (
        '' !==
        $messaging_service_sid
    ) {

        $body['MessagingServiceSid'] =
            $messaging_service_sid;

    } else {

        $body['From'] =
            $sender_id;
    }


    $response =
        wp_remote_post(
            $endpoint,
            array(

                'timeout' =>
                    20,

                'headers' =>
                    array(

                        'Authorization' =>
                            'Basic ' .
                            base64_encode(
                                $account_sid .
                                ':' .
                                $auth_token
                            ),
                    ),

                'body' =>
                    $body,
            )
        );


    if (
        is_wp_error(
            $response
        )
    ) {
        return $response;
    }


    $status_code =
        wp_remote_retrieve_response_code(
            $response
        );

    $response_body =
        wp_remote_retrieve_body(
            $response
        );

    $decoded =
        json_decode(
            $response_body,
            true
        );


    if (
        $status_code >= 200
        &&
        $status_code < 300
    ) {

        return array(

            'success' =>
                true,

            'provider_message_id' =>
                sanitize_text_field(
                    $decoded['sid']
                    ?? ''
                ),

            'provider_status' =>
                sanitize_text_field(
                    $decoded['status']
                    ?? ''
                ),
        );
    }


    $error_message =
        'Twilio could not send the SMS.';

    if (
        is_array(
            $decoded
        )
        &&
        ! empty(
            $decoded['message']
        )
    ) {

        $error_message =
            sanitize_text_field(
                $decoded['message']
            );
    }


    return new WP_Error(
        'sms_twilio_send_failed',
        $error_message
    );
}


/*
 * =========================================================
 * SEND SMS
 * =========================================================
 */

function rud_crm_send_sms(
    $args
) {

    if (
        ! function_exists(
            'rud_crm_get_sms_settings'
        )
        ||
        ! function_exists(
            'rud_crm_create_sms_log'
        )
    ) {

        return new WP_Error(
            'sms_system_unavailable',
            'The RUD CRM SMS System is not available.'
        );
    }


    $args =
        wp_parse_args(
            $args,
            array(

                'customer_id' =>
                    0,

                'contact_id' =>
                    0,

                'project_id' =>
                    0,

                'task_id' =>
                    0,

                'template_id' =>
                    0,

                'message' =>
                    '',
            )
        );


    $customer_id =
        absint(
            $args['customer_id']
        );

    $contact_id =
        absint(
            $args['contact_id']
        );

    $project_id =
        absint(
            $args['project_id']
        );

    $task_id =
        absint(
            $args['task_id']
        );

    $template_id =
        absint(
            $args['template_id']
        );


    $recipient =
        rud_crm_sms_resolve_recipient(
            $customer_id,
            $contact_id
        );

    if (
        is_wp_error(
            $recipient
        )
    ) {
        return $recipient;
    }


    $message =
        sanitize_textarea_field(
            $args['message']
        );


    if (
        $template_id
    ) {

        $template =
            rud_crm_get_sms_template(
                $template_id
            );

        if (
            ! $template
            ||
            'active' !==
            $template->status
        ) {

            return new WP_Error(
                'sms_template_unavailable',
                'The selected SMS Template is not available.'
            );
        }

        $message =
            $template->message;
    }


    if (
        '' ===
        trim(
            $message
        )
    ) {

        return new WP_Error(
            'sms_message_required',
            'SMS Message is required.'
        );
    }


    $context =
        array(

            'customer_id' =>
                $customer_id,

            'contact_id' =>
                $recipient['contact_id'],

            'project_id' =>
                $project_id,

            'task_id' =>
                $task_id,
        );


    $message =
        rud_crm_apply_sms_template_variables(
            $message,
            $context
        );


    $settings =
        rud_crm_get_sms_settings();

    $provider =
        sanitize_key(
            $settings['provider']
            ?? 'twilio'
        );


    $log_id =
        rud_crm_create_sms_log(
            array(

                'customer_id' =>
                    $customer_id,

                'contact_id' =>
                    $recipient['contact_id'],

                'project_id' =>
                    $project_id,

                'task_id' =>
                    $task_id,

                'template_id' =>
                    $template_id,

                'sent_by' =>
                    get_current_user_id(),

                'provider' =>
                    $provider,

                'from_number' =>
                    $settings['sender_id']
                    ?? '',

                'to_name' =>
                    $recipient['name'],

                'to_number' =>
                    $recipient['number'],

                'message' =>
                    $message,

                'status' =>
                    'pending',
            )
        );


    if (
        'twilio' !==
        $provider
    ) {

        $error =
            new WP_Error(
                'sms_provider_unsupported',
                'The selected SMS provider is not supported.'
            );

        if (
            $log_id
        ) {

            rud_crm_update_sms_log_result(
                $log_id,
                'failed',
                '',
                $error->get_error_message()
            );
        }

        return $error;
    }


    $result =
        rud_crm_sms_send_via_twilio(
            $recipient['number'],
            $message,
            $settings
        );


    if (
        is_wp_error(
            $result
        )
    ) {

        if (
            $log_id
        ) {

            rud_crm_update_sms_log_result(
                $log_id,
                'failed',
                '',
                $result->get_error_message()
            );
        }

        return $result;
    }


    if (
        $log_id
    ) {

        rud_crm_update_sms_log_result(
            $log_id,
            'sent',
            $result['provider_message_id']
            ?? ''
        );
    }


    return array(

        'success' =>
            true,

        'log_id' =>
            $log_id,

        'to_name' =>
            $recipient['name'],

        'to_number' =>
            $recipient['number'],

        'provider_message_id' =>
            $result['provider_message_id']
            ?? '',
    );
}
