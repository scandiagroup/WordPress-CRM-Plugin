<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END NOTIFICATION ALERT
 * Version 1.0
 * =========================================================
 *
 * Adds a compact notification indicator at the top of
 * the main CRM frontend for logged-in users.
 *
 * Shows only when unread CRM notifications exist.
 *
 * =========================================================
 */


/*
 * =========================================================
 * NOTIFICATION ALERT HTML
 * =========================================================
 */

function rud_crm_frontend_notification_alert_html() {

    if (
        ! is_user_logged_in()
        ||
        ! function_exists(
            'rud_crm_get_unread_notification_count'
        )
    ) {
        return '';
    }

    $user_id =
        get_current_user_id();

    $count =
        rud_crm_get_unread_notification_count(
            $user_id
        );

    if (
        $count < 1
    ) {
        return '';
    }

    $notifications_url =
        home_url(
            '/crm-notifications/'
        );

    $latest =
        function_exists(
            'rud_crm_get_user_notifications'
        )
        ? rud_crm_get_user_notifications(
            $user_id,
            array(
                'status' =>
                    'unread',

                'limit' =>
                    1,
            )
        )
        : array();

    $latest_title =
        '';

    if (
        ! empty(
            $latest
        )
        &&
        ! empty(
            $latest[0]->title
        )
    ) {

        $latest_title =
            sanitize_text_field(
                $latest[0]->title
            );
    }

    ob_start();

    ?>

    <div class="rud-crm-notification-alert">

        <div class="rud-crm-notification-alert-icon">
            !
        </div>

        <div class="rud-crm-notification-alert-content">

            <strong>
                <?php
                echo esc_html(
                    sprintf(
                        _n(
                            '%d unread CRM notification',
                            '%d unread CRM notifications',
                            $count,
                            'rud-crm-server'
                        ),
                        $count
                    )
                );
                ?>
            </strong>

            <?php if ( $latest_title ) : ?>

                <span>
                    Latest:
                    <?php echo esc_html( $latest_title ); ?>
                </span>

            <?php else : ?>

                <span>
                    You have a task reminder or CRM alert waiting.
                </span>

            <?php endif; ?>

        </div>

        <a
            href="<?php echo esc_url( $notifications_url ); ?>"
            class="rud-crm-notification-alert-button"
        >
            VIEW NOTIFICATIONS
        </a>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * PREFIX MAIN CRM SHORTCODE
 * =========================================================
 */

function rud_crm_frontend_add_notification_alert_to_crm(
    $output,
    $tag,
    $attr,
    $m
) {

    if (
        'rud_crm_frontend' !==
        $tag
    ) {
        return $output;
    }

    $alert =
        rud_crm_frontend_notification_alert_html();

    if (
        '' ===
        $alert
    ) {
        return $output;
    }

    return
        $alert .
        $output;
}


add_filter(
    'do_shortcode_tag',
    'rud_crm_frontend_add_notification_alert_to_crm',
    20,
    4
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_notification_alert_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-notification-alert {
        display:flex;
        align-items:center;
        gap:14px;
        width:100%;
        margin:0 0 20px;
        padding:14px 16px;
        border:1px solid #f1c36d;
        border-radius:10px;
        background:#fffaf0;
        box-sizing:border-box;
    }

    .rud-crm-notification-alert * {
        box-sizing:border-box;
    }

    .rud-crm-notification-alert-icon {
        display:flex;
        align-items:center;
        justify-content:center;
        flex:0 0 34px;
        width:34px;
        height:34px;
        border-radius:50%;
        background:#f79009;
        color:#fff;
        font-size:18px;
        font-weight:800;
    }

    .rud-crm-notification-alert-content {
        display:flex;
        flex-direction:column;
        gap:2px;
        min-width:0;
        flex:1 1 auto;
    }

    .rud-crm-notification-alert-content strong {
        font-size:14px;
    }

    .rud-crm-notification-alert-content span {
        color:#667085;
        font-size:12px;
        overflow-wrap:anywhere;
    }

    .rud-crm-notification-alert-button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:38px;
        padding:8px 13px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff !important;
        text-decoration:none !important;
        font-size:11px;
        font-weight:700;
        white-space:nowrap;
    }

    @media (max-width:700px) {

        .rud-crm-notification-alert {
            align-items:flex-start;
            flex-wrap:wrap;
        }

        .rud-crm-notification-alert-button {
            width:100%;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-notification-alert',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-notification-alert'
    );

    wp_add_inline_style(
        'rud-crm-frontend-notification-alert',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_notification_alert_styles',
    61
);
