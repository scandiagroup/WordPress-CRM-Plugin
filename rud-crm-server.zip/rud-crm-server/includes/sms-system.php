<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * SMS SYSTEM
 * Version 1.0
 * =========================================================
 *
 * Foundation for SMS delivery.
 *
 * Provides:
 * - SMS settings
 * - Provider selection
 * - SMS message templates
 * - SMS log
 * - Template variables
 *
 * Actual provider API sending is added in a separate sender
 * module after credentials have been configured and tested.
 *
 * =========================================================
 */


/*
 * =========================================================
 * TABLE NAMES
 * =========================================================
 */

function rud_crm_sms_templates_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_sms_templates';
}


function rud_crm_sms_log_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_sms_log';
}


/*
 * =========================================================
 * CREATE / UPDATE TABLES
 * =========================================================
 */

function rud_crm_ensure_sms_tables() {

    global $wpdb;

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $charset_collate =
        $wpdb->get_charset_collate();

    $templates_table =
        rud_crm_sms_templates_table();

    $log_table =
        rud_crm_sms_log_table();


    $sql_templates = "
        CREATE TABLE {$templates_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            template_name VARCHAR(190) NOT NULL DEFAULT '',
            message TEXT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'active',

            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,

            PRIMARY KEY (id),
            KEY status (status),
            KEY created_by (created_by)
        ) {$charset_collate};
    ";


    $sql_log = "
        CREATE TABLE {$log_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            task_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            template_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            sent_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            provider VARCHAR(50) NOT NULL DEFAULT '',

            from_number VARCHAR(100) NOT NULL DEFAULT '',
            to_name VARCHAR(190) NOT NULL DEFAULT '',
            to_number VARCHAR(100) NOT NULL DEFAULT '',

            message TEXT NULL,

            provider_message_id VARCHAR(190) NOT NULL DEFAULT '',
            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            error_message TEXT NULL,

            created_at DATETIME NULL,
            sent_at DATETIME NULL,

            PRIMARY KEY (id),

            KEY customer_id (customer_id),
            KEY contact_id (contact_id),
            KEY project_id (project_id),
            KEY task_id (task_id),
            KEY template_id (template_id),
            KEY sent_by (sent_by),
            KEY status (status)
        ) {$charset_collate};
    ";

    dbDelta(
        $sql_templates
    );

    dbDelta(
        $sql_log
    );
}


add_action(
    'init',
    'rud_crm_ensure_sms_tables',
    20
);


/*
 * =========================================================
 * SMS SETTINGS
 * =========================================================
 */

function rud_crm_get_sms_settings() {

    $defaults =
        array(

            'provider' =>
                'twilio',

            'sender_type' =>
                'number',

            'sender_id' =>
                '',

            'account_sid' =>
                '',

            'auth_token' =>
                '',

            'messaging_service_sid' =>
                '',
        );

    $settings =
        get_option(
            'rud_crm_sms_settings',
            array()
        );

    if (
        ! is_array(
            $settings
        )
    ) {
        $settings =
            array();
    }

    return
        wp_parse_args(
            $settings,
            $defaults
        );
}


function rud_crm_update_sms_settings(
    $settings
) {

    $current =
        rud_crm_get_sms_settings();

    $provider =
        sanitize_key(
            $settings['provider']
            ?? $current['provider']
        );

    if (
        ! in_array(
            $provider,
            array(
                'twilio',
            ),
            true
        )
    ) {
        $provider =
            'twilio';
    }

    $sender_type =
        sanitize_key(
            $settings['sender_type']
            ?? $current['sender_type']
        );

    if (
        ! in_array(
            $sender_type,
            array(
                'number',
                'alphanumeric',
            ),
            true
        )
    ) {
        $sender_type =
            'number';
    }

    $clean =
        array(

            'provider' =>
                $provider,

            'sender_type' =>
                $sender_type,

            'sender_id' =>
                sanitize_text_field(
                    $settings['sender_id']
                    ?? $current['sender_id']
                ),

            'account_sid' =>
                sanitize_text_field(
                    $settings['account_sid']
                    ?? $current['account_sid']
                ),

            'auth_token' =>
                sanitize_text_field(
                    $settings['auth_token']
                    ?? $current['auth_token']
                ),

            'messaging_service_sid' =>
                sanitize_text_field(
                    $settings['messaging_service_sid']
                    ?? $current['messaging_service_sid']
                ),
        );

    return
        update_option(
            'rud_crm_sms_settings',
            $clean,
            false
        );
}


/*
 * =========================================================
 * SMS TEMPLATE VARIABLES
 * =========================================================
 */

function rud_crm_sms_template_variables() {

    return array(

        '{company_name}' =>
            'Company Name',

        '{customer_name}' =>
            'Customer Name',

        '{customer_number}' =>
            'Customer Number',

        '{contact_first_name}' =>
            'Contact First Name',

        '{contact_last_name}' =>
            'Contact Last Name',

        '{contact_full_name}' =>
            'Contact Full Name',

        '{project_name}' =>
            'Project Name',

        '{project_number}' =>
            'Project Number',

        '{task_title}' =>
            'Task Title',

        '{due_date}' =>
            'Due Date',

        '{due_time}' =>
            'Due Time',

        '{site_name}' =>
            'Website Name',
    );
}


/*
 * =========================================================
 * TEMPLATE DATA SANITIZER
 * =========================================================
 */

function rud_crm_sms_template_sanitize_data(
    $data
) {

    $status =
        sanitize_key(
            $data['status']
            ?? 'active'
        );

    if (
        ! in_array(
            $status,
            array(
                'active',
                'inactive',
            ),
            true
        )
    ) {
        $status =
            'active';
    }

    return array(

        'template_name' =>
            sanitize_text_field(
                $data['template_name']
                ?? ''
            ),

        'message' =>
            sanitize_textarea_field(
                $data['message']
                ?? ''
            ),

        'status' =>
            $status,
    );
}


/*
 * =========================================================
 * GET TEMPLATE
 * =========================================================
 */

function rud_crm_get_sms_template(
    $template_id
) {

    global $wpdb;

    $template_id =
        absint(
            $template_id
        );

    if (
        ! $template_id
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_sms_templates_table() .
                "
                 WHERE id = %d
                 LIMIT 1",
                $template_id
            )
        );
}


/*
 * =========================================================
 * GET TEMPLATES
 * =========================================================
 */

function rud_crm_get_sms_templates(
    $status = ''
) {

    global $wpdb;

    $table =
        rud_crm_sms_templates_table();

    if (
        in_array(
            $status,
            array(
                'active',
                'inactive',
            ),
            true
        )
    ) {

        return
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$table}
                     WHERE status = %s
                     ORDER BY template_name ASC, id DESC",
                    $status
                )
            );
    }

    return
        $wpdb->get_results(
            "SELECT *
             FROM {$table}
             ORDER BY template_name ASC, id DESC"
        );
}


/*
 * =========================================================
 * CREATE TEMPLATE
 * =========================================================
 */

function rud_crm_create_sms_template(
    $data
) {

    global $wpdb;

    $data =
        rud_crm_sms_template_sanitize_data(
            $data
        );

    if (
        '' ===
        $data['template_name']
    ) {

        return new WP_Error(
            'sms_template_name_required',
            'Template Name is required.'
        );
    }

    if (
        '' ===
        trim(
            $data['message']
        )
    ) {

        return new WP_Error(
            'sms_template_message_required',
            'SMS Message is required.'
        );
    }

    $now =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->insert(
            rud_crm_sms_templates_table(),
            array(

                'template_name' =>
                    $data['template_name'],

                'message' =>
                    $data['message'],

                'status' =>
                    $data['status'],

                'created_by' =>
                    get_current_user_id(),

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'sms_template_create_failed',
            'The SMS Template could not be created.'
        );
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * UPDATE TEMPLATE
 * =========================================================
 */

function rud_crm_update_sms_template(
    $template_id,
    $data
) {

    global $wpdb;

    $template_id =
        absint(
            $template_id
        );

    if (
        ! $template_id
    ) {

        return new WP_Error(
            'sms_template_invalid',
            'Invalid SMS Template.'
        );
    }

    $data =
        rud_crm_sms_template_sanitize_data(
            $data
        );

    if (
        '' ===
        $data['template_name']
    ) {

        return new WP_Error(
            'sms_template_name_required',
            'Template Name is required.'
        );
    }

    if (
        '' ===
        trim(
            $data['message']
        )
    ) {

        return new WP_Error(
            'sms_template_message_required',
            'SMS Message is required.'
        );
    }

    $result =
        $wpdb->update(
            rud_crm_sms_templates_table(),
            array(

                'template_name' =>
                    $data['template_name'],

                'message' =>
                    $data['message'],

                'status' =>
                    $data['status'],

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    $template_id,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'sms_template_update_failed',
            'The SMS Template could not be updated.'
        );
    }

    return true;
}


/*
 * =========================================================
 * DELETE TEMPLATE
 * =========================================================
 */

function rud_crm_delete_sms_template(
    $template_id
) {

    global $wpdb;

    return
        false !==
        $wpdb->delete(
            rud_crm_sms_templates_table(),
            array(
                'id' =>
                    absint(
                        $template_id
                    ),
            )
        );
}


/*
 * =========================================================
 * CREATE SMS LOG ENTRY
 * =========================================================
 */

function rud_crm_create_sms_log(
    $data
) {

    global $wpdb;

    $data =
        wp_parse_args(
            $data,
            array(

                'customer_id' =>
                    0,

                'contact_id' =>
                    0,

                'project_id' =>
                    0,

                'task_id' =>
                    0,

                'template_id' =>
                    0,

                'sent_by' =>
                    0,

                'provider' =>
                    '',

                'from_number' =>
                    '',

                'to_name' =>
                    '',

                'to_number' =>
                    '',

                'message' =>
                    '',

                'provider_message_id' =>
                    '',

                'status' =>
                    'pending',

                'error_message' =>
                    '',

                'sent_at' =>
                    null,
            )
        );

    $result =
        $wpdb->insert(
            rud_crm_sms_log_table(),
            array(

                'customer_id' =>
                    absint(
                        $data['customer_id']
                    ),

                'contact_id' =>
                    absint(
                        $data['contact_id']
                    ),

                'project_id' =>
                    absint(
                        $data['project_id']
                    ),

                'task_id' =>
                    absint(
                        $data['task_id']
                    ),

                'template_id' =>
                    absint(
                        $data['template_id']
                    ),

                'sent_by' =>
                    absint(
                        $data['sent_by']
                    ),

                'provider' =>
                    sanitize_key(
                        $data['provider']
                    ),

                'from_number' =>
                    sanitize_text_field(
                        $data['from_number']
                    ),

                'to_name' =>
                    sanitize_text_field(
                        $data['to_name']
                    ),

                'to_number' =>
                    sanitize_text_field(
                        $data['to_number']
                    ),

                'message' =>
                    sanitize_textarea_field(
                        $data['message']
                    ),

                'provider_message_id' =>
                    sanitize_text_field(
                        $data['provider_message_id']
                    ),

                'status' =>
                    sanitize_key(
                        $data['status']
                    ),

                'error_message' =>
                    sanitize_textarea_field(
                        $data['error_message']
                    ),

                'created_at' =>
                    current_time(
                        'mysql'
                    ),

                'sent_at' =>
                    $data['sent_at'],
            )
        );

    if (
        false ===
        $result
    ) {
        return 0;
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * APPLY TEMPLATE VARIABLES
 * =========================================================
 */

function rud_crm_apply_sms_template_variables(
    $message,
    $context = array()
) {

    if (
        function_exists(
            'rud_crm_email_template_values'
        )
    ) {

        $values =
            rud_crm_email_template_values(
                $context
            );

        return
            strtr(
                (string)
                $message,
                $values
            );
    }

    return
        (string)
        $message;
}
