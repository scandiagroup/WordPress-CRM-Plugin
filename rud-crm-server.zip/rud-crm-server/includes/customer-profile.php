<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM CUSTOMER PROFILE
 * INTERNATIONAL PHONE FIELD VERSION
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * LOAD WORDPRESS MEDIA LIBRARY
 * ---------------------------------------------------------
 */

function rud_crm_customer_profile_media_library() {

    if (
        isset( $_GET['page'] ) &&
        'rud-crm-customers' === sanitize_key(
            wp_unslash( $_GET['page'] )
        ) &&
        isset( $_GET['customer_id'] )
    ) {

        wp_enqueue_media();
    }
}

add_action(
    'admin_enqueue_scripts',
    'rud_crm_customer_profile_media_library'
);


/*
 * ---------------------------------------------------------
 * MAXIMUM CUSTOMER IMAGES
 * ---------------------------------------------------------
 */

function rud_crm_customer_max_images() {

    return 10;
}


/*
 * ---------------------------------------------------------
 * IMAGE DISPLAY SETTINGS
 * ---------------------------------------------------------
 */

function rud_crm_customer_image_settings() {

    return array(
        'admin_thumbnail_width'  => 140,
        'admin_thumbnail_height' => 140,
        'profile_width'          => 800,
        'profile_height'         => 800,
        'card_width'             => 400,
        'card_height'            => 400,
        'avatar_width'           => 200,
        'avatar_height'          => 200
    );
}


/*
 * ---------------------------------------------------------
 * GET CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_get_customer( $customer_id ) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customers
             WHERE id = %d",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET CUSTOMER DETAILS
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_details( $customer_id ) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customer_details
             WHERE customer_id = %d",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET ONE CONTACT VALUE
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_contact_value(
    $customer_id,
    $contact_type
) {

    global $wpdb;

    $value =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT contact_value
                 FROM {$wpdb->prefix}rudcrm_contact_methods
                 WHERE customer_id = %d
                 AND contact_type = %s
                 ORDER BY is_primary DESC, id ASC
                 LIMIT 1",
                $customer_id,
                $contact_type
            )
        );

    return null !== $value
        ? $value
        : '';
}


/*
 * ---------------------------------------------------------
 * SAFE CONTACT SAVE
 * ---------------------------------------------------------
 */

function rud_crm_profile_save_contact(
    $customer_id,
    $contact_type,
    $contact_label,
    $contact_value,
    $is_primary = 0
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_contact_methods';

    $existing =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM $table
                 WHERE customer_id = %d
                 AND contact_type = %s
                 ORDER BY id ASC
                 LIMIT 1",
                $customer_id,
                $contact_type
            )
        );

    $now =
        current_time( 'mysql' );

    if ( $existing ) {

        return $wpdb->update(
            $table,
            array(
                'contact_label' => $contact_label,
                'contact_value' => $contact_value,
                'is_primary'    => $is_primary,
                'updated_at'    => $now
            ),
            array(
                'id' => $existing->id
            )
        );
    }

    if (
        '' ===
        trim(
            (string) $contact_value
        )
    ) {
        return true;
    }

    return $wpdb->insert(
        $table,
        array(
            'customer_id'   => $customer_id,
            'contact_type'  => $contact_type,
            'contact_label' => $contact_label,
            'contact_value' => $contact_value,
            'is_primary'    => $is_primary,
            'is_verified'   => 0,
            'created_at'    => $now,
            'updated_at'    => $now
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET PRIVATE ADDRESS
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_private_address( $customer_id ) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_addresses
             WHERE customer_id = %d
             AND address_type = 'private'
             ORDER BY is_primary DESC, id ASC
             LIMIT 1",
            $customer_id
        )
    );
}


/*
 * ---------------------------------------------------------
 * GET SOCIAL ACCOUNTS
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_social_accounts( $customer_id ) {

    global $wpdb;

    $rows =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_social_accounts
                 WHERE customer_id = %d
                 ORDER BY platform ASC",
                $customer_id
            )
        );

    $social_accounts =
        array();

    if ( $rows ) {

        foreach ( $rows as $row ) {

            $social_accounts[
                $row->platform
            ] = $row;
        }
    }

    return $social_accounts;
}


/*
 * ---------------------------------------------------------
 * GET CUSTOMER IMAGES
 * ---------------------------------------------------------
 */

function rud_crm_get_customer_images( $customer_id ) {

    global $wpdb;

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customer_images
             WHERE customer_id = %d
             ORDER BY is_primary DESC, sort_order ASC, id ASC",
            $customer_id
        )
    );
}


/*
 * =========================================================
 * SAVE COMPLETE CUSTOMER PROFILE
 * =========================================================
 */

function rud_crm_save_customer_profile( $customer_id ) {

    global $wpdb;

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    $details_table =
        $wpdb->prefix .
        'rudcrm_customer_details';

    $addresses_table =
        $wpdb->prefix .
        'rudcrm_addresses';

    $social_table =
        $wpdb->prefix .
        'rudcrm_social_accounts';

    $now =
        current_time( 'mysql' );

    $errors =
        array();


    /*
     * CORE CUSTOMER
     */

    $company_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['company_name'] ?? ''
            )
        );

    $status =
        sanitize_key(
            wp_unslash(
                $_POST['status'] ?? 'customer'
            )
        );

    $allowed_statuses =
        array(
            'lead',
            'customer',
            'partner',
            'inactive'
        );

    if (
        ! in_array(
            $status,
            $allowed_statuses,
            true
        )
    ) {
        $status =
            'customer';
    }

    $result =
        $wpdb->update(
            $customers_table,
            array(
                'customer_type' =>
                    $company_name
                    ? 'company'
                    : 'person',

                'title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['title'] ?? ''
                        )
                    ),

                'first_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['first_name'] ?? ''
                        )
                    ),

                'middle_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['middle_name'] ?? ''
                        )
                    ),

                'last_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['last_name'] ?? ''
                        )
                    ),

                'preferred_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['preferred_name'] ?? ''
                        )
                    ),

                'company_name' =>
                    $company_name,

                'organization_number' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['organization_number'] ?? ''
                        )
                    ),

                'job_title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['job_title'] ?? ''
                        )
                    ),

                'department' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['department'] ?? ''
                        )
                    ),

                'status' =>
                    $status,

                'updated_at' =>
                    $now
            ),
            array(
                'id' =>
                    $customer_id
            )
        );

    if ( false === $result ) {

        $errors[] =
            'Core customer information could not be saved.';
    }


    /*
     * PERSONAL DETAILS
     */

    $birth_date =
        sanitize_text_field(
            wp_unslash(
                $_POST['birth_date'] ?? ''
            )
        );

    if (
        '' !== $birth_date &&
        ! preg_match(
            '/^\d{4}-\d{2}-\d{2}$/',
            $birth_date
        )
    ) {
        $birth_date =
            '';
    }

    $birth_year =
        $birth_date
        ? (int) substr(
            $birth_date,
            0,
            4
        )
        : null;

    $details =
        rud_crm_get_customer_details(
            $customer_id
        );

    $details_data =
        array(
            'birth_date' =>
                $birth_date
                ? $birth_date
                : null,

            'birth_year' =>
                $birth_year,

            'gender' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['gender'] ?? ''
                    )
                ),

            'preferred_language' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['preferred_language'] ?? ''
                    )
                ),

            'nationality' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['nationality'] ?? ''
                    )
                ),

            'notes' =>
                sanitize_textarea_field(
                    wp_unslash(
                        $_POST['notes'] ?? ''
                    )
                ),

            'updated_at' =>
                $now
        );

    if ( $details ) {

        $result =
            $wpdb->update(
                $details_table,
                $details_data,
                array(
                    'customer_id' =>
                        $customer_id
                )
            );

        if ( false === $result ) {

            $errors[] =
                'Personal information could not be saved.';
        }

    } else {

        $details_data['customer_id'] =
            $customer_id;

        $details_data['website_url'] =
            '';

        $details_data['created_at'] =
            $now;

        $result =
            $wpdb->insert(
                $details_table,
                $details_data
            );

        if ( false === $result ) {

            $errors[] =
                'Personal information could not be created.';
        }
    }


    /*
     * CONTACT INFORMATION
     */

    $contact_results =
        array(

            rud_crm_profile_save_contact(
                $customer_id,
                'private_email',
                'Private Email',
                sanitize_email(
                    wp_unslash(
                        $_POST['private_email'] ?? ''
                    )
                ),
                1
            ),

            rud_crm_profile_save_contact(
                $customer_id,
                'work_email',
                'Work Email',
                sanitize_email(
                    wp_unslash(
                        $_POST['work_email'] ?? ''
                    )
                )
            ),

            rud_crm_profile_save_contact(
                $customer_id,
                'mobile_phone',
                'Mobile Phone',
                sanitize_text_field(
                    wp_unslash(
                        $_POST['mobile_phone'] ?? ''
                    )
                ),
                1
            ),

            rud_crm_profile_save_contact(
                $customer_id,
                'home_phone',
                'Home Phone',
                sanitize_text_field(
                    wp_unslash(
                        $_POST['home_phone'] ?? ''
                    )
                )
            ),

            rud_crm_profile_save_contact(
                $customer_id,
                'office_phone',
                'Office Phone',
                sanitize_text_field(
                    wp_unslash(
                        $_POST['office_phone'] ?? ''
                    )
                )
            ),

            rud_crm_profile_save_contact(
                $customer_id,
                'whatsapp',
                'WhatsApp',
                sanitize_text_field(
                    wp_unslash(
                        $_POST['whatsapp'] ?? ''
                    )
                )
            )
        );

    foreach (
        $contact_results as
        $contact_result
    ) {

        if ( false === $contact_result ) {

            $errors[] =
                'One or more contact fields could not be saved.';

            break;
        }
    }


    /*
     * PRIVATE ADDRESS
     */

    $private_address =
        rud_crm_get_customer_private_address(
            $customer_id
        );

    $address_columns_raw =
        $wpdb->get_results(
            "SHOW COLUMNS FROM $addresses_table"
        );

    $address_columns =
        array();

    if ( $address_columns_raw ) {

        foreach (
            $address_columns_raw as
            $column
        ) {

            $address_columns[] =
                $column->Field;
        }
    }

    $address_values =
        array(
            'customer_id' =>
                $customer_id,

            'address_type' =>
                'private',

            'company_name' =>
                '',

            'address_line_1' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['address_line_1'] ?? ''
                    )
                ),

            'address_line_2' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['address_line_2'] ?? ''
                    )
                ),

            'address_line_3' =>
                '',

            'postal_code' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['postal_code'] ?? ''
                    )
                ),

            'city' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['city'] ?? ''
                    )
                ),

            'state_region' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['state_region'] ?? ''
                    )
                ),

            'country_code' =>
                strtoupper(
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['country_code'] ?? ''
                        )
                    )
                ),

            'is_primary' =>
                1,

            'created_at' =>
                $now,

            'updated_at' =>
                $now
        );

    foreach (
        array_keys(
            $address_values
        ) as
        $column_name
    ) {

        if (
            ! in_array(
                $column_name,
                $address_columns,
                true
            )
        ) {

            unset(
                $address_values[
                    $column_name
                ]
            );
        }
    }

    if ( $private_address ) {

        $update_address_values =
            $address_values;

        unset(
            $update_address_values['customer_id'],
            $update_address_values['created_at']
        );

        $wpdb->last_error =
            '';

        $address_result =
            $wpdb->update(
                $addresses_table,
                $update_address_values,
                array(
                    'id' =>
                        $private_address->id
                )
            );

        if (
            false ===
            $address_result
        ) {

            $errors[] =
                'Private address could not be saved. MySQL: ' .
                $wpdb->last_error;
        }

    } else {

        $has_address_data =
            ! empty(
                $address_values[
                    'address_line_1'
                ] ?? ''
            ) ||
            ! empty(
                $address_values[
                    'address_line_2'
                ] ?? ''
            ) ||
            ! empty(
                $address_values[
                    'postal_code'
                ] ?? ''
            ) ||
            ! empty(
                $address_values[
                    'city'
                ] ?? ''
            ) ||
            ! empty(
                $address_values[
                    'state_region'
                ] ?? ''
            ) ||
            ! empty(
                $address_values[
                    'country_code'
                ] ?? ''
            );

        if ( $has_address_data ) {

            $wpdb->last_error =
                '';

            $address_result =
                $wpdb->insert(
                    $addresses_table,
                    $address_values
                );

            if (
                false ===
                $address_result
            ) {

                $errors[] =
                    'Private address could not be created. MySQL: ' .
                    $wpdb->last_error;
            }
        }
    }


    /*
     * SOCIAL MEDIA
     */

    if (
        function_exists(
            'rud_crm_social_platforms'
        )
    ) {

        foreach (
            rud_crm_social_platforms()
            as
            $platform_key =>
            $platform_name
        ) {

            $active =
                isset(
                    $_POST['social_active'][
                        $platform_key
                    ]
                )
                ? 1
                : 0;

            $account_name =
                sanitize_text_field(
                    wp_unslash(
                        $_POST['social_account'][
                            $platform_key
                        ] ?? ''
                    )
                );

            $profile_url =
                esc_url_raw(
                    wp_unslash(
                        $_POST['social_url'][
                            $platform_key
                        ] ?? ''
                    )
                );

            $existing_social =
                $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT *
                         FROM $social_table
                         WHERE customer_id = %d
                         AND platform = %s",
                        $customer_id,
                        $platform_key
                    )
                );

            if ( $existing_social ) {

                $safe_account_name =
                    '' !==
                    $account_name
                    ? $account_name
                    : $existing_social->account_name;

                $safe_profile_url =
                    '' !==
                    $profile_url
                    ? $profile_url
                    : $existing_social->profile_url;

                $result =
                    $wpdb->update(
                        $social_table,
                        array(
                            'is_active' =>
                                $active,

                            'account_name' =>
                                $safe_account_name,

                            'profile_url' =>
                                $safe_profile_url,

                            'updated_at' =>
                                $now
                        ),
                        array(
                            'id' =>
                                $existing_social->id
                        )
                    );

                if ( false === $result ) {

                    $errors[] =
                        $platform_name .
                        ' could not be saved.';
                }

            } else {

                if (
                    $active ||
                    '' !==
                    $account_name ||
                    '' !==
                    $profile_url
                ) {

                    $result =
                        $wpdb->insert(
                            $social_table,
                            array(
                                'customer_id' =>
                                    $customer_id,

                                'platform' =>
                                    $platform_key,

                                'is_active' =>
                                    $active,

                                'account_name' =>
                                    $account_name,

                                'profile_url' =>
                                    $profile_url,

                                'notes' =>
                                    '',

                                'created_at' =>
                                    $now,

                                'updated_at' =>
                                    $now
                            )
                        );

                    if ( false === $result ) {

                        $errors[] =
                            $platform_name .
                            ' could not be created.';
                    }
                }
            }
        }
    }


    if (
        ! empty(
            $errors
        )
    ) {

        return new WP_Error(
            'rud_profile_save_error',
            implode(
                ' ',
                array_unique(
                    $errors
                )
            )
        );
    }

    return true;
}


/*
 * =========================================================
 * IMAGE FUNCTIONS
 * =========================================================
 */

function rud_crm_get_primary_customer_image( $customer_id ) {

    global $wpdb;

    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customer_images
             WHERE customer_id = %d
             AND is_primary = 1
             ORDER BY id ASC
             LIMIT 1",
            $customer_id
        )
    );
}


function rud_crm_get_customer_gallery_images( $customer_id ) {

    global $wpdb;

    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_customer_images
             WHERE customer_id = %d
             AND is_primary = 0
             ORDER BY sort_order ASC, id ASC",
            $customer_id
        )
    );
}


function rud_crm_set_customer_primary_attachment(
    $customer_id,
    $attachment_id
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $attachment_id =
        absint(
            $attachment_id
        );

    if (
        ! $attachment_id ||
        ! wp_attachment_is_image(
            $attachment_id
        )
    ) {

        return new WP_Error(
            'rud_invalid_primary_image',
            'Please select a valid image.'
        );
    }

    $existing_selected =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM $table
                 WHERE customer_id = %d
                 AND attachment_id = %d
                 LIMIT 1",
                $customer_id,
                $attachment_id
            )
        );

    /*
     * Replacing the primary image should not push the old
     * primary image into the gallery. Remove the old CRM row.
     * The WordPress Media Library attachment itself is untouched.
     */
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM $table
             WHERE customer_id = %d
             AND is_primary = 1
             AND attachment_id <> %d",
            $customer_id,
            $attachment_id
        )
    );

    if ( $existing_selected ) {

        $wpdb->update(
            $table,
            array(
                'image_type' => 'profile',
                'is_primary' => 1,
                'updated_at' => current_time( 'mysql' )
            ),
            array(
                'id' => $existing_selected->id,
                'customer_id' => $customer_id
            )
        );

        return true;
    }

    $sort_order =
        (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT MAX(sort_order)
                 FROM $table
                 WHERE customer_id = %d",
                $customer_id
            )
        );

    $result =
        $wpdb->insert(
            $table,
            array(
                'customer_id'   => $customer_id,
                'attachment_id' => $attachment_id,
                'image_type'    => 'profile',
                'is_primary'    => 1,
                'sort_order'    => $sort_order + 1,
                'created_at'    => current_time( 'mysql' ),
                'updated_at'    => current_time( 'mysql' )
            )
        );

    if ( false === $result ) {

        return new WP_Error(
            'rud_primary_image_save_failed',
            'The Company Logo / Profile Picture could not be saved.'
        );
    }

    return true;
}


function rud_crm_add_customer_images(
    $customer_id,
    $attachment_ids
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    /*
     * The maximum applies only to gallery images.
     * The Company Logo / Profile Picture is separate.
     */
    $existing_count =
        (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM $table
                 WHERE customer_id = %d
                 AND is_primary = 0",
                $customer_id
            )
        );

    $remaining =
        rud_crm_customer_max_images() -
        $existing_count;

    if ( $remaining <= 0 ) {

        return new WP_Error(
            'rud_image_limit',
            sprintf(
                'Maximum %d gallery images are allowed for each customer.',
                rud_crm_customer_max_images()
            )
        );
    }

    $attachment_ids =
        array_filter(
            array_unique(
                array_map(
                    'absint',
                    $attachment_ids
                )
            )
        );

    $attachment_ids =
        array_slice(
            $attachment_ids,
            0,
            $remaining
        );

    if ( empty( $attachment_ids ) ) {

        return new WP_Error(
            'rud_no_images',
            'No images were selected.'
        );
    }

    $primary_attachment_id =
        (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT attachment_id
                 FROM $table
                 WHERE customer_id = %d
                 AND is_primary = 1
                 LIMIT 1",
                $customer_id
            )
        );

    $sort_order =
        (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT MAX(sort_order)
                 FROM $table
                 WHERE customer_id = %d",
                $customer_id
            )
        );

    $added = 0;

    foreach ( $attachment_ids as $attachment_id ) {

        if (
            ! wp_attachment_is_image(
                $attachment_id
            )
        ) {
            continue;
        }

        /* Keep the primary picture out of the gallery. */
        if (
            $primary_attachment_id &&
            $attachment_id === $primary_attachment_id
        ) {
            continue;
        }

        $exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM $table
                     WHERE customer_id = %d
                     AND attachment_id = %d",
                    $customer_id,
                    $attachment_id
                )
            );

        if ( $exists ) {
            continue;
        }

        $sort_order++;

        $result =
            $wpdb->insert(
                $table,
                array(
                    'customer_id'   => $customer_id,
                    'attachment_id' => $attachment_id,
                    'image_type'    => 'gallery',
                    'is_primary'    => 0,
                    'sort_order'    => $sort_order,
                    'created_at'    => current_time( 'mysql' ),
                    'updated_at'    => current_time( 'mysql' )
                )
            );

        if ( false !== $result ) {
            $added++;
        }
    }

    return $added;
}


function rud_crm_set_primary_customer_image(
    $customer_id,
    $image_id
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $image =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM $table
                 WHERE id = %d
                 AND customer_id = %d",
                $image_id,
                $customer_id
            )
        );

    if ( ! $image ) {
        return;
    }

    rud_crm_set_customer_primary_attachment(
        $customer_id,
        $image->attachment_id
    );
}


function rud_crm_remove_customer_image(
    $customer_id,
    $image_id
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $wpdb->delete(
        $table,
        array(
            'id' => absint( $image_id ),
            'customer_id' => absint( $customer_id )
        )
    );
}


function rud_crm_remove_primary_customer_image( $customer_id ) {

    global $wpdb;

    $wpdb->delete(
        $wpdb->prefix . 'rudcrm_customer_images',
        array(
            'customer_id' => absint( $customer_id ),
            'is_primary'  => 1
        )
    );
}


function rud_crm_delete_selected_customer_gallery_images(
    $customer_id,
    $image_ids
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $image_ids =
        array_filter(
            array_unique(
                array_map(
                    'absint',
                    (array) $image_ids
                )
            )
        );

    if ( empty( $image_ids ) ) {
        return 0;
    }

    $deleted = 0;

    foreach ( $image_ids as $image_id ) {

        $result =
            $wpdb->delete(
                $table,
                array(
                    'id'          => $image_id,
                    'customer_id' => absint( $customer_id ),
                    'is_primary'  => 0
                )
            );

        if ( false !== $result ) {
            $deleted += (int) $result;
        }
    }

    return $deleted;
}


function rud_crm_delete_all_customer_gallery_images( $customer_id ) {

    global $wpdb;

    return $wpdb->delete(
        $wpdb->prefix . 'rudcrm_customer_images',
        array(
            'customer_id' => absint( $customer_id ),
            'is_primary'  => 0
        )
    );
}


function rud_crm_move_customer_image(
    $customer_id,
    $image_id,
    $direction
) {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    /* Only gallery images can be reordered. */
    $images =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM $table
                 WHERE customer_id = %d
                 AND is_primary = 0
                 ORDER BY sort_order ASC, id ASC",
                $customer_id
            )
        );

    $current_index = null;

    foreach ( $images as $index => $image ) {

        if (
            (int) $image->id ===
            (int) $image_id
        ) {

            $current_index = $index;
            break;
        }
    }

    if ( null === $current_index ) {
        return;
    }

    $target_index =
        'up' === $direction
        ? $current_index - 1
        : $current_index + 1;

    if ( ! isset( $images[ $target_index ] ) ) {
        return;
    }

    $current = $images[ $current_index ];
    $target  = $images[ $target_index ];

    $current_order = (int) $current->sort_order;
    $target_order  = (int) $target->sort_order;

    $wpdb->update(
        $table,
        array( 'sort_order' => $target_order ),
        array( 'id' => $current->id )
    );

    $wpdb->update(
        $table,
        array( 'sort_order' => $current_order ),
        array( 'id' => $target->id )
    );
}


/*
 * =========================================================
 * EDIT INPUT HELPER
 * =========================================================
 */

function rud_crm_profile_input(
    $name,
    $label,
    $value = '',
    $type = 'text'
) {

    echo '<tr>';

    echo '<th scope="row">';

    echo '<label for="' .
        esc_attr(
            $name
        ) .
        '">' .
        esc_html(
            $label
        ) .
        '</label>';

    echo '</th>';

    echo '<td>';

    echo '<input
        type="' .
        esc_attr(
            $type
        ) .
        '"
        name="' .
        esc_attr(
            $name
        ) .
        '"
        id="' .
        esc_attr(
            $name
        ) .
        '"
        value="' .
        esc_attr(
            $value
        ) .
        '"
        class="regular-text"
    >';

    echo '</td>';

    echo '</tr>';
}


/*
 * =========================================================
 * CUSTOMER PROFILE PAGE
 * =========================================================
 */

function rud_crm_render_customer_profile(
    $customer_id
) {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        wp_die(
            'You do not have permission to access this customer.'
        );
    }

    $customer_id =
        absint(
            $customer_id
        );


    /*
     * SAVE MAIN PROFILE
     */

    if (
        isset(
            $_POST[
                'rud_crm_save_customer'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_save_customer_action',
            'rud_crm_save_customer_nonce'
        );

        $save_result =
            rud_crm_save_customer_profile(
                $customer_id
            );

        if (
            is_wp_error(
                $save_result
            )
        ) {

            echo '<div class="notice notice-error">';

            echo '<p><strong>Some changes were not saved:</strong> ' .
                esc_html(
                    $save_result->get_error_message()
                ) .
                '</p>';

            echo '</div>';

        } else {

            echo '<div class="notice notice-success">';

            echo '<p><strong>Customer changes saved successfully.</strong></p>';

            echo '</div>';
        }
    }


    /*
     * IMAGE ACTIONS
     */

    if (
        isset(
            $_POST[
                'rud_crm_set_primary_attachment'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_primary_image_action',
            'rud_crm_customer_primary_image_nonce'
        );

        $primary_result =
            rud_crm_set_customer_primary_attachment(
                $customer_id,
                absint(
                    $_POST[
                        'primary_attachment_id'
                    ] ?? 0
                )
            );

        if ( is_wp_error( $primary_result ) ) {

            echo '<div class="notice notice-error"><p>' .
                esc_html(
                    $primary_result->get_error_message()
                ) .
                '</p></div>';

        } else {

            echo '<div class="notice notice-success"><p><strong>Company Logo / Profile Picture updated.</strong></p></div>';
        }
    }

    if (
        isset(
            $_POST[
                'rud_crm_remove_primary_image'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_primary_image_action',
            'rud_crm_customer_primary_image_nonce'
        );

        rud_crm_remove_primary_customer_image(
            $customer_id
        );

        echo '<div class="notice notice-success"><p><strong>Company Logo / Profile Picture removed.</strong></p></div>';
    }

    if (
        isset(
            $_POST[
                'rud_crm_add_images'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_images_action',
            'rud_crm_customer_images_nonce'
        );

        $raw =
            sanitize_text_field(
                wp_unslash(
                    $_POST[
                        'attachment_ids'
                    ] ?? ''
                )
            );

        $ids =
            $raw
            ? explode( ',', $raw )
            : array();

        $image_result =
            rud_crm_add_customer_images(
                $customer_id,
                $ids
            );

        if ( is_wp_error( $image_result ) ) {

            echo '<div class="notice notice-error"><p>' .
                esc_html(
                    $image_result->get_error_message()
                ) .
                '</p></div>';

        } else {

            echo '<div class="notice notice-success"><p>' .
                esc_html( $image_result ) .
                ' gallery image(s) added.</p></div>';
        }
    }

    if (
        isset(
            $_POST[
                'rud_crm_remove_image'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_image_action',
            'rud_crm_customer_image_action_nonce'
        );

        rud_crm_remove_customer_image(
            $customer_id,
            absint(
                $_POST[
                    'image_id'
                ] ?? 0
            )
        );
    }

    if (
        isset(
            $_POST[
                'rud_crm_delete_selected_images'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_bulk_images_action',
            'rud_crm_customer_bulk_images_nonce'
        );

        $selected_ids =
            isset( $_POST['selected_image_ids'] )
            ? array_map(
                'absint',
                (array) wp_unslash(
                    $_POST['selected_image_ids']
                )
            )
            : array();

        $deleted =
            rud_crm_delete_selected_customer_gallery_images(
                $customer_id,
                $selected_ids
            );

        echo '<div class="notice notice-success"><p>' .
            esc_html( $deleted ) .
            ' gallery image(s) removed.</p></div>';
    }

    if (
        isset(
            $_POST[
                'rud_crm_delete_all_images'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_bulk_images_action',
            'rud_crm_customer_bulk_images_nonce'
        );

        $deleted =
            rud_crm_delete_all_customer_gallery_images(
                $customer_id
            );

        echo '<div class="notice notice-success"><p>' .
            esc_html( (int) $deleted ) .
            ' gallery image(s) removed.</p></div>';
    }

    if (
        isset(
            $_POST[
                'rud_crm_move_image'
            ]
        )
    ) {

        check_admin_referer(
            'rud_crm_customer_image_action',
            'rud_crm_customer_image_action_nonce'
        );

        rud_crm_move_customer_image(
            $customer_id,
            absint(
                $_POST[
                    'image_id'
                ] ?? 0
            ),
            sanitize_key(
                wp_unslash(
                    $_POST[
                        'direction'
                    ] ?? ''
                )
            )
        );
    }


    /*
     * LOAD FRESH DATA
     */

    $customer =
        rud_crm_get_customer(
            $customer_id
        );

    if ( ! $customer ) {

        echo '<div class="wrap">';

        echo '<h1>Customer not found</h1>';

        echo '</div>';

        return;
    }

    $details =
        rud_crm_get_customer_details(
            $customer_id
        );

    $private_address =
        rud_crm_get_customer_private_address(
            $customer_id
        );

    $social_accounts =
        rud_crm_get_customer_social_accounts(
            $customer_id
        );

    $primary_image =
        rud_crm_get_primary_customer_image(
            $customer_id
        );

    $images =
        rud_crm_get_customer_gallery_images(
            $customer_id
        );

    $maximum =
        rud_crm_customer_max_images();

    $remaining =
        max(
            0,
            $maximum -
            count(
                $images
            )
        );

    $back_url =
        admin_url(
            'admin.php?page=rud-crm-customers'
        );


    /*
     * PAGE
     */

    echo '<div class="wrap">';

    echo '<p>';

    echo '<a href="' .
        esc_url(
            $back_url
        ) .
        '">&larr; Back to Customers</a>';

    echo '</p>';

    echo '<h1>';

    echo esc_html(
        trim(
            $customer->first_name .
            ' ' .
            $customer->middle_name .
            ' ' .
            $customer->last_name
        )
    );

    echo '</h1>';

    echo '<p>';

    echo '<strong>Customer ID:</strong> ' .
        esc_html(
            $customer->customer_number
        );

    echo '</p>';


    /*
     * =========================================================
     * MAIN EDIT FORM
     * =========================================================
     */

    echo '<form method="post">';

    wp_nonce_field(
        'rud_crm_save_customer_action',
        'rud_crm_save_customer_nonce'
    );


    /*
     * NAME
     */

    echo '<h2>Name</h2>';

    echo '<table class="form-table">';

    rud_crm_profile_input(
        'title',
        'Title',
        $customer->title
    );

    rud_crm_profile_input(
        'first_name',
        'First Name',
        $customer->first_name
    );

    rud_crm_profile_input(
        'middle_name',
        'Middle Name',
        $customer->middle_name
    );

    rud_crm_profile_input(
        'last_name',
        'Last Name',
        $customer->last_name
    );

    rud_crm_profile_input(
        'preferred_name',
        'Preferred Name',
        $customer->preferred_name
    );

    echo '</table>';


    /*
     * COMPANY
     */

    echo '<h2>Company</h2>';

    echo '<table class="form-table">';

    rud_crm_profile_input(
        'company_name',
        'Company Name',
        $customer->company_name
    );

    rud_crm_profile_input(
        'organization_number',
        'Organization Number',
        $customer->organization_number
    );

    rud_crm_profile_input(
        'job_title',
        'Job Title',
        $customer->job_title
    );

    rud_crm_profile_input(
        'department',
        'Department',
        $customer->department
    );

    echo '</table>';


    /*
     * STATUS
     */

    echo '<h2>Status</h2>';

    echo '<p>';

    echo '<select name="status">';

    foreach (
        array(
            'lead' =>
                'Lead',

            'customer' =>
                'Customer',

            'partner' =>
                'Partner',

            'inactive' =>
                'Inactive'
        )
        as
        $status_key =>
        $status_label
    ) {

        echo '<option
            value="' .
            esc_attr(
                $status_key
            ) .
            '" ' .
            selected(
                $customer->status,
                $status_key,
                false
            ) .
            '
        >';

        echo esc_html(
            $status_label
        );

        echo '</option>';
    }

    echo '</select>';

    echo '</p>';


    /*
     * PERSONAL INFORMATION
     */

    echo '<h2>Personal Information</h2>';

    echo '<table class="form-table">';

    rud_crm_profile_input(
        'birth_date',
        'Birth Date',
        $details
            ? $details->birth_date
            : '',
        'date'
    );

    rud_crm_profile_input(
        'gender',
        'Gender',
        $details
            ? $details->gender
            : ''
    );

    rud_crm_profile_input(
        'preferred_language',
        'Preferred Language',
        $details
            ? $details->preferred_language
            : ''
    );

    rud_crm_profile_input(
        'nationality',
        'Nationality',
        $details
            ? $details->nationality
            : ''
    );

    echo '</table>';


    /*
     * =========================================================
     * CONTACT INFORMATION
     * INTERNATIONAL PHONE FIELDS
     * =========================================================
     */

    echo '<h2>Contact Information</h2>';

    echo '<table class="form-table">';


    /*
     * Email fields remain normal.
     */

    rud_crm_profile_input(
        'private_email',
        'Private Email',
        rud_crm_get_customer_contact_value(
            $customer_id,
            'private_email'
        ),
        'email'
    );

    rud_crm_profile_input(
        'work_email',
        'Work Email',
        rud_crm_get_customer_contact_value(
            $customer_id,
            'work_email'
        ),
        'email'
    );


    /*
     * INTERNATIONAL PHONE FIELDS
     */

    if (
        function_exists(
            'rud_crm_phone_input'
        )
    ) {

        rud_crm_phone_input(
            'mobile_phone',
            'Mobile Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'mobile_phone'
            )
        );

        rud_crm_phone_input(
            'home_phone',
            'Home Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'home_phone'
            )
        );

        rud_crm_phone_input(
            'office_phone',
            'Office Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'office_phone'
            )
        );

        rud_crm_phone_input(
            'whatsapp',
            'WhatsApp',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'whatsapp'
            )
        );

    } else {

        /*
         * Safety fallback if phone-fields.php
         * is ever missing.
         */

        rud_crm_profile_input(
            'mobile_phone',
            'Mobile Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'mobile_phone'
            )
        );

        rud_crm_profile_input(
            'home_phone',
            'Home Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'home_phone'
            )
        );

        rud_crm_profile_input(
            'office_phone',
            'Office Phone',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'office_phone'
            )
        );

        rud_crm_profile_input(
            'whatsapp',
            'WhatsApp',
            rud_crm_get_customer_contact_value(
                $customer_id,
                'whatsapp'
            )
        );
    }

    echo '</table>';


    /*
     * PRIVATE ADDRESS
     */

    echo '<h2>Private Address</h2>';

    echo '<table class="form-table">';

    rud_crm_profile_input(
        'address_line_1',
        'Address Line 1',
        $private_address
            ? $private_address->address_line_1
            : ''
    );

    rud_crm_profile_input(
        'address_line_2',
        'Address Line 2',
        $private_address
            ? $private_address->address_line_2
            : ''
    );

    rud_crm_profile_input(
        'postal_code',
        'Postal Code',
        $private_address
            ? $private_address->postal_code
            : ''
    );

    rud_crm_profile_input(
        'city',
        'City',
        $private_address
            ? $private_address->city
            : ''
    );

    rud_crm_profile_input(
        'state_region',
        'State / Region',
        $private_address
            ? $private_address->state_region
            : ''
    );

    rud_crm_profile_input(
        'country_code',
        'Country Code',
        $private_address
            ? $private_address->country_code
            : ''
    );

    echo '</table>';


    /*
     * SOCIAL MEDIA
     */

    echo '<h2>Social Media & Messaging</h2>';

    echo '<p>';

    echo '<button
        type="button"
        class="button"
        onclick="rudSocialAll(true);"
    >
        Activate All
    </button> ';

    echo '<button
        type="button"
        class="button"
        onclick="rudSocialAll(false);"
    >
        Deactivate All
    </button>';

    echo '</p>';

    echo '<table class="widefat striped">';

    echo '<thead>';

    echo '<tr>';

    echo '<th>Platform</th>';

    echo '<th style="width:90px;">Active</th>';

    echo '<th>Username / Account</th>';

    echo '<th>Profile Link</th>';

    echo '</tr>';

    echo '</thead>';

    echo '<tbody>';

    foreach (
        rud_crm_social_platforms()
        as
        $platform_key =>
        $platform_name
    ) {

        $social =
            isset(
                $social_accounts[
                    $platform_key
                ]
            )
            ? $social_accounts[
                $platform_key
            ]
            : null;

        echo '<tr>';

        echo '<td>';

        echo '<strong>' .
            esc_html(
                $platform_name
            ) .
            '</strong>';

        echo '</td>';

        echo '<td>';

        echo '<input
            class="rud-social-active"
            type="checkbox"
            name="social_active[' .
            esc_attr(
                $platform_key
            ) .
            ']"
            value="1" ' .
            checked(
                $social &&
                (int)
                $social->is_active ===
                1,
                true,
                false
            ) .
            '
        >';

        echo '</td>';

        echo '<td>';

        echo '<input
            type="text"
            name="social_account[' .
            esc_attr(
                $platform_key
            ) .
            ']"
            value="' .
            esc_attr(
                $social
                    ? $social->account_name
                    : ''
            ) .
            '"
            class="regular-text"
        >';

        echo '</td>';

        echo '<td>';

        echo '<input
            type="url"
            name="social_url[' .
            esc_attr(
                $platform_key
            ) .
            ']"
            value="' .
            esc_attr(
                $social
                    ? $social->profile_url
                    : ''
            ) .
            '"
            class="large-text"
            placeholder="https://"
        >';

        echo '</td>';

        echo '</tr>';
    }

    echo '</tbody>';

    echo '</table>';


    /*
     * NOTES
     */

    echo '<h2>Internal CRM Notes</h2>';

    echo '<textarea
        name="notes"
        rows="7"
        class="large-text"
    >' .
        esc_textarea(
            $details
                ? $details->notes
                : ''
        ) .
        '</textarea>';


    /*
     * SAVE CHANGES
     */

    echo '<div
        style="
            margin-top:30px;
            margin-bottom:30px;
            padding:20px;
            background:#fff;
            border:1px solid #ccd0d4;
        "
    >';

    submit_button(
        'Save Changes',
        'primary large',
        'rud_crm_save_customer',
        false
    );

    echo '</div>';

    echo '</form>';


    /*
     * =========================================================
     * COMPANY LOGO / PROFILE PICTURE
     * LAST CUSTOMER OPTION
     * =========================================================
     */

    echo '<hr style="margin:40px 0;">';

    echo '<h2>Company Logo / Profile Picture</h2>';

    echo '<p class="description">';
    echo 'Optional. This is the customer\'s main profile image or company logo. It is separate from the gallery below and is not included in the gallery/slideshow.';
    echo '</p>';

    echo '<div style="display:flex;align-items:flex-start;gap:24px;flex-wrap:wrap;margin:20px 0;">';

    echo '<div style="width:180px;min-height:180px;background:#fff;border:1px solid #ccd0d4;padding:15px;box-sizing:border-box;">';

    if ( $primary_image ) {

        $primary_url =
            wp_get_attachment_image_url(
                $primary_image->attachment_id,
                'medium'
            );

        if ( $primary_url ) {

            echo '<img
                src="' . esc_url( $primary_url ) . '"
                alt=""
                style="width:148px;height:148px;object-fit:cover;display:block;"
            >';
        }

    } else {

        echo '<div style="width:148px;height:148px;display:flex;align-items:center;justify-content:center;background:#f6f7f7;color:#646970;text-align:center;">No profile picture</div>';
    }

    echo '</div>';

    echo '<div>';

    echo '<form method="post" id="rud-crm-primary-image-form" style="margin-bottom:12px;">';

    wp_nonce_field(
        'rud_crm_customer_primary_image_action',
        'rud_crm_customer_primary_image_nonce'
    );

    echo '<input
        type="hidden"
        name="primary_attachment_id"
        id="rud-crm-primary-attachment-id"
        value=""
    >';

    echo '<button
        type="button"
        class="button"
        id="rud-crm-select-primary-image"
    >';

    echo $primary_image
        ? 'Replace Company Logo / Profile Picture'
        : 'Select Company Logo / Profile Picture';

    echo '</button> ';

    submit_button(
        $primary_image
            ? 'Save Replacement'
            : 'Save Profile Picture',
        'primary',
        'rud_crm_set_primary_attachment',
        false
    );

    echo '<div id="rud-crm-primary-selected-name" style="margin-top:10px;color:#50575e;"></div>';

    echo '</form>';

    if ( $primary_image ) {

        echo '<form method="post">';

        wp_nonce_field(
            'rud_crm_customer_primary_image_action',
            'rud_crm_customer_primary_image_nonce'
        );

        echo '<button
            type="submit"
            class="button"
            name="rud_crm_remove_primary_image"
            onclick="return confirm(\'Remove the Company Logo / Profile Picture?\');"
        >Remove Profile Picture</button>';

        echo '</form>';
    }

    echo '</div>';
    echo '</div>';


    /*
     * =========================================================
     * CUSTOMER IMAGE GALLERY
     * =========================================================
     */

    echo '<h2>Customer Images / Gallery</h2>';

    echo '<p>';

    echo 'Maximum: <strong>' .
        esc_html( $maximum ) .
        '</strong> gallery images. ';

    echo 'Currently used: <strong>' .
        esc_html( count( $images ) ) .
        '</strong>. ';

    echo 'Available slots: <strong>' .
        esc_html( $remaining ) .
        '</strong>.';

    echo '</p>';

    echo '<p class="description">The Company Logo / Profile Picture above is not counted as a gallery image.</p>';

    if ( $remaining > 0 ) {

        echo '<form
            method="post"
            id="rud-crm-image-form"
            style="margin:18px 0;"
        >';

        wp_nonce_field(
            'rud_crm_customer_images_action',
            'rud_crm_customer_images_nonce'
        );

        echo '<input
            type="hidden"
            name="attachment_ids"
            id="rud-crm-attachment-ids"
            value=""
        >';

        echo '<input
            type="hidden"
            id="rud-crm-image-slots"
            value="' .
            esc_attr( $remaining ) .
            '"
        >';

        echo '<button
            type="button"
            class="button"
            id="rud-crm-select-images"
        >Select / Upload Gallery Images</button> ';

        submit_button(
            'Add Selected Images',
            'secondary',
            'rud_crm_add_images',
            false
        );

        echo '<span
            id="rud-crm-selected-count"
            style="margin-left:15px;"
        >No images selected</span>';

        echo '</form>';
    }

    if ( ! empty( $images ) ) {

        echo '<form method="post" id="rud-crm-gallery-bulk-form">';

        wp_nonce_field(
            'rud_crm_customer_bulk_images_action',
            'rud_crm_customer_bulk_images_nonce'
        );

        echo '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:18px 0;">';

        echo '<button type="button" class="button" id="rud-crm-select-all-gallery">Select All</button>';
        echo '<button type="button" class="button" id="rud-crm-clear-gallery-selection">Clear Selection</button>';

        echo '<button
            type="submit"
            class="button"
            name="rud_crm_delete_selected_images"
            id="rud-crm-delete-selected-images"
            onclick="return confirm(\'Delete the selected gallery images from this customer?\');"
        >Delete Selected</button>';

        echo '<button
            type="submit"
            class="button"
            name="rud_crm_delete_all_images"
            onclick="return confirm(\'Delete ALL gallery images from this customer? The Company Logo / Profile Picture will remain.\');"
        >Delete All Gallery Images</button>';

        echo '<strong id="rud-crm-gallery-selected-count">0 selected</strong>';

        echo '</div>';

        echo '<div
            style="
                display:flex;
                flex-wrap:wrap;
                gap:20px;
                margin-top:20px;
            "
        >';

        foreach ( $images as $image ) {

            $url =
                wp_get_attachment_image_url(
                    $image->attachment_id,
                    'medium'
                );

            echo '<div
                style="
                    width:190px;
                    background:#fff;
                    border:1px solid #ccd0d4;
                    padding:15px;
                    box-sizing:border-box;
                "
            >';

            echo '<label style="display:block;margin-bottom:10px;font-weight:600;">';
            echo '<input
                type="checkbox"
                class="rud-crm-gallery-checkbox"
                name="selected_image_ids[]"
                value="' . esc_attr( $image->id ) . '"
            > Select';
            echo '</label>';

            if ( $url ) {

                echo '<img
                    src="' . esc_url( $url ) . '"
                    alt=""
                    style="
                        width:140px;
                        height:140px;
                        object-fit:cover;
                        display:block;
                    "
                >';
            }

            echo '<div style="margin-top:12px;">';

            echo '<button
                type="submit"
                class="button"
                name="rud_crm_move_image"
                value="1"
                formaction=""
                onclick="this.form.image_id.value=' . esc_attr( $image->id ) . ';this.form.direction.value=\'up\';"
            >↑</button> ';

            echo '<button
                type="submit"
                class="button"
                name="rud_crm_move_image"
                value="1"
                formaction=""
                onclick="this.form.image_id.value=' . esc_attr( $image->id ) . ';this.form.direction.value=\'down\';"
            >↓</button> ';

            echo '<button
                type="submit"
                class="button"
                name="rud_crm_remove_image"
                value="1"
                onclick="if(!confirm(\'Remove this gallery image from the customer?\')){return false;}this.form.image_id.value=' . esc_attr( $image->id ) . ';"
            >Remove</button>';

            echo '</div>';

            echo '</div>';
        }

        echo '</div>';

        /* Shared hidden fields used by per-image move/remove buttons. */
        echo '<input type="hidden" name="image_id" id="rud_crm_gallery_image_id" value="">';
        echo '<input type="hidden" name="direction" id="rud_crm_gallery_direction" value="">';

        /* Nonce for the individual move/remove actions. */
        wp_nonce_field(
            'rud_crm_customer_image_action',
            'rud_crm_customer_image_action_nonce'
        );

        echo '</form>';
    }


    /*
     * =========================================================
     * JAVASCRIPT
     * =========================================================
     */

    ?>

    <script>

    function rudSocialAll(state) {

        document
            .querySelectorAll(
                '.rud-social-active'
            )
            .forEach(
                function(box) {
                    box.checked = state;
                }
            );
    }


    jQuery(document).ready(function($) {

        var galleryFrame;
        var primaryFrame;

        var remainingSlots =
            parseInt(
                $('#rud-crm-image-slots').val() || 0,
                10
            );


        $('#rud-crm-select-primary-image').on(
            'click',
            function(event) {

                event.preventDefault();

                primaryFrame =
                    wp.media({
                        title: 'Select Company Logo / Profile Picture',
                        button: {
                            text: 'Use This Image'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: false
                    });

                primaryFrame.on(
                    'select',
                    function() {

                        var attachment =
                            primaryFrame
                                .state()
                                .get('selection')
                                .first()
                                .toJSON();

                        $('#rud-crm-primary-attachment-id')
                            .val( attachment.id );

                        $('#rud-crm-primary-selected-name')
                            .text(
                                'Selected: ' +
                                ( attachment.filename || 'image' )
                            );
                    }
                );

                primaryFrame.open();
            }
        );


        $('#rud-crm-primary-image-form').on(
            'submit',
            function(event) {

                if (
                    $(document.activeElement)
                        .attr('name') ===
                    'rud_crm_set_primary_attachment' &&
                    ! $('#rud-crm-primary-attachment-id').val()
                ) {

                    event.preventDefault();

                    alert(
                        'Please select a Company Logo / Profile Picture first.'
                    );
                }
            }
        );


        $('#rud-crm-select-images').on(
            'click',
            function(event) {

                event.preventDefault();

                galleryFrame =
                    wp.media({
                        title: 'Select Customer Gallery Images',
                        button: {
                            text: 'Use Selected Images'
                        },
                        library: {
                            type: 'image'
                        },
                        multiple: 'add'
                    });

                galleryFrame.on(
                    'select',
                    function() {

                        var selection =
                            galleryFrame
                                .state()
                                .get('selection');

                        var ids = [];

                        selection.each(
                            function(attachment) {

                                if (
                                    ids.length <
                                    remainingSlots
                                ) {
                                    ids.push(
                                        attachment.get('id')
                                    );
                                }
                            }
                        );

                        $('#rud-crm-attachment-ids')
                            .val(
                                ids.join(',')
                            );

                        $('#rud-crm-selected-count')
                            .text(
                                ids.length +
                                ' image(s) selected'
                            );
                    }
                );

                galleryFrame.open();
            }
        );


        $('#rud-crm-image-form').on(
            'submit',
            function(event) {

                if (
                    ! $('#rud-crm-attachment-ids')
                        .val()
                ) {

                    event.preventDefault();

                    alert(
                        'Please select at least one gallery image.'
                    );
                }
            }
        );


        function rudUpdateGallerySelectionCount() {

            var count =
                $('.rud-crm-gallery-checkbox:checked')
                    .length;

            $('#rud-crm-gallery-selected-count')
                .text(
                    count +
                    ' selected'
                );
        }


        $('#rud-crm-select-all-gallery').on(
            'click',
            function() {

                $('.rud-crm-gallery-checkbox')
                    .prop('checked', true);

                rudUpdateGallerySelectionCount();
            }
        );


        $('#rud-crm-clear-gallery-selection').on(
            'click',
            function() {

                $('.rud-crm-gallery-checkbox')
                    .prop('checked', false);

                rudUpdateGallerySelectionCount();
            }
        );


        $(document).on(
            'change',
            '.rud-crm-gallery-checkbox',
            rudUpdateGallerySelectionCount
        );


        $('#rud-crm-delete-selected-images').on(
            'click',
            function(event) {

                if (
                    $('.rud-crm-gallery-checkbox:checked')
                        .length === 0
                ) {

                    event.preventDefault();

                    alert(
                        'Select at least one gallery image to delete.'
                    );
                }
            }
        );
    });

    </script>

    <?php

    echo '</div>';
}