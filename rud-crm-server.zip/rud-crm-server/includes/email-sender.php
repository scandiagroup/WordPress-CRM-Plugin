<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * EMAIL SENDER
 * Version 1.0
 * =========================================================
 *
 * Provides:
 * - Resolve Customer / Contact Person email recipient
 * - Send email from saved template
 * - Send custom email
 * - Apply template variables
 * - Save complete email history / result
 *
 * Uses WordPress wp_mail().
 *
 * =========================================================
 */


/*
 * =========================================================
 * RESOLVE RECIPIENT
 * =========================================================
 */

function rud_crm_email_resolve_recipient(
    $customer_id,
    $contact_id = 0
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    $contact_id =
        absint(
            $contact_id
        );

    /*
     * Contact Person has priority.
     */
    if (
        $contact_id
        &&
        function_exists(
            'rud_crm_get_company_contact'
        )
    ) {

        $contact =
            rud_crm_get_company_contact(
                $contact_id
            );

        if (
            $contact
            &&
            absint(
                $contact->customer_id
            )
            ===
            $customer_id
        ) {

            $email =
                trim(
                    (string)
                    (
                        $contact->work_email
                        ?: $contact->private_email
                    )
                );

            if (
                is_email(
                    $email
                )
            ) {

                $name =
                    trim(
                        implode(
                            ' ',
                            array_filter(
                                array(
                                    $contact->first_name ?? '',
                                    $contact->middle_name ?? '',
                                    $contact->last_name ?? '',
                                )
                            )
                        )
                    );

                return array(

                    'name' =>
                        $name,

                    'email' =>
                        $email,

                    'contact_id' =>
                        $contact_id,
                );
            }
        }
    }

    /*
     * Fall back to the main customer/company email.
     */
    if (
        ! $customer_id
    ) {
        return new WP_Error(
            'email_recipient_missing',
            'No customer or contact recipient was selected.'
        );
    }

    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );

    if (
        ! $customer
    ) {

        return new WP_Error(
            'email_customer_not_found',
            'Customer could not be found.'
        );
    }

    $email = '';

    if (
        function_exists(
            'rud_crm_frontend_contact'
        )
    ) {

        $email =
            trim(
                (string)
                rud_crm_frontend_contact(
                    $customer_id,
                    'work_email'
                )
            );

        if (
            ! is_email(
                $email
            )
        ) {

            $email =
                trim(
                    (string)
                    rud_crm_frontend_contact(
                        $customer_id,
                        'private_email'
                    )
                );
        }
    }

    if (
        ! is_email(
            $email
        )
    ) {

        return new WP_Error(
            'email_recipient_missing',
            'No valid email address is saved for this customer or contact person.'
        );
    }

    $name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $customer->first_name ?? '',
                        $customer->middle_name ?? '',
                        $customer->last_name ?? '',
                    )
                )
            )
        );

    if (
        '' ===
        $name
    ) {

        $name =
            trim(
                (string)
                (
                    $customer->company_name
                    ?? ''
                )
            );
    }

    return array(

        'name' =>
            $name,

        'email' =>
            $email,

        'contact_id' =>
            0,
    );
}


/*
 * =========================================================
 * UPDATE EMAIL LOG RESULT
 * =========================================================
 */

function rud_crm_update_email_log_result(
    $log_id,
    $status,
    $error_message = ''
) {

    global $wpdb;

    $log_id =
        absint(
            $log_id
        );

    if (
        ! $log_id
        ||
        ! function_exists(
            'rud_crm_email_log_table'
        )
    ) {
        return false;
    }

    $data =
        array(

            'status' =>
                sanitize_key(
                    $status
                ),

            'error_message' =>
                sanitize_textarea_field(
                    $error_message
                ),
        );

    if (
        'sent' ===
        $status
    ) {

        $data['sent_at'] =
            current_time(
                'mysql'
            );
    }

    return
        false !==
        $wpdb->update(
            rud_crm_email_log_table(),
            $data,
            array(
                'id' =>
                    $log_id,
            )
        );
}


/*
 * =========================================================
 * BUILD EMAIL HEADERS
 * =========================================================
 */

function rud_crm_email_build_headers(
    $settings
) {

    $headers =
        array();

    $from_name =
        trim(
            (string)
            (
                $settings['from_name']
                ?? ''
            )
        );

    $from_email =
        trim(
            (string)
            (
                $settings['from_email']
                ?? ''
            )
        );

    $reply_to =
        trim(
            (string)
            (
                $settings['reply_to_email']
                ?? ''
            )
        );

    if (
        $from_name
        &&
        is_email(
            $from_email
        )
    ) {

        $headers[] =
            'From: ' .
            $from_name .
            ' <' .
            $from_email .
            '>';
    }

    if (
        is_email(
            $reply_to
        )
    ) {

        $headers[] =
            'Reply-To: ' .
            $reply_to;
    }

    if (
        ! empty(
            $settings['send_html']
        )
    ) {

        $headers[] =
            'Content-Type: text/html; charset=UTF-8';
    }

    return $headers;
}


/*
 * =========================================================
 * SEND EMAIL
 * =========================================================
 */

function rud_crm_send_email(
    $args
) {

    if (
        ! function_exists(
            'rud_crm_get_email_settings'
        )
        ||
        ! function_exists(
            'rud_crm_create_email_log'
        )
    ) {

        return new WP_Error(
            'email_system_unavailable',
            'The RUD CRM Email System is not available.'
        );
    }

    $args =
        wp_parse_args(
            $args,
            array(

                'customer_id' =>
                    0,

                'contact_id' =>
                    0,

                'project_id' =>
                    0,

                'task_id' =>
                    0,

                'template_id' =>
                    0,

                'subject' =>
                    '',

                'body' =>
                    '',
            )
        );

    $customer_id =
        absint(
            $args['customer_id']
        );

    $contact_id =
        absint(
            $args['contact_id']
        );

    $project_id =
        absint(
            $args['project_id']
        );

    $task_id =
        absint(
            $args['task_id']
        );

    $template_id =
        absint(
            $args['template_id']
        );

    $recipient =
        rud_crm_email_resolve_recipient(
            $customer_id,
            $contact_id
        );

    if (
        is_wp_error(
            $recipient
        )
    ) {
        return $recipient;
    }

    $subject =
        sanitize_text_field(
            $args['subject']
        );

    $body =
        wp_kses_post(
            $args['body']
        );

    /*
     * Load selected template when provided.
     */
    if (
        $template_id
    ) {

        $template =
            rud_crm_get_email_template(
                $template_id
            );

        if (
            ! $template
            ||
            'active' !==
            $template->status
        ) {

            return new WP_Error(
                'email_template_unavailable',
                'The selected email template is not available.'
            );
        }

        $subject =
            $template->subject;

        $body =
            $template->body;
    }

    if (
        '' ===
        trim(
            $subject
        )
    ) {

        return new WP_Error(
            'email_subject_required',
            'Email Subject is required.'
        );
    }

    if (
        '' ===
        trim(
            wp_strip_all_tags(
                $body
            )
        )
    ) {

        return new WP_Error(
            'email_body_required',
            'Email Body is required.'
        );
    }

    $context =
        array(

            'customer_id' =>
                $customer_id,

            'contact_id' =>
                $recipient['contact_id'],

            'project_id' =>
                $project_id,

            'task_id' =>
                $task_id,
        );

    $subject =
        rud_crm_apply_email_template_variables(
            $subject,
            $context
        );

    $body =
        rud_crm_apply_email_template_variables(
            $body,
            $context
        );

    $settings =
        rud_crm_get_email_settings();

    if (
        ! empty(
            $settings['send_html']
        )
    ) {

        /*
         * Preserve simple line breaks in template text.
         * Existing HTML remains supported.
         */
        $body =
            wpautop(
                $body
            );
    }

    $headers =
        rud_crm_email_build_headers(
            $settings
        );

    $log_id =
        rud_crm_create_email_log(
            array(

                'customer_id' =>
                    $customer_id,

                'contact_id' =>
                    $recipient['contact_id'],

                'project_id' =>
                    $project_id,

                'task_id' =>
                    $task_id,

                'template_id' =>
                    $template_id,

                'sent_by' =>
                    get_current_user_id(),

                'from_name' =>
                    $settings['from_name'],

                'from_email' =>
                    $settings['from_email'],

                'to_name' =>
                    $recipient['name'],

                'to_email' =>
                    $recipient['email'],

                'subject' =>
                    $subject,

                'body' =>
                    $body,

                'status' =>
                    'pending',
            )
        );

    $mail_error =
        '';

    $capture_error =
        function(
            $wp_error
        ) use (
            &
            $mail_error
        ) {

            if (
                is_wp_error(
                    $wp_error
                )
            ) {

                $mail_error =
                    $wp_error->get_error_message();
            }
        };

    add_action(
        'wp_mail_failed',
        $capture_error
    );

    $sent =
        wp_mail(
            $recipient['email'],
            $subject,
            $body,
            $headers
        );

    remove_action(
        'wp_mail_failed',
        $capture_error
    );

    if (
        $sent
    ) {

        if (
            $log_id
        ) {

            rud_crm_update_email_log_result(
                $log_id,
                'sent'
            );
        }

        return array(

            'success' =>
                true,

            'log_id' =>
                $log_id,

            'to_name' =>
                $recipient['name'],

            'to_email' =>
                $recipient['email'],

            'subject' =>
                $subject,
        );
    }

    if (
        '' ===
        $mail_error
    ) {

        $mail_error =
            'WordPress wp_mail() could not send the email.';
    }

    if (
        $log_id
    ) {

        rud_crm_update_email_log_result(
            $log_id,
            'failed',
            $mail_error
        );
    }

    return new WP_Error(
        'email_send_failed',
        $mail_error
    );
}
