<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END EMAIL SETUP + TEMPLATES
 * Version 1.3
 * =========================================================
 *
 * Shortcode:
 * [rud_crm_email_setup]
 *
 * Provides:
 * - Sender settings
 * - From Name
 * - From Email
 * - Reply-To Email
 * - HTML Email on/off
 * - Create Email Template
 * - Edit Email Template
 * - Delete Email Template
 * - Template variable reference
 *
 * Actual Send Email will be connected in the next module.
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_frontend_email_setup_can_manage() {

    if (
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_frontend_is_crm_admin'
        )
        &&
        rud_crm_frontend_is_crm_admin()
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            get_current_user_id()
        )
    ) {
        return true;
    }

    return false;
}


/*
 * =========================================================
 * PAGE URL
 * =========================================================
 */

function rud_crm_frontend_email_setup_url(
    $args = array()
) {

    $url =
        home_url(
            '/email-setup/'
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * SAVE EMAIL SETTINGS
 * =========================================================
 */

function rud_crm_frontend_process_email_settings() {

    if (
        empty(
            $_POST['rud_crm_email_action']
        )
        ||
        'save_settings' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_email_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_email_setup_can_manage()
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_email_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_email_nonce']
                )
            ),
            'rud_crm_save_email_settings'
        )
    ) {
        return;
    }

    rud_crm_update_email_settings(
        array(

            'from_name' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['from_name']
                        ?? ''
                    )
                ),

            'from_email' =>
                sanitize_email(
                    wp_unslash(
                        $_POST['from_email']
                        ?? ''
                    )
                ),

            'reply_to_email' =>
                sanitize_email(
                    wp_unslash(
                        $_POST['reply_to_email']
                        ?? ''
                    )
                ),

            'always_bcc_email' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['always_bcc_email']
                        ?? ''
                    )
                ),

            'send_html' =>
                ! empty(
                    $_POST['send_html']
                )
                ? 1
                : 0,
        )
    );

    wp_safe_redirect(
        rud_crm_frontend_email_setup_url(
            array(
                'rud_email_message' =>
                    'settings_saved',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_email_settings',
    71
);


/*
 * =========================================================
 * CREATE / UPDATE TEMPLATE
 * =========================================================
 */

function rud_crm_frontend_process_email_template_save() {

    if (
        empty(
            $_POST['rud_crm_email_action']
        )
        ||
        ! in_array(
            sanitize_key(
                wp_unslash(
                    $_POST['rud_crm_email_action']
                )
            ),
            array(
                'create_template',
                'update_template',
            ),
            true
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_email_setup_can_manage()
    ) {
        return;
    }

    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_email_action']
            )
        );

    $template_id =
        absint(
            $_POST['template_id']
            ?? 0
        );

    $nonce_action =
        'create_template' ===
        $action
        ? 'rud_crm_create_email_template'
        : 'rud_crm_update_email_template_' .
          $template_id;

    if (
        empty(
            $_POST['rud_crm_email_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_email_nonce']
                )
            ),
            $nonce_action
        )
    ) {
        return;
    }

    $data =
        array(

            'template_name' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['template_name']
                        ?? ''
                    )
                ),

            'subject' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['subject']
                        ?? ''
                    )
                ),

            'cc_email' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['cc_email']
                        ?? ''
                    )
                ),

            'bcc_email' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['bcc_email']
                        ?? ''
                    )
                ),

            'body' =>
                wp_kses_post(
                    wp_unslash(
                        $_POST['body']
                        ?? ''
                    )
                ),

            'status' =>
                sanitize_key(
                    wp_unslash(
                        $_POST['status']
                        ?? 'active'
                    )
                ),
        );

    if (
        'create_template' ===
        $action
    ) {

        $result =
            rud_crm_create_email_template(
                $data
            );

    } else {

        $result =
            rud_crm_update_email_template(
                $template_id,
                $data
            );
    }

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_email_setup_url(
                array(
                    'rud_email_error' =>
                        $result->get_error_code(),

                    'rud_edit_template' =>
                        $template_id,
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        rud_crm_frontend_email_setup_url(
            array(
                'rud_email_message' =>
                    'create_template' ===
                    $action
                    ? 'template_created'
                    : 'template_updated',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_email_template_save',
    72
);


/*
 * =========================================================
 * DELETE TEMPLATE
 * =========================================================
 */

function rud_crm_frontend_process_email_template_delete() {

    if (
        empty(
            $_POST['rud_crm_email_action']
        )
        ||
        'delete_template' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_email_action']
            )
        )
    ) {
        return;
    }

    if (
        ! rud_crm_frontend_email_setup_can_manage()
    ) {
        return;
    }

    $template_id =
        absint(
            $_POST['template_id']
            ?? 0
        );

    if (
        empty(
            $_POST['rud_crm_email_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_email_nonce']
                )
            ),
            'rud_crm_delete_email_template_' .
            $template_id
        )
    ) {
        return;
    }

    rud_crm_delete_email_template(
        $template_id
    );

    wp_safe_redirect(
        rud_crm_frontend_email_setup_url(
            array(
                'rud_email_message' =>
                    'template_deleted',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_email_template_delete',
    73
);


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_frontend_email_setup_message() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_email_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_email_error']
                ?? ''
            )
        );

    $messages =
        array(

            'settings_saved' =>
                'Email settings saved.',

            'template_created' =>
                'Email template created.',

            'template_updated' =>
                'Email template updated.',

            'template_deleted' =>
                'Email template deleted.',
        );

    if (
        isset(
            $messages[
                $message
            ]
        )
    ) {

        return
            '<div class="rud-crm-email-message rud-crm-email-success">' .
            esc_html(
                $messages[
                    $message
                ]
            ) .
            '</div>';
    }

    if (
        $error
    ) {

        return
            '<div class="rud-crm-email-message rud-crm-email-error">' .
            'The email setup could not be saved.' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * MAIN EMAIL SETUP UI
 * =========================================================
 */

function rud_crm_frontend_email_setup_shortcode() {

    if (
        ! rud_crm_frontend_email_setup_can_manage()
    ) {

        return
            '<div class="rud-crm-email-access-denied">' .
            'You do not have permission to manage Email Setup.' .
            '</div>';
    }

    $settings =
        rud_crm_get_email_settings();

    $templates =
        rud_crm_get_email_templates();

    $edit_template_id =
        absint(
            $_GET['rud_edit_template']
            ?? 0
        );

    $edit_template =
        $edit_template_id
        ? rud_crm_get_email_template(
            $edit_template_id
        )
        : null;

    $variables =
        rud_crm_email_template_variables();

    ob_start();

    ?>

    <div class="rud-crm-email-setup">

        <h1>
            EMAIL SETUP
        </h1>

        <p class="rud-crm-email-intro">
            Configure sender information, automatic copies and reusable email templates.
            <strong>Email Setup v1.3</strong>
        </p>

        <?php
        echo rud_crm_frontend_email_setup_message();
        ?>


        <section class="rud-crm-email-panel">

            <h2>
                Sender Settings
            </h2>

            <form method="post">

                <?php
                wp_nonce_field(
                    'rud_crm_save_email_settings',
                    'rud_crm_email_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_email_action"
                    value="save_settings"
                >

                <div class="rud-crm-email-subsection">

                    <h3>
                        Sender
                    </h3>

                    <div class="rud-crm-email-grid">

                        <div>

                            <label>
                                From Name
                            </label>

                            <input
                                type="text"
                                name="from_name"
                                value="<?php echo esc_attr( $settings['from_name'] ?? '' ); ?>"
                                placeholder="Olaf Rudolfsen"
                            >

                        </div>

                        <div>

                            <label>
                                From Email
                            </label>

                            <input
                                type="email"
                                name="from_email"
                                value="<?php echo esc_attr( $settings['from_email'] ?? '' ); ?>"
                                placeholder="olaf@rudolfsen.com"
                            >

                        </div>

                        <div>

                            <label>
                                Reply-To Email
                            </label>

                            <input
                                type="email"
                                name="reply_to_email"
                                value="<?php echo esc_attr( $settings['reply_to_email'] ?? '' ); ?>"
                                placeholder="olaf@rudolfsen.com"
                            >

                        </div>

                        <div class="rud-crm-email-checkbox-wrap">

                            <label>

                                <input
                                    type="checkbox"
                                    name="send_html"
                                    value="1"
                                    <?php checked( ! empty( $settings['send_html'] ) ); ?>
                                >

                                Send HTML Email

                            </label>

                        </div>

                    </div>

                </div>


                <div class="rud-crm-email-subsection rud-crm-email-copy-settings">

                    <h3>
                        Copy Settings
                    </h3>

                    <p class="rud-crm-email-help">
                        This address automatically receives a hidden copy of every CRM email.
                    </p>

                    <div class="rud-crm-email-grid">

                        <div class="rud-crm-email-wide">

                            <label>
                                Always BCC Email
                            </label>

                            <input
                                type="text"
                                name="always_bcc_email"
                                value="<?php echo esc_attr( $settings['always_bcc_email'] ?? 'olaf@rudolfsen.com' ); ?>"
                                placeholder="olaf@rudolfsen.com"
                            >

                            <small>
                                Default: olaf@rudolfsen.com. Multiple addresses may be separated with commas.
                            </small>

                        </div>

                    </div>

                </div>

                <button
                    type="submit"
                    class="rud-crm-email-primary-button"
                >
                    SAVE EMAIL SETTINGS
                </button>

            </form>

        </section>


        <section class="rud-crm-email-panel">

            <h2>
                Email Templates
            </h2>

            <p class="rud-crm-email-help">
                Each template can have its own optional CC and BCC recipients.
            </p>

            <p>
                <a
                    class="rud-crm-email-primary-button rud-crm-email-create-link"
                    href="#rud-crm-create-email-template"
                >
                    + CREATE NEW EMAIL TEMPLATE
                </a>
            </p>

            <?php if ( ! empty( $templates ) ) : ?>

                <div class="rud-crm-email-template-list">

                    <?php foreach ( $templates as $template ) : ?>

                        <div class="rud-crm-email-template-row">

                            <div>

                                <strong>
                                    <?php echo esc_html( $template->template_name ); ?>
                                </strong>

                                <div class="rud-crm-email-template-subject">
                                    <?php echo esc_html( $template->subject ); ?>
                                </div>

                                <span class="rud-crm-email-template-status">
                                    <?php echo esc_html( ucfirst( $template->status ) ); ?>
                                </span>

                                <?php if ( ! empty( $template->cc_email ) ) : ?>
                                    <div class="rud-crm-email-copy-line">
                                        <strong>CC:</strong>
                                        <?php echo esc_html( $template->cc_email ); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ( ! empty( $template->bcc_email ) ) : ?>
                                    <div class="rud-crm-email-copy-line">
                                        <strong>BCC:</strong>
                                        <?php echo esc_html( $template->bcc_email ); ?>
                                    </div>
                                <?php endif; ?>

                            </div>

                            <div class="rud-crm-email-template-actions">

                                <a
                                    href="<?php
                                    echo esc_url(
                                        rud_crm_frontend_email_setup_url(
                                            array(
                                                'rud_edit_template' =>
                                                    $template->id,
                                            )
                                        )
                                    );
                                    ?>"
                                >
                                    EDIT
                                </a>

                                <form method="post">

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_delete_email_template_' .
                                        $template->id,
                                        'rud_crm_email_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_email_action"
                                        value="delete_template"
                                    >

                                    <input
                                        type="hidden"
                                        name="template_id"
                                        value="<?php echo esc_attr( $template->id ); ?>"
                                    >

                                    <button
                                        type="submit"
                                        onclick="return confirm('Delete this email template?');"
                                    >
                                        DELETE
                                    </button>

                                </form>

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php else : ?>

                <div class="rud-crm-email-empty">
                    No email templates have been created yet.
                </div>

            <?php endif; ?>


            <div class="rud-crm-email-template-editor">

                <h3 id="rud-crm-create-email-template">
                    <?php
                    echo $edit_template
                    ? 'Edit Email Template'
                    : 'Create New Email Template';
                    ?>
                </h3>

                <?php if ( ! $edit_template ) : ?>
                    <p class="rud-crm-email-help">
                        Enter the template details below and click CREATE EMAIL TEMPLATE.
                    </p>
                <?php endif; ?>

                <form method="post">

                    <?php

                    if (
                        $edit_template
                    ) {

                        wp_nonce_field(
                            'rud_crm_update_email_template_' .
                            $edit_template->id,
                            'rud_crm_email_nonce'
                        );

                    } else {

                        wp_nonce_field(
                            'rud_crm_create_email_template',
                            'rud_crm_email_nonce'
                        );
                    }

                    ?>

                    <input
                        type="hidden"
                        name="rud_crm_email_action"
                        value="<?php echo $edit_template ? 'update_template' : 'create_template'; ?>"
                    >

                    <?php if ( $edit_template ) : ?>

                        <input
                            type="hidden"
                            name="template_id"
                            value="<?php echo esc_attr( $edit_template->id ); ?>"
                        >

                    <?php endif; ?>

                    <div class="rud-crm-email-grid">

                        <div>

                            <label>
                                Template Name
                            </label>

                            <input
                                type="text"
                                name="template_name"
                                required
                                value="<?php echo esc_attr( $edit_template->template_name ?? '' ); ?>"
                                placeholder="Example: Follow-up Email"
                            >

                        </div>

                        <div>

                            <label>
                                Status
                            </label>

                            <select name="status">

                                <option
                                    value="active"
                                    <?php selected( $edit_template->status ?? 'active', 'active' ); ?>
                                >
                                    Active
                                </option>

                                <option
                                    value="inactive"
                                    <?php selected( $edit_template->status ?? '', 'inactive' ); ?>
                                >
                                    Inactive
                                </option>

                            </select>

                        </div>

                        <div class="rud-crm-email-wide">

                            <label>
                                Email Subject
                            </label>

                            <input
                                type="text"
                                name="subject"
                                required
                                value="<?php echo esc_attr( $edit_template->subject ?? '' ); ?>"
                                placeholder="Example: Follow-up regarding {company_name}"
                            >

                        </div>

                        <div>

                            <label>
                                CC Email (Optional)
                            </label>

                            <input
                                type="text"
                                name="cc_email"
                                value="<?php echo esc_attr( $edit_template->cc_email ?? '' ); ?>"
                                placeholder="name@example.com"
                            >

                            <small>
                                Optional. Separate multiple addresses with commas.
                            </small>

                        </div>

                        <div>

                            <label>
                                BCC Email (Optional)
                            </label>

                            <input
                                type="text"
                                name="bcc_email"
                                value="<?php echo esc_attr( $edit_template->bcc_email ?? '' ); ?>"
                                placeholder="name@example.com"
                            >

                            <small>
                                Optional. Separate multiple addresses with commas.
                            </small>

                        </div>

                        <div class="rud-crm-email-wide">

                            <label>
                                Email Body
                            </label>

                            <textarea
                                name="body"
                                rows="12"
                                placeholder="Hello {contact_first_name},"
                            ><?php echo esc_textarea( $edit_template->body ?? '' ); ?></textarea>

                        </div>

                    </div>

                    <div class="rud-crm-email-editor-actions">

                        <button
                            type="submit"
                            class="rud-crm-email-primary-button"
                        >
                            <?php
                            echo $edit_template
                            ? 'SAVE TEMPLATE CHANGES'
                            : 'CREATE TEMPLATE';
                            ?>
                        </button>

                        <?php if ( $edit_template ) : ?>

                            <a
                                href="<?php echo esc_url( rud_crm_frontend_email_setup_url() ); ?>"
                                class="rud-crm-email-secondary-button"
                            >
                                CANCEL
                            </a>

                        <?php endif; ?>

                    </div>

                </form>

            </div>

        </section>


        <section class="rud-crm-email-panel">

            <h2>
                Template Variables
            </h2>

            <p>
                These variables can be used in the Email Subject and Email Body.
            </p>

            <div class="rud-crm-email-variable-grid">

                <?php foreach ( $variables as $variable => $label ) : ?>

                    <div>

                        <code>
                            <?php echo esc_html( $variable ); ?>
                        </code>

                        <span>
                            <?php echo esc_html( $label ); ?>
                        </span>

                    </div>

                <?php endforeach; ?>

            </div>

        </section>

    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_email_setup',
    'rud_crm_frontend_email_setup_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_email_setup_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-email-setup {
        width:100%;
    }

    .rud-crm-email-intro {
        margin-top:-8px;
        color:#667085;
    }

    .rud-crm-email-panel {
        margin-top:22px;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
    }

    .rud-crm-email-panel h2 {
        margin-top:0 !important;
    }

    .rud-crm-email-subsection {
        margin:0 0 22px;
        padding:18px;
        border:1px solid #eaecf0;
        border-radius:9px;
        background:#fafafa;
    }

    .rud-crm-email-subsection h3 {
        margin:0 0 14px !important;
    }

    .rud-crm-email-copy-settings {
        margin-top:18px;
        background:#f8fafc;
    }

    .rud-crm-email-help {
        margin:0 0 14px;
        color:#667085;
    }

    .rud-crm-email-copy-line {
        margin-top:6px;
        font-size:12px;
        color:#475467;
    }

    .rud-crm-email-create-link {
        display:inline-block;
        text-decoration:none;
    }

    .rud-crm-email-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-email-wide {
        grid-column:1 / -1;
    }

    .rud-crm-email-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-email-grid input,
    .rud-crm-email-grid select,
    .rud-crm-email-grid textarea {
        width:100%;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-email-checkbox-wrap {
        display:flex;
        align-items:flex-end;
    }

    .rud-crm-email-checkbox-wrap label {
        display:flex;
        align-items:center;
        gap:8px;
    }

    .rud-crm-email-checkbox-wrap input {
        width:auto;
    }

    .rud-crm-email-primary-button,
    .rud-crm-email-secondary-button,
    .rud-crm-email-template-actions a,
    .rud-crm-email-template-actions button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:38px;
        padding:8px 13px;
        border:1px solid #1d2939;
        border-radius:7px;
        font-size:11px;
        font-weight:700;
        text-decoration:none !important;
        cursor:pointer;
    }

    .rud-crm-email-primary-button {
        margin-top:18px;
        background:#1d2939;
        color:#fff;
    }

    .rud-crm-email-secondary-button,
    .rud-crm-email-template-actions a {
        background:#fff;
        color:#1d2939 !important;
    }

    .rud-crm-email-template-actions button {
        background:#fff;
        border-color:#b42318;
        color:#b42318;
    }

    .rud-crm-email-template-list {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-email-template-row {
        display:flex;
        justify-content:space-between;
        gap:18px;
        padding:14px 16px;
        border-bottom:1px solid #eaecf0;
    }

    .rud-crm-email-template-row:last-child {
        border-bottom:0;
    }

    .rud-crm-email-template-subject {
        margin-top:4px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-email-template-status {
        display:inline-flex;
        margin-top:6px;
        padding:3px 7px;
        border-radius:999px;
        background:#f2f4f7;
        font-size:10px;
        font-weight:700;
        text-transform:uppercase;
    }

    .rud-crm-email-template-actions {
        display:flex;
        gap:7px;
        flex-wrap:wrap;
    }

    .rud-crm-email-template-actions form {
        margin:0;
    }

    .rud-crm-email-template-editor {
        margin-top:20px;
        padding-top:20px;
        border-top:1px solid #eaecf0;
    }

    .rud-crm-email-editor-actions {
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
    }

    .rud-crm-email-empty {
        padding:14px 16px;
        border:1px solid #eaecf0;
        border-radius:8px;
        color:#667085;
    }

    .rud-crm-email-variable-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:10px;
    }

    .rud-crm-email-variable-grid > div {
        display:flex;
        align-items:center;
        gap:12px;
        padding:10px 12px;
        border:1px solid #eaecf0;
        border-radius:8px;
    }

    .rud-crm-email-variable-grid code {
        font-weight:700;
    }

    .rud-crm-email-variable-grid span {
        color:#667085;
        font-size:12px;
    }

    .rud-crm-email-message {
        margin-top:16px;
        padding:11px 13px;
        border-radius:7px;
    }

    .rud-crm-email-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-email-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:700px) {

        .rud-crm-email-grid,
        .rud-crm-email-variable-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-email-wide {
            grid-column:auto;
        }

        .rud-crm-email-template-row {
            flex-direction:column;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-email-setup',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-email-setup'
    );

    wp_add_inline_style(
        'rud-crm-frontend-email-setup',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_email_setup_styles',
    80
);
