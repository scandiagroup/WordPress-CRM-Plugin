<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END CUSTOMER EDIT / DELETE
 * Version 2.1
 * =========================================================
 *
 * CLEANUP:
 * - Edit Customer no longer shows the "Add Norwegian Company"
 *   BRREG creation/search block.
 * - Existing company information remains directly editable.
 * - Customer Type is moved to the bottom, below Customer Image / Company Logo.
 *
 * =========================================================
 */


/*
 * =========================================================
 * CRM URL HELPERS
 * =========================================================
 */

function rud_crm_frontend_edit_crm_url() {

    if ( function_exists( 'rud_crm_customer_frontend_url' ) ) {
        return rud_crm_customer_frontend_url();
    }

    $page =
        get_page_by_path(
            'customer-crm'
        );

    if (
        $page
        &&
        'publish' === $page->post_status
    ) {
        return get_permalink(
            $page->ID
        );
    }

    return home_url(
        '/customer-crm/'
    );
}


function rud_crm_frontend_edit_customer_url(
    $customer_id
) {

    return add_query_arg(
        array(
            'rud_crm_action'  => 'edit_customer',
            'rud_customer_id' => absint( $customer_id ),
        ),
        rud_crm_frontend_edit_crm_url()
    );
}


function rud_crm_frontend_edit_profile_url(
    $customer_id,
    $message = ''
) {

    $args =
        array(
            'rud_customer_id' =>
                absint(
                    $customer_id
                ),
        );

    if ( $message ) {
        $args['rud_crm_customer_message'] =
            sanitize_key(
                $message
            );
    }

    return add_query_arg(
        $args,
        rud_crm_frontend_edit_crm_url()
    );
}


/*
 * =========================================================
 * TABLE EXISTS
 * =========================================================
 */

function rud_crm_frontend_edit_table_exists(
    $table
) {

    global $wpdb;

    return
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        )
        ===
        $table;
}


/*
 * =========================================================
 * PERMISSIONS
 * =========================================================
 */

function rud_crm_frontend_edit_can_edit(
    $customer_id
) {

    if (
        ! function_exists(
            'rud_crm_frontend_can_edit_customer'
        )
    ) {
        return false;
    }

    return (bool)
        rud_crm_frontend_can_edit_customer(
            absint(
                $customer_id
            )
        );
}


function rud_crm_frontend_edit_can_delete(
    $customer_id
) {

    if (
        ! function_exists(
            'rud_crm_frontend_can_delete_customer'
        )
    ) {
        return false;
    }

    return (bool)
        rud_crm_frontend_can_delete_customer(
            absint(
                $customer_id
            )
        );
}


/*
 * =========================================================
 * GET CONTACT
 * =========================================================
 */

function rud_crm_frontend_edit_get_contact(
    $customer_id,
    $contact_type
) {

    if (
        function_exists(
            'rud_crm_frontend_contact'
        )
    ) {
        return
            rud_crm_frontend_contact(
                absint(
                    $customer_id
                ),
                sanitize_key(
                    $contact_type
                )
            );
    }

    return '';
}


/*
 * =========================================================
 * SAVE / UPDATE CONTACT
 * =========================================================
 */

function rud_crm_frontend_edit_save_contact(
    $customer_id,
    $contact_type,
    $label,
    $value,
    $is_primary = 0
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    $contact_type =
        sanitize_key(
            $contact_type
        );

    $value =
        trim(
            (string)
            $value
        );

    $table =
        $wpdb->prefix .
        'rudcrm_contact_methods';

    if (
        ! rud_crm_frontend_edit_table_exists(
            $table
        )
    ) {
        return false;
    }

    $existing_id =
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$table}
                     WHERE customer_id = %d
                     AND contact_type = %s
                     ORDER BY is_primary DESC, id ASC
                     LIMIT 1",
                    $customer_id,
                    $contact_type
                )
            )
        );

    if (
        '' ===
        $value
    ) {

        $wpdb->delete(
            $table,
            array(
                'customer_id'  =>
                    $customer_id,

                'contact_type' =>
                    $contact_type,
            ),
            array(
                '%d',
                '%s',
            )
        );

        return true;
    }

    $now =
        current_time(
            'mysql'
        );

    if (
        $existing_id
    ) {

        $result =
            $wpdb->update(
                $table,
                array(
                    'contact_label' =>
                        sanitize_text_field(
                            $label
                        ),

                    'contact_value' =>
                        $value,

                    'is_primary' =>
                        $is_primary
                        ? 1
                        : 0,

                    'updated_at' =>
                        $now,
                ),
                array(
                    'id' =>
                        $existing_id,
                ),
                array(
                    '%s',
                    '%s',
                    '%d',
                    '%s',
                ),
                array(
                    '%d',
                )
            );

        return
            false !==
            $result;
    }

    if (
        function_exists(
            'rud_crm_frontend_create_contact'
        )
    ) {

        return
            rud_crm_frontend_create_contact(
                $customer_id,
                $contact_type,
                $label,
                $value,
                $is_primary
            );
    }

    $result =
        $wpdb->insert(
            $table,
            array(
                'customer_id' =>
                    $customer_id,

                'contact_type' =>
                    $contact_type,

                'contact_label' =>
                    sanitize_text_field(
                        $label
                    ),

                'contact_value' =>
                    $value,

                'is_primary' =>
                    $is_primary
                    ? 1
                    : 0,

                'is_verified' =>
                    0,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    return
        false !==
        $result;
}


/*
 * =========================================================
 * PROCESS CUSTOMER UPDATE
 * =========================================================
 */

function rud_crm_frontend_process_edit_customer() {

    if (
        empty(
            $_POST['rud_crm_frontend_edit_action']
        )
        ||
        'save_customer' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_frontend_edit_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $customer_id =
        isset(
            $_POST['rud_customer_id']
        )
        ? absint(
            $_POST['rud_customer_id']
        )
        : 0;

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to edit this customer.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_frontend_edit_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_frontend_edit_nonce']
                )
            ),
            'rud_crm_frontend_edit_customer_' .
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    global $wpdb;

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    $customer_type =
        sanitize_key(
            wp_unslash(
                $_POST['customer_type'] ?? 'person'
            )
        );

    if (
        ! in_array(
            $customer_type,
            array(
                'person',
                'company'
            ),
            true
        )
    ) {
        $customer_type =
            'person';
    }

    $title =
        sanitize_text_field(
            wp_unslash(
                $_POST['title'] ?? ''
            )
        );

    $first_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['first_name'] ?? ''
            )
        );

    $middle_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['middle_name'] ?? ''
            )
        );

    $last_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['last_name'] ?? ''
            )
        );

    $preferred_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['preferred_name'] ?? ''
            )
        );

    $company_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['company_name'] ?? ''
            )
        );

    $organization_number =
        sanitize_text_field(
            wp_unslash(
                $_POST['organization_number'] ?? ''
            )
        );

    $organization_form_code =
        strtoupper(
            sanitize_text_field(
                wp_unslash(
                    $_POST['organization_form_code'] ?? ''
                )
            )
        );

    $organization_form_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['organization_form_name'] ?? ''
            )
        );

    $industry_code =
        sanitize_text_field(
            wp_unslash(
                $_POST['industry_code'] ?? ''
            )
        );

    $industry_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['industry_name'] ?? ''
            )
        );

    /*
     * Edit mode no longer uses the Add Norwegian Company
     * BRREG selection interface.
     *
     * Existing company fields remain editable and are saved.
     */
    $brreg_selected =
        false;

    $job_title =
        sanitize_text_field(
            wp_unslash(
                $_POST['job_title'] ?? ''
            )
        );

    $department =
        sanitize_text_field(
            wp_unslash(
                $_POST['department'] ?? ''
            )
        );

    $status =
        sanitize_key(
            wp_unslash(
                $_POST['status'] ?? 'lead'
            )
        );

    $allowed_statuses =
        array(
            'lead',
            'customer',
            'partner',
            'inactive',
        );

    if (
        ! in_array(
            $status,
            $allowed_statuses,
            true
        )
    ) {
        $status =
            'lead';
    }

    if (
        (
            'person' ===
            $customer_type
            &&
            '' === trim( $first_name )
            &&
            '' === trim( $last_name )
        )
        ||
        (
            'company' ===
            $customer_type
            &&
            '' === trim( $company_name )
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_edit_error',
                'name_required',
                rud_crm_frontend_edit_customer_url(
                    $customer_id
                )
            )
        );

        exit;
    }

    $updated =
        $wpdb->update(
            $customers_table,
            array(
                'customer_type' =>
                    $customer_type,

                'title' =>
                    $title,

                'first_name' =>
                    $first_name,

                'middle_name' =>
                    $middle_name,

                'last_name' =>
                    $last_name,

                'preferred_name' =>
                    $preferred_name,

                'company_name' =>
                    $company_name,

                'organization_number' =>
                    $organization_number,

                'job_title' =>
                    $job_title,

                'department' =>
                    $department,

                'status' =>
                    $status,

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    $customer_id,
            )
        );

    if (
        false ===
        $updated
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_edit_error',
                'database_error',
                rud_crm_frontend_edit_customer_url(
                    $customer_id
                )
            )
        );

        exit;
    }

    if (
        'company' ===
        $customer_type
        &&
        function_exists(
            'rud_crm_brreg_save_company_details'
        )
    ) {

        rud_crm_brreg_save_company_details(
            $customer_id,
            array(
                'organization_form_code' =>
                    $organization_form_code,

                'organization_form_name' =>
                    $organization_form_name,

                'industry_code' =>
                    $industry_code,

                'industry_name' =>
                    $industry_name,

                'brreg_synced' =>
                    $brreg_selected
            )
        );
    }

    $details_table =
        $wpdb->prefix .
        'rudcrm_customer_details';

    if (
        rud_crm_frontend_edit_table_exists(
            $details_table
        )
    ) {

        $birth_date =
            sanitize_text_field(
                wp_unslash(
                    $_POST['birth_date'] ?? ''
                )
            );

        $gender =
            sanitize_text_field(
                wp_unslash(
                    $_POST['gender'] ?? ''
                )
            );

        $preferred_language =
            sanitize_text_field(
                wp_unslash(
                    $_POST['preferred_language'] ?? ''
                )
            );

        $nationality =
            sanitize_text_field(
                wp_unslash(
                    $_POST['nationality'] ?? ''
                )
            );

        $website_url =
            trim(
                sanitize_text_field(
                    wp_unslash(
                        $_POST['website_url'] ?? ''
                    )
                )
            );

        /*
         * Website convenience:
         * The user may enter only example.com.
         * We automatically store it as https://example.com.
         */
        if (
            '' !==
            $website_url
            &&
            ! preg_match(
                '#^https?://#i',
                $website_url
            )
        ) {

            $website_url =
                'https://' .
                ltrim(
                    $website_url,
                    '/'
                );
        }

        $website_url =
            esc_url_raw(
                $website_url
            );

        $notes =
            sanitize_textarea_field(
                wp_unslash(
                    $_POST['notes'] ?? ''
                )
            );

        $birth_year =
            null;

        if (
            $birth_date
            &&
            preg_match(
                '/^(\d{4})-\d{2}-\d{2}$/',
                $birth_date,
                $matches
            )
        ) {
            $birth_year =
                absint(
                    $matches[1]
                );
        }

        $details_id =
            absint(
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id
                         FROM {$details_table}
                         WHERE customer_id = %d
                         LIMIT 1",
                        $customer_id
                    )
                )
            );

        $details_data =
            array(
                'birth_date' =>
                    $birth_date
                    ? $birth_date
                    : null,

                'birth_year' =>
                    $birth_year,

                'gender' =>
                    $gender,

                'preferred_language' =>
                    $preferred_language,

                'nationality' =>
                    $nationality,

                'website_url' =>
                    $website_url,

                'notes' =>
                    $notes,

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            );

        if (
            $details_id
        ) {

            $wpdb->update(
                $details_table,
                $details_data,
                array(
                    'id' =>
                        $details_id,
                )
            );

        } else {

            $details_data['customer_id'] =
                $customer_id;

            $details_data['created_at'] =
                current_time(
                    'mysql'
                );

            $wpdb->insert(
                $details_table,
                $details_data
            );
        }
    }

    $private_email =
        sanitize_email(
            wp_unslash(
                $_POST['private_email'] ?? ''
            )
        );

    $work_email =
        sanitize_email(
            wp_unslash(
                $_POST['work_email'] ?? ''
            )
        );

    $mobile_phone =
        sanitize_text_field(
            wp_unslash(
                $_POST['mobile_phone'] ?? ''
            )
        );

    $home_phone =
        sanitize_text_field(
            wp_unslash(
                $_POST['home_phone'] ?? ''
            )
        );

    $office_phone =
        sanitize_text_field(
            wp_unslash(
                $_POST['office_phone'] ?? ''
            )
        );

    $whatsapp =
        sanitize_text_field(
            wp_unslash(
                $_POST['whatsapp'] ?? ''
            )
        );

    if (
        function_exists(
            'rud_crm_sanitize_phone_number'
        )
    ) {

        $mobile_phone =
            rud_crm_sanitize_phone_number(
                $mobile_phone
            );

        $home_phone =
            rud_crm_sanitize_phone_number(
                $home_phone
            );

        $office_phone =
            rud_crm_sanitize_phone_number(
                $office_phone
            );

        $whatsapp =
            rud_crm_sanitize_phone_number(
                $whatsapp
            );
    }

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'private_email',
        'Private Email',
        $private_email,
        1
    );

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'work_email',
        'Work Email',
        $work_email,
        0
    );

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'mobile_phone',
        'Mobile Phone',
        $mobile_phone,
        1
    );

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'home_phone',
        'Home Phone',
        $home_phone,
        0
    );

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'office_phone',
        'Office Phone',
        $office_phone,
        0
    );

    rud_crm_frontend_edit_save_contact(
        $customer_id,
        'whatsapp',
        'WhatsApp',
        $whatsapp,
        0
    );

    $address_table =
        $wpdb->prefix .
        'rudcrm_addresses';

    if (
        rud_crm_frontend_edit_table_exists(
            $address_table
        )
    ) {

        $address_line_1 =
            sanitize_text_field(
                wp_unslash(
                    $_POST['address_line_1'] ?? ''
                )
            );

        $address_line_2 =
            sanitize_text_field(
                wp_unslash(
                    $_POST['address_line_2'] ?? ''
                )
            );

        $postal_code =
            sanitize_text_field(
                wp_unslash(
                    $_POST['postal_code'] ?? ''
                )
            );

        $city =
            sanitize_text_field(
                wp_unslash(
                    $_POST['city'] ?? ''
                )
            );

        $state_region =
            sanitize_text_field(
                wp_unslash(
                    $_POST['state_region'] ?? ''
                )
            );

        $country_code =
            strtoupper(
                substr(
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['country_code'] ?? ''
                        )
                    ),
                    0,
                    2
                )
            );

        $has_address =
            (
                $address_line_1
                ||
                $address_line_2
                ||
                $postal_code
                ||
                $city
                ||
                $state_region
                ||
                $country_code
            );

        $address_id =
            absint(
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id
                         FROM {$address_table}
                         WHERE customer_id = %d
                         AND address_type = 'private'
                         ORDER BY is_primary DESC, id ASC
                         LIMIT 1",
                        $customer_id
                    )
                )
            );

        if (
            ! $has_address
        ) {

            if (
                $address_id
            ) {
                $wpdb->delete(
                    $address_table,
                    array(
                        'id' =>
                            $address_id,
                    )
                );
            }

        } else {

            $address_data =
                array(
                    'address_type' =>
                        'private',

                    'company_name' =>
                        $company_name,

                    'address_line_1' =>
                        $address_line_1,

                    'address_line_2' =>
                        $address_line_2,

                    'postal_code' =>
                        $postal_code,

                    'city' =>
                        $city,

                    'state_region' =>
                        $state_region,

                    'country_code' =>
                        $country_code,

                    'is_primary' =>
                        1,

                    'updated_at' =>
                        current_time(
                            'mysql'
                        ),
                );

            if (
                $address_id
            ) {

                $wpdb->update(
                    $address_table,
                    $address_data,
                    array(
                        'id' =>
                            $address_id,
                    )
                );

            } else {

                $address_data['customer_id'] =
                    $customer_id;

                $address_data['created_at'] =
                    current_time(
                        'mysql'
                    );

                $wpdb->insert(
                    $address_table,
                    $address_data
                );
            }
        }
    }

    wp_safe_redirect(
        rud_crm_frontend_edit_profile_url(
            $customer_id,
            'updated'
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_edit_customer',
    26
);


/*
 * =========================================================
 * PROJECT CONNECTION HELPERS
 * =========================================================
 */

function rud_crm_frontend_edit_is_project_admin() {

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_frontend_is_crm_admin'
        )
        &&
        rud_crm_frontend_is_crm_admin(
            get_current_user_id()
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            get_current_user_id()
        )
    ) {
        return true;
    }

    return false;
}


function rud_crm_frontend_edit_visible_projects() {

    global $wpdb;

    if (
        ! function_exists(
            'rud_crm_projects_table'
        )
    ) {
        return array();
    }

    $table =
        rud_crm_projects_table();

    if (
        rud_crm_frontend_edit_is_project_admin()
    ) {

        return
            $wpdb->get_results(
                "SELECT *
                 FROM {$table}
                 ORDER BY project_title ASC"
            );
    }

    return
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$table}
                 WHERE created_by = %d
                 ORDER BY project_title ASC",
                get_current_user_id()
            )
        );
}


function rud_crm_frontend_edit_can_manage_project(
    $project_id
) {

    global $wpdb;

    $project_id =
        absint(
            $project_id
        );

    if (
        ! $project_id
        ||
        ! function_exists(
            'rud_crm_projects_table'
        )
    ) {
        return false;
    }

    if (
        rud_crm_frontend_edit_is_project_admin()
    ) {
        return true;
    }

    $created_by =
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT created_by
                     FROM " .
                    rud_crm_projects_table() .
                    "
                     WHERE id = %d
                     LIMIT 1",
                    $project_id
                )
            )
        );

    return
        $created_by > 0
        &&
        $created_by ===
        get_current_user_id();
}


function rud_crm_frontend_edit_project_url(
    $project_id
) {

    if (
        function_exists(
            'rud_crm_frontend_project_url'
        )
    ) {
        return
            rud_crm_frontend_project_url(
                $project_id
            );
    }

    return add_query_arg(
        'rud_project_id',
        absint(
            $project_id
        ),
        home_url(
            '/projects/'
        )
    );
}


/*
 * =========================================================
 * CONNECT CUSTOMER TO PROJECT
 * =========================================================
 */

function rud_crm_frontend_process_customer_project_connect() {

    if (
        empty(
            $_POST['rud_crm_customer_project_action']
        )
        ||
        'connect_project' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_customer_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $project_id =
        absint(
            $_POST['rud_project_id']
            ?? 0
        );

    if (
        ! $customer_id
        ||
        ! $project_id
        ||
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
        ||
        ! rud_crm_frontend_edit_can_manage_project(
            $project_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to connect this customer to that project.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_customer_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_customer_project_nonce']
                )
            ),
            'rud_crm_customer_connect_project_' .
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    if (
        ! function_exists(
            'rud_crm_connect_customer_to_project'
        )
    ) {
        wp_die(
            esc_html__(
                'The Projects module is not available.',
                'rud-crm-server'
            )
        );
    }

    $result =
        rud_crm_connect_customer_to_project(
            $project_id,
            $customer_id,
            array(
                'relationship_role' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['relationship_role']
                            ?? ''
                        )
                    ),

                'relationship_status' =>
                    'active',

                'created_by' =>
                    get_current_user_id(),
            )
        );

    if (
        is_wp_error(
            $result
        )
    ) {
        wp_safe_redirect(
            add_query_arg(
                'rud_crm_project_connection_error',
                'connect_failed',
                rud_crm_frontend_edit_customer_url(
                    $customer_id
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_crm_project_connection',
            'connected',
            rud_crm_frontend_edit_customer_url(
                $customer_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_customer_project_connect',
    27
);


/*
 * =========================================================
 * REMOVE CUSTOMER FROM PROJECT
 * =========================================================
 */

function rud_crm_frontend_process_customer_project_disconnect() {

    if (
        empty(
            $_POST['rud_crm_customer_project_action']
        )
        ||
        'disconnect_project' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_customer_project_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $project_id =
        absint(
            $_POST['rud_project_id']
            ?? 0
        );

    if (
        ! $customer_id
        ||
        ! $project_id
        ||
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
        ||
        ! rud_crm_frontend_edit_can_manage_project(
            $project_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to remove this project connection.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_customer_project_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_customer_project_nonce']
                )
            ),
            'rud_crm_customer_disconnect_project_' .
            $customer_id .
            '_' .
            $project_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    if (
        function_exists(
            'rud_crm_disconnect_customer_from_project'
        )
    ) {
        rud_crm_disconnect_customer_from_project(
            $project_id,
            $customer_id
        );
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_crm_project_connection',
            'removed',
            rud_crm_frontend_edit_customer_url(
                $customer_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_customer_project_disconnect',
    28
);


/*
 * =========================================================
 * PROJECT CONNECTION HTML
 * =========================================================
 */

function rud_crm_frontend_edit_project_connection_html(
    $customer_id
) {

    if (
        ! function_exists(
            'rud_crm_get_customer_projects'
        )
        ||
        ! function_exists(
            'rud_crm_connect_customer_to_project'
        )
    ) {
        return '';
    }

    $customer_id =
        absint(
            $customer_id
        );

    $all_projects =
        rud_crm_frontend_edit_visible_projects();

    $connected_projects =
        rud_crm_get_customer_projects(
            $customer_id
        );

    /*
     * Only show project connections the current user may manage.
     */
    $connected_projects =
        array_values(
            array_filter(
                (array)
                $connected_projects,
                function( $project ) {

                    return
                        rud_crm_frontend_edit_can_manage_project(
                            $project->id
                        );
                }
            )
        );

    $connected_ids =
        array_map(
            function( $project ) {

                return absint(
                    $project->id
                );
            },
            $connected_projects
        );

    $available_projects =
        array_values(
            array_filter(
                (array)
                $all_projects,
                function( $project ) use ( $connected_ids ) {

                    return
                        ! in_array(
                            absint(
                                $project->id
                            ),
                            $connected_ids,
                            true
                        );
                }
            )
        );

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_crm_project_connection']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_crm_project_connection_error']
                ?? ''
            )
        );

    ob_start();

    ?>

    <div class="rud-crm-project-connection-box">

        <h3>
            Project Connection
        </h3>

        <p class="rud-crm-edit-section-note">
            Connect this customer to one or more CRM projects.
        </p>

        <?php if ( 'connected' === $message ) : ?>

            <div class="rud-crm-type-change-success">
                Customer connected to project.
            </div>

        <?php elseif ( 'removed' === $message ) : ?>

            <div class="rud-crm-type-change-success">
                Project connection removed.
            </div>

        <?php elseif ( $error ) : ?>

            <div class="rud-crm-project-connection-error">
                The project connection could not be saved.
            </div>

        <?php endif; ?>


        <?php if ( ! empty( $connected_projects ) ) : ?>

            <div class="rud-crm-connected-projects">

                <strong class="rud-crm-project-connection-label">
                    Connected Projects
                </strong>

                <?php foreach ( $connected_projects as $project ) : ?>

                    <div class="rud-crm-connected-project-row">

                        <div>

                            <strong>
                                <?php
                                echo esc_html(
                                    $project->project_title
                                );
                                ?>
                            </strong>

                            <span>
                                <?php
                                echo esc_html(
                                    $project->project_number
                                );

                                if (
                                    ! empty(
                                        $project->relationship_role
                                    )
                                ) {

                                    echo
                                        ' · ' .
                                        esc_html(
                                            $project->relationship_role
                                        );
                                }
                                ?>
                            </span>

                        </div>

                        <div class="rud-crm-connected-project-actions">

                            <a
                                class="rud-crm-project-open-button"
                                href="<?php
                                echo esc_url(
                                    rud_crm_frontend_edit_project_url(
                                        $project->id
                                    )
                                );
                                ?>"
                            >
                                OPEN PROJECT
                            </a>

                            <form method="post">

                                <?php

                                wp_nonce_field(
                                    'rud_crm_customer_disconnect_project_' .
                                    $customer_id .
                                    '_' .
                                    $project->id,
                                    'rud_crm_customer_project_nonce'
                                );

                                ?>

                                <input
                                    type="hidden"
                                    name="rud_crm_customer_project_action"
                                    value="disconnect_project"
                                >

                                <input
                                    type="hidden"
                                    name="rud_customer_id"
                                    value="<?php echo esc_attr( $customer_id ); ?>"
                                >

                                <input
                                    type="hidden"
                                    name="rud_project_id"
                                    value="<?php echo esc_attr( $project->id ); ?>"
                                >

                                <button
                                    type="submit"
                                    class="rud-crm-project-remove-button"
                                >
                                    REMOVE
                                </button>

                            </form>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ( ! empty( $available_projects ) ) : ?>

            <form
                method="post"
                class="rud-crm-project-connect-form"
            >

                <?php

                wp_nonce_field(
                    'rud_crm_customer_connect_project_' .
                    $customer_id,
                    'rud_crm_customer_project_nonce'
                );

                ?>

                <input
                    type="hidden"
                    name="rud_crm_customer_project_action"
                    value="connect_project"
                >

                <input
                    type="hidden"
                    name="rud_customer_id"
                    value="<?php echo esc_attr( $customer_id ); ?>"
                >

                <div class="rud-crm-project-connect-grid">

                    <div>

                        <label>
                            Connect to Project
                        </label>

                        <select
                            name="rud_project_id"
                            required
                        >

                            <option value="">
                                Select Project
                            </option>

                            <?php foreach ( $available_projects as $project ) : ?>

                                <option
                                    value="<?php echo esc_attr( $project->id ); ?>"
                                >
                                    <?php
                                    echo esc_html(
                                        $project->project_title .
                                        ' — ' .
                                        $project->project_number
                                    );
                                    ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div>

                        <label>
                            Relationship / Role
                        </label>

                        <input
                            type="text"
                            name="relationship_role"
                            value=""
                            placeholder="Supplier, participant, interview source..."
                        >

                    </div>

                </div>

                <button
                    type="submit"
                    class="rud-crm-project-connect-button"
                >
                    CONNECT TO PROJECT
                </button>

            </form>

        <?php elseif ( empty( $all_projects ) ) : ?>

            <div class="rud-crm-project-none">
                No projects are available yet. Create a project from My Account → Projects first.
            </div>

        <?php else : ?>

            <div class="rud-crm-project-none">
                This customer is already connected to all available projects.
            </div>

        <?php endif; ?>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * PROCESS CUSTOMER TYPE CHANGE
 * =========================================================
 *
 * Customer Type is intentionally handled separately from
 * the normal Edit Customer form because the selector now
 * lives below the Customer Image / Company Logo section.
 *
 * =========================================================
 */

function rud_crm_frontend_process_customer_type_change() {

    if (
        empty(
            $_POST['rud_crm_frontend_type_action']
        )
        ||
        'change_customer_type' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_frontend_type_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $customer_id =
        isset(
            $_POST['rud_customer_id']
        )
        ? absint(
            $_POST['rud_customer_id']
        )
        : 0;

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to edit this customer.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_frontend_type_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_frontend_type_nonce']
                )
            ),
            'rud_crm_frontend_change_customer_type_' .
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    $customer_type =
        sanitize_key(
            wp_unslash(
                $_POST['customer_type'] ?? ''
            )
        );

    if (
        ! in_array(
            $customer_type,
            array(
                'person',
                'company',
            ),
            true
        )
    ) {
        wp_die(
            esc_html__(
                'Invalid customer type.',
                'rud-crm-server'
            )
        );
    }

    global $wpdb;

    $updated =
        $wpdb->update(
            $wpdb->prefix .
            'rudcrm_customers',
            array(
                'customer_type' =>
                    $customer_type,

                'updated_at' =>
                    current_time(
                        'mysql'
                    ),
            ),
            array(
                'id' =>
                    $customer_id,
            ),
            array(
                '%s',
                '%s',
            ),
            array(
                '%d',
            )
        );

    if (
        false ===
        $updated
    ) {
        wp_safe_redirect(
            add_query_arg(
                'rud_crm_edit_error',
                'database_error',
                rud_crm_frontend_edit_customer_url(
                    $customer_id
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_crm_type_changed',
            '1',
            rud_crm_frontend_edit_customer_url(
                $customer_id
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_customer_type_change',
    29
);


/*
 * =========================================================
 * PROCESS DELETE CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_process_delete_customer() {

    if (
        empty(
            $_POST['rud_crm_frontend_delete_action']
        )
        ||
        'delete_customer' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_frontend_delete_action']
            )
        )
    ) {
        return;
    }

    if (
        ! is_user_logged_in()
    ) {
        return;
    }

    $customer_id =
        isset(
            $_POST['rud_customer_id']
        )
        ? absint(
            $_POST['rud_customer_id']
        )
        : 0;

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_edit_can_delete(
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to delete this customer.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_frontend_delete_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_frontend_delete_nonce']
                )
            ),
            'rud_crm_frontend_delete_customer_' .
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed. Please go back and try again.',
                'rud-crm-server'
            )
        );
    }

    $confirmation =
        isset(
            $_POST['rud_crm_delete_confirmation']
        )
        ? strtoupper(
            trim(
                sanitize_text_field(
                    wp_unslash(
                        $_POST['rud_crm_delete_confirmation']
                    )
                )
            )
        )
        : '';

    if (
        'DELETE' !==
        $confirmation
    ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_delete_error',
                'confirmation',
                rud_crm_frontend_edit_profile_url(
                    $customer_id
                )
            )
        );

        exit;
    }

    global $wpdb;

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    if (
        function_exists(
            'rud_crm_frontend_is_shared_demo_customer'
        )
        &&
        rud_crm_frontend_is_shared_demo_customer(
            $customer_id
        )
        &&
        ! (
            function_exists(
                'rud_crm_frontend_is_crm_admin'
            )
            &&
            rud_crm_frontend_is_crm_admin(
                get_current_user_id()
            )
        )
    ) {
        wp_die(
            esc_html__(
                'Shared Demo customers cannot be deleted.',
                'rud-crm-server'
            )
        );
    }

    $related_tables =
        array(
            $wpdb->prefix .
                'rudcrm_customer_details',

            $wpdb->prefix .
                'rudcrm_addresses',

            $wpdb->prefix .
                'rudcrm_contact_methods',

            $wpdb->prefix .
                'rudcrm_social_accounts',

            $wpdb->prefix .
                'rudcrm_customer_images',

            $wpdb->prefix .
                'rudcrm_customer_permissions',

            $wpdb->prefix .
                'rudcrm_customer_activity',
        );

    foreach (
        $related_tables
        as
        $table
    ) {

        if (
            rud_crm_frontend_edit_table_exists(
                $table
            )
        ) {

            $wpdb->delete(
                $table,
                array(
                    'customer_id' =>
                        $customer_id,
                )
            );
        }
    }

    if (
        function_exists(
            'rud_crm_remove_customer_owner'
        )
    ) {

        rud_crm_remove_customer_owner(
            $customer_id
        );

    } else {

        $ownership_table =
            $wpdb->prefix .
            'rudcrm_customer_ownership';

        if (
            rud_crm_frontend_edit_table_exists(
                $ownership_table
            )
        ) {

            $wpdb->delete(
                $ownership_table,
                array(
                    'customer_id' =>
                        $customer_id,
                )
            );
        }
    }

    $deleted =
        $wpdb->delete(
            $customers_table,
            array(
                'id' =>
                    $customer_id,
            )
        );

    if (
        false ===
        $deleted
    ) {
        wp_die(
            esc_html__(
                'The customer could not be deleted.',
                'rud-crm-server'
            )
        );
    }

    wp_safe_redirect(
        add_query_arg(
            'rud_crm_customer_message',
            'deleted',
            rud_crm_frontend_edit_crm_url()
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_delete_customer',
    30
);


/*
 * =========================================================
 * EDIT FORM
 * =========================================================
 */

function rud_crm_frontend_edit_customer_form(
    $customer_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
    ) {

        return
            '<div class="rud-crm-access-box">' .
            '<h2>Access Restricted</h2>' .
            '<p>You do not have permission to edit this customer.</p>' .
            '</div>';
    }

    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );

    if (
        ! $customer
    ) {

        return
            '<div class="rud-crm-empty">' .
            'Customer could not be found.' .
            '</div>';
    }

    $company_details =
        function_exists(
            'rud_crm_brreg_get_company_details'
        )
        ? rud_crm_brreg_get_company_details(
            $customer_id
        )
        : null;

    $details =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_details
                 WHERE customer_id = %d
                 LIMIT 1",
                $customer_id
            )
        );

    $address =
        function_exists(
            'rud_crm_frontend_address'
        )
        ? rud_crm_frontend_address(
            $customer_id
        )
        : null;

    $private_email =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'private_email'
        );

    $work_email =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'work_email'
        );

    $mobile_phone =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'mobile_phone'
        );

    $home_phone =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'home_phone'
        );

    $office_phone =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'office_phone'
        );

    $whatsapp =
        rud_crm_frontend_edit_get_contact(
            $customer_id,
            'whatsapp'
        );

    if (
        function_exists(
            'rud_crm_enqueue_phone_assets'
        )
    ) {
        rud_crm_enqueue_phone_assets();
    }

    $error =
        isset(
            $_GET['rud_crm_edit_error']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_edit_error']
            )
        )
        : '';

    ob_start();

    ?>

    <div class="rud-crm-edit-customer-wrap">

        <div class="rud-crm-edit-toolbar">

            <a
                class="rud-crm-button"
                href="<?php
                echo esc_url(
                    rud_crm_frontend_edit_profile_url(
                        $customer_id
                    )
                );
                ?>"
            >
                ← Back to Customer Profile
            </a>

        </div>

        <?php if ( 'name_required' === $error ) : ?>

            <div class="rud-crm-edit-error">
                Enter at least a first name, last name, or company name.
            </div>

        <?php elseif ( 'database_error' === $error ) : ?>

            <div class="rud-crm-edit-error">
                The customer could not be updated because of a database error.
            </div>

        <?php endif; ?>

        <div class="rud-crm-edit-card">

            <h2>
                Edit Customer
            </h2>

            <p class="rud-crm-edit-number">
                <?php
                echo esc_html(
                    $customer->customer_number
                );
                ?>
            </p>

            <form
                method="post"
                class="rud-crm-edit-form"
            >

                <?php

                wp_nonce_field(
                    'rud_crm_frontend_edit_customer_' .
                    $customer_id,
                    'rud_crm_frontend_edit_nonce'
                );

                ?>

                <input
                    type="hidden"
                    name="rud_crm_frontend_edit_action"
                    value="save_customer"
                >

                <input
                    type="hidden"
                    name="rud_customer_id"
                    value="<?php
                    echo esc_attr(
                        $customer_id
                    );
                    ?>"
                >

                <input
                    type="hidden"
                    name="customer_type"
                    value="<?php
                    echo esc_attr(
                        $customer->customer_type
                        ?? 'person'
                    );
                    ?>"
                >

                <div data-rud-customer-person>

                    <h3>
                        Personal Information
                    </h3>

                    <div class="rud-crm-edit-grid">

                    <div>
                        <label>Title</label>
                        <input
                            type="text"
                            name="title"
                            value="<?php echo esc_attr( $customer->title ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>First Name</label>
                        <input
                            type="text"
                            name="first_name"
                            value="<?php echo esc_attr( $customer->first_name ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Middle Name</label>
                        <input
                            type="text"
                            name="middle_name"
                            value="<?php echo esc_attr( $customer->middle_name ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Last Name</label>
                        <input
                            type="text"
                            name="last_name"
                            value="<?php echo esc_attr( $customer->last_name ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Preferred Name</label>
                        <input
                            type="text"
                            name="preferred_name"
                            value="<?php echo esc_attr( $customer->preferred_name ?? '' ); ?>"
                        >
                    </div>

                    </div>

                </div>

                <div data-rud-customer-company>

                    <h3>
                        Company Information
                    </h3>

                    <p class="rud-crm-edit-section-note">
                        Company information from Brønnøysundregistrene and your CRM record.
                    </p>

                    <div class="rud-crm-edit-grid">

                    <div>
                        <label>Company Name</label>
                        <input
                            type="text"
                            name="company_name"
                            value="<?php echo esc_attr( $customer->company_name ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Organization Number</label>
                        <input
                            type="text"
                            name="organization_number"
                            value="<?php echo esc_attr( $customer->organization_number ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Company Type Code</label>
                        <input
                            type="text"
                            name="organization_form_code"
                            value="<?php echo esc_attr( $company_details->organization_form_code ?? '' ); ?>"
                            placeholder="AS"
                        >
                    </div>

                    <div>
                        <label>Company Type</label>
                        <input
                            type="text"
                            name="organization_form_name"
                            value="<?php echo esc_attr( $company_details->organization_form_name ?? '' ); ?>"
                            placeholder="Aksjeselskap"
                        >
                    </div>

                    <div>
                        <label>Industry Code</label>
                        <input
                            type="text"
                            name="industry_code"
                            value="<?php echo esc_attr( $company_details->industry_code ?? '' ); ?>"
                            placeholder="70.200"
                        >
                    </div>

                    <div>
                        <label>Industry</label>
                        <input
                            type="text"
                            name="industry_name"
                            value="<?php echo esc_attr( $company_details->industry_name ?? '' ); ?>"
                            placeholder="Bedriftsrådgivning og annen administrativ rådgivning"
                        >
                    </div>

                    <input
                        type="hidden"
                        name="job_title"
                        value="<?php echo esc_attr( $customer->job_title ?? '' ); ?>"
                    >

                    <input
                        type="hidden"
                        name="department"
                        value="<?php echo esc_attr( $customer->department ?? '' ); ?>"
                    >

                    </div>

                </div>

                <div class="rud-crm-edit-section rud-crm-edit-status-section">

                    <h3>
                        CRM Status
                    </h3>

                    <div class="rud-crm-edit-grid">

                        <div>
                            <label>Status</label>

                            <select name="status">

                                <option value="lead" <?php selected( $customer->status, 'lead' ); ?>>
                                    Lead
                                </option>

                                <option value="customer" <?php selected( $customer->status, 'customer' ); ?>>
                                    Customer
                                </option>

                                <option value="partner" <?php selected( $customer->status, 'partner' ); ?>>
                                    Partner
                                </option>

                                <option value="inactive" <?php selected( $customer->status, 'inactive' ); ?>>
                                    Inactive
                                </option>

                            </select>
                        </div>

                    </div>

                </div>

                <h3 data-rud-address-heading>
                    Private Address
                </h3>

                <div class="rud-crm-edit-grid">

                    <div class="rud-crm-edit-wide">
                        <label>Address</label>
                        <input
                            type="text"
                            name="address_line_1"
                            value="<?php echo esc_attr( $address->address_line_1 ?? '' ); ?>"
                        >
                    </div>

                    <div class="rud-crm-edit-wide">
                        <label>Address Line 2</label>
                        <input
                            type="text"
                            name="address_line_2"
                            value="<?php echo esc_attr( $address->address_line_2 ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Postal Code</label>
                        <input
                            type="text"
                            name="postal_code"
                            value="<?php echo esc_attr( $address->postal_code ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>City</label>
                        <input
                            type="text"
                            name="city"
                            value="<?php echo esc_attr( $address->city ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>State / Region</label>
                        <input
                            type="text"
                            name="state_region"
                            value="<?php echo esc_attr( $address->state_region ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Country Code</label>
                        <input
                            type="text"
                            name="country_code"
                            maxlength="2"
                            value="<?php echo esc_attr( $address->country_code ?? '' ); ?>"
                            placeholder="NO"
                        >
                    </div>

                </div>

                <h3 data-rud-contact-heading>
                    Contact Information
                </h3>

                <div class="rud-crm-edit-grid">

                    <div data-rud-person-contact>
                        <label>Private Email</label>
                        <input
                            type="email"
                            name="private_email"
                            value="<?php echo esc_attr( $private_email ); ?>"
                        >
                    </div>

                    <div>
                        <label>Email / Work Email</label>
                        <input
                            type="email"
                            name="work_email"
                            value="<?php echo esc_attr( $work_email ); ?>"
                        >
                    </div>

                    <div>
                        <label>Mobile Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'mobile_phone',
                                    $mobile_phone,
                                    array(
                                        'id' =>
                                            'rud_crm_customer_mobile_phone',

                                        'description' =>
                                            'Select the country flag and enter the mobile phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="mobile_phone"
                                value="<?php echo esc_attr( $mobile_phone ); ?>"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div data-rud-person-contact>
                        <label>Home Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'home_phone',
                                    $home_phone,
                                    array(
                                        'id' =>
                                            'rud_crm_customer_home_phone',

                                        'description' =>
                                            'Select the country flag and enter the home phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="home_phone"
                                value="<?php echo esc_attr( $home_phone ); ?>"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div>
                        <label>Office Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'office_phone',
                                    $office_phone,
                                    array(
                                        'id' =>
                                            'rud_crm_customer_office_phone',

                                        'description' =>
                                            'Select the country flag and enter the office phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="office_phone"
                                value="<?php echo esc_attr( $office_phone ); ?>"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div>
                        <label>WhatsApp</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'whatsapp',
                                    $whatsapp,
                                    array(
                                        'id' =>
                                            'rud_crm_customer_whatsapp',

                                        'description' =>
                                            'Select the country flag and enter the WhatsApp number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="whatsapp"
                                value="<?php echo esc_attr( $whatsapp ); ?>"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div class="rud-crm-edit-wide rud-crm-website-field">
                        <label>Website</label>

                        <input
                            type="text"
                            name="website_url"
                            value="<?php echo esc_attr( $details->website_url ?? '' ); ?>"
                            placeholder="rudolfsen.com"
                            autocomplete="url"
                            data-rud-website-input
                        >

                        <div class="rud-crm-website-help">
                            Enter only the domain if you want. HTTPS:// is added automatically when you save.
                        </div>

                        <a
                            href="<?php
                            $rud_crm_website_link =
                                trim(
                                    (string)
                                    (
                                        $details->website_url
                                        ?? ''
                                    )
                                );

                            if (
                                '' !==
                                $rud_crm_website_link
                                &&
                                ! preg_match(
                                    '#^https?://#i',
                                    $rud_crm_website_link
                                )
                            ) {

                                $rud_crm_website_link =
                                    'https://' .
                                    ltrim(
                                        $rud_crm_website_link,
                                        '/'
                                    );
                            }

                            echo esc_url(
                                $rud_crm_website_link
                            );
                            ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="rud-crm-website-open-link"
                            data-rud-website-link
                            <?php
                            if (
                                '' ===
                                trim(
                                    (string)
                                    (
                                        $details->website_url
                                        ?? ''
                                    )
                                )
                            ) {
                                echo ' style="display:none;"';
                            }
                            ?>
                        >
                            OPEN WEBSITE ↗
                        </a>
                    </div>

                </div>

                <div data-rud-person-details>

                    <h3>
                        Personal Information
                    </h3>

                <div class="rud-crm-edit-grid">

                    <div>
                        <label>Birth Date</label>
                        <input
                            type="date"
                            name="birth_date"
                            value="<?php echo esc_attr( $details->birth_date ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Gender</label>
                        <input
                            type="text"
                            name="gender"
                            value="<?php echo esc_attr( $details->gender ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Preferred Language</label>
                        <input
                            type="text"
                            name="preferred_language"
                            value="<?php echo esc_attr( $details->preferred_language ?? '' ); ?>"
                        >
                    </div>

                    <div>
                        <label>Nationality</label>
                        <input
                            type="text"
                            name="nationality"
                            value="<?php echo esc_attr( $details->nationality ?? '' ); ?>"
                        >
                    </div>

                </div>

                </div>
                <h3 data-rud-notes-heading>
                    Internal CRM Notes
                </h3>

                <textarea
                    name="notes"
                    rows="7"
                ><?php echo esc_textarea( $details->notes ?? '' ); ?></textarea>

                <button
                    type="submit"
                    class="rud-crm-edit-submit"
                >
                    SAVE CUSTOMER CHANGES
                </button>

            </form>

            <div
                data-rud-company-contacts-section
                <?php if ( 'company' !== ( $customer->customer_type ?? 'person' ) ) : ?>
                    style="display:none;"
                <?php endif; ?>
            >

                <div
                    class="rud-crm-edit-main-divider"
                    aria-hidden="true"
                ></div>

                <div class="rud-crm-edit-company-contact-section">

                    <?php

                    if (
                        function_exists(
                            'rud_crm_frontend_company_contacts_section'
                        )
                    ) {

                        echo
                            rud_crm_frontend_company_contacts_section(
                                $customer_id
                            );
                    }

                    ?>

                </div>

            </div>

            <div
                class="rud-crm-edit-main-divider"
                aria-hidden="true"
            ></div>

            <div class="rud-crm-edit-project-section">

                <?php

                echo rud_crm_frontend_edit_project_connection_html(
                    $customer_id
                );

                ?>

            </div>

            <div
                class="rud-crm-edit-main-divider rud-crm-edit-main-divider-second"
                aria-hidden="true"
            ></div>

            <div class="rud-crm-edit-secondary-section">

                <?php

                if (
                    function_exists(
                        'rud_crm_frontend_customer_image_form'
                    )
                ) {

                    echo rud_crm_frontend_customer_image_form(
                        $customer_id
                    );
                }

                ?>

            </div>

            <div
                class="rud-crm-edit-main-divider rud-crm-edit-main-divider-third"
                aria-hidden="true"
            ></div>

            <div class="rud-crm-edit-customer-type-section">

                <div class="rud-crm-customer-type-selector rud-crm-customer-type-selector-bottom">

                    <h3>
                        Customer Type
                    </h3>

                    <p>
                        Change the customer type only if this record was created with the wrong type.
                    </p>

                    <?php if (
                        isset(
                            $_GET['rud_crm_type_changed']
                        )
                        &&
                        '1' ===
                        sanitize_text_field(
                            wp_unslash(
                                $_GET['rud_crm_type_changed']
                            )
                        )
                    ) : ?>

                        <div class="rud-crm-type-change-success">
                            Customer type updated.
                        </div>

                    <?php endif; ?>

                    <form
                        method="post"
                        class="rud-crm-customer-type-form"
                    >

                        <?php

                        wp_nonce_field(
                            'rud_crm_frontend_change_customer_type_' .
                            $customer_id,
                            'rud_crm_frontend_type_nonce'
                        );

                        ?>

                        <input
                            type="hidden"
                            name="rud_crm_frontend_type_action"
                            value="change_customer_type"
                        >

                        <input
                            type="hidden"
                            name="rud_customer_id"
                            value="<?php
                            echo esc_attr(
                                $customer_id
                            );
                            ?>"
                        >

                        <div class="rud-crm-customer-type-options">

                            <label>
                                <input
                                    type="radio"
                                    name="customer_type"
                                    value="person"
                                    <?php checked( $customer->customer_type ?? 'person', 'person' ); ?>
                                >
                                <strong>Private Person</strong>
                            </label>

                            <label>
                                <input
                                    type="radio"
                                    name="customer_type"
                                    value="company"
                                    <?php checked( $customer->customer_type ?? '', 'company' ); ?>
                                >
                                <strong>Company / Organization</strong>
                            </label>

                        </div>

                        <button
                            type="submit"
                            class="rud-crm-customer-type-submit"
                        >
                            SAVE CUSTOMER TYPE
                        </button>

                    </form>

                </div>

            </div>

        </div>

    </div>

    <style>

        .rud-crm-edit-customer-wrap {
            width:100%;
            max-width:1000px;
            margin:0 auto;
        }

        .rud-crm-edit-toolbar {
            margin-bottom:20px;
        }

        .rud-crm-edit-card {
            padding:28px;
            border:1px solid #eaecf0;
            border-radius:12px;
            background:#fff;
        }

        .rud-crm-edit-card h2 {
            margin-top:0;
            margin-bottom:4px;
        }

        .rud-crm-edit-number {
            margin-top:0;
            opacity:.65;
        }

        .rud-crm-edit-card h3 {
            margin-top:30px;
            margin-bottom:14px;
        }

        .rud-crm-edit-section-note {
            margin:-4px 0 16px;
            color:#667085;
            font-size:14px;
        }

        .rud-crm-edit-status-section {
            margin-top:8px;
        }

        .rud-crm-edit-company-section-divider {
            width:100%;
            height:0;
            margin:34px 0;
            border-top:2px solid #d0d5dd;
        }

        .rud-crm-edit-grid {
            display:grid;
            grid-template-columns:
                repeat(
                    2,
                    minmax(
                        0,
                        1fr
                    )
                );
            gap:16px;
        }

        .rud-crm-edit-wide {
            grid-column:1 / -1;
        }

        .rud-crm-edit-form label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }

        .rud-crm-edit-form input,
        .rud-crm-edit-form select,
        .rud-crm-edit-form textarea {
            width:100%;
            box-sizing:border-box;
            padding:11px 13px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            font:inherit;
        }

        .rud-crm-customer-type-selector {
            margin-bottom:24px;
            padding:20px;
            border:1px solid #eaecf0;
            border-radius:10px;
            background:#f9fafb;
        }

        .rud-crm-edit-main-divider {
            width:100%;
            height:0;
            margin:42px 0 34px;
            border-top:3px solid #c7cdd4;
        }

        .rud-crm-edit-secondary-section {
            width:100%;
        }

        .rud-crm-customer-type-selector-bottom {
            margin-top:0;
            margin-bottom:0;
        }

        .rud-crm-edit-project-section {
            width:100%;
        }

        .rud-crm-edit-company-contact-section {
            width:100%;
        }

        .rud-crm-website-help {
            margin-top:6px;
            color:#667085;
            font-size:12px;
        }

        .rud-crm-website-open-link {
            display:inline-flex;
            align-items:center;
            margin-top:10px;
            padding:8px 12px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            color:#1d2939 !important;
            text-decoration:none !important;
            font-size:12px;
            font-weight:700;
        }

        .rud-crm-website-open-link:hover {
            background:#f9fafb;
        }

        .rud-crm-project-connection-box {
            margin:0;
            padding:22px;
            border:1px solid #eaecf0;
            border-radius:10px;
            background:#f9fafb;
        }

        .rud-crm-edit-main-divider-second {
            margin-top:34px;
            margin-bottom:34px;
        }

        .rud-crm-edit-main-divider-third {
            margin-top:34px;
            margin-bottom:34px;
        }

        .rud-crm-edit-customer-type-section {
            width:100%;
        }

        .rud-crm-project-connection-box h3 {
            margin-top:0;
        }

        .rud-crm-project-connection-label {
            display:block;
            margin-bottom:10px;
        }

        .rud-crm-connected-projects {
            margin-bottom:20px;
        }

        .rud-crm-connected-project-row {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:14px;
            padding:12px 0;
            border-bottom:1px solid #dfe3e8;
        }

        .rud-crm-connected-project-row:last-child {
            border-bottom:0;
        }

        .rud-crm-connected-project-row strong,
        .rud-crm-connected-project-row span {
            display:block;
        }

        .rud-crm-connected-project-row span {
            margin-top:3px;
            color:#667085;
            font-size:13px;
        }

        .rud-crm-connected-project-actions {
            display:flex;
            align-items:center;
            gap:8px;
            flex-wrap:wrap;
        }

        .rud-crm-connected-project-actions form {
            margin:0;
        }

        .rud-crm-project-open-button,
        .rud-crm-project-remove-button,
        .rud-crm-project-connect-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:38px;
            padding:9px 13px;
            border-radius:7px;
            text-decoration:none !important;
            font-weight:700;
            cursor:pointer;
        }

        .rud-crm-project-open-button,
        .rud-crm-project-connect-button {
            border:1px solid #1d2939;
            background:#1d2939;
            color:#fff !important;
        }

        .rud-crm-project-remove-button {
            border:1px solid #b42318;
            background:#fff;
            color:#b42318;
        }

        .rud-crm-project-connect-form {
            margin:0;
        }

        .rud-crm-project-connect-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:14px;
        }

        .rud-crm-project-connect-form label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }

        .rud-crm-project-connect-form input,
        .rud-crm-project-connect-form select {
            width:100%;
            box-sizing:border-box;
            padding:11px 13px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            font:inherit;
        }

        .rud-crm-project-connect-button {
            margin-top:16px;
        }

        .rud-crm-project-none {
            padding:12px 14px;
            border:1px solid #dfe3e8;
            border-radius:7px;
            background:#fff;
            color:#667085;
        }

        .rud-crm-project-connection-error {
            margin:0 0 14px;
            padding:10px 12px;
            border-left:4px solid #b32d2e;
            background:#fff5f5;
        }

        .rud-crm-customer-type-form {
            margin:0;
        }

        .rud-crm-customer-type-submit {
            margin-top:16px;
            padding:11px 18px;
            border:0;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            cursor:pointer;
            font-weight:700;
        }

        .rud-crm-type-change-success {
            margin:0 0 14px;
            padding:10px 12px;
            border-left:4px solid #00a32a;
            background:#f3fff5;
        }

        .rud-crm-customer-type-selector h3 {
            margin-top:0;
        }

        .rud-crm-customer-type-options {
            display:flex;
            gap:14px;
            flex-wrap:wrap;
            margin-top:14px;
        }

        .rud-crm-customer-type-options label {
            display:flex;
            align-items:center;
            gap:8px;
            padding:12px 16px;
            border:1px solid #d0d5dd;
            border-radius:8px;
            background:#fff;
            cursor:pointer;
        }

        .rud-crm-customer-type-options input {
            width:auto;
        }

        .rud-crm-edit-submit {
            width:100%;
            margin-top:28px;
            padding:14px 20px;
            border:0;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            font-weight:700;
            cursor:pointer;
        }

        .rud-crm-edit-error {
            margin-bottom:20px;
            padding:16px 18px;
            border:1px solid #f0c7c7;
            border-radius:8px;
            background:#fff6f6;
        }

        @media (max-width:700px) {

            .rud-crm-edit-grid,
            .rud-crm-project-connect-grid {
                grid-template-columns:1fr;
            }

            .rud-crm-edit-wide {
                grid-column:auto;
            }
        }

    </style>

    <script>
    (function() {

        function rudCrmEditToggleCustomerType() {

            var selected =
                document.querySelector(
                    '.rud-crm-customer-type-form input[name="customer_type"]:checked'
                );

            var person =
                document.querySelector(
                    '[data-rud-customer-person]'
                );

            var company =
                document.querySelector(
                    '[data-rud-customer-company]'
                );

            if (
                ! selected
                ||
                ! person
                ||
                ! company
            ) {
                return;
            }

            var hiddenType =
                document.querySelector(
                    '.rud-crm-edit-form input[name="customer_type"]'
                );

            if (
                hiddenType
            ) {
                hiddenType.value =
                    selected.value;
            }

            var personDetails =
                document.querySelector(
                    '[data-rud-person-details]'
                );

            var personContacts =
                document.querySelectorAll(
                    '[data-rud-person-contact]'
                );

            var addressHeading =
                document.querySelector(
                    '[data-rud-address-heading]'
                );

            var contactHeading =
                document.querySelector(
                    '[data-rud-contact-heading]'
                );

            var notesHeading =
                document.querySelector(
                    '[data-rud-notes-heading]'
                );

            var companyContacts =
                document.querySelector(
                    '[data-rud-company-contacts-section]'
                );

            if (
                selected.value ===
                'company'
            ) {

                person.style.display =
                    'none';

                company.style.display =
                    '';

                if ( personDetails ) {
                    personDetails.style.display =
                        'none';
                }

                personContacts.forEach(
                    function(field) {
                        field.style.display =
                            'none';
                    }
                );

                if ( addressHeading ) {
                    addressHeading.textContent =
                        'Company Address';
                }

                if ( contactHeading ) {
                    contactHeading.textContent =
                        'Company Contact Information';
                }

                if ( notesHeading ) {
                    notesHeading.textContent =
                        'Internal CRM Company Notes';
                }

                if ( companyContacts ) {
                    companyContacts.style.display =
                        '';
                }

            } else {

                person.style.display =
                    '';

                company.style.display =
                    'none';

                if ( personDetails ) {
                    personDetails.style.display =
                        '';
                }

                personContacts.forEach(
                    function(field) {
                        field.style.display =
                            '';
                    }
                );

                if ( addressHeading ) {
                    addressHeading.textContent =
                        'Private Address';
                }

                if ( contactHeading ) {
                    contactHeading.textContent =
                        'Contact Information';
                }

                if ( notesHeading ) {
                    notesHeading.textContent =
                        'Internal CRM Notes';
                }

                if ( companyContacts ) {
                    companyContacts.style.display =
                        'none';
                }
            }
        }

        document.addEventListener(
            'change',
            function(event) {

                if (
                    event.target
                    &&
                    event.target.name ===
                    'customer_type'
                ) {
                    rudCrmEditToggleCustomerType();
                }
            }
        );

        rudCrmEditToggleCustomerType();

    })();
    </script>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * INTERCEPT SHORTCODE FOR EDIT SCREEN
 * =========================================================
 */

function rud_crm_frontend_edit_intercept_shortcode(
    $return,
    $tag,
    $attr,
    $m
) {

    if (
        'rud_crm_frontend' !==
        $tag
        &&
        'rud_crm_customer_list' !==
        $tag
    ) {
        return $return;
    }

    $action =
        isset(
            $_GET['rud_crm_action']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_action']
            )
        )
        : '';

    if (
        'edit_customer' !==
        $action
    ) {
        return $return;
    }

    $customer_id =
        isset(
            $_GET['rud_customer_id']
        )
        ? absint(
            $_GET['rud_customer_id']
        )
        : 0;

    return
        rud_crm_frontend_edit_customer_form(
            $customer_id
        );
}


add_filter(
    'pre_do_shortcode_tag',
    'rud_crm_frontend_edit_intercept_shortcode',
    9,
    4
);


/*
 * =========================================================
 * PROFILE ACTIONS / MESSAGES
 * =========================================================
 */

function rud_crm_frontend_edit_profile_controls_html(
    $customer_id
) {

    if (
        ! rud_crm_frontend_edit_can_edit(
            $customer_id
        )
    ) {
        return '';
    }

    $can_delete =
        rud_crm_frontend_edit_can_delete(
            $customer_id
        );

    ob_start();

    ?>

    <div class="rud-crm-owner-actions">

        <a
            href="<?php
            echo esc_url(
                rud_crm_frontend_edit_customer_url(
                    $customer_id
                )
            );
            ?>"
            class="rud-crm-button rud-crm-button-primary"
        >
            EDIT CUSTOMER
        </a>

        <?php if ( $can_delete ) : ?>

            <details class="rud-crm-delete-panel">

                <summary>
                    Delete Customer
                </summary>

                <div class="rud-crm-delete-box">

                    <strong>
                        Permanent deletion
                    </strong>

                    <p>
                        This removes this customer and its CRM information.
                        This action cannot be undone.
                    </p>

                    <p>
                        Type <strong>DELETE</strong> below to confirm.
                    </p>

                    <form method="post">

                        <?php

                        wp_nonce_field(
                            'rud_crm_frontend_delete_customer_' .
                            $customer_id,
                            'rud_crm_frontend_delete_nonce'
                        );

                        ?>

                        <input
                            type="hidden"
                            name="rud_crm_frontend_delete_action"
                            value="delete_customer"
                        >

                        <input
                            type="hidden"
                            name="rud_customer_id"
                            value="<?php
                            echo esc_attr(
                                $customer_id
                            );
                            ?>"
                        >

                        <input
                            type="text"
                            name="rud_crm_delete_confirmation"
                            value=""
                            autocomplete="off"
                            placeholder="Type DELETE"
                            required
                        >

                        <button
                            type="submit"
                            class="rud-crm-delete-button"
                        >
                            DELETE CUSTOMER PERMANENTLY
                        </button>

                    </form>

                </div>

            </details>

        <?php endif; ?>

    </div>

    <style>

        .rud-crm-owner-actions {
            display:flex;
            align-items:flex-start;
            gap:12px;
            flex-wrap:wrap;
            margin:0 0 20px;
        }

        .rud-crm-delete-panel {
            position:relative;
        }

        .rud-crm-delete-panel summary {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:40px;
            padding:9px 16px;
            border:1px solid #b42318;
            border-radius:7px;
            background:#fff;
            color:#b42318;
            cursor:pointer;
            font-weight:600;
            list-style:none;
        }

        .rud-crm-delete-panel summary::-webkit-details-marker {
            display:none;
        }

        .rud-crm-delete-box {
            width:min(440px,calc(100vw - 40px));
            margin-top:10px;
            padding:18px;
            border:1px solid #f0c7c7;
            border-radius:9px;
            background:#fff6f6;
        }

        .rud-crm-delete-box p {
            margin:8px 0;
        }

        .rud-crm-delete-box input {
            width:100%;
            box-sizing:border-box;
            margin-top:8px;
            padding:10px 12px;
            border:1px solid #d0d5dd;
            border-radius:6px;
        }

        .rud-crm-delete-button {
            width:100%;
            margin-top:10px;
            padding:11px 14px;
            border:0;
            border-radius:6px;
            background:#b42318;
            color:#fff;
            cursor:pointer;
            font-weight:700;
        }

    </style>

    <?php

    return ob_get_clean();
}


function rud_crm_frontend_edit_message_html() {

    $message =
        isset(
            $_GET['rud_crm_customer_message']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_customer_message']
            )
        )
        : '';

    $delete_error =
        isset(
            $_GET['rud_crm_delete_error']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_delete_error']
            )
        )
        : '';

    if (
        'updated' ===
        $message
    ) {

        return
            '<div class="rud-crm-customer-success">' .
            '<strong>Customer Updated</strong>' .
            '<span>The customer information was saved successfully.</span>' .
            '</div>';
    }

    if (
        'deleted' ===
        $message
    ) {

        return
            '<div class="rud-crm-customer-success">' .
            '<strong>Customer Deleted</strong>' .
            '<span>The customer was permanently removed from your CRM.</span>' .
            '</div>';
    }

    if (
        'confirmation' ===
        $delete_error
    ) {

        return
            '<div class="rud-crm-customer-error">' .
            '<strong>Deletion Not Confirmed</strong>' .
            '<span>Type DELETE exactly before deleting the customer.</span>' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * ADD BUTTONS / MESSAGES TO CRM OUTPUT
 * =========================================================
 */

function rud_crm_frontend_edit_enhance_output(
    $output,
    $tag,
    $attr,
    $m
) {

    if (
        'rud_crm_frontend' !==
        $tag
        &&
        'rud_crm_customer_list' !==
        $tag
    ) {
        return $output;
    }

    $action =
        isset(
            $_GET['rud_crm_action']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_action']
            )
        )
        : '';

    if (
        'edit_customer' ===
        $action
        ||
        'new_customer' ===
        $action
    ) {
        return $output;
    }

    $customer_id =
        isset(
            $_GET['rud_customer_id']
        )
        ? absint(
            $_GET['rud_customer_id']
        )
        : 0;

    $message =
        rud_crm_frontend_edit_message_html();

    if (
        $customer_id >
        0
    ) {

        return
            $message
            .
            rud_crm_frontend_edit_profile_controls_html(
                $customer_id
            )
            .
            $output;
    }

    if (
        $message
    ) {
        return
            $message .
            $output;
    }

    return $output;
}


add_filter(
    'do_shortcode_tag',
    'rud_crm_frontend_edit_enhance_output',
    20,
    4
);


/*
 * =========================================================
 * MESSAGE STYLES
 * =========================================================
 */

function rud_crm_frontend_edit_message_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-customer-success,
    .rud-crm-customer-error {
        display:flex;
        flex-direction:column;
        gap:4px;
        margin:0 0 20px;
        padding:16px 18px;
        border-radius:8px;
    }

    .rud-crm-customer-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-customer-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    ';

    wp_register_style(
        'rud-crm-frontend-edit-delete',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.1'
    );

    wp_enqueue_style(
        'rud-crm-frontend-edit-delete'
    );

    wp_add_inline_style(
        'rud-crm-frontend-edit-delete',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_edit_message_styles',
    30
);


/*
 * =========================================================
 * WEBSITE LINK PREVIEW
 * =========================================================
 */

function rud_crm_frontend_edit_website_link_preview_script() {

    if ( is_admin() ) {
        return;
    }

    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function () {

        var input =
            document.querySelector(
                '[data-rud-website-input]'
            );

        var link =
            document.querySelector(
                '[data-rud-website-link]'
            );

        if (!input || !link) {
            return;
        }

        function updateWebsiteLink() {

            var value =
                input.value.trim();

            if (!value) {
                link.style.display = 'none';
                link.removeAttribute('href');
                return;
            }

            if (!/^https?:\\/\\//i.test(value)) {
                value = 'https://' + value.replace(/^\\/+/, '');
            }

            link.href = value;
            link.style.display = 'inline-flex';
        }

        input.addEventListener(
            'input',
            updateWebsiteLink
        );

        input.addEventListener(
            'change',
            updateWebsiteLink
        );

        updateWebsiteLink();
    });
    </script>
    <?php
}

add_action(
    'wp_footer',
    'rud_crm_frontend_edit_website_link_preview_script',
    40
);
