<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * SECURITY SETTINGS
 * =========================================================
 *
 * Supported bot-protection providers:
 *
 * - Cloudflare Turnstile
 * - Google reCAPTCHA v2 Checkbox
 * - Disabled
 *
 * Permissions:
 *
 * ADMIN-LEVEL-001:
 * Full configuration
 *
 * ADMIN-LEVEL-002:
 * Full configuration
 *
 * ADMIN-LEVEL-003:
 * Status viewing only
 *
 * ADMIN-LEVEL-004/005/006:
 * No access
 *
 * =========================================================
 */


/*
 * =========================================================
 * OPTION NAMES
 * =========================================================
 */

function rud_crm_security_option_provider() {
    return 'rud_crm_security_bot_provider';
}

function rud_crm_security_option_turnstile_site_key() {
    return 'rud_crm_turnstile_site_key';
}

function rud_crm_security_option_turnstile_secret_key() {
    return 'rud_crm_turnstile_secret_key';
}

function rud_crm_security_option_recaptcha_site_key() {
    return 'rud_crm_recaptcha_site_key';
}

function rud_crm_security_option_recaptcha_secret_key() {
    return 'rud_crm_recaptcha_secret_key';
}


/*
 * =========================================================
 * PROVIDER
 * =========================================================
 */

function rud_crm_security_provider() {

    $provider =
        get_option(
            rud_crm_security_option_provider(),
            'turnstile'
        );


    $allowed =
        array(
            'turnstile',
            'recaptcha',
            'disabled'
        );


    if (
        ! in_array(
            $provider,
            $allowed,
            true
        )
    ) {
        return 'turnstile';
    }


    return $provider;
}


/*
 * =========================================================
 * GET KEYS
 * =========================================================
 */

function rud_crm_turnstile_site_key() {

    return trim(
        (string)
        get_option(
            rud_crm_security_option_turnstile_site_key(),
            ''
        )
    );
}


function rud_crm_turnstile_secret_key() {

    return trim(
        (string)
        get_option(
            rud_crm_security_option_turnstile_secret_key(),
            ''
        )
    );
}


function rud_crm_recaptcha_site_key() {

    return trim(
        (string)
        get_option(
            rud_crm_security_option_recaptcha_site_key(),
            ''
        )
    );
}


function rud_crm_recaptcha_secret_key() {

    return trim(
        (string)
        get_option(
            rud_crm_security_option_recaptcha_secret_key(),
            ''
        )
    );
}


/*
 * =========================================================
 * CONFIGURATION CHECK
 * =========================================================
 */

function rud_crm_security_provider_configured(
    $provider = ''
) {

    if (
        ! $provider
    ) {
        $provider =
            rud_crm_security_provider();
    }


    if (
        'disabled' ===
        $provider
    ) {
        return true;
    }


    if (
        'turnstile' ===
        $provider
    ) {

        return
            '' !== rud_crm_turnstile_site_key()
            &&
            '' !== rud_crm_turnstile_secret_key();
    }


    if (
        'recaptcha' ===
        $provider
    ) {

        return
            '' !== rud_crm_recaptcha_site_key()
            &&
            '' !== rud_crm_recaptcha_secret_key();
    }


    return false;
}


/*
 * =========================================================
 * ADMIN ACCESS
 * =========================================================
 */

function rud_crm_security_can_view() {

    if (
        ! function_exists(
            'rud_crm_get_admin_level'
        )
    ) {
        return false;
    }


    $level =
        rud_crm_get_admin_level();


    return in_array(
        $level,
        array(
            1,
            2,
            3
        ),
        true
    );
}


/*
 * Only Level 001 and 002 may change credentials.
 */

function rud_crm_security_can_edit() {

    if (
        ! function_exists(
            'rud_crm_get_admin_level'
        )
    ) {
        return false;
    }


    return in_array(
        rud_crm_get_admin_level(),
        array(
            1,
            2
        ),
        true
    );
}


/*
 * =========================================================
 * MASK SECRET
 * =========================================================
 */

function rud_crm_security_mask_secret(
    $secret
) {

    if (
        '' ===
        trim(
            (string)
            $secret
        )
    ) {
        return 'Not configured';
    }


    return '••••••••••••••••••••';
}


/*
 * =========================================================
 * SAVE SETTINGS
 * =========================================================
 */

function rud_crm_security_process_settings() {

    if (
        empty(
            $_POST['rud_crm_security_action']
        )
        ||
        'save_security' !==
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_security_action']
            )
        )
    ) {
        return;
    }


    if (
        ! rud_crm_security_can_edit()
    ) {

        wp_die(
            'You are not allowed to change RUD CRM security settings.'
        );
    }


    if (
        empty(
            $_POST['rud_crm_security_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_security_nonce']
                )
            ),
            'rud_crm_security_settings'
        )
    ) {

        wp_die(
            'Security verification failed.'
        );
    }


    $provider =
        isset(
            $_POST['bot_provider']
        )
        ? sanitize_key(
            wp_unslash(
                $_POST['bot_provider']
            )
        )
        : 'disabled';


    if (
        ! in_array(
            $provider,
            array(
                'turnstile',
                'recaptcha',
                'disabled'
            ),
            true
        )
    ) {

        $provider =
            'disabled';
    }


    update_option(
        rud_crm_security_option_provider(),
        $provider,
        false
    );


    /*
     * Site keys are not secret.
     */

    if (
        isset(
            $_POST['turnstile_site_key']
        )
    ) {

        update_option(
            rud_crm_security_option_turnstile_site_key(),
            sanitize_text_field(
                wp_unslash(
                    $_POST['turnstile_site_key']
                )
            ),
            false
        );
    }


    if (
        isset(
            $_POST['recaptcha_site_key']
        )
    ) {

        update_option(
            rud_crm_security_option_recaptcha_site_key(),
            sanitize_text_field(
                wp_unslash(
                    $_POST['recaptcha_site_key']
                )
            ),
            false
        );
    }


    /*
     * Secret fields:
     *
     * Empty means KEEP existing secret.
     *
     * This prevents an existing secret from disappearing
     * simply because the password field is blank.
     */

    if (
        ! empty(
            $_POST['turnstile_secret_key']
        )
    ) {

        update_option(
            rud_crm_security_option_turnstile_secret_key(),
            sanitize_text_field(
                wp_unslash(
                    $_POST['turnstile_secret_key']
                )
            ),
            false
        );
    }


    if (
        ! empty(
            $_POST['recaptcha_secret_key']
        )
    ) {

        update_option(
            rud_crm_security_option_recaptcha_secret_key(),
            sanitize_text_field(
                wp_unslash(
                    $_POST['recaptcha_secret_key']
                )
            ),
            false
        );
    }


    wp_safe_redirect(
        add_query_arg(
            array(
                'page' =>
                    'rud-crm-security',

                'rud_crm_security_saved' =>
                    '1'
            ),
            admin_url(
                'admin.php'
            )
        )
    );

    exit;
}


add_action(
    'admin_init',
    'rud_crm_security_process_settings',
    25
);


/*
 * =========================================================
 * STATUS LABEL
 * =========================================================
 */

function rud_crm_security_status_label(
    $provider
) {

    if (
        'disabled' ===
        $provider
    ) {
        return 'DISABLED';
    }


    if (
        rud_crm_security_provider_configured(
            $provider
        )
    ) {
        return 'CONFIGURED';
    }


    return 'NOT CONFIGURED';
}


/*
 * =========================================================
 * SECURITY SETTINGS PAGE
 * =========================================================
 */

function rud_crm_security_settings_page() {

    if (
        ! rud_crm_security_can_view()
    ) {

        wp_die(
            'You are not allowed to access RUD CRM Security Settings.'
        );
    }


    $provider =
        rud_crm_security_provider();


    $can_edit =
        rud_crm_security_can_edit();


    $turnstile_site =
        rud_crm_turnstile_site_key();


    $turnstile_secret =
        rud_crm_turnstile_secret_key();


    $recaptcha_site =
        rud_crm_recaptcha_site_key();


    $recaptcha_secret =
        rud_crm_recaptcha_secret_key();

    ?>

    <div class="wrap">

        <h1>
            RUD CRM Security
        </h1>


        <p>
            Configure bot protection for public RUD CRM forms.
        </p>


        <?php

        if (
            isset(
                $_GET['rud_crm_security_saved']
            )
            &&
            '1' ===
            sanitize_text_field(
                wp_unslash(
                    $_GET['rud_crm_security_saved']
                )
            )
        ) :

        ?>

            <div class="notice notice-success is-dismissible">

                <p>
                    RUD CRM security settings saved.
                </p>

            </div>

        <?php endif; ?>


        <form method="post">


            <?php

            wp_nonce_field(
                'rud_crm_security_settings',
                'rud_crm_security_nonce'
            );

            ?>


            <input
                type="hidden"
                name="rud_crm_security_action"
                value="save_security"
            >


            <h2>
                Bot Protection Provider
            </h2>


            <table class="form-table">


                <tr>

                    <th>
                        Provider
                    </th>

                    <td>


                        <label>

                            <input
                                type="radio"
                                name="bot_provider"
                                value="turnstile"
                                <?php checked( $provider, 'turnstile' ); ?>
                                <?php disabled( ! $can_edit ); ?>
                            >

                            <strong>
                                Cloudflare Turnstile
                            </strong>

                        </label>


                        <br><br>


                        <label>

                            <input
                                type="radio"
                                name="bot_provider"
                                value="recaptcha"
                                <?php checked( $provider, 'recaptcha' ); ?>
                                <?php disabled( ! $can_edit ); ?>
                            >

                            <strong>
                                Google reCAPTCHA v2 Checkbox
                            </strong>

                        </label>


                        <br><br>


                        <label>

                            <input
                                type="radio"
                                name="bot_provider"
                                value="disabled"
                                <?php checked( $provider, 'disabled' ); ?>
                                <?php disabled( ! $can_edit ); ?>
                            >

                            Disabled

                        </label>


                    </td>

                </tr>


            </table>


            <hr>


            <h2>
                Cloudflare Turnstile
            </h2>


            <p>
                Status:
                <strong>
                    <?php
                    echo esc_html(
                        rud_crm_security_status_label(
                            'turnstile'
                        )
                    );
                    ?>
                </strong>
            </p>


            <table class="form-table">


                <tr>

                    <th>
                        Site Key
                    </th>

                    <td>

                        <?php if ( $can_edit ) : ?>

                            <input
                                type="text"
                                name="turnstile_site_key"
                                value="<?php echo esc_attr( $turnstile_site ); ?>"
                                class="regular-text"
                                autocomplete="off"
                            >

                        <?php else : ?>

                            <code>
                                <?php
                                echo esc_html(
                                    $turnstile_site
                                    ? $turnstile_site
                                    : 'Not configured'
                                );
                                ?>
                            </code>

                        <?php endif; ?>

                    </td>

                </tr>


                <tr>

                    <th>
                        Secret Key
                    </th>

                    <td>

                        <strong>
                            <?php
                            echo esc_html(
                                rud_crm_security_mask_secret(
                                    $turnstile_secret
                                )
                            );
                            ?>
                        </strong>


                        <?php if ( $can_edit ) : ?>

                            <br><br>

                            <input
                                type="password"
                                name="turnstile_secret_key"
                                value=""
                                class="regular-text"
                                autocomplete="new-password"
                            >

                            <p class="description">
                                Leave blank to keep the existing Secret Key.
                            </p>

                        <?php endif; ?>

                    </td>

                </tr>


            </table>


            <hr>


            <h2>
                Google reCAPTCHA
            </h2>


            <p>
                Version:
                <strong>
                    reCAPTCHA v2 Checkbox
                </strong>
            </p>


            <p>
                Status:
                <strong>
                    <?php
                    echo esc_html(
                        rud_crm_security_status_label(
                            'recaptcha'
                        )
                    );
                    ?>
                </strong>
            </p>


            <table class="form-table">


                <tr>

                    <th>
                        Site Key
                    </th>

                    <td>

                        <?php if ( $can_edit ) : ?>

                            <input
                                type="text"
                                name="recaptcha_site_key"
                                value="<?php echo esc_attr( $recaptcha_site ); ?>"
                                class="regular-text"
                                autocomplete="off"
                            >

                        <?php else : ?>

                            <code>
                                <?php
                                echo esc_html(
                                    $recaptcha_site
                                    ? $recaptcha_site
                                    : 'Not configured'
                                );
                                ?>
                            </code>

                        <?php endif; ?>

                    </td>

                </tr>


                <tr>

                    <th>
                        Secret Key
                    </th>

                    <td>

                        <strong>
                            <?php
                            echo esc_html(
                                rud_crm_security_mask_secret(
                                    $recaptcha_secret
                                )
                            );
                            ?>
                        </strong>


                        <?php if ( $can_edit ) : ?>

                            <br><br>

                            <input
                                type="password"
                                name="recaptcha_secret_key"
                                value=""
                                class="regular-text"
                                autocomplete="new-password"
                            >

                            <p class="description">
                                Leave blank to keep the existing Secret Key.
                            </p>

                        <?php endif; ?>

                    </td>

                </tr>


            </table>


            <?php if ( $can_edit ) : ?>

                <?php

                submit_button(
                    'Save Security Settings'
                );

                ?>

            <?php else : ?>

                <p>
                    <strong>
                        View-only access.
                    </strong>
                    Security credentials can only be changed by
                    ADMIN-LEVEL-001 or ADMIN-LEVEL-002.
                </p>

            <?php endif; ?>


        </form>


    </div>

    <?php
}


/*
 * =========================================================
 * SECURITY MENU
 * =========================================================
 */

function rud_crm_security_settings_menu() {

    if (
        ! rud_crm_security_can_view()
    ) {
        return;
    }


    add_submenu_page(

        'rud-crm',

        'Security',

        'Security',

        'read',

        'rud-crm-security',

        'rud_crm_security_settings_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_security_settings_menu',
    35
);