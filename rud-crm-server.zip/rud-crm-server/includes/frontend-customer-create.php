<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END CUSTOMER CREATE
 * Version 1.2 - Customer Create Cleanup
 * =========================================================
 *
 * Works together with:
 * - includes/frontend.php
 * - includes/customer-ownership.php
 *
 * DEMO:
 * - Maximum 10 owned customers
 * - Shared DEMO customers do not count
 *
 * FULL CRM CLIENT:
 * - May create owned customers
 *
 * ADMINS:
 * - May create customers
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS / CREATE PERMISSION
 * =========================================================
 */

function rud_crm_frontend_create_can_access() {

    if ( ! is_user_logged_in() ) {
        return false;
    }

    $user_id = get_current_user_id();

    if (
        function_exists( 'rud_crm_frontend_is_crm_admin' )
        &&
        rud_crm_frontend_is_crm_admin( $user_id )
    ) {
        return true;
    }

    if (
        function_exists( 'rud_crm_frontend_is_full_client' )
        &&
        rud_crm_frontend_is_full_client( $user_id )
    ) {
        return true;
    }

    if (
        function_exists( 'rud_crm_frontend_is_demo_client' )
        &&
        rud_crm_frontend_is_demo_client( $user_id )
    ) {

        if ( function_exists( 'rud_crm_can_create_trial_customer' ) ) {
            return (bool) rud_crm_can_create_trial_customer( $user_id );
        }

        return false;
    }

    return false;
}


/*
 * =========================================================
 * OWNERSHIP TYPE
 * =========================================================
 */

function rud_crm_frontend_create_ownership_type( $user_id ) {

    if (
        function_exists( 'rud_crm_frontend_is_demo_client' )
        &&
        rud_crm_frontend_is_demo_client( $user_id )
    ) {
        return 'trial';
    }

    return 'client';
}


/*
 * =========================================================
 * CURRENT CUSTOMER CRM URL
 * =========================================================
 */

function rud_crm_frontend_create_crm_url() {

    if ( function_exists( 'rud_crm_customer_frontend_url' ) ) {
        return rud_crm_customer_frontend_url();
    }

    $page = get_page_by_path( 'customer-crm' );

    if ( $page && 'publish' === $page->post_status ) {
        return get_permalink( $page->ID );
    }

    return home_url( '/customer-crm/' );
}


/*
 * =========================================================
 * NEW CUSTOMER URL
 * =========================================================
 */

function rud_crm_frontend_create_new_url() {

    return add_query_arg(
        'rud_crm_action',
        'new_customer',
        rud_crm_frontend_create_crm_url()
    );
}


/*
 * =========================================================
 * GENERATE CUSTOMER NUMBER
 * =========================================================
 */

function rud_crm_frontend_create_customer_number( $customer_id ) {

    return sprintf(
        'CUST-%s-%06d',
        wp_date( 'y' ),
        absint( $customer_id )
    );
}


/*
 * =========================================================
 * SAVE CONTACT
 * =========================================================
 */

function rud_crm_frontend_create_contact(
    $customer_id,
    $type,
    $label,
    $value,
    $is_primary = 0
) {

    global $wpdb;

    $value = trim( (string) $value );

    if ( '' === $value ) {
        return true;
    }

    $result = $wpdb->insert(
        $wpdb->prefix . 'rudcrm_contact_methods',
        array(
            'customer_id'   => absint( $customer_id ),
            'contact_type'  => sanitize_key( $type ),
            'contact_label' => sanitize_text_field( $label ),
            'contact_value' => $value,
            'is_primary'    => absint( $is_primary ) ? 1 : 0,
            'is_verified'   => 0,
            'created_at'    => current_time( 'mysql' ),
            'updated_at'    => current_time( 'mysql' ),
        ),
        array(
            '%d',
            '%s',
            '%s',
            '%s',
            '%d',
            '%d',
            '%s',
            '%s',
        )
    );

    return false !== $result;
}


/*
 * =========================================================
 * PROCESS CREATE CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_process_create_customer() {

    if (
        empty( $_POST['rud_crm_frontend_create_action'] )
        ||
        'create_customer' !== sanitize_key(
            wp_unslash( $_POST['rud_crm_frontend_create_action'] )
        )
    ) {
        return;
    }

    if ( ! is_user_logged_in() ) {
        return;
    }

    $user_id = get_current_user_id();

    /*
     * Security.
     */

    if (
        empty( $_POST['rud_crm_frontend_create_nonce'] )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash( $_POST['rud_crm_frontend_create_nonce'] )
            ),
            'rud_crm_frontend_create_customer'
        )
    ) {
        wp_die(
            esc_html__( 'Security verification failed. Please go back and try again.', 'rud-crm-server' )
        );
    }

    /*
     * Enforce the Demo limit again SERVER-SIDE.
     */

    if ( ! rud_crm_frontend_create_can_access() ) {

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_create',
                'limit_reached',
                rud_crm_frontend_create_crm_url()
            )
        );

        exit;
    }

    /*
     * Sanitize.
     */

    $customer_type =
        sanitize_key(
            wp_unslash(
                $_POST['customer_type'] ?? 'person'
            )
        );


    if (
        ! in_array(
            $customer_type,
            array(
                'person',
                'company'
            ),
            true
        )
    ) {
        $customer_type =
            'person';
    }


    $title = sanitize_text_field(
        wp_unslash( $_POST['title'] ?? '' )
    );

    $first_name = sanitize_text_field(
        wp_unslash( $_POST['first_name'] ?? '' )
    );

    $middle_name = sanitize_text_field(
        wp_unslash( $_POST['middle_name'] ?? '' )
    );

    $last_name = sanitize_text_field(
        wp_unslash( $_POST['last_name'] ?? '' )
    );

    $preferred_name = sanitize_text_field(
        wp_unslash( $_POST['preferred_name'] ?? '' )
    );

    $company_name = sanitize_text_field(
        wp_unslash( $_POST['company_name'] ?? '' )
    );

    $organization_number = sanitize_text_field(
        wp_unslash( $_POST['organization_number'] ?? '' )
    );

    $organization_form_code =
        strtoupper(
            sanitize_text_field(
                wp_unslash(
                    $_POST['organization_form_code'] ?? ''
                )
            )
        );

    $organization_form_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['organization_form_name'] ?? ''
            )
        );

    $industry_code =
        sanitize_text_field(
            wp_unslash(
                $_POST['industry_code'] ?? ''
            )
        );

    $industry_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['industry_name'] ?? ''
            )
        );

    $brreg_selected =
        ! empty(
            $_POST['rud_crm_brreg_selected']
        );

    $job_title = sanitize_text_field(
        wp_unslash( $_POST['job_title'] ?? '' )
    );

    $department = sanitize_text_field(
        wp_unslash( $_POST['department'] ?? '' )
    );

    $status = sanitize_key(
        wp_unslash( $_POST['status'] ?? 'lead' )
    );

    $allowed_statuses = array(
        'lead',
        'customer',
        'partner',
        'inactive',
    );

    if ( 'company' === $customer_type && isset( $_POST['company_status'] ) ) {
        $status = sanitize_key( wp_unslash( $_POST['company_status'] ) );
    }

    if ( ! in_array( $status, $allowed_statuses, true ) ) {
        $status = 'lead';
    }


    /*
     * Validation.
     */

    if (
        (
            'person' ===
            $customer_type
            &&
            '' === trim( $first_name )
            &&
            '' === trim( $last_name )
        )
        ||
        (
            'company' ===
            $customer_type
            &&
            '' === trim( $company_name )
        )
    ) {

        wp_safe_redirect(
            add_query_arg(
                array(
                    'rud_crm_action' => 'new_customer',
                    'rud_crm_create' => 'name_required',
                ),
                rud_crm_frontend_create_crm_url()
            )
        );

        exit;
    }

    $now = current_time( 'mysql' );
    $uuid = wp_generate_uuid4();

    /*
     * Temporary unique number because customer_number
     * is NOT NULL and UNIQUE before we know the new ID.
     */

    $temporary_number =
        'TMP-' .
        strtoupper(
            substr(
                str_replace( '-', '', $uuid ),
                0,
                20
            )
        );

    global $wpdb;

    $customers_table =
        $wpdb->prefix . 'rudcrm_customers';

    /*
     * Insert core customer.
     */

    $inserted =
        $wpdb->insert(
            $customers_table,
            array(
                'customer_uuid'       => $uuid,
                'customer_number'     => $temporary_number,
                'customer_type'       => $customer_type,
                'title'               => $title,
                'first_name'          => $first_name,
                'middle_name'         => $middle_name,
                'last_name'           => $last_name,
                'preferred_name'      => $preferred_name,
                'company_name'        => $company_name,
                'organization_number' => $organization_number,
                'job_title'           => $job_title,
                'department'          => $department,
                'status'              => $status,
                'created_at'          => $now,
                'updated_at'          => $now,
            ),
            array(
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
            )
        );

    if ( false === $inserted ) {

        wp_safe_redirect(
            add_query_arg(
                array(
                    'rud_crm_action' => 'new_customer',
                    'rud_crm_create' => 'database_error',
                ),
                rud_crm_frontend_create_crm_url()
            )
        );

        exit;
    }

    $customer_id =
        absint( $wpdb->insert_id );

    /*
     * Final customer number based on database ID.
     */

    $customer_number =
        rud_crm_frontend_create_customer_number(
            $customer_id
        );

    $number_updated =
        $wpdb->update(
            $customers_table,
            array(
                'customer_number' => $customer_number,
                'updated_at'      => $now,
            ),
            array(
                'id' => $customer_id,
            ),
            array(
                '%s',
                '%s',
            ),
            array(
                '%d',
            )
        );

    if ( false === $number_updated ) {

        $wpdb->delete(
            $customers_table,
            array( 'id' => $customer_id ),
            array( '%d' )
        );

        wp_safe_redirect(
            add_query_arg(
                array(
                    'rud_crm_action' => 'new_customer',
                    'rud_crm_create' => 'database_error',
                ),
                rud_crm_frontend_create_crm_url()
            )
        );

        exit;
    }

    /*
     * Assign owner immediately.
     */

    if ( ! function_exists( 'rud_crm_assign_customer_owner' ) ) {

        $wpdb->delete(
            $customers_table,
            array( 'id' => $customer_id ),
            array( '%d' )
        );

        wp_die(
            esc_html__( 'Customer ownership system is unavailable.', 'rud-crm-server' )
        );
    }

    $ownership_type =
        rud_crm_frontend_create_ownership_type(
            $user_id
        );

    $owner_saved =
        rud_crm_assign_customer_owner(
            $customer_id,
            $user_id,
            $ownership_type
        );

    if ( ! $owner_saved ) {

        $wpdb->delete(
            $customers_table,
            array( 'id' => $customer_id ),
            array( '%d' )
        );

        wp_safe_redirect(
            add_query_arg(
                array(
                    'rud_crm_action' => 'new_customer',
                    'rud_crm_create' => 'ownership_error',
                ),
                rud_crm_frontend_create_crm_url()
            )
        );

        exit;
    }

    /*
     * Company-specific information.
     */

    if (
        'company' ===
        $customer_type
        &&
        function_exists(
            'rud_crm_brreg_save_company_details'
        )
    ) {

        rud_crm_brreg_save_company_details(
            $customer_id,
            array(
                'organization_form_code' =>
                    $organization_form_code,

                'organization_form_name' =>
                    $organization_form_name,

                'industry_code' =>
                    $industry_code,

                'industry_name' =>
                    $industry_name,

                'brreg_synced' =>
                    $brreg_selected
            )
        );
    }


    /*
     * Optional customer details.
     */

    $birth_date = sanitize_text_field(
        wp_unslash( $_POST['birth_date'] ?? '' )
    );

    $gender = sanitize_text_field(
        wp_unslash( $_POST['gender'] ?? '' )
    );

    $preferred_language = sanitize_text_field(
        wp_unslash( $_POST['preferred_language'] ?? '' )
    );

    $nationality = sanitize_text_field(
        wp_unslash( $_POST['nationality'] ?? '' )
    );

    $website_url = trim( sanitize_text_field( wp_unslash( $_POST['website_url'] ?? '' ) ) );

    if ( $website_url && ! preg_match( '#^https?://#i', $website_url ) ) {
        $website_url = 'https://' . $website_url;
    }

    $website_url = esc_url_raw( $website_url );

    $notes = sanitize_textarea_field(
        wp_unslash( $_POST['notes'] ?? '' )
    );

    $birth_year = 0;

    if ( $birth_date && preg_match( '/^(\d{4})-\d{2}-\d{2}$/', $birth_date, $matches ) ) {
        $birth_year = absint( $matches[1] );
    }

    $wpdb->insert(
        $wpdb->prefix . 'rudcrm_customer_details',
        array(
            'customer_id'        => $customer_id,
            'birth_date'         => $birth_date ? $birth_date : null,
            'birth_year'         => $birth_year ? $birth_year : null,
            'gender'             => $gender,
            'preferred_language' => $preferred_language,
            'nationality'        => $nationality,
            'website_url'        => $website_url,
            'notes'              => $notes,
            'created_at'         => $now,
            'updated_at'         => $now,
        ),
        array(
            '%d',
            '%s',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
        )
    );

    /*
     * Contacts.
     */

    $private_email =
        sanitize_email(
            wp_unslash( $_POST['private_email'] ?? '' )
        );

    $work_email =
        sanitize_email(
            wp_unslash( $_POST['work_email'] ?? '' )
        );

    $mobile_phone =
        sanitize_text_field(
            wp_unslash( $_POST['mobile_phone'] ?? '' )
        );

    $home_phone =
        sanitize_text_field(
            wp_unslash( $_POST['home_phone'] ?? '' )
        );

    $office_phone =
        sanitize_text_field(
            wp_unslash( $_POST['office_phone'] ?? '' )
        );

    $whatsapp =
        sanitize_text_field(
            wp_unslash( $_POST['whatsapp'] ?? '' )
        );

    if ( function_exists( 'rud_crm_sanitize_phone_number' ) ) {

        $mobile_phone =
            rud_crm_sanitize_phone_number( $mobile_phone );

        $home_phone =
            rud_crm_sanitize_phone_number( $home_phone );

        $office_phone =
            rud_crm_sanitize_phone_number( $office_phone );

        $whatsapp =
            rud_crm_sanitize_phone_number( $whatsapp );
    }

    rud_crm_frontend_create_contact(
        $customer_id,
        'private_email',
        'Private Email',
        $private_email,
        1
    );

    rud_crm_frontend_create_contact(
        $customer_id,
        'work_email',
        'Work Email',
        $work_email,
        0
    );

    rud_crm_frontend_create_contact(
        $customer_id,
        'mobile_phone',
        'Mobile Phone',
        $mobile_phone,
        1
    );

    rud_crm_frontend_create_contact(
        $customer_id,
        'home_phone',
        'Home Phone',
        $home_phone,
        0
    );

    rud_crm_frontend_create_contact(
        $customer_id,
        'office_phone',
        'Office Phone',
        $office_phone,
        0
    );

    rud_crm_frontend_create_contact(
        $customer_id,
        'whatsapp',
        'WhatsApp',
        $whatsapp,
        0
    );

    /*
     * Primary address (Private Address or Company Address).
     */

    $address_line_1 =
        sanitize_text_field(
            wp_unslash( $_POST['address_line_1'] ?? '' )
        );

    $address_line_2 =
        sanitize_text_field(
            wp_unslash( $_POST['address_line_2'] ?? '' )
        );

    $postal_code =
        sanitize_text_field(
            wp_unslash( $_POST['postal_code'] ?? '' )
        );

    $city =
        sanitize_text_field(
            wp_unslash( $_POST['city'] ?? '' )
        );

    $state_region =
        sanitize_text_field(
            wp_unslash( $_POST['state_region'] ?? '' )
        );

    $country_code =
        strtoupper(
            substr(
                sanitize_text_field(
                    wp_unslash( $_POST['country_code'] ?? '' )
                ),
                0,
                2
            )
        );

    if (
        $address_line_1
        ||
        $address_line_2
        ||
        $postal_code
        ||
        $city
        ||
        $state_region
        ||
        $country_code
    ) {

        $wpdb->insert(
            $wpdb->prefix . 'rudcrm_addresses',
            array(
                'customer_id'    => $customer_id,
                'address_type'   => 'private',
                'company_name'   => $company_name,
                'address_line_1' => $address_line_1,
                'address_line_2' => $address_line_2,
                'postal_code'    => $postal_code,
                'city'           => $city,
                'state_region'   => $state_region,
                'country_code'   => $country_code,
                'is_primary'     => 1,
                'created_at'     => $now,
                'updated_at'     => $now,
            ),
            array(
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%d',
                '%s',
                '%s',
            )
        );
    }

    /*
     * Optional profile images / company logo.
     */

    $image_upload_error =
        '';

    if (
        function_exists(
            'rud_crm_frontend_customer_image_upload'
        )
    ) {

        if (
            'company' ===
            $customer_type
        ) {

            $image_file =
                $_FILES['rud_crm_new_customer_company_logo']
                ?? array();

            if (
                ! empty(
                    $image_file['tmp_name']
                )
            ) {

                $image_result =
                    rud_crm_frontend_customer_image_upload(
                        $customer_id,
                        $image_file,
                        true
                    );

                if (
                    is_wp_error(
                        $image_result
                    )
                ) {
                    $image_upload_error =
                        $image_result->get_error_message();
                }
            }

        } elseif (
            function_exists(
                'rud_crm_frontend_customer_image_upload_multiple'
            )
        ) {

            $image_results =
                rud_crm_frontend_customer_image_upload_multiple(
                    $customer_id,
                    $_FILES['rud_crm_new_customer_person_images']
                    ?? array()
                );

            foreach (
                $image_results
                as
                $image_result
            ) {

                if (
                    is_wp_error(
                        $image_result
                    )
                ) {
                    $image_upload_error =
                        $image_result->get_error_message();

                    break;
                }
            }
        }
    }


    /*
     * Redirect directly to the new customer's profile.
     */

    $redirect_args =
        array(
            'rud_customer_id' =>
                $customer_id,

            'rud_crm_create' =>
                'success',
        );


    if (
        $image_upload_error
    ) {

        $redirect_args['rud_crm_image'] =
            'error';

        $redirect_args['rud_crm_image_message'] =
            rawurlencode(
                $image_upload_error
            );
    }


    wp_safe_redirect(
        add_query_arg(
            $redirect_args,
            rud_crm_frontend_create_crm_url()
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_create_customer',
    25
);


/*
 * =========================================================
 * CREATE FORM MESSAGE
 * =========================================================
 */

function rud_crm_frontend_create_message() {

    $status =
        isset( $_GET['rud_crm_create'] )
        ? sanitize_key(
            wp_unslash( $_GET['rud_crm_create'] )
        )
        : '';

    if ( 'limit_reached' === $status ) {
        return 'Your Demo account has reached the maximum of 10 owned customers.';
    }

    if ( 'name_required' === $status ) {
        return 'Enter at least a first name, last name, or company name.';
    }

    if ( 'database_error' === $status ) {
        return 'The customer could not be created because of a database error.';
    }

    if ( 'ownership_error' === $status ) {
        return 'The customer could not be assigned to your CRM account.';
    }

    return '';
}


/*
 * =========================================================
 * CREATE CUSTOMER FORM
 * =========================================================
 */

function rud_crm_frontend_create_customer_form() {

    if ( ! is_user_logged_in() ) {
        return '';
    }

    $user_id = get_current_user_id();

    $is_demo =
        function_exists( 'rud_crm_frontend_is_demo_client' )
        &&
        rud_crm_frontend_is_demo_client( $user_id );

    $slots = null;

    if (
        $is_demo
        &&
        function_exists( 'rud_crm_trial_customer_slots_remaining' )
    ) {
        $slots =
            rud_crm_trial_customer_slots_remaining( $user_id );
    }

    if ( ! rud_crm_frontend_create_can_access() ) {

        ob_start();
        ?>

        <div class="rud-crm-create-wrap">

            <a
                class="rud-crm-button"
                href="<?php echo esc_url( rud_crm_frontend_create_crm_url() ); ?>"
            >
                ← Back to Customers
            </a>

            <div class="rud-crm-create-limit-box">

                <h2>Customer Limit Reached</h2>

                <p>
                    Your Demo account already has the maximum of
                    <strong>10 owned customers</strong>.
                </p>

                <p>
                    The shared Demo customers do not count toward this limit.
                </p>

            </div>

        </div>

        <?php
        return ob_get_clean();
    }

    $message =
        rud_crm_frontend_create_message();

    if ( function_exists( 'rud_crm_enqueue_phone_assets' ) ) {
        rud_crm_enqueue_phone_assets();
    }

    ob_start();
    ?>

    <div class="rud-crm-create-wrap">

        <div class="rud-crm-create-toolbar">

            <a
                class="rud-crm-button"
                href="<?php echo esc_url( rud_crm_frontend_create_crm_url() ); ?>"
            >
                ← Back to Customers
            </a>

            <?php if ( $is_demo && null !== $slots ) : ?>

                <span class="rud-crm-create-slots">
                    <?php echo esc_html( $slots ); ?> of 10 customer slots remaining
                </span>

            <?php endif; ?>

        </div>

        <?php if ( $message ) : ?>

            <div class="rud-crm-create-error">
                <?php echo esc_html( $message ); ?>
            </div>

        <?php endif; ?>

        <div class="rud-crm-create-card">

            <h2>Create New Customer</h2>

            <p>
                Add a customer to your private RUD CRM customer database.
            </p>

            <form method="post" enctype="multipart/form-data" class="rud-crm-create-form">

                <?php
                wp_nonce_field(
                    'rud_crm_frontend_create_customer',
                    'rud_crm_frontend_create_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_frontend_create_action"
                    value="create_customer"
                >

                <div class="rud-crm-customer-type-selector">

                    <h3>Customer Type</h3>

                    <p>
                        Choose whether you are registering a private person or a company / organization.
                    </p>

                    <div class="rud-crm-customer-type-options">

                        <label>
                            <input
                                type="radio"
                                name="customer_type"
                                value="person"
                                checked
                            >
                            <strong>Private Person</strong>
                        </label>

                        <label>
                            <input
                                type="radio"
                                name="customer_type"
                                value="company"
                            >
                            <strong>Company / Organization</strong>
                        </label>

                    </div>

                </div>


                <div data-rud-customer-person>

                    <h3>Personal Information</h3>

                    <div class="rud-crm-create-grid">

                    <div>
                        <label>First Name</label>
                        <input type="text" name="first_name">
                    </div>

                    <div>
                        <label>Middle Name</label>
                        <input type="text" name="middle_name">
                    </div>

                    <div>
                        <label>Last Name</label>
                        <input type="text" name="last_name">
                    </div>

                    <div>
                        <label>Preferred Name</label>
                        <input type="text" name="preferred_name">
                    </div>

                    <div>
                        <label>Title</label>
                        <input type="text" name="title">
                    </div>

                    <div>
                        <label>Status</label>
                        <select name="status">
                            <option value="lead">Lead</option>
                            <option value="customer">Customer</option>
                            <option value="partner">Partner</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>

                    </div>

                </div>


                <div data-rud-customer-company style="display:none;">

                    <h3>Company Information</h3>

                    <?php
                    if ( function_exists( 'rud_crm_brreg_company_lookup_html' ) ) {
                        echo rud_crm_brreg_company_lookup_html();
                    }
                    ?>

                    <div class="rud-crm-create-grid">
                        <div><label>Company Name</label><input type="text" name="company_name"></div>
                        <div>
                            <label>Status</label>
                            <select name="company_status" data-rud-company-status>
                                <option value="lead">Lead</option>
                                <option value="customer">Customer</option>
                                <option value="partner">Partner</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div><label>Organization Number</label><input type="text" name="organization_number"></div>
                        <div><label>Company Type Code</label><input type="text" name="organization_form_code" placeholder="AS"></div>
                        <div><label>Company Type</label><input type="text" name="organization_form_name" placeholder="Aksjeselskap"></div>
                        <div><label>Industry Code</label><input type="text" name="industry_code" placeholder="70.200"></div>
                        <div class="rud-crm-create-wide"><label>Industry</label><input type="text" name="industry_name" placeholder="Bedriftsrådgivning og annen administrativ rådgivning"></div>
                        <input type="hidden" name="rud_crm_brreg_selected" value="">
                    </div>

                </div>


                <h3 data-rud-contact-heading>Contact Information</h3>

                <div class="rud-crm-create-grid">

                    <div data-rud-person-contact>
                        <label>Private Email</label>
                        <input type="email" name="private_email">
                    </div>

                    <div>
                        <label>Work Email</label>
                        <input type="email" name="work_email">
                    </div>

                    <div data-rud-person-contact>
                        <label>Mobile Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'mobile_phone',
                                    '',
                                    array(
                                        'id' =>
                                            'rud_crm_customer_mobile_phone',

                                        'description' =>
                                            'Select the country flag and enter the mobile phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="mobile_phone"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div data-rud-person-contact>
                        <label>Home Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'home_phone',
                                    '',
                                    array(
                                        'id' =>
                                            'rud_crm_customer_home_phone',

                                        'description' =>
                                            'Select the country flag and enter the home phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="home_phone"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div>
                        <label>Office Phone</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'office_phone',
                                    '',
                                    array(
                                        'id' =>
                                            'rud_crm_customer_office_phone',

                                        'description' =>
                                            'Select the country flag and enter the office phone number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="office_phone"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div>
                        <label>WhatsApp</label>

                        <?php

                        if (
                            function_exists(
                                'rud_crm_render_phone_field'
                            )
                        ) {

                            echo wp_kses(
                                rud_crm_render_phone_field(
                                    'whatsapp',
                                    '',
                                    array(
                                        'id' =>
                                            'rud_crm_customer_whatsapp',

                                        'description' =>
                                            'Select the country flag and enter the WhatsApp number.'
                                    )
                                ),
                                rud_crm_phone_allowed_html()
                            );

                        } else {

                            ?>

                            <input
                                type="tel"
                                name="whatsapp"
                                autocomplete="tel"
                            >

                            <?php
                        }

                        ?>

                    </div>

                    <div class="rud-crm-create-wide">
                        <label>Website</label>
                        <input type="text" name="website_url" placeholder="https://example.com">
                    </div>

                </div>

                <div data-rud-person-details>

                <h3>Additional Personal Information</h3>

                <div class="rud-crm-create-grid">

                    <div>
                        <label>Birth Date</label>
                        <input type="date" name="birth_date">
                    </div>

                    <div>
                        <label>Gender</label>
                        <input type="text" name="gender">
                    </div>

                    <div>
                        <label>Preferred Language</label>
                        <input type="text" name="preferred_language">
                    </div>

                    <div>
                        <label>Nationality</label>
                        <input type="text" name="nationality">
                    </div>

                </div>

                </div>

                <h3 data-rud-address-heading>Private Address</h3>

                <div class="rud-crm-create-grid">

                    <div class="rud-crm-create-wide">
                        <label>Address</label>
                        <input type="text" name="address_line_1">
                    </div>

                    <div class="rud-crm-create-wide">
                        <label>Address Line 2</label>
                        <input type="text" name="address_line_2">
                    </div>

                    <div>
                        <label>Postal Code</label>
                        <input type="text" name="postal_code">
                    </div>

                    <div>
                        <label>City</label>
                        <input type="text" name="city">
                    </div>

                    <div>
                        <label>State / Region</label>
                        <input type="text" name="state_region">
                    </div>

                    <div>
                        <label>Country Code</label>
                        <input
                            type="text"
                            name="country_code"
                            maxlength="2"
                            placeholder="NO"
                        >
                    </div>

                </div>

                <h3 data-rud-notes-heading>Internal CRM Notes</h3>

                <div>
                    <textarea
                        name="notes"
                        rows="6"
                    ></textarea>
                </div>


                <div data-rud-person-image>
                    <h3>Customer Images</h3>
                    <div class="rud-crm-create-image-field">
                        <label>Private Person Images</label>
                        <div class="rud-crm-dropzone" data-rud-dropzone>
                            <input
                                type="file"
                                name="rud_crm_new_customer_person_images[]"
                                accept=".jpg,.jpeg,image/jpeg"
                                data-rud-drop-input
                                multiple
                            >
                            <div class="rud-crm-dropzone-icon" aria-hidden="true">+</div>
                            <strong>Drag & Drop Images Here</strong>
                            <span>or click to browse — JPG/JPEG only</span>
                            <small>Maximum 10 images total. The first image becomes the Primary profile image. Large images are automatically reduced to a maximum of 1200 × 1200 px.</small>
                            <div class="rud-crm-dropzone-selection" data-rud-drop-selection></div>
                        </div>
                    </div>
                </div>

                <div data-rud-company-image style="display:none;">
                    <h3>Company Logo</h3>
                    <div class="rud-crm-create-image-field">
                        <label>Company / Organization Logo</label>
                        <div class="rud-crm-dropzone" data-rud-dropzone>
                            <input type="file" name="rud_crm_new_customer_company_logo" accept=".jpg,.jpeg,.png,image/jpeg,image/png" data-rud-drop-input>
                            <div class="rud-crm-dropzone-icon" aria-hidden="true">+</div>
                            <strong>Drag & Drop Company Logo Here</strong>
                            <span>or click to browse — JPG, JPEG or PNG</span>
                            <small>One logo/image only. The logo keeps its proportions and is reduced automatically.</small>
                            <div class="rud-crm-dropzone-selection" data-rud-drop-selection></div>
                        </div>
                    </div>
                </div>

                <button
                    type="submit"
                    class="rud-crm-create-submit"
                >
                    CREATE CUSTOMER
                </button>

            </form>

        </div>

    </div>

    <style>

        .rud-crm-create-wrap {
            width:100%;
            max-width:1000px;
            margin:0 auto;
        }

        .rud-crm-create-toolbar {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:20px;
            margin-bottom:20px;
        }

        .rud-crm-create-slots {
            font-weight:700;
        }

        .rud-crm-create-card {
            background:#fff;
            border:1px solid #eaecf0;
            border-radius:12px;
            padding:28px;
        }

        .rud-crm-create-card h2 {
            margin-top:0;
        }

        .rud-crm-create-card h3 {
            margin-top:30px;
            margin-bottom:14px;
        }

        .rud-crm-create-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:16px;
        }

        .rud-crm-create-wide {
            grid-column:1 / -1;
        }

        .rud-crm-create-form label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }

        .rud-crm-create-form input,
        .rud-crm-create-form select,
        .rud-crm-create-form textarea {
            width:100%;
            box-sizing:border-box;
            padding:11px 13px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            font:inherit;
        }

        .rud-crm-customer-type-selector {
            margin-bottom:24px;
            padding:20px;
            border:1px solid #eaecf0;
            border-radius:10px;
            background:#f9fafb;
        }

        .rud-crm-customer-type-selector h3 {
            margin-top:0;
        }

        .rud-crm-customer-type-options {
            display:flex;
            gap:14px;
            flex-wrap:wrap;
            margin-top:14px;
        }

        .rud-crm-customer-type-options label {
            display:flex;
            align-items:center;
            gap:8px;
            padding:12px 16px;
            border:1px solid #d0d5dd;
            border-radius:8px;
            background:#fff;
            cursor:pointer;
        }

        .rud-crm-customer-type-options input {
            width:auto;
        }

        .rud-crm-create-help {
            margin-top:-6px;
            opacity:.7;
        }

        .rud-crm-create-submit {
            margin-top:28px;
            width:100%;
            padding:14px 20px;
            border:0;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            font-weight:700;
            cursor:pointer;
        }

        .rud-crm-create-image-field {
            margin:0 0 22px;
            padding:18px;
            border:1px solid #eaecf0;
            border-radius:10px;
            background:#f9fafb;
        }

        .rud-crm-create-image-field label {
            display:block;
            margin-bottom:8px;
            font-weight:700;
        }

        .rud-crm-create-image-field input[type="file"] {
            width:100%;
        }

        .rud-crm-create-error,
        .rud-crm-create-limit-box {
            margin-bottom:20px;
            padding:18px 20px;
            border:1px solid #f0c7c7;
            border-radius:8px;
            background:#fff6f6;
        }

        @media (max-width:700px) {

            .rud-crm-create-grid {
                grid-template-columns:1fr;
            }

            .rud-crm-create-wide {
                grid-column:auto;
            }

            .rud-crm-create-toolbar {
                display:block;
            }

            .rud-crm-create-slots {
                display:block;
                margin-top:10px;
            }
        }

    </style>

    <script>
    (function() {

        function rudCrmCreateToggleCustomerType() {

            var selected = document.querySelector('input[name="customer_type"]:checked');
            var person = document.querySelector('[data-rud-customer-person]');
            var company = document.querySelector('[data-rud-customer-company]');
            var personDetails = document.querySelector('[data-rud-person-details]');
            var personContacts = document.querySelectorAll('[data-rud-person-contact]');
            var addressHeading = document.querySelector('[data-rud-address-heading]');
            var contactHeading = document.querySelector('[data-rud-contact-heading]');
            var notesHeading = document.querySelector('[data-rud-notes-heading]');
            var personImage = document.querySelector('[data-rud-person-image]');
            var companyImage = document.querySelector('[data-rud-company-image]');

            if ( ! selected || ! person || ! company ) {
                return;
            }

            if ( selected.value === 'company' ) {
                person.style.display = 'none';
                company.style.display = '';

                if ( personDetails ) {
                    personDetails.style.display = 'none';
                }

                personContacts.forEach(function(field) {
                    field.style.display = 'none';
                });

                if ( addressHeading ) {
                    addressHeading.textContent = 'Company Address';
                }

                if ( contactHeading ) {
                    contactHeading.textContent = 'Company Contact Information';
                }

                if ( notesHeading ) {
                    notesHeading.textContent = 'Internal CRM Company Notes';
                }
                if ( personImage ) { personImage.style.display = 'none'; }
                if ( companyImage ) { companyImage.style.display = ''; }

            } else {
                person.style.display = '';
                company.style.display = 'none';

                if ( personDetails ) {
                    personDetails.style.display = '';
                }

                personContacts.forEach(function(field) {
                    field.style.display = '';
                });

                if ( addressHeading ) {
                    addressHeading.textContent = 'Private Address';
                }

                if ( contactHeading ) {
                    contactHeading.textContent = 'Contact Information';
                }

                if ( notesHeading ) {
                    notesHeading.textContent = 'Internal CRM Notes';
                }
                if ( personImage ) { personImage.style.display = ''; }
                if ( companyImage ) { companyImage.style.display = 'none'; }
            }
        }

        document.addEventListener(
            'change',
            function(event) {

                if (
                    event.target
                    &&
                    event.target.name ===
                    'customer_type'
                ) {
                    rudCrmCreateToggleCustomerType();
                }
            }
        );

        rudCrmCreateToggleCustomerType();

    })();
    </script>

    <?php
    return ob_get_clean();
}


/*
 * =========================================================
 * CUSTOMER CRM CREATE BUTTON
 * =========================================================
 */

function rud_crm_frontend_create_button_html() {

    if ( ! is_user_logged_in() ) {
        return '';
    }

    $user_id = get_current_user_id();

    $is_demo =
        function_exists( 'rud_crm_frontend_is_demo_client' )
        &&
        rud_crm_frontend_is_demo_client( $user_id );

    $can_create =
        rud_crm_frontend_create_can_access();

    ob_start();
    ?>

    <div class="rud-crm-create-button-row">

        <?php if ( $can_create ) : ?>

            <a
                href="<?php echo esc_url( rud_crm_frontend_create_new_url() ); ?>"
                class="rud-crm-button rud-crm-button-primary"
            >
                + CREATE NEW CUSTOMER
            </a>

        <?php elseif ( $is_demo ) : ?>

            <span class="rud-crm-create-limit-label">
                Demo customer limit reached: 10 / 10
            </span>

        <?php endif; ?>

    </div>

    <style>
        .rud-crm-create-button-row {
            margin:0 0 20px;
        }

        .rud-crm-create-limit-label {
            display:inline-block;
            padding:10px 14px;
            border:1px solid #eaecf0;
            border-radius:7px;
            background:#fff;
            font-weight:600;
        }
    </style>

    <?php
    return ob_get_clean();
}


/*
 * =========================================================
 * INTERCEPT [rud_crm_frontend] FOR CREATE SCREEN
 * =========================================================
 *
 * This lets us add Create Customer without replacing
 * frontend.php again.
 *
 * =========================================================
 */

function rud_crm_frontend_create_intercept_shortcode(
    $return,
    $tag,
    $attr,
    $m
) {

    if (
        'rud_crm_frontend' !== $tag
        &&
        'rud_crm_customer_list' !== $tag
    ) {
        return $return;
    }

    $action =
        isset( $_GET['rud_crm_action'] )
        ? sanitize_key(
            wp_unslash( $_GET['rud_crm_action'] )
        )
        : '';

    if ( 'new_customer' === $action ) {
        return rud_crm_frontend_create_customer_form();
    }

    return $return;
}


add_filter(
    'pre_do_shortcode_tag',
    'rud_crm_frontend_create_intercept_shortcode',
    10,
    4
);


/*
 * =========================================================
 * ADD CREATE BUTTON BEFORE CUSTOMER CRM SHORTCODE OUTPUT
 * =========================================================
 */

function rud_crm_frontend_create_add_button(
    $output,
    $tag,
    $attr,
    $m
) {

    if (
        'rud_crm_frontend' !== $tag
        &&
        'rud_crm_customer_list' !== $tag
    ) {
        return $output;
    }

    $action =
        isset( $_GET['rud_crm_action'] )
        ? sanitize_key(
            wp_unslash( $_GET['rud_crm_action'] )
        )
        : '';

    $customer_id =
        isset( $_GET['rud_customer_id'] )
        ? absint( $_GET['rud_customer_id'] )
        : 0;

    /*
     * Only show the Create button on the main customer list,
     * not on a profile and not on the create form.
     */

    if (
        'new_customer' === $action
        ||
        $customer_id > 0
    ) {
        return $output;
    }

    if (
        ! function_exists( 'rud_crm_frontend_user_can_access' )
        ||
        ! rud_crm_frontend_user_can_access()
    ) {
        return $output;
    }

    return
        rud_crm_frontend_create_button_html()
        .
        $output;
}


add_filter(
    'do_shortcode_tag',
    'rud_crm_frontend_create_add_button',
    10,
    4
);