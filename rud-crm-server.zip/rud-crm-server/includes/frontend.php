<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM FRONT-END
 * Version 1.10
 * =========================================================
 *
 * Shortcodes:
 *
 * [rud_crm_frontend]
 * [rud_crm_customer_list]
 *
 *
 * ACCESS MODEL
 * ------------
 *
 * ADMIN-LEVEL-001 through ADMIN-LEVEL-006:
 * - Full customer visibility
 *
 * DEMO CRM CLIENT:
 * - Shared DEMO customers: VIEW ONLY
 * - Own customers: VIEW / EDIT / DELETE
 * - Maximum 10 owned customers
 *
 * FULL CRM CLIENT:
 * - Own customers: VIEW / EDIT / DELETE
 *
 * LOGGED OUT:
 * - No CRM access
 *
 * =========================================================
 */


/*
 * =========================================================
 * USER TYPE HELPERS
 * =========================================================
 */

function rud_crm_frontend_is_crm_admin(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return false;
    }


    /*
     * Preferred hierarchy helper.
     */

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
    ) {

        $level =
            rud_crm_get_admin_level(
                $user_id
            );


        if (
            $level >= 1
            &&
            $level <= 6
        ) {

            return true;
        }
    }


    /*
     * Backward compatibility.
     */

    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    $roles =
        (array)
        $user->roles;


    foreach (
        array(
            'rud_crm_admin_level_001',
            'rud_crm_admin_level_002',
            'rud_crm_admin_level_003',
            'rud_crm_admin_level_004',
            'rud_crm_admin_level_005',
            'rud_crm_admin_level_006',
            'rud_crm_manager',
            'rud_crm_editor',
            'rud_crm_viewer'
        )
        as
        $role
    ) {

        if (
            in_array(
                $role,
                $roles,
                true
            )
        ) {

            return true;
        }
    }


    /*
     * Existing WordPress administrators remain
     * supported during migration.
     */

    if (
        user_can(
            $user,
            'manage_options'
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * DEMO CRM CLIENT
 * =========================================================
 */

function rud_crm_frontend_is_demo_client(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    return in_array(
        'rud_crm_demo',
        (array)
        $user->roles,
        true
    );
}


/*
 * =========================================================
 * FULL CRM CLIENT
 * =========================================================
 */

function rud_crm_frontend_is_full_client(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return false;
    }


    return in_array(
        'rud_crm_client',
        (array)
        $user->roles,
        true
    );
}


/*
 * =========================================================
 * FRONT-END ACCESS
 * =========================================================
 */

function rud_crm_frontend_user_can_access() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    $user_id =
        get_current_user_id();


    if (
        rud_crm_frontend_is_crm_admin(
            $user_id
        )
    ) {

        return true;
    }


    if (
        rud_crm_frontend_is_demo_client(
            $user_id
        )
    ) {

        return true;
    }


    if (
        rud_crm_frontend_is_full_client(
            $user_id
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * CRM ACCOUNT URL
 * =========================================================
 */

function rud_crm_frontend_account_url() {

    if (
        function_exists(
            'rud_crm_account_page_url'
        )
    ) {

        return rud_crm_account_page_url();
    }


    return home_url(
        '/crm-account/'
    );
}


/*
 * =========================================================
 * ACCESS MESSAGE
 * =========================================================
 */

function rud_crm_frontend_access_message() {

    if (
        ! is_user_logged_in()
    ) {

        ob_start();

        ?>

        <div class="rud-crm-access-box">

            <h2>
                CRM Login Required
            </h2>

            <p>
                Please log in to your RUD CRM account to access Customer CRM.
            </p>

            <p>

                <a
                    class="rud-crm-button rud-crm-button-primary"
                    href="<?php
                    echo esc_url(
                        rud_crm_frontend_account_url()
                    );
                    ?>"
                >
                    CRM ACCOUNT LOGIN
                </a>

            </p>

        </div>

        <?php

        return ob_get_clean();
    }


    ob_start();

    ?>

    <div class="rud-crm-access-box">

        <h2>
            Access Restricted
        </h2>

        <p>
            Your account does not currently have permission to access Customer CRM.
        </p>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * OWNED CUSTOMER IDS
 * =========================================================
 */

function rud_crm_frontend_owned_customer_ids(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return array();
    }


    /*
     * Preferred ownership module.
     */

    if (
        function_exists(
            'rud_crm_get_owned_customer_ids'
        )
    ) {

        $ids =
            rud_crm_get_owned_customer_ids(
                $user_id
            );


        if (
            is_array(
                $ids
            )
        ) {

            return array_values(
                array_unique(
                    array_filter(
                        array_map(
                            'absint',
                            $ids
                        )
                    )
                )
            );
        }
    }


    /*
     * Direct database fallback.
     */

    global $wpdb;


    $table =
        $wpdb->prefix .
        'rudcrm_customer_ownership';


    $ids =
        $wpdb->get_col(
            $wpdb->prepare(
                "SELECT customer_id
                 FROM {$table}
                 WHERE user_id = %d",
                absint(
                    $user_id
                )
            )
        );


    return array_values(
        array_unique(
            array_filter(
                array_map(
                    'absint',
                    (array)
                    $ids
                )
            )
        )
    );
}


/*
 * =========================================================
 * CAN VIEW CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_can_view_customer(
    $customer_id,
    $user_id = 0
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return false;
    }


    /*
     * Administrators see all customers.
     */

    if (
        rud_crm_frontend_is_crm_admin(
            $user_id
        )
    ) {

        return true;
    }


    /*
     * Owned customer.
     */

    $owned_ids =
        rud_crm_frontend_owned_customer_ids(
            $user_id
        );


    if (
        in_array(
            $customer_id,
            $owned_ids,
            true
        )
    ) {

        return true;
    }


    /*
     * Demo accounts may additionally view
     * shared DEMO records.
     */

    if (
        rud_crm_frontend_is_demo_client(
            $user_id
        )
    ) {

        $customer_number =
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT customer_number
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );


        if (
            is_string(
                $customer_number
            )
            &&
            0 ===
            strpos(
                strtoupper(
                    $customer_number
                ),
                'DEMO-'
            )
        ) {

            return true;
        }
    }


    return false;
}


/*
 * =========================================================
 * CUSTOMER VISIBILITY SQL
 * =========================================================
 *
 * Returns SQL + values that can be appended to
 * customer queries.
 *
 * =========================================================
 */

function rud_crm_frontend_visibility_condition(
    $customer_table_alias = ''
) {

    $user_id =
        get_current_user_id();


    $prefix =
        $customer_table_alias
        ? $customer_table_alias . '.'
        : '';


    /*
     * Administrators:
     * unrestricted.
     */

    if (
        rud_crm_frontend_is_crm_admin(
            $user_id
        )
    ) {

        return array(
            'sql'    => '1=1',
            'values' => array()
        );
    }


    $owned_ids =
        rud_crm_frontend_owned_customer_ids(
            $user_id
        );


    /*
     * Demo user:
     *
     * shared DEMO customers
     * +
     * owned customers
     */

    if (
        rud_crm_frontend_is_demo_client(
            $user_id
        )
    ) {

        if (
            ! empty(
                $owned_ids
            )
        ) {

            $placeholders =
                implode(
                    ',',
                    array_fill(
                        0,
                        count(
                            $owned_ids
                        ),
                        '%d'
                    )
                );


            return array(

                'sql' =>
                    '(' .
                    $prefix .
                    "customer_number LIKE %s
                    OR " .
                    $prefix .
                    "id IN ({$placeholders})
                    )",

                'values' =>
                    array_merge(
                        array(
                            'DEMO-%'
                        ),
                        $owned_ids
                    )
            );
        }


        return array(

            'sql' =>
                $prefix .
                'customer_number LIKE %s',

            'values' =>
                array(
                    'DEMO-%'
                )
        );
    }


    /*
     * Full CRM Client:
     * owned customers only.
     */

    if (
        rud_crm_frontend_is_full_client(
            $user_id
        )
    ) {

        if (
            empty(
                $owned_ids
            )
        ) {

            return array(
                'sql' =>
                    '1=0',

                'values' =>
                    array()
            );
        }


        $placeholders =
            implode(
                ',',
                array_fill(
                    0,
                    count(
                        $owned_ids
                    ),
                    '%d'
                )
            );


        return array(

            'sql' =>
                $prefix .
                "id IN ({$placeholders})",

            'values' =>
                $owned_ids
        );
    }


    /*
     * Unknown account:
     * no data.
     */

    return array(
        'sql'    => '1=0',
        'values' => array()
    );
}


/*
 * =========================================================
 * SHARED DEMO CUSTOMER
 * =========================================================
 *
 * Shared demo records are identified by customer numbers
 * beginning with DEMO-.
 *
 * These records are always read-only for CRM Clients.
 * Administrators may still manage them.
 *
 * =========================================================
 */

function rud_crm_frontend_is_shared_demo_customer(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    $customer_number =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT customer_number
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    if (
        ! is_string(
            $customer_number
        )
    ) {

        return false;
    }


    return 0 === strpos(
        strtoupper(
            $customer_number
        ),
        'DEMO-'
    );
}


/*
 * =========================================================
 * CAN EDIT CUSTOMER
 * =========================================================
 *
 * SERVER-SIDE RULE:
 *
 * ADMIN:
 * - May edit all customers.
 *
 * DEMO / FULL CLIENT:
 * - May edit only customers they own.
 * - Shared DEMO customers are never editable.
 *
 * =========================================================
 */

function rud_crm_frontend_can_edit_customer(
    $customer_id,
    $user_id = 0
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return false;
    }


    if (
        rud_crm_frontend_is_crm_admin(
            $user_id
        )
    ) {

        return true;
    }


    /*
     * Shared demo records are read-only for clients,
     * even if bad ownership data were ever attached.
     */

    if (
        rud_crm_frontend_is_shared_demo_customer(
            $customer_id
        )
    ) {

        return false;
    }


    if (
        ! rud_crm_frontend_is_demo_client(
            $user_id
        )
        &&
        ! rud_crm_frontend_is_full_client(
            $user_id
        )
    ) {

        return false;
    }


    return in_array(
        $customer_id,
        rud_crm_frontend_owned_customer_ids(
            $user_id
        ),
        true
    );
}


/*
 * =========================================================
 * CAN DELETE CUSTOMER
 * =========================================================
 */

function rud_crm_frontend_can_delete_customer(
    $customer_id,
    $user_id = 0
) {

    return rud_crm_frontend_can_edit_customer(
        $customer_id,
        $user_id
    );
}


/*
 * =========================================================
 * DEMO CUSTOMER LIMIT
 * =========================================================
 */

function rud_crm_frontend_demo_customer_limit() {

    if (
        function_exists(
            'rud_crm_trial_customer_limit'
        )
    ) {

        return max(
            0,
            absint(
                rud_crm_trial_customer_limit()
            )
        );
    }


    return 10;
}


/*
 * =========================================================
 * OWNED CUSTOMER COUNT
 * =========================================================
 */

function rud_crm_frontend_owned_customer_count(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return 0;
    }


    if (
        function_exists(
            'rud_crm_count_owned_customers'
        )
    ) {

        return absint(
            rud_crm_count_owned_customers(
                $user_id,
                'trial'
            )
        );
    }


    return count(
        rud_crm_frontend_owned_customer_ids(
            $user_id
        )
    );
}


/*
 * =========================================================
 * CAN CREATE CUSTOMER
 * =========================================================
 *
 * This is the central server-side gate that customer-create
 * handlers must call before inserting a new customer.
 *
 * =========================================================
 */

function rud_crm_frontend_can_create_customer(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! $user_id
    ) {

        return false;
    }


    if (
        rud_crm_frontend_is_crm_admin(
            $user_id
        )
    ) {

        return true;
    }


    if (
        rud_crm_frontend_is_full_client(
            $user_id
        )
    ) {

        return true;
    }


    if (
        ! rud_crm_frontend_is_demo_client(
            $user_id
        )
    ) {

        return false;
    }


    if (
        function_exists(
            'rud_crm_can_create_trial_customer'
        )
    ) {

        return (bool)
            rud_crm_can_create_trial_customer(
                $user_id
            );
    }


    return rud_crm_frontend_owned_customer_count(
        $user_id
    ) < rud_crm_frontend_demo_customer_limit();
}


/*
 * =========================================================
 * DEMO REMAINING CUSTOMER SLOTS
 * =========================================================
 */

function rud_crm_frontend_remaining_customer_slots(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    if (
        ! rud_crm_frontend_is_demo_client(
            $user_id
        )
    ) {

        return null;
    }


    return max(
        0,
        rud_crm_frontend_demo_customer_limit()
        -
        rud_crm_frontend_owned_customer_count(
            $user_id
        )
    );
}


/*
 * =========================================================
 * GET PRIMARY CUSTOMER IMAGE
 * =========================================================
 */

function rud_crm_frontend_get_primary_image(
    $customer_id,
    $size = 'medium'
) {

    if (
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {

        return '';
    }


    global $wpdb;


    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';


    $attachment_id =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT attachment_id
                 FROM {$table}
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC,
                          sort_order ASC,
                          id ASC
                 LIMIT 1",
                absint(
                    $customer_id
                )
            )
        );


    if (
        ! $attachment_id
    ) {

        return '';
    }


    $url =
        wp_get_attachment_image_url(
            absint(
                $attachment_id
            ),
            $size
        );


    return
        $url
        ? $url
        : '';
}


/*
 * =========================================================
 * GET CUSTOMER CONTACT
 * =========================================================
 */

function rud_crm_frontend_contact(
    $customer_id,
    $contact_type
) {

    if (
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {

        return '';
    }


    global $wpdb;


    $table =
        $wpdb->prefix .
        'rudcrm_contact_methods';


    $value =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT contact_value
                 FROM {$table}
                 WHERE customer_id = %d
                 AND contact_type = %s
                 ORDER BY is_primary DESC,
                          id ASC
                 LIMIT 1",
                absint(
                    $customer_id
                ),
                sanitize_key(
                    $contact_type
                )
            )
        );


    return
        null !==
        $value
        ? $value
        : '';
}


/*
 * =========================================================
 * GET PRIVATE ADDRESS
 * =========================================================
 */

function rud_crm_frontend_address(
    $customer_id
) {

    if (
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {

        return null;
    }


    global $wpdb;


    return $wpdb->get_row(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_addresses
             WHERE customer_id = %d
             AND address_type = 'private'
             ORDER BY is_primary DESC,
                      id ASC
             LIMIT 1",
            absint(
                $customer_id
            )
        )
    );
}


/*
 * =========================================================
 * GET SOCIAL ACCOUNTS
 * =========================================================
 */

function rud_crm_frontend_social_accounts(
    $customer_id
) {

    if (
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {

        return array();
    }


    global $wpdb;


    return $wpdb->get_results(
        $wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}rudcrm_social_accounts
             WHERE customer_id = %d
             AND is_active = 1
             ORDER BY platform ASC",
            absint(
                $customer_id
            )
        )
    );
}


/*
 * =========================================================
 * CUSTOMER NAME
 * =========================================================
 */

function rud_crm_frontend_customer_name(
    $customer
) {

    /*
     * Company / Organization:
     * the company name is the primary CRM display name.
     */

    if (
        ! empty(
            $customer->customer_type
        )
        &&
        'company' ===
        $customer->customer_type
        &&
        ! empty(
            $customer->company_name
        )
    ) {

        return
            $customer->company_name;
    }


    $name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $customer->first_name ?? '',
                        $customer->middle_name ?? '',
                        $customer->last_name ?? ''
                    )
                )
            )
        );


    if (
        '' !==
        $name
    ) {

        return $name;
    }


    if (
        ! empty(
            $customer->company_name
        )
    ) {

        return $customer->company_name;
    }


    return 'Unnamed Customer';
}


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

function rud_crm_frontend_customer_url(
    $customer_id
) {

    $url =
        remove_query_arg(
            array(
                'rud_customer_id'
            )
        );


    return add_query_arg(
        'rud_customer_id',
        absint(
            $customer_id
        ),
        $url
    );
}


/*
 * =========================================================
 * BACK TO CUSTOMER LIST URL
 * =========================================================
 */

function rud_crm_frontend_customer_list_url() {

    return remove_query_arg(
        array(
            'rud_customer_id'
        )
    );
}


/*
 * =========================================================
 * GET VISIBLE CUSTOMERS
 * =========================================================
 */

function rud_crm_frontend_get_customers() {

    global $wpdb;


    $table =
        $wpdb->prefix .
        'rudcrm_customers';


    $search =
        isset(
            $_GET['rud_crm_search']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_GET['rud_crm_search']
            )
        )
        : '';


    $status =
        isset(
            $_GET['rud_crm_status']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_status']
            )
        )
        : '';


    $allowed_statuses =
        array(
            'customer',
            'lead',
            'partner',
            'inactive'
        );


    if (
        '' !==
        $status
        &&
        ! in_array(
            $status,
            $allowed_statuses,
            true
        )
    ) {

        $status = '';
    }


    /*
     * Start with security visibility condition.
     */

    $visibility =
        rud_crm_frontend_visibility_condition();


    $where =
        array(
            $visibility['sql']
        );


    $values =
        $visibility['values'];


    /*
     * Search.
     */

    if (
        '' !==
        $search
    ) {

        $like =
            '%' .
            $wpdb->esc_like(
                $search
            ) .
            '%';


        $where[] =
            "(
                customer_number LIKE %s
                OR first_name LIKE %s
                OR middle_name LIKE %s
                OR last_name LIKE %s
                OR company_name LIKE %s
            )";


        $values[] = $like;
        $values[] = $like;
        $values[] = $like;
        $values[] = $like;
        $values[] = $like;
    }


    /*
     * Status.
     */

    if (
        '' !==
        $status
    ) {

        $where[] =
            'status = %s';


        $values[] =
            $status;
    }


    $sql =
        "SELECT *
         FROM {$table}
         WHERE " .
        implode(
            ' AND ',
            $where
        ) .
        "
         ORDER BY
            last_name ASC,
            first_name ASC,
            company_name ASC";


    if (
        ! empty(
            $values
        )
    ) {

        $sql =
            $wpdb->prepare(
                $sql,
                $values
            );
    }


    return $wpdb->get_results(
        $sql
    );
}


/*
 * =========================================================
 * DASHBOARD COUNTS
 * =========================================================
 */

function rud_crm_frontend_dashboard_counts() {

    $customers =
        rud_crm_frontend_get_customers();


    $counts =
        array(

            'all' =>
                0,

            'customers' =>
                0,

            'leads' =>
                0,

            'partners' =>
                0,

            'inactive' =>
                0
        );


    foreach (
        $customers
        as
        $customer
    ) {

        $counts['all']++;


        switch (
            $customer->status
        ) {

            case 'customer':

                $counts['customers']++;

                break;


            case 'lead':

                $counts['leads']++;

                break;


            case 'partner':

                $counts['partners']++;

                break;


            case 'inactive':

                $counts['inactive']++;

                break;
        }
    }


    return $counts;
}


/*
 * =========================================================
 * DASHBOARD CARDS
 * =========================================================
 */

function rud_crm_frontend_dashboard() {

    $counts =
        rud_crm_frontend_dashboard_counts();


    ob_start();

    ?>

    <div class="rud-crm-dashboard-cards">

        <div class="rud-crm-stat-card">

            <span class="rud-crm-stat-number">
                <?php echo esc_html( $counts['all'] ); ?>
            </span>

            <span class="rud-crm-stat-label">
                All Contacts
            </span>

        </div>


        <div class="rud-crm-stat-card">

            <span class="rud-crm-stat-number">
                <?php echo esc_html( $counts['customers'] ); ?>
            </span>

            <span class="rud-crm-stat-label">
                Customers
            </span>

        </div>


        <div class="rud-crm-stat-card">

            <span class="rud-crm-stat-number">
                <?php echo esc_html( $counts['leads'] ); ?>
            </span>

            <span class="rud-crm-stat-label">
                Leads
            </span>

        </div>


        <div class="rud-crm-stat-card">

            <span class="rud-crm-stat-number">
                <?php echo esc_html( $counts['partners'] ); ?>
            </span>

            <span class="rud-crm-stat-label">
                Partners
            </span>

        </div>


        <div class="rud-crm-stat-card">

            <span class="rud-crm-stat-number">
                <?php echo esc_html( $counts['inactive'] ); ?>
            </span>

            <span class="rud-crm-stat-label">
                Inactive
            </span>

        </div>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CUSTOMER SEARCH
 * =========================================================
 */

function rud_crm_frontend_search_form() {

    $search =
        isset(
            $_GET['rud_crm_search']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_GET['rud_crm_search']
            )
        )
        : '';


    $status =
        isset(
            $_GET['rud_crm_status']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_status']
            )
        )
        : '';


    ob_start();

    ?>

    <form
        method="get"
        class="rud-crm-search-form"
    >

        <div class="rud-crm-search-field">

            <input
                type="search"
                name="rud_crm_search"
                value="<?php echo esc_attr( $search ); ?>"
                placeholder="Search customer, company or customer ID..."
            >

        </div>


        <div class="rud-crm-status-field">

            <select
                name="rud_crm_status"
            >

                <option value="">
                    All Statuses
                </option>

                <option
                    value="customer"
                    <?php selected( $status, 'customer' ); ?>
                >
                    Customer
                </option>

                <option
                    value="lead"
                    <?php selected( $status, 'lead' ); ?>
                >
                    Lead
                </option>

                <option
                    value="partner"
                    <?php selected( $status, 'partner' ); ?>
                >
                    Partner
                </option>

                <option
                    value="inactive"
                    <?php selected( $status, 'inactive' ); ?>
                >
                    Inactive
                </option>

            </select>

        </div>


        <div>

            <button
                type="submit"
                class="rud-crm-button rud-crm-button-primary"
            >
                Search
            </button>

        </div>


        <?php

        if (
            '' !==
            $search
            ||
            '' !==
            $status
        ) :

        ?>

            <div>

                <a
                    href="<?php
                    echo esc_url(
                        remove_query_arg(
                            array(
                                'rud_crm_search',
                                'rud_crm_status'
                            )
                        )
                    );
                    ?>"
                    class="rud-crm-button"
                >
                    Clear
                </a>

            </div>

        <?php endif; ?>

    </form>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CUSTOMER LIST
 * =========================================================
 */

function rud_crm_frontend_customer_list_html() {

    $customers =
        rud_crm_frontend_get_customers();

    $search =
        isset( $_GET['rud_crm_search'] )
        ? sanitize_text_field( wp_unslash( $_GET['rud_crm_search'] ) )
        : '';

    $status =
        isset( $_GET['rud_crm_status'] )
        ? sanitize_key( wp_unslash( $_GET['rud_crm_status'] ) )
        : '';

    $view_all =
        isset( $_GET['rud_crm_view'] )
        &&
        'all' === sanitize_key( wp_unslash( $_GET['rud_crm_view'] ) );

    $is_filtered =
        '' !== $search
        ||
        '' !== $status;

    $total_results =
        count( $customers );

    /*
     * Default CRM start screen:
     * show only the 5 most recently created/added customers.
     *
     * Search/filter and "View All Customers" show the complete
     * matching customer list.
     */
    if (
        ! $is_filtered
        &&
        ! $view_all
        &&
        ! empty( $customers )
    ) {

        usort(
            $customers,
            function( $a, $b ) {
                return absint( $b->id ?? 0 ) <=> absint( $a->id ?? 0 );
            }
        );

        $customers =
            array_slice(
                $customers,
                0,
                5
            );
    }

    ob_start();

    ?>

    <div class="rud-crm-customer-section">

        <?php
        echo rud_crm_frontend_search_form();
        ?>

        <div class="rud-crm-compact-heading">

            <strong>
                <?php
                echo esc_html(
                    (
                        ! $is_filtered
                        &&
                        ! $view_all
                    )
                    ? 'Latest Customers'
                    : 'Customers'
                );
                ?>
            </strong>

            <span class="rud-crm-list-info">
                <?php echo esc_html( $total_results ); ?> result(s)
            </span>

        </div>

        <?php if ( empty( $customers ) ) : ?>

            <div class="rud-crm-empty">
                No customers were found.
            </div>

        <?php else : ?>

            <div class="rud-crm-compact-list">

                <div class="rud-crm-compact-row rud-crm-compact-header">
                    <div>Name / Company</div>
                    <div>Customer / Org. No.</div>
                    <div>Phone</div>
                    <div>Status</div>
                    <div></div>
                </div>

                <?php foreach ( $customers as $customer ) : ?>

                    <?php

                    $name =
                        rud_crm_frontend_customer_name(
                            $customer
                        );

                    $is_company =
                        ! empty( $customer->customer_type )
                        &&
                        'company' === $customer->customer_type;

                    $reference =
                        (
                            $is_company
                            &&
                            ! empty( $customer->organization_number )
                        )
                        ? $customer->organization_number
                        : $customer->customer_number;

                    if ( $is_company ) {

                        $phone =
                            rud_crm_frontend_contact(
                                $customer->id,
                                'office_phone'
                            );

                        if ( '' === $phone ) {
                            $phone =
                                rud_crm_frontend_contact(
                                    $customer->id,
                                    'mobile_phone'
                                );
                        }

                    } else {

                        $phone =
                            rud_crm_frontend_contact(
                                $customer->id,
                                'mobile_phone'
                            );

                        if ( '' === $phone ) {
                            $phone =
                                rud_crm_frontend_contact(
                                    $customer->id,
                                    'home_phone'
                                );
                        }
                    }

                    $profile_url =
                        rud_crm_frontend_customer_url(
                            $customer->id
                        );

                    $shared_demo =
                        rud_crm_frontend_is_shared_demo_customer(
                            $customer->id
                        );

                    $can_edit =
                        rud_crm_frontend_can_edit_customer(
                            $customer->id
                        );

                    ?>

                    <div class="rud-crm-compact-row">

                        <div class="rud-crm-compact-name">

                            <strong>
                                <?php echo esc_html( $name ); ?>
                            </strong>

                            <?php
                            if (
                                $shared_demo
                                &&
                                ! $can_edit
                            ) :
                            ?>
                                <span class="rud-crm-compact-readonly">
                                    DEMO · READ ONLY
                                </span>
                            <?php endif; ?>

                        </div>

                        <div class="rud-crm-compact-reference">

                            <?php if ( $is_company ) : ?>
                                <span class="rud-crm-mobile-label">Org. No.</span>
                            <?php else : ?>
                                <span class="rud-crm-mobile-label">Customer No.</span>
                            <?php endif; ?>

                            <?php
                            echo esc_html(
                                $reference
                                ? $reference
                                : '—'
                            );
                            ?>

                        </div>

                        <div class="rud-crm-compact-phone">

                            <span class="rud-crm-mobile-label">
                                Phone
                            </span>

                            <?php
                            echo esc_html(
                                $phone
                                ? $phone
                                : '—'
                            );
                            ?>

                        </div>

                        <div class="rud-crm-compact-status">

                            <span
                                class="rud-crm-status rud-crm-status-<?php echo esc_attr( $customer->status ); ?>"
                            >
                                <?php echo esc_html( ucfirst( $customer->status ) ); ?>
                            </span>

                        </div>

                        <div class="rud-crm-compact-action">

                            <a
                                href="<?php echo esc_url( $profile_url ); ?>"
                                class="rud-crm-button rud-crm-button-primary"
                            >
                                Open Profile
                            </a>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

            <?php
            if (
                ! $is_filtered
                &&
                ! $view_all
                &&
                $total_results > 5
            ) :
            ?>

                <div class="rud-crm-view-all-wrap">

                    <a
                        class="rud-crm-button"
                        href="<?php
                        echo esc_url(
                            add_query_arg(
                                'rud_crm_view',
                                'all',
                                remove_query_arg(
                                    array(
                                        'rud_customer_id',
                                        'rud_crm_search',
                                        'rud_crm_status'
                                    )
                                )
                            )
                        );
                        ?>"
                    >
                        View All Customers
                    </a>

                </div>

            <?php elseif ( $view_all && ! $is_filtered ) : ?>

                <div class="rud-crm-view-all-wrap">

                    <a
                        class="rud-crm-button"
                        href="<?php
                        echo esc_url(
                            remove_query_arg(
                                'rud_crm_view'
                            )
                        );
                        ?>"
                    >
                        Show Latest Customers
                    </a>

                </div>

            <?php endif; ?>

        <?php endif; ?>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * COMPANY / ORGANIZATION OPEN PROFILE
 * =========================================================
 */

function rud_crm_frontend_company_profile_html(
    $customer,
    $details,
    $address,
    $company_details,
    $customer_id,
    $shared_demo,
    $can_edit
) {

    $company_name =
        trim(
            (string)
            (
                $customer->company_name
                ?? ''
            )
        );

    if ( '' === $company_name ) {
        $company_name = 'Unnamed Company';
    }

    $office_phone =
        rud_crm_frontend_contact(
            $customer_id,
            'office_phone'
        );

    $mobile_phone =
        rud_crm_frontend_contact(
            $customer_id,
            'mobile_phone'
        );

    $work_email =
        rud_crm_frontend_contact(
            $customer_id,
            'work_email'
        );

    $whatsapp =
        rud_crm_frontend_contact(
            $customer_id,
            'whatsapp'
        );

    $website_url =
        $details->website_url
        ?? '';

    $organization_form = '';
    $industry = '';

    if ( $company_details ) {

        $organization_form =
            trim(
                (
                    $company_details->organization_form_code
                    ?? ''
                )
                .
                (
                    ! empty( $company_details->organization_form_name )
                    ? ' — ' . $company_details->organization_form_name
                    : ''
                )
            );

        $industry =
            trim(
                (
                    $company_details->industry_code
                    ?? ''
                )
                .
                (
                    ! empty( $company_details->industry_name )
                    ? ' — ' . $company_details->industry_name
                    : ''
                )
            );
    }

    $contacts =
        function_exists(
            'rud_crm_get_company_contacts'
        )
        ? rud_crm_get_company_contacts(
            $customer_id
        )
        : array();

    $primary_image =
        rud_crm_frontend_get_primary_image(
            $customer_id,
            'large'
        );

    ob_start();
    ?>

    <div class="rud-crm-profile rud-crm-company-open-profile">

        <div class="rud-crm-profile-toolbar">

            <a
                href="<?php echo esc_url( rud_crm_frontend_customer_list_url() ); ?>"
                class="rud-crm-button"
            >
                ← Back to Customers
            </a>

        </div>

        <?php if ( $shared_demo && ! $can_edit ) : ?>

            <div class="rud-crm-readonly-notice">

                <strong>Shared Demo Customer — Read Only</strong>

                <span>
                    This customer is part of the shared RUD CRM Demo database.
                    You can view the information, but you cannot edit or delete it.
                </span>

            </div>

        <?php endif; ?>

        <div class="rud-crm-company-open-grid">

            <section class="rud-crm-panel rud-crm-company-open-company">

                <h2>Company Name</h2>

                <div class="rud-crm-company-open-head">

                    <div class="rud-crm-company-open-logo">

                        <?php if ( $primary_image ) : ?>

                            <img
                                src="<?php echo esc_url( $primary_image ); ?>"
                                alt="<?php echo esc_attr( $company_name ); ?>"
                            >

                        <?php else : ?>

                            <div class="rud-crm-company-open-logo-placeholder">
                                <?php echo esc_html( strtoupper( substr( $company_name, 0, 1 ) ) ); ?>
                            </div>

                        <?php endif; ?>

                    </div>

                    <div class="rud-crm-company-open-title">

                        <h1><?php echo esc_html( $company_name ); ?></h1>

                        <div class="rud-crm-profile-number">
                            <?php echo esc_html( $customer->customer_number ?? '' ); ?>
                        </div>

                        <?php if ( ! empty( $customer->status ) ) : ?>
                            <span class="rud-crm-status rud-crm-status-<?php echo esc_attr( $customer->status ); ?>">
                                <?php echo esc_html( ucfirst( $customer->status ) ); ?>
                            </span>
                        <?php endif; ?>

                    </div>

                </div>

                <?php
                rud_crm_frontend_profile_value(
                    'Organization Number',
                    $customer->organization_number ?? ''
                );

                rud_crm_frontend_profile_value(
                    'Company Type',
                    $organization_form
                );

                rud_crm_frontend_profile_value(
                    'Industry',
                    $industry
                );
                ?>

                <?php if ( $details && ! empty( $details->notes ) ) : ?>

                    <button
                        type="button"
                        class="rud-crm-notes-popup-button"
                        data-rud-notes-open="company-notes-<?php echo esc_attr( $customer_id ); ?>"
                    >
                        SEE NOTES
                    </button>

                    <div
                        class="rud-crm-notes-modal"
                        data-rud-notes-modal="company-notes-<?php echo esc_attr( $customer_id ); ?>"
                        aria-hidden="true"
                    >

                        <div class="rud-crm-notes-modal-backdrop" data-rud-notes-close></div>

                        <div
                            class="rud-crm-notes-modal-dialog"
                            role="dialog"
                            aria-modal="true"
                            aria-label="Internal CRM Company Notes"
                        >

                            <div class="rud-crm-notes-modal-header">

                                <h3>Internal CRM Company Notes</h3>

                                <button
                                    type="button"
                                    class="rud-crm-notes-modal-close"
                                    data-rud-notes-close
                                    aria-label="Close notes"
                                >
                                    ×
                                </button>

                            </div>

                            <div class="rud-crm-notes-modal-content">
                                <?php echo nl2br( esc_html( $details->notes ) ); ?>
                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            </section>

            <section class="rud-crm-panel">

                <h2>Company Address</h2>

                <?php if ( $address ) : ?>

                    <?php
                    rud_crm_frontend_profile_value( 'Address', $address->address_line_1 ?? '' );
                    rud_crm_frontend_profile_value( 'Address Line 2', $address->address_line_2 ?? '' );
                    rud_crm_frontend_profile_value( 'Postal Code', $address->postal_code ?? '' );
                    rud_crm_frontend_profile_value( 'City', $address->city ?? '' );
                    rud_crm_frontend_profile_value( 'State / Region', $address->state_region ?? '' );
                    rud_crm_frontend_profile_value( 'Country', $address->country_code ?? '' );
                    ?>

                <?php else : ?>

                    <p class="rud-crm-muted">No company address saved.</p>

                <?php endif; ?>

            </section>

            <section class="rud-crm-panel">

                <h2>Company Information</h2>

                <?php
                rud_crm_frontend_profile_value( 'Office Phone', $office_phone );
                rud_crm_frontend_profile_value( 'Mobile Phone', $mobile_phone );
                rud_crm_frontend_profile_value( 'Email', $work_email );
                rud_crm_frontend_profile_value( 'WhatsApp', $whatsapp );
                ?>

                <?php if ( ! empty( $website_url ) ) : ?>

                    <?php
                    $rud_crm_company_website =
                        trim(
                            (string)
                            $website_url
                        );

                    if (
                        ! preg_match(
                            '#^https?://#i',
                            $rud_crm_company_website
                        )
                    ) {

                        $rud_crm_company_website =
                            'https://' .
                            ltrim(
                                $rud_crm_company_website,
                                '/'
                            );
                    }

                    $rud_crm_company_website_label =
                        preg_replace(
                            '#^https?://#i',
                            '',
                            $rud_crm_company_website
                        );

                    $rud_crm_company_website_label =
                        rtrim(
                            $rud_crm_company_website_label,
                            '/'
                        );
                    ?>

                    <div class="rud-crm-profile-row rud-crm-company-website-row">

                        <div class="rud-crm-profile-label">
                            Website
                        </div>

                        <div class="rud-crm-profile-value">

                            <a
                                href="<?php echo esc_url( $rud_crm_company_website ); ?>"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="rud-crm-company-website-link"
                            >
                                <?php echo esc_html( $rud_crm_company_website_label ); ?> ↗
                            </a>

                        </div>

                    </div>

                <?php endif; ?>

            </section>

            <section class="rud-crm-panel">

                <h2>Contact Persons</h2>

                <?php if ( ! empty( $contacts ) ) : ?>

                    <div class="rud-crm-company-open-contacts">

                        <?php foreach ( $contacts as $contact ) : ?>

                            <?php
                            $contact_name =
                                trim(
                                    implode(
                                        ' ',
                                        array_filter(
                                            array(
                                                $contact->first_name ?? '',
                                                $contact->middle_name ?? '',
                                                $contact->last_name ?? ''
                                            )
                                        )
                                    )
                                );

                            $job_title =
                                function_exists( 'rud_crm_company_contact_job_title_label' )
                                ? rud_crm_company_contact_job_title_label( $contact )
                                : ( $contact->job_title ?? '' );

                            $department =
                                function_exists( 'rud_crm_company_contact_department_label' )
                                ? rud_crm_company_contact_department_label( $contact )
                                : ( $contact->department ?? '' );
                            ?>

                            <div class="rud-crm-company-open-contact">

                                <div class="rud-crm-company-open-contact-name">

                                    <strong><?php echo esc_html( $contact_name ); ?></strong>

                                    <?php if ( ! empty( $contact->is_primary ) ) : ?>
                                        <span class="rud-crm-company-open-primary">Primary</span>
                                    <?php endif; ?>

                                </div>

                                <?php if ( $job_title ) : ?>
                                    <div class="rud-crm-company-open-contact-title">
                                        <?php echo esc_html( $job_title ); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ( $department ) : ?>
                                    <div class="rud-crm-company-open-contact-department">
                                        <?php echo esc_html( $department ); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ( ! empty( $contact->work_email ) ) : ?>
                                    <div class="rud-crm-company-open-contact-detail">
                                        <span>Email</span>
                                        <a href="mailto:<?php echo esc_attr( $contact->work_email ); ?>">
                                            <?php echo esc_html( $contact->work_email ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if ( ! empty( $contact->mobile_phone ) ) : ?>
                                    <div class="rud-crm-company-open-contact-detail">
                                        <span>Mobile</span>
                                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $contact->mobile_phone ) ); ?>">
                                            <?php echo esc_html( $contact->mobile_phone ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if ( ! empty( $contact->direct_office_phone ) ) : ?>
                                    <div class="rud-crm-company-open-contact-detail">
                                        <span>Office</span>
                                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $contact->direct_office_phone ) ); ?>">
                                            <?php echo esc_html( $contact->direct_office_phone ); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if ( ! empty( $contact->personal_notes ) ) : ?>

                                    <button
                                        type="button"
                                        class="rud-crm-notes-popup-button rud-crm-contact-notes-button"
                                        data-rud-notes-open="contact-notes-<?php echo esc_attr( $contact->id ); ?>"
                                    >
                                        SEE NOTES
                                    </button>

                                    <div
                                        class="rud-crm-notes-modal"
                                        data-rud-notes-modal="contact-notes-<?php echo esc_attr( $contact->id ); ?>"
                                        aria-hidden="true"
                                    >

                                        <div class="rud-crm-notes-modal-backdrop" data-rud-notes-close></div>

                                        <div
                                            class="rud-crm-notes-modal-dialog"
                                            role="dialog"
                                            aria-modal="true"
                                            aria-label="Personal Contact Notes"
                                        >

                                            <div class="rud-crm-notes-modal-header">

                                                <h3>
                                                    Personal Contact Notes
                                                    <?php if ( $contact_name ) : ?>
                                                        — <?php echo esc_html( $contact_name ); ?>
                                                    <?php endif; ?>
                                                </h3>

                                                <button
                                                    type="button"
                                                    class="rud-crm-notes-modal-close"
                                                    data-rud-notes-close
                                                    aria-label="Close notes"
                                                >
                                                    ×
                                                </button>

                                            </div>

                                            <div class="rud-crm-notes-modal-content">
                                                <?php echo nl2br( esc_html( $contact->personal_notes ) ); ?>
                                            </div>

                                        </div>

                                    </div>

                                <?php endif; ?>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php else : ?>

                    <p class="rud-crm-muted">No contact persons have been added.</p>

                <?php endif; ?>

            </section>

        </div>

        <?php

        if (
            function_exists(
                'rud_crm_frontend_customer_email_panel'
            )
        ) {

            echo
                rud_crm_frontend_customer_email_panel(
                    $customer_id
                );
        }

        if (
            function_exists(
                'rud_crm_frontend_customer_sms_panel'
            )
        ) {

            echo
                rud_crm_frontend_customer_sms_panel(
                    $customer_id
                );
        }

        if (
            function_exists(
                'rud_crm_frontend_todo_list'
            )
        ) {

            echo
                rud_crm_frontend_todo_list(
                    $customer_id
                );
        }

        ?>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CUSTOMER PROFILE
 * =========================================================
 */

function rud_crm_frontend_customer_profile_html(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    /*
     * Critical security check.
     */

    if (
        ! rud_crm_frontend_can_view_customer(
            $customer_id
        )
    ) {

        return
            '<div class="rud-crm-access-box">' .
                '<h2>Access Restricted</h2>' .
                '<p>You do not have permission to view this customer.</p>' .
                '<p><a class="rud-crm-button" href="' .
                esc_url(
                    rud_crm_frontend_customer_list_url()
                ) .
                '">← Back to Customers</a></p>' .
            '</div>';
    }


    $customer =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    if (
        ! $customer
    ) {

        return
            '<div class="rud-crm-empty">' .
            'Customer could not be found.' .
            '</div>';
    }


    $shared_demo =
        rud_crm_frontend_is_shared_demo_customer(
            $customer_id
        );


    $can_edit =
        rud_crm_frontend_can_edit_customer(
            $customer_id
        );


    $company_details =
        function_exists(
            'rud_crm_brreg_get_company_details'
        )
        ? rud_crm_brreg_get_company_details(
            $customer_id
        )
        : null;


    $details =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_details
                 WHERE customer_id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    $address =
        rud_crm_frontend_address(
            $customer_id
        );


    $social_accounts =
        rud_crm_frontend_social_accounts(
            $customer_id
        );


    $images =
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM {$wpdb->prefix}rudcrm_customer_images
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC,
                          sort_order ASC,
                          id ASC",
                $customer_id
            )
        );


    $mobile =
        rud_crm_frontend_contact(
            $customer_id,
            'mobile_phone'
        );


    $home_phone =
        rud_crm_frontend_contact(
            $customer_id,
            'home_phone'
        );


    $office_phone =
        rud_crm_frontend_contact(
            $customer_id,
            'office_phone'
        );


    $whatsapp =
        rud_crm_frontend_contact(
            $customer_id,
            'whatsapp'
        );


    $private_email =
        rud_crm_frontend_contact(
            $customer_id,
            'private_email'
        );


    $work_email =
        rud_crm_frontend_contact(
            $customer_id,
            'work_email'
        );


    $name =
        rud_crm_frontend_customer_name(
            $customer
        );


    $primary_image =
        rud_crm_frontend_get_primary_image(
            $customer_id,
            'large'
        );


    /*
     * Company / Organization has its own Open Profile layout.
     * Private Person continues to use the existing profile below.
     */

    if (
        'company' ===
        (
            $customer->customer_type
            ?? ''
        )
    ) {

        return rud_crm_frontend_company_profile_html(
            $customer,
            $details,
            $address,
            $company_details,
            $customer_id,
            $shared_demo,
            $can_edit
        );
    }


    ob_start();

    ?>

    <div class="rud-crm-profile">


        <div class="rud-crm-profile-toolbar">

            <a
                href="<?php
                echo esc_url(
                    rud_crm_frontend_customer_list_url()
                );
                ?>"
                class="rud-crm-button"
            >
                ← Back to Customers
            </a>

        </div>


        <?php

        if (
            function_exists(
                'rud_crm_frontend_customer_image_message_html'
            )
        ) {

            echo rud_crm_frontend_customer_image_message_html();
        }


        if (
            $shared_demo
            &&
            ! $can_edit
        ) :

        ?>

            <div class="rud-crm-readonly-notice">

                <strong>Shared Demo Customer — Read Only</strong>

                <span>
                    This customer is part of the shared RUD CRM Demo database.
                    You can view the information, but you cannot edit or delete it.
                </span>

            </div>

        <?php endif; ?>


        <section class="rud-crm-profile-hero">


            <?php

            if (
                function_exists(
                    'rud_crm_frontend_customer_header_media_html'
                )
            ) {

                echo rud_crm_frontend_customer_header_media_html(
                    $customer_id,
                    $name
                );

            } else {

                ?>

                <div class="rud-crm-profile-photo">

                    <?php if ( $primary_image ) : ?>

                        <img
                            src="<?php echo esc_url( $primary_image ); ?>"
                            alt="<?php echo esc_attr( $name ); ?>"
                        >

                    <?php else : ?>

                        <div class="rud-crm-profile-placeholder">
                            <?php echo esc_html( strtoupper( substr( $name, 0, 1 ) ) ); ?>
                        </div>

                    <?php endif; ?>

                </div>

                <?php
            }

            ?>


            <div class="rud-crm-profile-heading">


                <div>

                    <span
                        class="rud-crm-status rud-crm-status-<?php
                        echo esc_attr(
                            $customer->status
                        );
                        ?>"
                    >

                        <?php
                        echo esc_html(
                            ucfirst(
                                $customer->status
                            )
                        );
                        ?>

                    </span>

                </div>


                <h1>
                    <?php echo esc_html( $name ); ?>
                </h1>


                <div class="rud-crm-profile-number">

                    <?php
                    echo esc_html(
                        $customer->customer_number
                    );
                    ?>

                </div>


                <?php

                if (
                    ! empty(
                        $customer->company_name
                    )
                ) :

                ?>

                    <div class="rud-crm-profile-company">

                        <?php
                        echo esc_html(
                            $customer->company_name
                        );
                        ?>

                    </div>

                <?php endif; ?>


            </div>


        </section>


        <div class="rud-crm-profile-columns">


            <section class="rud-crm-panel">

                <h2>
                    Contact Information
                </h2>


                <?php

                rud_crm_frontend_profile_value(
                    'Mobile Phone',
                    $mobile
                );


                rud_crm_frontend_profile_value(
                    'Home Phone',
                    $home_phone
                );


                rud_crm_frontend_profile_value(
                    'Office Phone',
                    $office_phone
                );


                rud_crm_frontend_profile_value(
                    'WhatsApp',
                    $whatsapp
                );


                rud_crm_frontend_profile_value(
                    'Private Email',
                    $private_email
                );


                rud_crm_frontend_profile_value(
                    'Work Email',
                    $work_email
                );

                ?>

            </section>


            <section class="rud-crm-panel">

                <h2>
                    Company
                </h2>


                <?php

                rud_crm_frontend_profile_value(
                    'Company',
                    $customer->company_name
                );


                rud_crm_frontend_profile_value(
                    'Organization Number',
                    $customer->organization_number
                );


                if (
                    $company_details
                ) {

                    $organization_form =
                        trim(
                            (
                                $company_details->organization_form_code
                                ?? ''
                            )
                            .
                            (
                                ! empty(
                                    $company_details->organization_form_name
                                )
                                ? ' — ' .
                                  $company_details->organization_form_name
                                : ''
                            )
                        );


                    $industry =
                        trim(
                            (
                                $company_details->industry_code
                                ?? ''
                            )
                            .
                            (
                                ! empty(
                                    $company_details->industry_name
                                )
                                ? ' — ' .
                                  $company_details->industry_name
                                : ''
                            )
                        );


                    rud_crm_frontend_profile_value(
                        'Company Type',
                        $organization_form
                    );


                    rud_crm_frontend_profile_value(
                        'Industry',
                        $industry
                    );
                }


                rud_crm_frontend_profile_value(
                    'Job Title',
                    $customer->job_title
                );


                rud_crm_frontend_profile_value(
                    'Department',
                    $customer->department
                );

                ?>

            </section>


        </div>


        <div class="rud-crm-profile-columns">


            <section class="rud-crm-panel">

                <h2>
                    Personal Information
                </h2>


                <?php

                rud_crm_frontend_profile_value(
                    'Preferred Name',
                    $customer->preferred_name
                );


                if (
                    $details
                ) {

                    rud_crm_frontend_profile_value(
                        'Birth Date',
                        $details->birth_date ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Gender',
                        $details->gender ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Preferred Language',
                        $details->preferred_language ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Nationality',
                        $details->nationality ?? ''
                    );
                }

                ?>

            </section>


            <section class="rud-crm-panel">

                <h2>
                    Private Address
                </h2>


                <?php

                if (
                    $address
                ) {

                    rud_crm_frontend_profile_value(
                        'Address',
                        $address->address_line_1 ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Address Line 2',
                        $address->address_line_2 ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Postal Code',
                        $address->postal_code ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'City',
                        $address->city ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'State / Region',
                        $address->state_region ?? ''
                    );


                    rud_crm_frontend_profile_value(
                        'Country',
                        $address->country_code ?? ''
                    );

                } else {

                    echo
                        '<p class="rud-crm-muted">' .
                        'No private address saved.' .
                        '</p>';
                }

                ?>

            </section>


        </div>


        <?php

        if (
            ! empty(
                $social_accounts
            )
        ) :

        ?>

            <section class="rud-crm-panel rud-crm-full-panel">

                <h2>
                    Social Media & Messaging
                </h2>


                <div class="rud-crm-social-grid">


                    <?php

                    foreach (
                        $social_accounts
                        as
                        $social
                    ) :


                        $label =
                            ucfirst(
                                $social->platform
                            );


                        if (
                            function_exists(
                                'rud_crm_social_platforms'
                            )
                        ) {

                            $platforms =
                                rud_crm_social_platforms();


                            if (
                                isset(
                                    $platforms[
                                        $social->platform
                                    ]
                                )
                            ) {

                                $label =
                                    $platforms[
                                        $social->platform
                                    ];
                            }
                        }

                    ?>

                        <div class="rud-crm-social-item">


                            <strong>

                                <?php
                                echo esc_html(
                                    $label
                                );
                                ?>

                            </strong>


                            <?php

                            if (
                                ! empty(
                                    $social->account_name
                                )
                            ) :

                            ?>

                                <span>

                                    <?php
                                    echo esc_html(
                                        $social->account_name
                                    );
                                    ?>

                                </span>

                            <?php endif; ?>


                            <?php

                            if (
                                ! empty(
                                    $social->profile_url
                                )
                            ) :

                            ?>

                                <a
                                    href="<?php
                                    echo esc_url(
                                        $social->profile_url
                                    );
                                    ?>"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Open Profile
                                </a>

                            <?php endif; ?>


                        </div>


                    <?php endforeach; ?>


                </div>


            </section>


        <?php endif; ?>


        <?php

        if (
            function_exists(
                'rud_crm_frontend_customer_gallery_html'
            )
        ) {

            echo rud_crm_frontend_customer_gallery_html(
                $customer_id
            );
        }


        if (
            $details
            &&
            ! empty(
                $details->notes
            )
        ) :

        ?>

            <section class="rud-crm-panel rud-crm-full-panel">

                <h2>
                    Internal CRM Notes
                </h2>


                <div class="rud-crm-notes">

                    <?php

                    echo nl2br(
                        esc_html(
                            $details->notes
                        )
                    );

                    ?>

                </div>

            </section>


        <?php endif; ?>


        <?php

        if (
            function_exists(
                'rud_crm_frontend_customer_email_panel'
            )
        ) {

            echo
                rud_crm_frontend_customer_email_panel(
                    $customer_id
                );
        }

        if (
            function_exists(
                'rud_crm_frontend_customer_sms_panel'
            )
        ) {

            echo
                rud_crm_frontend_customer_sms_panel(
                    $customer_id
                );
        }

        if (
            function_exists(
                'rud_crm_frontend_todo_list'
            )
        ) {

            echo
                rud_crm_frontend_todo_list(
                    $customer_id
                );
        }

        ?>


    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * PROFILE VALUE
 * =========================================================
 */

function rud_crm_frontend_profile_value(
    $label,
    $value
) {

    if (
        '' ===
        trim(
            (string)
            $value
        )
    ) {

        return;
    }

    ?>

    <div class="rud-crm-profile-row">


        <span class="rud-crm-profile-label">

            <?php
            echo esc_html(
                $label
            );
            ?>

        </span>


        <span class="rud-crm-profile-value">

            <?php
            echo esc_html(
                $value
            );
            ?>

        </span>


    </div>

    <?php
}


/*
 * =========================================================
 * FRONT-END SHORTCODE
 * =========================================================
 */

function rud_crm_frontend_shortcode() {

    if (
        ! rud_crm_frontend_user_can_access()
    ) {

        return
            rud_crm_frontend_access_message();
    }


    $customer_id =
        isset(
            $_GET['rud_customer_id']
        )
        ? absint(
            $_GET['rud_customer_id']
        )
        : 0;


    ob_start();

    ?>

    <div class="rud-crm-frontend">


        <?php

        /*
         * Demo account information.
         */

        if (
            ! $customer_id
            &&
            rud_crm_frontend_is_demo_client()
        ) {

            $owned_count =
                rud_crm_frontend_owned_customer_count();


            $limit =
                rud_crm_frontend_demo_customer_limit();


            $remaining =
                rud_crm_frontend_remaining_customer_slots();

            ?>

            <div class="rud-crm-demo-access-summary">

                <strong>Demo CRM Access</strong>

                <span>
                    Shared DEMO customers are read-only.
                    Your own customers can be managed normally.
                </span>

                <span>
                    Your Customers:
                    <strong><?php echo esc_html( $owned_count ); ?> / <?php echo esc_html( $limit ); ?></strong>
                    &nbsp;—&nbsp;
                    Remaining:
                    <strong><?php echo esc_html( $remaining ); ?></strong>
                </span>

            </div>

            <?php
        }


        if (
            $customer_id >
            0
        ) {

            echo rud_crm_frontend_customer_profile_html(
                $customer_id
            );

        } else {

            echo rud_crm_frontend_dashboard();

            echo rud_crm_frontend_customer_list_html();
        }

        ?>


    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_frontend',
    'rud_crm_frontend_shortcode'
);


add_shortcode(
    'rud_crm_customer_list',
    'rud_crm_frontend_shortcode'
);


/*
 * =========================================================
 * NOINDEX CRM FRONT-END
 * =========================================================
 */

function rud_crm_frontend_robots(
    $robots
) {

    global $post;


    if (
        ! $post
        ||
        ! is_singular()
    ) {

        return $robots;
    }


    if (
        has_shortcode(
            $post->post_content,
            'rud_crm_frontend'
        )
        ||
        has_shortcode(
            $post->post_content,
            'rud_crm_customer_list'
        )
    ) {

        $robots['noindex'] =
            true;


        $robots['nofollow'] =
            true;
    }


    return $robots;
}


add_filter(
    'wp_robots',
    'rud_crm_frontend_robots'
);


/*
 * =========================================================
 * FRONT-END CSS
 * =========================================================
 */

function rud_crm_frontend_styles() {

    if (
        is_admin()
    ) {

        return;
    }


    $css = '

    .rud-crm-frontend {
        width:100%;
        box-sizing:border-box;
        font-family:inherit;
    }

    .rud-crm-frontend *,
    .rud-crm-frontend *::before,
    .rud-crm-frontend *::after {
        box-sizing:border-box;
    }

    .rud-crm-muted {
        opacity:.65;
    }

    .rud-crm-demo-access-summary {
        display:flex;
        flex-direction:column;
        gap:6px;
        margin-bottom:22px;
        padding:16px 18px;
        border:1px solid #d0d5dd;
        border-radius:10px;
        background:#fff;
    }

    .rud-crm-readonly-badge {
        display:inline-block;
        margin-top:8px;
        padding:4px 8px;
        border:1px solid #d0d5dd;
        border-radius:999px;
        font-size:10px;
        font-weight:700;
        letter-spacing:.04em;
    }

    .rud-crm-readonly-notice {
        display:flex;
        flex-direction:column;
        gap:5px;
        margin-bottom:18px;
        padding:16px 18px;
        border:1px solid #d0d5dd;
        border-radius:10px;
        background:#fff;
    }


    .rud-crm-button {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:40px;
        padding:9px 16px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        text-decoration:none !important;
        background:#fff;
        color:#1d2939;
        cursor:pointer;
        font-weight:600;
        line-height:1.2;
        transition:.15s ease;
    }

    .rud-crm-button:hover {
        transform:translateY(-1px);
        text-decoration:none;
    }

    .rud-crm-button-primary {
        background:#1d2939;
        border-color:#1d2939;
        color:#fff !important;
    }


    .rud-crm-access-box {
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
        padding:30px;
        max-width:700px;
    }


    .rud-crm-dashboard-cards {
        display:grid;
        grid-template-columns:repeat(5,minmax(0,1fr));
        gap:16px;
        margin-bottom:28px;
    }

    .rud-crm-stat-card {
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
        padding:20px;
        box-shadow:0 1px 2px rgba(16,24,40,.04);
    }

    .rud-crm-stat-number {
        display:block;
        font-size:30px;
        font-weight:700;
        line-height:1.1;
        margin-bottom:5px;
    }

    .rud-crm-stat-label {
        display:block;
        font-size:13px;
        opacity:.7;
    }


    .rud-crm-search-form {
        display:flex;
        align-items:center;
        gap:10px;
        flex-wrap:wrap;
        margin-bottom:18px;
    }

    .rud-crm-search-field {
        flex:1 1 350px;
    }

    .rud-crm-search-field input,
    .rud-crm-status-field select {
        width:100%;
        min-height:44px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        padding:8px 12px;
        font:inherit;
    }

    .rud-crm-status-field {
        flex:0 1 190px;
    }

    .rud-crm-list-info {
        margin-bottom:15px;
        opacity:.65;
        font-size:13px;
    }


    .rud-crm-customer-grid {
        display:grid;
        grid-template-columns:repeat(3,minmax(0,1fr));
        gap:18px;
    }

    .rud-crm-customer-card {
        display:grid;
        gap:18px;
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
        padding:18px;
        min-width:0;
        box-shadow:0 1px 2px rgba(16,24,40,.04);
        align-items:center;
    }

    /*
     * Private Person card:
     * 100 x 100 round profile image.
     */

    .rud-crm-customer-card-person {
        grid-template-columns:100px 1fr;
    }

    .rud-crm-customer-card-person .rud-crm-card-image {
        width:100px;
        height:100px;
    }

    .rud-crm-customer-card-person .rud-crm-card-image img,
    .rud-crm-customer-card-person .rud-crm-image-placeholder {
        display:flex;
        align-items:center;
        justify-content:center;
        width:100px;
        height:100px;
        object-fit:cover;
        border-radius:50%;
        border:1px solid #d0d5dd;
        padding:3px;
        background:#fff;
    }

    /*
     * Company card:
     * give the logo more room than before, while keeping
     * its original proportions.
     */

    .rud-crm-customer-card-company {
        grid-template-columns:160px 1fr;
    }

    .rud-crm-customer-card-company .rud-crm-card-image {
        display:flex;
        align-items:center;
        justify-content:flex-start;
        width:160px;
        min-height:100px;
    }

    .rud-crm-customer-card-company .rud-crm-card-image img {
        display:block;
        width:auto;
        height:auto;
        max-width:160px;
        max-height:90px;
        object-fit:contain;
        border-radius:0;
        padding:0;
        border:0;
        background:transparent;
    }

    .rud-crm-customer-card-company .rud-crm-image-placeholder {
        display:flex;
        align-items:center;
        justify-content:center;
        width:140px;
        height:90px;
        border:1px solid #d0d5dd;
        border-radius:8px;
        background:#f2f4f7;
    }

    .rud-crm-image-placeholder {
        font-size:38px;
        font-weight:700;
        color:#667085;
    }

    .rud-crm-card-content {
        min-width:0;
    }

    .rud-crm-customer-name {
        margin:8px 0 2px !important;
        font-size:18px;
        line-height:1.25;
    }

    .rud-crm-customer-number {
        font-size:12px;
        opacity:.6;
        margin-bottom:10px;
    }

    .rud-crm-card-company {
        font-weight:600;
        margin-bottom:8px;
    }

    .rud-crm-card-detail {
        display:flex;
        flex-direction:column;
        margin-top:6px;
        font-size:13px;
        overflow-wrap:anywhere;
    }

    .rud-crm-card-label {
        font-size:11px;
        text-transform:uppercase;
        letter-spacing:.04em;
        opacity:.55;
    }

    .rud-crm-card-actions {
        margin-top:14px;
    }


    .rud-crm-status {
        display:inline-flex;
        border-radius:999px;
        padding:4px 9px;
        font-size:11px;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.04em;
        background:#f2f4f7;
    }

    .rud-crm-status-customer {
        background:#ecfdf3;
    }

    .rud-crm-status-lead {
        background:#fffaeb;
    }

    .rud-crm-status-partner {
        background:#eff8ff;
    }

    .rud-crm-status-inactive {
        background:#f2f4f7;
    }


    .rud-crm-profile-toolbar {
        margin-bottom:18px;
    }

    .rud-crm-profile-hero {
        display:flex;
        align-items:center;
        gap:30px;
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:14px;
        padding:26px;
        margin-bottom:20px;
        min-width:0;
    }

    .rud-crm-profile-heading {
        flex:1 1 auto;
        min-width:0;
    }

    .rud-crm-profile-photo {
        flex:0 0 150px;
    }

    .rud-crm-profile-photo img,
    .rud-crm-profile-placeholder {
        width:150px;
        height:150px;
        border-radius:50%;
        object-fit:cover;
        border:1px solid #d0d5dd;
        padding:3px;
        background:#fff;
    }

    .rud-crm-profile-placeholder {
        display:flex;
        align-items:center;
        justify-content:center;
        background:#f2f4f7;
        font-size:48px;
        font-weight:700;
        color:#667085;
    }

    .rud-crm-profile-heading h1 {
        margin:10px 0 3px !important;
        font-size:38px;
        line-height:1.15;
    }

    .rud-crm-profile-number {
        opacity:.6;
        font-size:13px;
    }

    .rud-crm-profile-company {
        font-size:18px;
        font-weight:600;
        margin-top:12px;
    }


    .rud-crm-profile-columns {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:20px;
        margin-bottom:20px;
    }

    .rud-crm-panel {
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
        padding:24px;
        min-width:0;
    }

    .rud-crm-panel h2 {
        margin:0 0 18px !important;
        font-size:19px;
    }

    .rud-crm-full-panel {
        margin-bottom:20px;
    }

    .rud-crm-profile-row {
        display:grid;
        grid-template-columns:minmax(120px,35%) 1fr;
        gap:16px;
        padding:10px 0;
        border-bottom:1px solid #f2f4f7;
    }

    .rud-crm-profile-row:last-child {
        border-bottom:0;
    }

    .rud-crm-profile-label {
        font-size:12px;
        text-transform:uppercase;
        letter-spacing:.03em;
        opacity:.55;
    }

    .rud-crm-profile-value {
        overflow-wrap:anywhere;
    }


    .rud-crm-social-grid {
        display:grid;
        grid-template-columns:repeat(4,minmax(0,1fr));
        gap:12px;
    }

    .rud-crm-social-item {
        display:flex;
        flex-direction:column;
        gap:5px;
        border:1px solid #eaecf0;
        border-radius:8px;
        padding:14px;
    }


    .rud-crm-notes {
        white-space:normal;
        line-height:1.7;
    }


    .rud-crm-empty {
        background:#fff;
        border:1px solid #eaecf0;
        border-radius:12px;
        padding:25px;
    }


    @media (max-width:1024px) {

        .rud-crm-dashboard-cards {
            grid-template-columns:repeat(3,minmax(0,1fr));
        }

        .rud-crm-customer-grid {
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-social-grid {
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-image-gallery {
            grid-template-columns:repeat(3,minmax(0,1fr));
        }
    }


    @media (max-width:767px) {

        .rud-crm-dashboard-cards {
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-customer-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-customer-card-person {
            grid-template-columns:80px 1fr;
        }

        .rud-crm-customer-card-person .rud-crm-card-image,
        .rud-crm-customer-card-person .rud-crm-card-image img,
        .rud-crm-customer-card-person .rud-crm-image-placeholder {
            width:80px;
            height:80px;
        }

        .rud-crm-customer-card-company {
            grid-template-columns:130px 1fr;
        }

        .rud-crm-customer-card-company .rud-crm-card-image {
            width:130px;
            min-height:80px;
        }

        .rud-crm-customer-card-company .rud-crm-card-image img {
            max-width:130px;
            max-height:75px;
        }

        .rud-crm-customer-card-company .rud-crm-image-placeholder {
            width:120px;
            height:75px;
        }

        .rud-crm-profile-hero {
            grid-template-columns:1fr;
        }

        .rud-crm-profile-photo img,
        .rud-crm-profile-placeholder {
            width:140px;
            height:140px;
        }

        .rud-crm-profile-heading h1 {
            font-size:30px;
        }

        .rud-crm-profile-columns {
            grid-template-columns:1fr;
        }

        .rud-crm-social-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-image-gallery {
            grid-template-columns:repeat(2,minmax(0,1fr));
        }

        .rud-crm-profile-row {
            grid-template-columns:1fr;
            gap:4px;
        }
    }


    /*
     * =====================================================
     * COMPACT CUSTOMER LIST
     * =====================================================
     */

    .rud-crm-compact-heading {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:16px;
        margin:8px 0 12px;
    }

    .rud-crm-compact-heading .rud-crm-list-info {
        margin:0;
    }

    .rud-crm-compact-list {
        width:100%;
        overflow:hidden;
        border:1px solid #eaecf0;
        border-radius:10px;
        background:#fff;
    }

    .rud-crm-compact-row {
        display:grid;
        grid-template-columns:minmax(220px,2fr) minmax(150px,1fr) minmax(150px,1fr) 110px auto;
        align-items:center;
        gap:16px;
        min-height:56px;
        padding:9px 14px;
        border-bottom:1px solid #eaecf0;
    }

    .rud-crm-compact-row:last-child {
        border-bottom:0;
    }

    .rud-crm-compact-header {
        min-height:38px;
        padding-top:7px;
        padding-bottom:7px;
        background:#f9fafb;
        font-size:11px;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.04em;
        color:#667085;
    }

    .rud-crm-compact-name,
    .rud-crm-compact-reference,
    .rud-crm-compact-phone {
        min-width:0;
        overflow-wrap:anywhere;
    }

    .rud-crm-compact-name {
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
    }

    .rud-crm-compact-readonly {
        display:inline-flex;
        padding:2px 6px;
        border:1px solid #d0d5dd;
        border-radius:999px;
        font-size:9px;
        font-weight:700;
        white-space:nowrap;
    }

    .rud-crm-compact-action {
        justify-self:end;
    }

    .rud-crm-compact-action .rud-crm-button {
        min-height:34px;
        padding:7px 12px;
        font-size:12px;
        white-space:nowrap;
    }

    .rud-crm-mobile-label {
        display:none;
    }

    .rud-crm-view-all-wrap {
        display:flex;
        justify-content:flex-end;
        margin-top:14px;
    }

    @media (max-width:850px) {

        .rud-crm-compact-header {
            display:none;
        }

        .rud-crm-compact-row {
            grid-template-columns:1fr auto;
            gap:7px 16px;
            padding:13px 14px;
        }

        .rud-crm-compact-name {
            grid-column:1;
            grid-row:1;
        }

        .rud-crm-compact-reference,
        .rud-crm-compact-phone {
            grid-column:1;
            font-size:12px;
            color:#667085;
        }

        .rud-crm-compact-status {
            grid-column:2;
            grid-row:1;
            justify-self:end;
        }

        .rud-crm-compact-action {
            grid-column:2;
            grid-row:2 / span 2;
            align-self:center;
        }

        .rud-crm-mobile-label {
            display:inline;
            margin-right:5px;
            font-weight:600;
            color:#475467;
        }
    }

    @media (max-width:520px) {

        .rud-crm-compact-heading {
            align-items:flex-start;
            flex-direction:column;
            gap:3px;
        }

        .rud-crm-compact-row {
            grid-template-columns:1fr;
        }

        .rud-crm-compact-name,
        .rud-crm-compact-reference,
        .rud-crm-compact-phone,
        .rud-crm-compact-status,
        .rud-crm-compact-action {
            grid-column:1;
            grid-row:auto;
            justify-self:stretch;
        }

        .rud-crm-compact-action .rud-crm-button {
            width:100%;
            margin-top:3px;
        }

        .rud-crm-view-all-wrap .rud-crm-button {
            width:100%;
        }
    }

    ';


    wp_register_style(
        'rud-crm-frontend',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.3'
    );


    wp_enqueue_style(
        'rud-crm-frontend'
    );


    wp_add_inline_style(
        'rud-crm-frontend',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_styles'
);

/*
 * =========================================================
 * COMPANY OPEN PROFILE STYLES
 * =========================================================
 */

function rud_crm_frontend_company_open_profile_styles() {

    if ( is_admin() ) {
        return;
    }

    ?>

    <style>
        .rud-crm-company-open-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:22px;
            align-items:stretch;
        }

        .rud-crm-company-open-grid > .rud-crm-panel {
            min-width:0;
            margin:0;
        }

        .rud-crm-company-open-head {
            display:flex;
            align-items:center;
            gap:18px;
            margin-bottom:18px;
        }

        .rud-crm-company-open-logo {
            flex:0 0 120px;
            min-width:0;
        }

        .rud-crm-company-open-logo img,
        .rud-crm-company-open-logo-placeholder {
            display:flex;
            align-items:center;
            justify-content:center;
            width:120px;
            height:80px;
            object-fit:contain;
            border:1px solid #d0d5dd;
            border-radius:9px;
            background:#fff;
        }

        .rud-crm-company-open-logo-placeholder {
            background:#f2f4f7;
            color:#667085;
            font-size:34px;
            font-weight:700;
        }

        .rud-crm-company-open-title {
            min-width:0;
        }

        .rud-crm-company-open-title h1 {
            margin:0 0 6px;
            font-size:25px;
            line-height:1.2;
            overflow-wrap:anywhere;
        }

        .rud-crm-company-open-contacts {
            display:flex;
            flex-direction:column;
        }

        .rud-crm-company-open-contact {
            padding:0 0 16px;
            margin:0 0 16px;
            border-bottom:1px solid #eaecf0;
        }

        .rud-crm-company-open-contact:last-child {
            padding-bottom:0;
            margin-bottom:0;
            border-bottom:0;
        }

        .rud-crm-company-open-contact-name {
            display:flex;
            align-items:center;
            gap:8px;
            flex-wrap:wrap;
            margin-bottom:3px;
            font-size:16px;
        }

        .rud-crm-company-open-primary {
            display:inline-flex;
            padding:3px 7px;
            border-radius:999px;
            background:#eef7ef;
            font-size:10px;
            font-weight:700;
        }

        .rud-crm-company-open-contact-title {
            font-weight:600;
        }

        .rud-crm-company-open-contact-department {
            margin-top:2px;
            color:#667085;
            font-size:13px;
        }

        .rud-crm-company-open-contact-detail {
            display:grid;
            grid-template-columns:65px minmax(0,1fr);
            gap:8px;
            margin-top:7px;
            font-size:13px;
        }

        .rud-crm-company-open-contact-detail span {
            color:#667085;
        }

        .rud-crm-company-open-contact-detail a {
            color:inherit;
            text-decoration:none;
            overflow-wrap:anywhere;
        }

        .rud-crm-company-website-link {
            color:#1d2939 !important;
            font-weight:600;
            text-decoration:none !important;
        }

        .rud-crm-company-website-link:hover {
            text-decoration:underline !important;
        }

        .rud-crm-company-open-notes {
            margin-top:22px;
            border:1px solid #e4e7ec;
            border-radius:10px;
            background:#fff;
            overflow:hidden;
        }

        .rud-crm-company-open-notes summary {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:40px;
            margin:14px;
            padding:9px 16px;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            cursor:pointer;
            font-weight:700;
            list-style:none;
        }

        .rud-crm-company-open-notes summary::-webkit-details-marker {
            display:none;
        }

        .rud-crm-company-open-notes-content {
            padding:0 20px 20px;
        }

        .rud-crm-notes-popup-button {
            display:inline-flex;
            align-items:center;
            justify-content:center;
            min-height:36px;
            margin-top:16px;
            padding:7px 13px;
            border:1px solid #1d2939;
            border-radius:7px;
            background:#1d2939;
            color:#fff;
            cursor:pointer;
            font-size:12px;
            font-weight:700;
        }

        .rud-crm-contact-notes-button {
            margin-top:12px;
        }

        .rud-crm-notes-modal {
            position:fixed;
            inset:0;
            z-index:999999;
            display:none;
            align-items:center;
            justify-content:center;
            padding:20px;
        }

        .rud-crm-notes-modal.is-open {
            display:flex;
        }

        .rud-crm-notes-modal-backdrop {
            position:absolute;
            inset:0;
            background:rgba(16,24,40,.55);
        }

        .rud-crm-notes-modal-dialog {
            position:relative;
            z-index:1;
            width:min(680px,100%);
            max-height:80vh;
            overflow:auto;
            border-radius:12px;
            background:#fff;
            box-shadow:0 20px 50px rgba(16,24,40,.25);
        }

        .rud-crm-notes-modal-header {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
            padding:18px 20px;
            border-bottom:1px solid #eaecf0;
        }

        .rud-crm-notes-modal-header h3 {
            margin:0 !important;
            font-size:18px;
        }

        .rud-crm-notes-modal-close {
            display:flex;
            align-items:center;
            justify-content:center;
            width:34px;
            height:34px;
            border:0;
            border-radius:7px;
            background:#f2f4f7;
            color:#1d2939;
            cursor:pointer;
            font-size:24px;
            line-height:1;
        }

        .rud-crm-notes-modal-content {
            padding:20px;
            line-height:1.65;
            white-space:normal;
        }

        body.rud-crm-notes-modal-open {
            overflow:hidden;
        }

        @media (max-width:800px) {
            .rud-crm-company-open-grid {
                grid-template-columns:1fr;
            }
        }

        @media (max-width:520px) {
            .rud-crm-company-open-head {
                align-items:flex-start;
                flex-direction:column;
            }

            .rud-crm-company-open-contact-detail {
                grid-template-columns:1fr;
                gap:2px;
            }
        }
    </style>

    <?php
}

add_action(
    'wp_head',
    'rud_crm_frontend_company_open_profile_styles',
    40
);


/*
 * =========================================================
 * COMPANY / CONTACT NOTES POPUP
 * =========================================================
 */

function rud_crm_frontend_company_notes_popup_script() {
    ?>
    <script>
    document.addEventListener('click', function (event) {

        var openButton =
            event.target.closest(
                '[data-rud-notes-open]'
            );

        if (openButton) {

            var key =
                openButton.getAttribute(
                    'data-rud-notes-open'
                );

            var modal =
                document.querySelector(
                    '[data-rud-notes-modal="' + key + '"]'
                );

            if (modal) {
                modal.classList.add('is-open');
                modal.setAttribute('aria-hidden', 'false');
                document.body.classList.add('rud-crm-notes-modal-open');
            }

            return;
        }

        var closeButton =
            event.target.closest(
                '[data-rud-notes-close]'
            );

        if (closeButton) {

            var modal =
                closeButton.closest(
                    '[data-rud-notes-modal]'
                );

            if (modal) {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
            }

            if (
                ! document.querySelector(
                    '.rud-crm-notes-modal.is-open'
                )
            ) {
                document.body.classList.remove('rud-crm-notes-modal-open');
            }
        }
    });

    document.addEventListener('keydown', function (event) {

        if (event.key !== 'Escape') {
            return;
        }

        document
            .querySelectorAll(
                '.rud-crm-notes-modal.is-open'
            )
            .forEach(function (modal) {
                modal.classList.remove('is-open');
                modal.setAttribute('aria-hidden', 'true');
            });

        document.body.classList.remove('rud-crm-notes-modal-open');
    });
    </script>
    <?php
}

add_action(
    'wp_footer',
    'rud_crm_frontend_company_notes_popup_script',
    40
);
