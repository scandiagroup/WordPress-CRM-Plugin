<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END SEND EMAIL
 * Version 1.1
 * =========================================================
 *
 * Provides:
 * - Send Email panel on Customer Open Profile
 * - Select Contact Person
 * - Select Email Template
 * - Preview template subject/body before sending
 * - Send using RUD CRM Email Sender
 * - Success / error messages
 *
 * =========================================================
 */


/*
 * =========================================================
 * PERMISSION
 * =========================================================
 */

function rud_crm_frontend_email_can_send_for_customer(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        function_exists(
            'rud_crm_frontend_edit_can_edit'
        )
    ) {

        return (bool)
            rud_crm_frontend_edit_can_edit(
                $customer_id
            );
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_user_owns_customer'
        )
    ) {

        return (bool)
            rud_crm_user_owns_customer(
                get_current_user_id(),
                $customer_id
            );
    }

    return false;
}


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

function rud_crm_frontend_email_customer_url(
    $customer_id,
    $args = array()
) {

    $url =
        add_query_arg(
            array(
                'rud_customer_id' =>
                    absint(
                        $customer_id
                    ),
            ),
            home_url(
                '/customer-crm/'
            )
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * SEND EMAIL FORM PROCESSOR
 * =========================================================
 */

function rud_crm_frontend_process_send_email() {

    $email_action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_email_send_action']
                ?? ''
            )
        );

    if (
        ! in_array(
            $email_action,
            array(
                'send_email',
                'save_template',
            ),
            true
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_email_can_send_for_customer(
            $customer_id
        )
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_email_send_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_email_send_nonce']
                )
            ),
            'rud_crm_send_email_' .
            $customer_id
        )
    ) {
        return;
    }

    $contact_id =
        absint(
            $_POST['contact_id']
            ?? 0
        );

    $template_id =
        absint(
            $_POST['template_id']
            ?? 0
        );

    $project_id =
        absint(
            $_POST['project_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['task_id']
            ?? 0
        );

    $subject =
        sanitize_text_field(
            wp_unslash(
                $_POST['subject']
                ?? ''
            )
        );

    $body =
        wp_kses_post(
            wp_unslash(
                $_POST['body']
                ?? ''
            )
        );


    /*
     * Save current composition as a NEW Email Template.
     * This does not send an email.
     */
    if (
        'save_template' ===
        $email_action
    ) {

        if (
            ! function_exists(
                'rud_crm_create_email_template'
            )
        ) {

            wp_safe_redirect(
                rud_crm_frontend_email_customer_url(
                    $customer_id,
                    array(
                        'rud_email_send_error' =>
                            'email_template_system_unavailable',
                    )
                )
            );

            exit;
        }

        $template_name =
            sanitize_text_field(
                wp_unslash(
                    $_POST['new_template_name']
                    ?? ''
                )
            );

        $template_result =
            rud_crm_create_email_template(
                array(

                    'template_name' =>
                        $template_name,

                    'subject' =>
                        $subject,

                    'cc_email' =>
                        '',

                    'bcc_email' =>
                        '',

                    'body' =>
                        $body,

                    'status' =>
                        'active',
                )
            );

        if (
            is_wp_error(
                $template_result
            )
        ) {

            wp_safe_redirect(
                rud_crm_frontend_email_customer_url(
                    $customer_id,
                    array(
                        'rud_email_send_error' =>
                            $template_result->get_error_code(),
                    )
                )
            );

            exit;
        }

        wp_safe_redirect(
            rud_crm_frontend_email_customer_url(
                $customer_id,
                array(
                    'rud_email_send_message' =>
                        'template_saved',
                )
            )
        );

        exit;
    }


    /*
     * Send Email.
     */
    if (
        ! function_exists(
            'rud_crm_send_email'
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_email_customer_url(
                $customer_id,
                array(
                    'rud_email_send_error' =>
                        'email_sender_unavailable',
                )
            )
        );

        exit;
    }

    $result =
        rud_crm_send_email(
            array(

                'customer_id' =>
                    $customer_id,

                'contact_id' =>
                    $contact_id,

                'project_id' =>
                    $project_id,

                'task_id' =>
                    $task_id,

                'template_id' =>
                    $template_id,

                'subject' =>
                    $subject,

                'body' =>
                    $body,
            )
        );

    if (
        is_wp_error(
            $result
        )
    ) {

        wp_safe_redirect(
            rud_crm_frontend_email_customer_url(
                $customer_id,
                array(
                    'rud_email_send_error' =>
                        $result->get_error_code(),
                )
            )
        );

        exit;
    }

    wp_safe_redirect(
        rud_crm_frontend_email_customer_url(
            $customer_id,
            array(
                'rud_email_send_message' =>
                    'sent',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_send_email',
    85
);


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_frontend_email_send_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_email_send_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_email_send_error']
                ?? ''
            )
        );

    if (
        'sent' ===
        $message
    ) {

        return
            '<div class="rud-crm-email-send-message rud-crm-email-send-success">' .
            'Email sent successfully.' .
            '</div>';
    }

    if (
        'template_saved' ===
        $message
    ) {

        return
            '<div class="rud-crm-email-send-message rud-crm-email-send-success">' .
            'New Email Template saved successfully.' .
            '</div>';
    }

    if (
        $error
    ) {

        $text =
            'Email could not be sent.';

        if (
            'email_recipient_missing' ===
            $error
        ) {

            $text =
                'No valid email address is saved for the selected recipient.';
        }

        if (
            'email_template_unavailable' ===
            $error
        ) {

            $text =
                'The selected email template is not available.';
        }

        if (
            'email_sender_unavailable' ===
            $error
        ) {

            $text =
                'The Email Sender module is not available.';
        }

        if (
            'email_template_system_unavailable' ===
            $error
        ) {

            $text =
                'The Email Template system is not available.';
        }

        if (
            'email_template_name_required' ===
            $error
        ) {

            $text =
                'Template Name is required before saving a new template.';
        }

        if (
            'email_template_subject_required' ===
            $error
        ) {

            $text =
                'Email Subject is required before saving a new template.';
        }

        return
            '<div class="rud-crm-email-send-message rud-crm-email-send-error">' .
            esc_html(
                $text
            ) .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * CONTACT OPTIONS
 * =========================================================
 */

function rud_crm_frontend_email_contact_options(
    $customer_id
) {

    $options =
        array(
            0 =>
                'Main Customer / Company Email',
        );

    if (
        ! function_exists(
            'rud_crm_get_company_contacts'
        )
    ) {
        return $options;
    }

    $contacts =
        rud_crm_get_company_contacts(
            $customer_id
        );

    foreach (
        $contacts
        as
        $contact
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $contact->first_name ?? '',
                            $contact->middle_name ?? '',
                            $contact->last_name ?? '',
                        )
                    )
                )
            );

        if (
            '' ===
            $name
        ) {
            continue;
        }

        $email =
            trim(
                (string)
                (
                    $contact->work_email
                    ?: $contact->private_email
                )
            );

        $label =
            $name;

        if (
            $email
        ) {

            $label .=
                ' — ' .
                $email;
        }

        $options[
            absint(
                $contact->id
            )
        ] =
            $label;
    }

    return $options;
}


/*
 * =========================================================
 * PROJECT OPTIONS
 * =========================================================
 */

function rud_crm_frontend_email_project_options(
    $customer_id
) {

    $options =
        array(
            0 =>
                'No Project',
        );

    if (
        ! function_exists(
            'rud_crm_get_customer_projects'
        )
    ) {
        return $options;
    }

    $projects =
        rud_crm_get_customer_projects(
            $customer_id
        );

    foreach (
        $projects
        as
        $project
    ) {

        $project_id =
            absint(
                $project->id
                ??
                $project->project_id
                ??
                0
            );

        if (
            ! $project_id
        ) {
            continue;
        }

        $label =
            $project->project_title
            ??
            $project->title
            ??
            $project->project_number
            ??
            (
                'Project #' .
                $project_id
            );

        $options[
            $project_id
        ] =
            $label;
    }

    return $options;
}


/*
 * =========================================================
 * TASK OPTIONS
 * =========================================================
 */

function rud_crm_frontend_email_task_options(
    $customer_id
) {

    $options =
        array(
            0 =>
                'No Task',
        );

    if (
        ! function_exists(
            'rud_crm_get_tasks'
        )
    ) {
        return $options;
    }

    $tasks =
        rud_crm_get_tasks(
            array(

                'customer_id' =>
                    $customer_id,

                'include_completed' =>
                    true,

                'limit' =>
                    100,
            )
        );

    foreach (
        $tasks
        as
        $task
    ) {

        $options[
            absint(
                $task->id
            )
        ] =
            $task->title;
    }

    return $options;
}


/*
 * =========================================================
 * SEND EMAIL PANEL
 * =========================================================
 */

function rud_crm_frontend_customer_email_panel(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! rud_crm_frontend_email_can_send_for_customer(
            $customer_id
        )
        ||
        ! function_exists(
            'rud_crm_get_email_templates'
        )
    ) {
        return '';
    }

    $templates =
        rud_crm_get_email_templates(
            'active'
        );

    $contact_options =
        rud_crm_frontend_email_contact_options(
            $customer_id
        );

    $project_options =
        rud_crm_frontend_email_project_options(
            $customer_id
        );

    $task_options =
        rud_crm_frontend_email_task_options(
            $customer_id
        );

    ob_start();

    ?>

    <section class="rud-crm-send-email-section">

        <div class="rud-crm-send-email-header">

            <div>

                <h2>
                    SEND EMAIL
                </h2>

                <p>
                    Send an email to the customer or one of the connected contact persons.
                </p>

            </div>

        </div>

        <?php
        echo rud_crm_frontend_email_send_message_html();
        ?>

        <details class="rud-crm-send-email-panel">

            <summary>
                + COMPOSE EMAIL
            </summary>

            <div class="rud-crm-send-email-form-wrap">

                <form method="post">

                    <?php
                    wp_nonce_field(
                        'rud_crm_send_email_' .
                        $customer_id,
                        'rud_crm_email_send_nonce'
                    );
                    ?>


                    <input
                        type="hidden"
                        name="rud_customer_id"
                        value="<?php echo esc_attr( $customer_id ); ?>"
                    >

                    <div class="rud-crm-send-email-grid">

                        <div>

                            <label>
                                Recipient
                            </label>

                            <select name="contact_id">

                                <?php foreach ( $contact_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                Email Template
                            </label>

                            <select
                                name="template_id"
                                data-rud-email-template-select
                            >

                                <option value="0">
                                    Custom Email
                                </option>

                                <?php foreach ( $templates as $template ) : ?>

                                    <option
                                        value="<?php echo esc_attr( $template->id ); ?>"
                                        data-subject="<?php echo esc_attr( $template->subject ); ?>"
                                        data-body="<?php echo esc_attr( $template->body ); ?>"
                                    >
                                        <?php echo esc_html( $template->template_name ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                Project
                            </label>

                            <select name="project_id">

                                <?php foreach ( $project_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div>

                            <label>
                                Task
                            </label>

                            <select name="task_id">

                                <?php foreach ( $task_options as $value => $label ) : ?>

                                    <option value="<?php echo esc_attr( $value ); ?>">
                                        <?php echo esc_html( $label ); ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>

                        <div class="rud-crm-send-email-wide">

                            <label>
                                Email Subject
                            </label>

                            <input
                                type="text"
                                name="subject"
                                data-rud-email-subject
                                placeholder="Email subject"
                            >

                        </div>

                        <div class="rud-crm-send-email-wide">

                            <label>
                                Email Body
                            </label>

                            <textarea
                                name="body"
                                rows="10"
                                data-rud-email-body
                                placeholder="Write your email here or select a template."
                            ></textarea>

                        </div>

                    </div>

                    <div class="rud-crm-send-email-note">
                        Template variables are replaced automatically when the email is sent.
                    </div>

                    <div class="rud-crm-save-template-box">

                        <label>
                            Save Current Email as New Template
                        </label>

                        <div class="rud-crm-save-template-row">

                            <input
                                type="text"
                                name="new_template_name"
                                placeholder="New Template Name"
                            >

                            <button
                                type="submit"
                                name="rud_crm_email_send_action"
                                value="save_template"
                                class="rud-crm-save-template-button"
                            >
                                SAVE AS NEW TEMPLATE
                            </button>

                        </div>

                        <small>
                            Saves the current Subject and Body as a new active Email Template. The email is not sent.
                        </small>

                    </div>

                    <button
                        type="submit"
                        name="rud_crm_email_send_action"
                        value="send_email"
                        class="rud-crm-send-email-button"
                        onclick="return confirm('Send this email now?');"
                    >
                        SEND EMAIL
                    </button>

                </form>

            </div>

        </details>

    </section>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * STYLES + TEMPLATE PREVIEW
 * =========================================================
 */

function rud_crm_frontend_send_email_assets() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-send-email-section {
        width:100%;
        margin-top:28px;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
        box-sizing:border-box;
    }

    .rud-crm-send-email-section * {
        box-sizing:border-box;
    }

    .rud-crm-send-email-header h2 {
        margin:0 0 5px !important;
    }

    .rud-crm-send-email-header p {
        margin:0 0 18px;
        color:#667085;
    }

    .rud-crm-send-email-panel {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-send-email-panel summary {
        padding:14px 16px;
        cursor:pointer;
        font-weight:700;
        list-style:none;
    }

    .rud-crm-send-email-panel summary::-webkit-details-marker {
        display:none;
    }

    .rud-crm-send-email-form-wrap {
        padding:18px;
        border-top:1px solid #eaecf0;
        background:#f9fafb;
    }

    .rud-crm-send-email-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-send-email-wide {
        grid-column:1 / -1;
    }

    .rud-crm-send-email-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-send-email-grid input,
    .rud-crm-send-email-grid select,
    .rud-crm-send-email-grid textarea {
        width:100%;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-send-email-note {
        margin-top:10px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-save-template-box {
        margin-top:18px;
        padding:15px;
        border:1px solid #d0d5dd;
        border-radius:8px;
        background:#fff;
    }

    .rud-crm-save-template-box > label {
        display:block;
        margin-bottom:8px;
        font-weight:700;
    }

    .rud-crm-save-template-row {
        display:flex;
        gap:10px;
        align-items:center;
    }

    .rud-crm-save-template-row input {
        flex:1 1 auto;
        min-width:0;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-save-template-box small {
        display:block;
        margin-top:7px;
        color:#667085;
        font-size:11px;
    }

    .rud-crm-save-template-button {
        min-height:38px;
        padding:8px 13px;
        border:1px solid #475467;
        border-radius:7px;
        background:#fff;
        color:#1d2939;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
        white-space:nowrap;
    }

    .rud-crm-send-email-button {
        min-height:38px;
        margin-top:16px;
        padding:8px 13px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-email-send-message {
        margin-bottom:16px;
        padding:11px 13px;
        border-radius:7px;
    }

    .rud-crm-email-send-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-email-send-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:700px) {

        .rud-crm-send-email-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-send-email-wide {
            grid-column:auto;
        }

        .rud-crm-save-template-row {
            display:block;
        }

        .rud-crm-save-template-button {
            width:100%;
            margin-top:10px;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-send-email',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-send-email'
    );

    wp_add_inline_style(
        'rud-crm-frontend-send-email',
        $css
    );


    $js = <<<'JS'
document.addEventListener('change', function (event) {

    if (
        ! event.target.matches(
            '[data-rud-email-template-select]'
        )
    ) {
        return;
    }

    var option =
        event.target.options[
            event.target.selectedIndex
        ];

    var form =
        event.target.closest('form');

    if (!form) {
        return;
    }

    var subject =
        form.querySelector(
            '[data-rud-email-subject]'
        );

    var body =
        form.querySelector(
            '[data-rud-email-body]'
        );

    if (!subject || !body) {
        return;
    }

    if (
        event.target.value === '0'
    ) {
        subject.value = '';
        body.value = '';
        return;
    }

    subject.value =
        option.getAttribute(
            'data-subject'
        )
        || '';

    body.value =
        option.getAttribute(
            'data-body'
        )
        || '';
});
JS;

    wp_register_script(
        'rud-crm-frontend-send-email',
        '',
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0',
        true
    );

    wp_enqueue_script(
        'rud-crm-frontend-send-email'
    );

    wp_add_inline_script(
        'rud-crm-frontend-send-email',
        $js
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_send_email_assets',
    90
);
