<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/*
 * =========================================================
 * RUD CRM SERVER
 * EMAIL VERIFICATION + AUTOMATIC LOGIN
 * =========================================================
 *
 * Flow:
 * 1. Public registration creates the WordPress user.
 * 2. rud_crm_public_user_registered fires.
 * 3. This file creates a one-time verification token and emails it.
 * 4. User clicks the link.
 * 5. Token is validated and consumed.
 * 6. Email is marked verified.
 * 7. User is logged in automatically.
 * 8. User is redirected to /crm-account/.
 *
 * Existing WordPress users that were not created through the public
 * RUD CRM registration flow are treated as verified, so this module
 * does not lock administrators or legacy accounts out.
 * =========================================================
 */


/*
 * =========================================================
 * META KEYS
 * =========================================================
 */
function rud_crm_email_verification_meta_keys() {
    return array(
        'verified'    => 'rud_crm_email_verified',
        'verified_at' => 'rud_crm_email_verified_at',
        'token_hash'  => 'rud_crm_email_verification_token_hash',
        'expires'     => 'rud_crm_email_verification_expires',
        'sent_at'     => 'rud_crm_email_verification_sent_at',
    );
}


/*
 * =========================================================
 * ACCOUNT URL
 * =========================================================
 */
function rud_crm_email_verification_account_url() {
    if ( function_exists( 'rud_crm_account_page_url' ) ) {
        return rud_crm_account_page_url();
    }

    if ( function_exists( 'rud_crm_registration_account_url' ) ) {
        return rud_crm_registration_account_url();
    }

    return home_url( '/crm-account/' );
}


/*
 * =========================================================
 * IS THIS AN ACCOUNT THAT REQUIRES VERIFICATION?
 * =========================================================
 */
function rud_crm_email_requires_verification( $user_id ) {
    $user_id = absint( $user_id );

    if ( ! $user_id ) {
        return false;
    }

    /*
     * Public registrations explicitly store this value in
     * registration.php. Legacy/admin users are therefore not blocked.
     */
    return 'public_registration' === get_user_meta(
        $user_id,
        'rud_crm_registration_source',
        true
    );
}


/*
 * =========================================================
 * PUBLIC VERIFICATION STATUS HELPER
 * =========================================================
 */
function rud_crm_email_is_verified( $user_id ) {
    $user_id = absint( $user_id );

    if ( ! $user_id ) {
        return false;
    }

    /*
     * Users not created through the public CRM registration flow
     * are considered verified for backward compatibility.
     */
    if ( ! rud_crm_email_requires_verification( $user_id ) ) {
        return true;
    }

    $keys = rud_crm_email_verification_meta_keys();

    $verified = get_user_meta(
        $user_id,
        $keys['verified'],
        true
    );

    /*
     * Legacy public-registration accounts created before this
     * replacement may not have our new verification meta key.
     * Treat those existing accounts as verified so this update
     * cannot accidentally lock them out. New registrations are
     * explicitly written with verified = 0 before the email is sent.
     */
    if ( '' === $verified ) {
        return true;
    }

    return '1' === (string) $verified;
}


/*
 * =========================================================
 * TOKEN LIFETIME
 * =========================================================
 */
function rud_crm_email_verification_lifetime() {
    /* 24 hours. */
    return DAY_IN_SECONDS;
}


/*
 * =========================================================
 * CREATE VERIFICATION LINK
 * =========================================================
 */
function rud_crm_email_create_verification_link( $user_id ) {
    $user_id = absint( $user_id );

    if ( ! $user_id ) {
        return new WP_Error(
            'rud_crm_invalid_user',
            'The CRM account could not be identified.'
        );
    }

    $user = get_userdata( $user_id );

    if ( ! $user ) {
        return new WP_Error(
            'rud_crm_invalid_user',
            'The CRM account could not be found.'
        );
    }

    try {
        $token = bin2hex( random_bytes( 32 ) );
    } catch ( Exception $e ) {
        $token = wp_generate_password( 64, false, false );
    }

    if ( '' === $token ) {
        return new WP_Error(
            'rud_crm_token_failed',
            'A verification token could not be created.'
        );
    }

    $keys    = rud_crm_email_verification_meta_keys();
    $expires = time() + rud_crm_email_verification_lifetime();

    update_user_meta(
        $user_id,
        $keys['verified'],
        '0'
    );

    update_user_meta(
        $user_id,
        $keys['token_hash'],
        hash( 'sha256', $token )
    );

    update_user_meta(
        $user_id,
        $keys['expires'],
        $expires
    );

    update_user_meta(
        $user_id,
        $keys['sent_at'],
        current_time( 'mysql' )
    );

    return add_query_arg(
        array(
            'rud_crm_verify_email' => '1',
            'rud_crm_user'         => $user_id,
            'rud_crm_token'        => rawurlencode( $token ),
        ),
        rud_crm_email_verification_account_url()
    );
}


/*
 * =========================================================
 * SEND VERIFICATION EMAIL
 * =========================================================
 */
function rud_crm_email_send_verification( $user_id ) {
    $user_id = absint( $user_id );
    $user    = get_userdata( $user_id );

    if ( ! $user || ! is_email( $user->user_email ) ) {
        return false;
    }

    $link = rud_crm_email_create_verification_link( $user_id );

    if ( is_wp_error( $link ) ) {
        return false;
    }

    $site_name = wp_specialchars_decode(
        get_bloginfo( 'name' ),
        ENT_QUOTES
    );

    $subject = sprintf(
        '[%s] Verify your email address',
        $site_name
    );

    $display_name = trim( (string) $user->display_name );

    if ( '' === $display_name ) {
        $display_name = $user->user_email;
    }

    $message  = "Hello {$display_name},\n\n";
    $message .= "Thank you for registering your RUD CRM account.\n\n";
    $message .= "Please verify your email address by opening the link below:\n\n";
    $message .= $link . "\n\n";
    $message .= "This verification link is valid for 24 hours and can only be used once.\n\n";
    $message .= "After verification you will be logged in automatically and returned to your RUD CRM account.\n\n";
    $message .= "If you did not create this account, you can ignore this email.\n";

    return wp_mail(
        $user->user_email,
        $subject,
        $message
    );
}


/*
 * =========================================================
 * NEW PUBLIC REGISTRATION
 * =========================================================
 */
function rud_crm_email_verification_after_registration( $user_id ) {
    $user_id = absint( $user_id );

    if ( ! $user_id ) {
        return;
    }

    rud_crm_email_send_verification( $user_id );
}

add_action(
    'rud_crm_public_user_registered',
    'rud_crm_email_verification_after_registration',
    20,
    1
);


/*
 * =========================================================
 * REDIRECT HELPER FOR FAILED VERIFICATION
 * =========================================================
 */
function rud_crm_email_verification_redirect_status( $status ) {
    $status = sanitize_key( $status );

    wp_safe_redirect(
        add_query_arg(
            'rud_crm_email_verification',
            $status,
            rud_crm_email_verification_account_url()
        )
    );

    exit;
}


/*
 * =========================================================
 * PROCESS VERIFICATION LINK
 * =========================================================
 */
function rud_crm_email_process_verification_link() {
    if (
        empty( $_GET['rud_crm_verify_email'] )
        ||
        '1' !== sanitize_text_field(
            wp_unslash( $_GET['rud_crm_verify_email'] )
        )
    ) {
        return;
    }

    $user_id = isset( $_GET['rud_crm_user'] )
        ? absint( $_GET['rud_crm_user'] )
        : 0;

    $token = isset( $_GET['rud_crm_token'] )
        ? sanitize_text_field(
            wp_unslash( $_GET['rud_crm_token'] )
        )
        : '';

    if ( ! $user_id || '' === $token ) {
        rud_crm_email_verification_redirect_status( 'invalid' );
    }

    $user = get_userdata( $user_id );

    if ( ! $user ) {
        rud_crm_email_verification_redirect_status( 'invalid' );
    }

    $keys = rud_crm_email_verification_meta_keys();

    /*
     * If already verified, allow the same account to be logged in,
     * but do not accept a missing/foreign account id.
     */
    if ( rud_crm_email_is_verified( $user_id ) ) {
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, true, is_ssl() );
        do_action( 'wp_login', $user->user_login, $user );

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_email_verification',
                'verified',
                rud_crm_email_verification_account_url()
            )
        );
        exit;
    }

    $stored_hash = (string) get_user_meta(
        $user_id,
        $keys['token_hash'],
        true
    );

    $expires = absint(
        get_user_meta(
            $user_id,
            $keys['expires'],
            true
        )
    );

    if ( ! $expires || time() > $expires ) {
        rud_crm_email_verification_redirect_status( 'expired' );
    }

    if ( '' === $stored_hash ) {
        rud_crm_email_verification_redirect_status( 'invalid' );
    }

    $provided_hash = hash( 'sha256', $token );

    if ( ! hash_equals( $stored_hash, $provided_hash ) ) {
        rud_crm_email_verification_redirect_status( 'invalid' );
    }

    /*
     * Mark verified before creating the authenticated session.
     */
    update_user_meta(
        $user_id,
        $keys['verified'],
        '1'
    );

    update_user_meta(
        $user_id,
        $keys['verified_at'],
        current_time( 'mysql' )
    );

    /* One-time token: remove it immediately after success. */
    delete_user_meta( $user_id, $keys['token_hash'] );
    delete_user_meta( $user_id, $keys['expires'] );

    /*
     * Automatic login after successful verification.
     */
    wp_clear_auth_cookie();
    wp_set_current_user( $user_id );
    wp_set_auth_cookie( $user_id, true, is_ssl() );
    do_action( 'wp_login', $user->user_login, $user );

    /*
     * Return to CRM Account. Existing account routing may then
     * move logged-in users onward to My Account as designed.
     */
    wp_safe_redirect(
        add_query_arg(
            'rud_crm_email_verification',
            'verified',
            rud_crm_email_verification_account_url()
        )
    );

    exit;
}

add_action(
    'template_redirect',
    'rud_crm_email_process_verification_link',
    3
);


/*
 * =========================================================
 * BLOCK PASSWORD LOGIN UNTIL EMAIL IS VERIFIED
 * =========================================================
 */
function rud_crm_email_block_unverified_login(
    $user,
    $username,
    $password
) {
    if ( is_wp_error( $user ) || ! ( $user instanceof WP_User ) ) {
        return $user;
    }

    if (
        rud_crm_email_requires_verification( $user->ID )
        &&
        ! rud_crm_email_is_verified( $user->ID )
    ) {
        return new WP_Error(
            'rud_crm_email_not_verified',
            'Please verify your email address before logging in to RUD CRM.'
        );
    }

    return $user;
}

add_filter(
    'authenticate',
    'rud_crm_email_block_unverified_login',
    40,
    3
);


/*
 * =========================================================
 * ADMIN USER LIST: EMAIL VERIFICATION STATUS
 * =========================================================
 */
function rud_crm_email_admin_user_column( $columns ) {
    $columns['rud_crm_email_verified'] = 'CRM Email Verified';
    return $columns;
}

add_filter(
    'manage_users_columns',
    'rud_crm_email_admin_user_column'
);


function rud_crm_email_admin_user_column_value(
    $value,
    $column_name,
    $user_id
) {
    if ( 'rud_crm_email_verified' !== $column_name ) {
        return $value;
    }

    if ( ! rud_crm_email_requires_verification( $user_id ) ) {
        return 'Not required';
    }

    return rud_crm_email_is_verified( $user_id )
        ? 'Verified'
        : 'Pending';
}

add_filter(
    'manage_users_custom_column',
    'rud_crm_email_admin_user_column_value',
    10,
    3
);
