<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * DATABASE
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CUSTOMER FIELDS AVAILABLE TO CONNECTED WEBSITES
 * ---------------------------------------------------------
 */

function rud_crm_available_fields() {

    return array(

        'title'               => 'Title',
        'first_name'          => 'First Name',
        'middle_name'         => 'Middle Name',
        'last_name'           => 'Last Name',
        'preferred_name'      => 'Preferred Name',

        'company_name'        => 'Company Name',
        'organization_number' => 'Organization Number',
        'job_title'           => 'Job Title',
        'department'          => 'Department',

        'birth_date'          => 'Birth Date',
        'gender'              => 'Gender',
        'preferred_language'  => 'Preferred Language',
        'nationality'         => 'Nationality',

        'private_email'       => 'Private Email',
        'work_email'          => 'Work Email',

        'mobile_phone'        => 'Mobile Phone',
        'home_phone'          => 'Home Phone',
        'office_phone'        => 'Office Phone',
        'whatsapp'            => 'WhatsApp',

        'private_address'     => 'Private Address',
        'business_address'    => 'Business Address',
        'billing_address'     => 'Billing Address',
        'delivery_address'    => 'Delivery Address',

        'social_accounts'     => 'Social Media Accounts',

        'profile_images'      => 'Customer Profile Images',

        'notes'               => 'Internal CRM Notes'
    );
}


/*
 * ---------------------------------------------------------
 * SOCIAL MEDIA / MESSAGING PLATFORMS
 * ---------------------------------------------------------
 */

function rud_crm_social_platforms() {

    return array(

        'facebook'          => 'Facebook',
        'instagram'         => 'Instagram',
        'tiktok'            => 'TikTok',
        'youtube'           => 'YouTube',

        'telegram'          => 'Telegram',
        'skype'             => 'Skype',

        'x'                 => 'X',
        'truth_social'      => 'Truth Social',

        'linkedin'          => 'LinkedIn',
        'pinterest'         => 'Pinterest',

        'snapchat'          => 'Snapchat',
        'threads'           => 'Threads',

        'discord'           => 'Discord',
        'reddit'            => 'Reddit',

        'wechat'            => 'WeChat',
        'line'              => 'LINE',
        'vk'                => 'VK',

        'signal'            => 'Signal',

        'whatsapp_business' => 'WhatsApp Business',

        'twitch'            => 'Twitch',
        'tumblr'            => 'Tumblr',

        'vimeo'             => 'Vimeo',
        'flickr'            => 'Flickr',

        'github'            => 'GitHub',

        'mastodon'          => 'Mastodon',
        'bluesky'           => 'Bluesky',

        'other'             => 'Other'
    );
}


/*
 * =========================================================
 * DATABASE INSTALLATION
 * =========================================================
 */

function rud_crm_server_install_database() {

    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate = $wpdb->get_charset_collate();


    /*
     * ---------------------------------------------------------
     * CUSTOMERS
     * ---------------------------------------------------------
     */

    $table = $wpdb->prefix . 'rudcrm_customers';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

        customer_uuid CHAR(36) NOT NULL,

        customer_number VARCHAR(30) NOT NULL,

        customer_type VARCHAR(30)
            NOT NULL
            DEFAULT 'person',

        title VARCHAR(50) NULL,

        first_name VARCHAR(100) NULL,

        middle_name VARCHAR(100) NULL,

        last_name VARCHAR(100) NULL,

        preferred_name VARCHAR(100) NULL,

        company_name VARCHAR(200) NULL,

        organization_number VARCHAR(100) NULL,

        job_title VARCHAR(150) NULL,

        department VARCHAR(150) NULL,

        status VARCHAR(30)
            NOT NULL
            DEFAULT 'lead',

        created_at DATETIME NOT NULL,

        updated_at DATETIME NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY customer_uuid
            (customer_uuid),

        UNIQUE KEY customer_number
            (customer_number)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CUSTOMER DETAILS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_customer_details';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        birth_date DATE NULL,

        birth_year SMALLINT UNSIGNED NULL,

        gender VARCHAR(50) NULL,

        preferred_language VARCHAR(20) NULL,

        nationality VARCHAR(100) NULL,

        website_url VARCHAR(255) NULL,

        notes LONGTEXT NULL,

        created_at DATETIME NOT NULL,

        updated_at DATETIME NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY customer_id
            (customer_id),

        KEY birth_date
            (birth_date)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * ADDRESSES
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_addresses';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        address_type VARCHAR(50)
            NOT NULL
            DEFAULT 'private',

        company_name VARCHAR(200) NULL,

        address_line_1 VARCHAR(255) NULL,

        address_line_2 VARCHAR(255) NULL,

        address_line_3 VARCHAR(255) NULL,

        postal_code VARCHAR(30) NULL,

        city VARCHAR(150) NULL,

        state_region VARCHAR(150) NULL,

        country_code CHAR(2) NULL,

        is_primary TINYINT(1)
            NOT NULL
            DEFAULT 0,

        created_at DATETIME NOT NULL,

        updated_at DATETIME NOT NULL,

        PRIMARY KEY  (id),

        KEY customer_id
            (customer_id),

        KEY address_type
            (address_type)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CONTACT METHODS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_contact_methods';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        contact_type VARCHAR(50)
            NOT NULL,

        contact_label VARCHAR(100) NULL,

        contact_value VARCHAR(255)
            NOT NULL,

        is_primary TINYINT(1)
            NOT NULL
            DEFAULT 0,

        is_verified TINYINT(1)
            NOT NULL
            DEFAULT 0,

        created_at DATETIME NOT NULL,

        updated_at DATETIME NOT NULL,

        PRIMARY KEY  (id),

        KEY customer_id
            (customer_id),

        KEY contact_type
            (contact_type)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * SOCIAL MEDIA ACCOUNTS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_social_accounts';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        platform VARCHAR(100)
            NOT NULL,

        is_active TINYINT(1)
            NOT NULL
            DEFAULT 1,

        account_name VARCHAR(255) NULL,

        profile_url VARCHAR(500) NULL,

        notes TEXT NULL,

        created_at DATETIME NOT NULL,

        updated_at DATETIME NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY customer_platform
            (customer_id, platform),

        KEY customer_id
            (customer_id),

        KEY platform
            (platform),

        KEY is_active
            (is_active)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CUSTOMER PROFILE IMAGES
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        attachment_id BIGINT UNSIGNED
            NOT NULL,

        image_type VARCHAR(50)
            NOT NULL
            DEFAULT 'profile',

        is_primary TINYINT(1)
            NOT NULL
            DEFAULT 0,

        sort_order SMALLINT UNSIGNED
            NOT NULL
            DEFAULT 1,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY customer_attachment
            (customer_id, attachment_id),

        KEY customer_id
            (customer_id),

        KEY attachment_id
            (attachment_id),

        KEY is_primary
            (is_primary),

        KEY sort_order
            (sort_order)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CONNECTED WEBSITES
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_sites';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        site_uuid CHAR(36)
            NOT NULL,

        site_number VARCHAR(30)
            NOT NULL,

        site_name VARCHAR(200)
            NOT NULL,

        domain VARCHAR(255)
            NOT NULL,

        status VARCHAR(30)
            NOT NULL
            DEFAULT 'active',

        allow_create TINYINT(1)
            NOT NULL
            DEFAULT 0,

        allow_read TINYINT(1)
            NOT NULL
            DEFAULT 0,

        allow_update TINYINT(1)
            NOT NULL
            DEFAULT 0,

        allow_delete TINYINT(1)
            NOT NULL
            DEFAULT 0,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY site_uuid
            (site_uuid),

        UNIQUE KEY site_number
            (site_number),

        UNIQUE KEY domain
            (domain)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CUSTOMER / WEBSITE RELATIONSHIPS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_customer_sites';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        site_id BIGINT UNSIGNED
            NOT NULL,

        source_type VARCHAR(100) NULL,

        source_reference VARCHAR(255) NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY customer_site
            (customer_id, site_id),

        KEY customer_id
            (customer_id),

        KEY site_id
            (site_id)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * API CREDENTIALS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_api_credentials';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        site_id BIGINT UNSIGNED
            NOT NULL,

        client_id VARCHAR(100)
            NOT NULL,

        secret_hash VARCHAR(255)
            NOT NULL,

        status VARCHAR(30)
            NOT NULL
            DEFAULT 'active',

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        last_used_at DATETIME NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY client_id
            (client_id),

        KEY site_id
            (site_id)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * WEBSITE FIELD PERMISSIONS
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_site_field_permissions';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        site_id BIGINT UNSIGNED
            NOT NULL,

        field_key VARCHAR(100)
            NOT NULL,

        can_read TINYINT(1)
            NOT NULL
            DEFAULT 0,

        can_write TINYINT(1)
            NOT NULL
            DEFAULT 0,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY site_field
            (site_id, field_key),

        KEY site_id
            (site_id),

        KEY field_key
            (field_key)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * CUSTOMER ACTIVITY / TIMELINE
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_customer_activity';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        activity_type VARCHAR(50)
            NOT NULL
            DEFAULT 'note',

        title VARCHAR(255)
            NULL,

        content LONGTEXT
            NULL,

        source VARCHAR(100)
            NULL,

        source_reference VARCHAR(255)
            NULL,

        created_by BIGINT UNSIGNED
            NULL,

        activity_date DATETIME
            NOT NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        KEY customer_id
            (customer_id),

        KEY activity_type
            (activity_type),

        KEY activity_date
            (activity_date),

        KEY created_by
            (created_by),

        KEY customer_activity_date
            (customer_id, activity_date)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * PROJECTS
     * ---------------------------------------------------------
     *
     * A project exists independently from customers.
     *
     * Examples:
     * - Et liv med Camping
     * - Motorseiler søker fosterhjem
     * - The Whale Whisperer
     *
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_projects';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        project_uuid CHAR(36)
            NOT NULL,

        project_number VARCHAR(30)
            NOT NULL,

        project_title VARCHAR(255)
            NOT NULL,

        project_type VARCHAR(100)
            NULL,

        status VARCHAR(30)
            NOT NULL
            DEFAULT 'planning',

        start_date DATE
            NULL,

        end_date DATE
            NULL,

        description LONGTEXT
            NULL,

        internal_notes LONGTEXT
            NULL,

        created_by BIGINT UNSIGNED
            NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY project_uuid
            (project_uuid),

        UNIQUE KEY project_number
            (project_number),

        KEY project_title
            (project_title),

        KEY status
            (status),

        KEY start_date
            (start_date),

        KEY created_by
            (created_by)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * PROJECT / CUSTOMER RELATIONSHIPS
     * ---------------------------------------------------------
     *
     * This is the many-to-many connection between projects
     * and existing CRM customers.
     *
     * One customer may belong to several projects.
     * One project may contain many customers.
     *
     * ---------------------------------------------------------
     */

    $table =
        $wpdb->prefix .
        'rudcrm_project_customers';

    $sql = "CREATE TABLE $table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        project_id BIGINT UNSIGNED
            NOT NULL,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        relationship_role VARCHAR(150)
            NULL,

        relationship_status VARCHAR(30)
            NOT NULL
            DEFAULT 'active',

        notes TEXT
            NULL,

        created_by BIGINT UNSIGNED
            NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY project_customer
            (project_id, customer_id),

        KEY project_id
            (project_id),

        KEY customer_id
            (customer_id),

        KEY relationship_status
            (relationship_status),

        KEY created_by
            (created_by)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * ---------------------------------------------------------
     * SAVE DATABASE VERSION
     * ---------------------------------------------------------
     */

    update_option(
        'rud_crm_db_version',
        RUD_CRM_DB_VERSION
    );
}


/*
 * =========================================================
 * DATABASE VERSION CHECK
 * =========================================================
 */

function rud_crm_check_database_version() {

    $installed_version =
        get_option(
            'rud_crm_db_version'
        );

    if (
        $installed_version !==
        RUD_CRM_DB_VERSION
    ) {

        rud_crm_server_install_database();
    }
}


/*
 * =========================================================
 * CUSTOMER IMAGE TABLE SAFETY CHECK
 * =========================================================
 */

function rud_crm_ensure_customer_images_table() {

    global $wpdb;

    $table_name =
        $wpdb->prefix .
        'rudcrm_customer_images';

    $table_exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table_name
            )
        );

    if (
        $table_exists ===
        $table_name
    ) {

        return;
    }

    $charset_collate =
        $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        attachment_id BIGINT UNSIGNED
            NOT NULL,

        image_type VARCHAR(50)
            NOT NULL
            DEFAULT 'profile',

        is_primary TINYINT(1)
            NOT NULL
            DEFAULT 0,

        sort_order SMALLINT UNSIGNED
            NOT NULL
            DEFAULT 1,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY (id),

        UNIQUE KEY customer_attachment
            (customer_id, attachment_id),

        KEY customer_id
            (customer_id),

        KEY attachment_id
            (attachment_id),

        KEY is_primary
            (is_primary),

        KEY sort_order
            (sort_order)

    ) $charset_collate;";

    $wpdb->query(
        $sql
    );
}


/*
 * =========================================================
 * PROJECT TABLES SAFETY CHECK
 * =========================================================
 *
 * This ensures the new project tables are created immediately
 * after this database.php file is installed, even before we
 * change the main plugin database version.
 *
 * =========================================================
 */

function rud_crm_ensure_project_tables() {

    global $wpdb;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $charset_collate =
        $wpdb->get_charset_collate();


    /*
     * PROJECTS
     */

    $projects_table =
        $wpdb->prefix .
        'rudcrm_projects';

    $sql = "CREATE TABLE $projects_table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        project_uuid CHAR(36)
            NOT NULL,

        project_number VARCHAR(30)
            NOT NULL,

        project_title VARCHAR(255)
            NOT NULL,

        project_type VARCHAR(100)
            NULL,

        status VARCHAR(30)
            NOT NULL
            DEFAULT 'planning',

        start_date DATE
            NULL,

        end_date DATE
            NULL,

        description LONGTEXT
            NULL,

        internal_notes LONGTEXT
            NULL,

        created_by BIGINT UNSIGNED
            NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY project_uuid
            (project_uuid),

        UNIQUE KEY project_number
            (project_number),

        KEY project_title
            (project_title),

        KEY status
            (status),

        KEY start_date
            (start_date),

        KEY created_by
            (created_by)

    ) $charset_collate;";

    dbDelta( $sql );


    /*
     * PROJECT / CUSTOMER RELATIONSHIPS
     */

    $project_customers_table =
        $wpdb->prefix .
        'rudcrm_project_customers';

    $sql = "CREATE TABLE $project_customers_table (

        id BIGINT UNSIGNED
            NOT NULL
            AUTO_INCREMENT,

        project_id BIGINT UNSIGNED
            NOT NULL,

        customer_id BIGINT UNSIGNED
            NOT NULL,

        relationship_role VARCHAR(150)
            NULL,

        relationship_status VARCHAR(30)
            NOT NULL
            DEFAULT 'active',

        notes TEXT
            NULL,

        created_by BIGINT UNSIGNED
            NULL,

        created_at DATETIME
            NOT NULL,

        updated_at DATETIME
            NOT NULL,

        PRIMARY KEY  (id),

        UNIQUE KEY project_customer
            (project_id, customer_id),

        KEY project_id
            (project_id),

        KEY customer_id
            (customer_id),

        KEY relationship_status
            (relationship_status),

        KEY created_by
            (created_by)

    ) $charset_collate;";

    dbDelta( $sql );
}


/*
 * Run safety checks when WordPress Admin loads.
 */

add_action(
    'admin_init',
    'rud_crm_ensure_customer_images_table'
);

add_action(
    'admin_init',
    'rud_crm_ensure_project_tables'
);
