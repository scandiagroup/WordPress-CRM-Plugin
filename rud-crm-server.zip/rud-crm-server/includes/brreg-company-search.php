<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * BRØNNØYSUNDREGISTRENE COMPANY SEARCH
 * Version 1.0
 * =========================================================
 *
 * Uses Brønnøysundregistrene Open Data API.
 *
 * Search methods:
 * - Organisation Number
 * - Company Name
 * - Manual Entry
 *
 * Nothing is copied into the CRM until the user clicks:
 * USE THIS COMPANY
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_brreg_can_lookup() {

    if ( ! is_user_logged_in() ) {
        return false;
    }

    if (
        function_exists( 'rud_crm_frontend_user_can_access' )
        &&
        rud_crm_frontend_user_can_access()
    ) {
        return true;
    }

    return current_user_can( 'manage_options' );
}


/*
 * =========================================================
 * API BASE
 * =========================================================
 */

function rud_crm_brreg_api_base() {

    return 'https://data.brreg.no/enhetsregisteret/api/enheter';
}


/*
 * =========================================================
 * COMPANY DETAILS TABLE
 * =========================================================
 *
 * Stores company-specific information that does not belong
 * in the generic customer/person columns.
 *
 * =========================================================
 */

function rud_crm_brreg_company_details_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_company_details';
}


function rud_crm_brreg_install_company_details_table() {

    global $wpdb;

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $table =
        rud_crm_brreg_company_details_table();

    $charset_collate =
        $wpdb->get_charset_collate();

    $sql =
        "CREATE TABLE {$table} (

            id BIGINT UNSIGNED
                NOT NULL
                AUTO_INCREMENT,

            customer_id BIGINT UNSIGNED
                NOT NULL,

            organization_form_code VARCHAR(30)
                NOT NULL
                DEFAULT '',

            organization_form_name VARCHAR(255)
                NOT NULL
                DEFAULT '',

            industry_code VARCHAR(50)
                NOT NULL
                DEFAULT '',

            industry_name VARCHAR(255)
                NOT NULL
                DEFAULT '',

            brreg_synced_at DATETIME
                NULL,

            created_at DATETIME
                NOT NULL,

            updated_at DATETIME
                NOT NULL,

            PRIMARY KEY (id),

            UNIQUE KEY customer_id
                (customer_id),

            KEY organization_form_code
                (organization_form_code),

            KEY industry_code
                (industry_code)

        ) {$charset_collate};";

    dbDelta(
        $sql
    );

    return
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        )
        ===
        $table;
}


function rud_crm_brreg_ensure_company_details_table() {

    global $wpdb;

    $table =
        rud_crm_brreg_company_details_table();

    if (
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        )
        ===
        $table
    ) {
        return true;
    }

    return
        rud_crm_brreg_install_company_details_table();
}


add_action(
    'admin_init',
    'rud_crm_brreg_ensure_company_details_table',
    12
);


add_action(
    'wp_loaded',
    'rud_crm_brreg_ensure_company_details_table',
    12
);


/*
 * =========================================================
 * SAVE COMPANY DETAILS
 * =========================================================
 */

function rud_crm_brreg_save_company_details(
    $customer_id,
    $data = array()
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_brreg_ensure_company_details_table()
    ) {
        return false;
    }

    $table =
        rud_crm_brreg_company_details_table();

    $now =
        current_time(
            'mysql'
        );

    $values =
        array(
            'organization_form_code' =>
                strtoupper(
                    sanitize_text_field(
                        $data['organization_form_code'] ?? ''
                    )
                ),

            'organization_form_name' =>
                sanitize_text_field(
                    $data['organization_form_name'] ?? ''
                ),

            'industry_code' =>
                sanitize_text_field(
                    $data['industry_code'] ?? ''
                ),

            'industry_name' =>
                sanitize_text_field(
                    $data['industry_name'] ?? ''
                ),

            'brreg_synced_at' =>
                ! empty(
                    $data['brreg_synced']
                )
                ? $now
                : null,

            'updated_at' =>
                $now,
        );

    $existing_id =
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$table}
                     WHERE customer_id = %d
                     LIMIT 1",
                    $customer_id
                )
            )
        );

    if (
        $existing_id
    ) {

        return
            false !==
            $wpdb->update(
                $table,
                $values,
                array(
                    'id' =>
                        $existing_id,
                )
            );
    }

    $values['customer_id'] =
        $customer_id;

    $values['created_at'] =
        $now;

    return
        false !==
        $wpdb->insert(
            $table,
            $values
        );
}


/*
 * =========================================================
 * GET COMPANY DETAILS
 * =========================================================
 */

function rud_crm_brreg_get_company_details(
    $customer_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_brreg_ensure_company_details_table()
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                 rud_crm_brreg_company_details_table() .
                 "
                 WHERE customer_id = %d
                 LIMIT 1",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * COMPANY NAME FORMATTING
 * =========================================================
 *
 * BRREG may return legal names in uppercase.
 *
 * Example:
 *
 * OLAF RUDOLFSEN AS
 * ->
 * Olaf Rudolfsen AS
 *
 * The legal organisation abbreviations remain uppercase.
 *
 * =========================================================
 */

function rud_crm_brreg_format_company_name(
    $name
) {

    $name =
        trim(
            sanitize_text_field(
                $name
            )
        );

    if (
        '' ===
        $name
    ) {
        return '';
    }

    /*
     * Only normalize names that are predominantly uppercase.
     * A manually styled/legal name such as eBay Norge AS
     * should not be unnecessarily changed.
     */

    $letters_only =
        preg_replace(
            '/[^\p{L}]/u',
            '',
            $name
        );

    $uppercase_letters =
        preg_replace(
            '/[^\p{Lu}]/u',
            '',
            $letters_only
        );

    $should_convert =
        (
            '' !==
            $letters_only
            &&
            mb_strlen(
                $uppercase_letters,
                'UTF-8'
            )
            >=
            (
                mb_strlen(
                    $letters_only,
                    'UTF-8'
                )
                *
                0.8
            )
        );

    if (
        ! $should_convert
    ) {
        return $name;
    }

    $formatted =
        mb_convert_case(
            mb_strtolower(
                $name,
                'UTF-8'
            ),
            MB_CASE_TITLE,
            'UTF-8'
        );

    /*
     * Preserve common Norwegian organisation abbreviations.
     */

    $abbreviations =
        array(
            'AS',
            'ASA',
            'ENK',
            'ANS',
            'DA',
            'SA',
            'NUF',
            'KF',
            'IKS',
            'BA',
            'SF',
            'STI',
            'FLI',
            'BRL',
            'ESEK',
            'SAM',
            'KTRF',
            'STAT',
            'KOMM',
            'FYLK',
            'ORGL',
            'BEDR'
        );

    foreach (
        $abbreviations
        as
        $abbreviation
    ) {

        $formatted =
            preg_replace(
                '/\b' .
                preg_quote(
                    ucfirst(
                        strtolower(
                            $abbreviation
                        )
                    ),
                    '/'
                ) .
                '\b/u',
                $abbreviation,
                $formatted
            );
    }

    return
        $formatted;
}


/*
 * =========================================================
 * NORMALIZE ADDRESS
 * =========================================================
 */

function rud_crm_brreg_normalize_address( $entity ) {

    $address = array();

    if (
        ! empty( $entity['forretningsadresse'] )
        &&
        is_array( $entity['forretningsadresse'] )
    ) {
        $address = $entity['forretningsadresse'];

    } elseif (
        ! empty( $entity['postadresse'] )
        &&
        is_array( $entity['postadresse'] )
    ) {
        $address = $entity['postadresse'];
    }

    $lines = array();

    if (
        ! empty( $address['adresse'] )
        &&
        is_array( $address['adresse'] )
    ) {

        foreach ( $address['adresse'] as $line ) {

            $line =
                sanitize_text_field(
                    $line
                );

            if ( '' !== $line ) {
                $lines[] = $line;
            }
        }
    }

    return array(
        'address_line_1' =>
            isset( $lines[0] )
            ? $lines[0]
            : '',

        'address_line_2' =>
            count( $lines ) > 1
            ? implode(
                ', ',
                array_slice(
                    $lines,
                    1
                )
            )
            : '',

        'postal_code' =>
            sanitize_text_field(
                $address['postnummer'] ?? ''
            ),

        'city' =>
            sanitize_text_field(
                $address['poststed'] ?? ''
            ),

        'country_code' =>
            strtoupper(
                sanitize_text_field(
                    $address['landkode'] ?? 'NO'
                )
            ),

        'country' =>
            sanitize_text_field(
                $address['land'] ?? 'Norge'
            ),
    );
}


/*
 * =========================================================
 * NORMALIZE ENTITY
 * =========================================================
 */

function rud_crm_brreg_normalize_entity( $entity ) {

    if ( ! is_array( $entity ) ) {
        return array();
    }

    $address =
        rud_crm_brreg_normalize_address(
            $entity
        );

    return array(
        'organization_number' =>
            sanitize_text_field(
                $entity['organisasjonsnummer'] ?? ''
            ),

        'company_name' =>
            rud_crm_brreg_format_company_name(
                $entity['navn'] ?? ''
            ),

        'organization_form_code' =>
            sanitize_text_field(
                $entity['organisasjonsform']['kode'] ?? ''
            ),

        'organization_form' =>
            sanitize_text_field(
                $entity['organisasjonsform']['beskrivelse'] ?? ''
            ),

        'address_line_1' =>
            $address['address_line_1'],

        'address_line_2' =>
            $address['address_line_2'],

        'postal_code' =>
            $address['postal_code'],

        'city' =>
            $address['city'],

        'country_code' =>
            $address['country_code'],

        'country' =>
            $address['country'],

        'industry_code' =>
            sanitize_text_field(
                $entity['naeringskode1']['kode'] ?? ''
            ),

        'industry' =>
            sanitize_text_field(
                $entity['naeringskode1']['beskrivelse'] ?? ''
            ),

        'website' =>
            esc_url_raw(
                $entity['hjemmeside'] ?? ''
            ),

        'email' =>
            sanitize_email(
                $entity['epostadresse'] ?? ''
            ),

        'phone' =>
            sanitize_text_field(
                $entity['telefon'] ?? (
                    $entity['mobil'] ?? ''
                )
            ),
    );
}


/*
 * =========================================================
 * REMOTE REQUEST
 * =========================================================
 */

function rud_crm_brreg_remote_get( $url ) {

    $response =
        wp_remote_get(
            $url,
            array(
                'timeout' =>
                    12,

                'redirection' =>
                    3,

                'headers' =>
                    array(
                        'Accept' =>
                            'application/json',

                        'User-Agent' =>
                            'RUD-CRM-Server/' .
                            (
                                defined( 'RUD_CRM_VERSION' )
                                ? RUD_CRM_VERSION
                                : '1.0'
                            )
                    ),
            )
        );

    if ( is_wp_error( $response ) ) {
        return $response;
    }

    $code =
        wp_remote_retrieve_response_code(
            $response
        );

    if ( 404 === $code ) {

        return new WP_Error(
            'rud_crm_brreg_not_found',
            'No company was found.'
        );
    }

    if (
        $code < 200
        ||
        $code >= 300
    ) {

        return new WP_Error(
            'rud_crm_brreg_http_error',
            sprintf(
                'Brønnøysundregistrene returned HTTP status %d.',
                absint( $code )
            )
        );
    }

    $body =
        json_decode(
            wp_remote_retrieve_body(
                $response
            ),
            true
        );

    if ( ! is_array( $body ) ) {

        return new WP_Error(
            'rud_crm_brreg_invalid_response',
            'Brønnøysundregistrene returned an invalid response.'
        );
    }

    return $body;
}


/*
 * =========================================================
 * AJAX LOOKUP
 * =========================================================
 */

function rud_crm_brreg_ajax_lookup() {

    if ( ! rud_crm_brreg_can_lookup() ) {

        wp_send_json_error(
            array(
                'message' =>
                    'You do not have permission to use company lookup.'
            ),
            403
        );
    }

    check_ajax_referer(
        'rud_crm_brreg_lookup',
        'nonce'
    );

    $mode =
        sanitize_key(
            wp_unslash(
                $_POST['mode'] ?? ''
            )
        );

    $query =
        sanitize_text_field(
            wp_unslash(
                $_POST['query'] ?? ''
            )
        );

    $results =
        array();

    /*
     * -----------------------------------------------------
     * ORGANISATION NUMBER
     * -----------------------------------------------------
     */

    if ( 'orgnr' === $mode ) {

        $orgnr =
            preg_replace(
                '/\D+/',
                '',
                $query
            );

        if (
            ! preg_match(
                '/^\d{9}$/',
                $orgnr
            )
        ) {

            wp_send_json_error(
                array(
                    'message' =>
                        'Enter a valid 9-digit Norwegian organisation number.'
                ),
                400
            );
        }

        $url =
            trailingslashit(
                rud_crm_brreg_api_base()
            )
            .
            rawurlencode(
                $orgnr
            );

        $entity =
            rud_crm_brreg_remote_get(
                $url
            );

        if ( is_wp_error( $entity ) ) {

            wp_send_json_error(
                array(
                    'message' =>
                        $entity->get_error_message()
                ),
                404
            );
        }

        $normalized =
            rud_crm_brreg_normalize_entity(
                $entity
            );

        if ( ! empty( $normalized ) ) {
            $results[] = $normalized;
        }

    /*
     * -----------------------------------------------------
     * COMPANY NAME
     * -----------------------------------------------------
     */

    } elseif ( 'name' === $mode ) {

        if (
            mb_strlen(
                trim(
                    $query
                )
            )
            <
            2
        ) {

            wp_send_json_error(
                array(
                    'message' =>
                        'Enter at least 2 characters of the company name.'
                ),
                400
            );
        }

        $url =
            add_query_arg(
                array(
                    'navn' =>
                        $query,

                    'navnMetodeForSoek' =>
                        'FORTLOEPENDE',

                    'size' =>
                        10,

                    'page' =>
                        0,
                ),
                rud_crm_brreg_api_base()
            );

        $response =
            rud_crm_brreg_remote_get(
                $url
            );

        if ( is_wp_error( $response ) ) {

            wp_send_json_error(
                array(
                    'message' =>
                        $response->get_error_message()
                ),
                500
            );
        }

        $entities =
            $response['_embedded']['enheter']
            ?? array();

        if ( is_array( $entities ) ) {

            foreach ( $entities as $entity ) {

                $normalized =
                    rud_crm_brreg_normalize_entity(
                        $entity
                    );

                if (
                    ! empty(
                        $normalized['organization_number']
                    )
                ) {
                    $results[] = $normalized;
                }
            }
        }

    } else {

        wp_send_json_error(
            array(
                'message' =>
                    'Invalid company search method.'
            ),
            400
        );
    }

    wp_send_json_success(
        array(
            'results' =>
                $results
        )
    );
}


add_action(
    'wp_ajax_rud_crm_brreg_lookup',
    'rud_crm_brreg_ajax_lookup'
);


/*
 * =========================================================
 * LOOKUP INTERFACE
 * =========================================================
 */

function rud_crm_brreg_company_lookup_html() {

    if ( ! is_user_logged_in() ) {
        return '';
    }

    $nonce =
        wp_create_nonce(
            'rud_crm_brreg_lookup'
        );

    ob_start();

    ?>

    <div
        class="rud-crm-brreg-box"
        data-rud-brreg
        data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
        data-nonce="<?php echo esc_attr( $nonce ); ?>"
    >

        <h4>
            Add Norwegian Company
        </h4>

        <p>
            Choose how you want to add the company.
        </p>

        <div class="rud-crm-brreg-methods">

            <label>
                <input
                    type="radio"
                    name="rud_crm_company_entry_method"
                    value="orgnr"
                >
                Search by Organization Number
            </label>

            <label>
                <input
                    type="radio"
                    name="rud_crm_company_entry_method"
                    value="name"
                >
                Search by Company Name
            </label>

            <label>
                <input
                    type="radio"
                    name="rud_crm_company_entry_method"
                    value="manual"
                    checked
                >
                Enter Manually
            </label>

        </div>


        <div
            class="rud-crm-brreg-search-panel"
            data-rud-brreg-panel="orgnr"
            hidden
        >

            <label>
                Norwegian Organization Number
            </label>

            <div class="rud-crm-brreg-search-row">

                <input
                    type="text"
                    inputmode="numeric"
                    maxlength="11"
                    data-rud-brreg-query="orgnr"
                    placeholder="9-digit organization number"
                >

                <button
                    type="button"
                    class="rud-crm-brreg-search-button"
                    data-rud-brreg-search="orgnr"
                >
                    SEARCH
                </button>

            </div>

        </div>


        <div
            class="rud-crm-brreg-search-panel"
            data-rud-brreg-panel="name"
            hidden
        >

            <label>
                Company Name
            </label>

            <div class="rud-crm-brreg-search-row">

                <input
                    type="text"
                    data-rud-brreg-query="name"
                    placeholder="Start typing the registered company name"
                >

                <button
                    type="button"
                    class="rud-crm-brreg-search-button"
                    data-rud-brreg-search="name"
                >
                    SEARCH
                </button>

            </div>

        </div>


        <div
            class="rud-crm-brreg-status"
            data-rud-brreg-status
            aria-live="polite"
        ></div>


        <div
            class="rud-crm-brreg-results"
            data-rud-brreg-results
        ></div>


        <div
            class="rud-crm-brreg-selected"
            data-rud-brreg-selected
            hidden
        ></div>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * FRONT-END ASSETS
 * =========================================================
 */

function rud_crm_brreg_assets() {

    if ( is_admin() ) {
        return;
    }

    $css = '

    .rud-crm-brreg-box {
        margin:0 0 22px;
        padding:20px;
        border:1px solid #d0d5dd;
        border-radius:10px;
        background:#f9fafb;
    }

    .rud-crm-brreg-box h4 {
        margin:0 0 6px;
        font-size:17px;
    }

    .rud-crm-brreg-methods {
        display:flex;
        gap:10px;
        flex-wrap:wrap;
        margin:14px 0;
    }

    .rud-crm-brreg-methods label {
        display:flex;
        align-items:center;
        gap:7px;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        cursor:pointer;
    }

    .rud-crm-brreg-methods input {
        width:auto !important;
        margin:0;
    }

    .rud-crm-brreg-search-panel {
        margin-top:14px;
    }

    .rud-crm-brreg-search-row {
        display:grid;
        grid-template-columns:1fr auto;
        gap:8px;
        margin-top:6px;
    }

    .rud-crm-brreg-search-button,
    .rud-crm-brreg-use-button {
        border:0;
        border-radius:7px;
        background:#1d2939;
        color:#fff;
        padding:10px 15px;
        cursor:pointer;
        font-weight:700;
    }

    .rud-crm-brreg-status {
        margin-top:12px;
        font-weight:600;
    }

    .rud-crm-brreg-result {
        margin-top:12px;
        padding:15px;
        border:1px solid #eaecf0;
        border-radius:8px;
        background:#fff;
    }

    .rud-crm-brreg-result-name {
        display:block;
        font-size:16px;
        margin-bottom:4px;
    }

    .rud-crm-brreg-result-meta {
        display:block;
        margin-bottom:3px;
        font-size:13px;
        opacity:.75;
    }

    .rud-crm-brreg-use-button {
        margin-top:10px;
    }

    .rud-crm-brreg-selected {
        margin-top:14px;
        padding:13px 15px;
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    @media (max-width:650px) {

        .rud-crm-brreg-search-row {
            grid-template-columns:1fr;
        }

        .rud-crm-brreg-methods {
            display:block;
        }

        .rud-crm-brreg-methods label {
            margin-bottom:8px;
        }
    }

    ';

    wp_register_style(
        'rud-crm-brreg',
        false,
        array(),
        defined( 'RUD_CRM_VERSION' )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-brreg'
    );

    wp_add_inline_style(
        'rud-crm-brreg',
        $css
    );


    $js = <<<'JS'
(function() {

    function rudBrregEscapeText(value) {
        return value == null ? '' : String(value);
    }

    function rudBrregField(form, name) {
        return form
            ? form.querySelector('[name="' + name + '"]')
            : null;
    }

    function rudBrregFillField(form, name, value) {

        var field =
            rudBrregField(
                form,
                name
            );

        if (!field) {
            return;
        }

        field.value =
            value || '';

        field.dispatchEvent(
            new Event(
                'change',
                {
                    bubbles:true
                }
            )
        );
    }

    function rudBrregUseCompany(box, company) {

        var form =
            box.closest('form');

        if (!form) {
            return;
        }

        rudBrregFillField(
            form,
            'company_name',
            company.company_name
        );

        rudBrregFillField(
            form,
            'organization_number',
            company.organization_number
        );

        rudBrregFillField(
            form,
            'organization_form_code',
            company.organization_form_code
        );

        rudBrregFillField(
            form,
            'organization_form_name',
            company.organization_form
        );

        rudBrregFillField(
            form,
            'industry_code',
            company.industry_code
        );

        rudBrregFillField(
            form,
            'industry_name',
            company.industry
        );

        rudBrregFillField(
            form,
            'rud_crm_brreg_selected',
            '1'
        );

        rudBrregFillField(
            form,
            'address_line_1',
            company.address_line_1
        );

        rudBrregFillField(
            form,
            'address_line_2',
            company.address_line_2
        );

        rudBrregFillField(
            form,
            'postal_code',
            company.postal_code
        );

        rudBrregFillField(
            form,
            'city',
            company.city
        );

        rudBrregFillField(
            form,
            'country_code',
            company.country_code || 'NO'
        );

        var selected =
            box.querySelector(
                '[data-rud-brreg-selected]'
            );

        if (selected) {

            selected.hidden =
                false;

            selected.textContent =
                'Selected: ' +
                rudBrregEscapeText(
                    company.company_name
                ) +
                ' — Org. No. ' +
                rudBrregEscapeText(
                    company.organization_number
                );
        }

        var status =
            box.querySelector(
                '[data-rud-brreg-status]'
            );

        if (status) {
            status.textContent =
                'Company information has been copied into the CRM fields. Review the information before saving.';
        }
    }

    function rudBrregRenderResults(box, companies) {

        var results =
            box.querySelector(
                '[data-rud-brreg-results]'
            );

        if (!results) {
            return;
        }

        results.innerHTML =
            '';

        if (
            !Array.isArray(companies)
            ||
            companies.length === 0
        ) {

            var none =
                document.createElement('div');

            none.className =
                'rud-crm-brreg-result';

            none.textContent =
                'No matching companies were found.';

            results.appendChild(
                none
            );

            return;
        }

        companies.forEach(
            function(company) {

                var card =
                    document.createElement('div');

                card.className =
                    'rud-crm-brreg-result';


                var name =
                    document.createElement('strong');

                name.className =
                    'rud-crm-brreg-result-name';

                name.textContent =
                    company.company_name || '';

                card.appendChild(
                    name
                );


                var org =
                    document.createElement('span');

                org.className =
                    'rud-crm-brreg-result-meta';

                org.textContent =
                    'Org. No. ' +
                    (
                        company.organization_number
                        || ''
                    );

                card.appendChild(
                    org
                );


                if (
                    company.organization_form
                    ||
                    company.organization_form_code
                ) {

                    var formMeta =
                        document.createElement('span');

                    formMeta.className =
                        'rud-crm-brreg-result-meta';

                    formMeta.textContent =
                        [
                            company.organization_form_code,
                            company.organization_form
                        ]
                        .filter(Boolean)
                        .join(' — ');

                    card.appendChild(
                        formMeta
                    );
                }


                var addressParts =
                    [
                        company.address_line_1,
                        company.postal_code,
                        company.city
                    ]
                    .filter(Boolean);

                if (
                    addressParts.length
                ) {

                    var address =
                        document.createElement('span');

                    address.className =
                        'rud-crm-brreg-result-meta';

                    address.textContent =
                        addressParts.join(', ');

                    card.appendChild(
                        address
                    );
                }


                if (
                    company.industry
                ) {

                    var industry =
                        document.createElement('span');

                    industry.className =
                        'rud-crm-brreg-result-meta';

                    industry.textContent =
                        (
                            company.industry_code
                            ? company.industry_code + ' — '
                            : ''
                        )
                        +
                        company.industry;

                    card.appendChild(
                        industry
                    );
                }


                var use =
                    document.createElement('button');

                use.type =
                    'button';

                use.className =
                    'rud-crm-brreg-use-button';

                use.textContent =
                    'USE THIS COMPANY';

                use.addEventListener(
                    'click',
                    function() {

                        rudBrregUseCompany(
                            box,
                            company
                        );
                    }
                );

                card.appendChild(
                    use
                );

                results.appendChild(
                    card
                );
            }
        );
    }

    function rudBrregSearch(box, mode) {

        var input =
            box.querySelector(
                '[data-rud-brreg-query="' +
                mode +
                '"]'
            );

        var status =
            box.querySelector(
                '[data-rud-brreg-status]'
            );

        var results =
            box.querySelector(
                '[data-rud-brreg-results]'
            );

        if (
            !input
            ||
            !status
            ||
            !results
        ) {
            return;
        }

        var query =
            input.value.trim();

        if (!query) {

            status.textContent =
                'Enter a search value first.';

            return;
        }

        status.textContent =
            'Searching Brønnøysundregistrene...';

        results.innerHTML =
            '';

        var data =
            new URLSearchParams();

        data.append(
            'action',
            'rud_crm_brreg_lookup'
        );

        data.append(
            'nonce',
            box.dataset.nonce || ''
        );

        data.append(
            'mode',
            mode
        );

        data.append(
            'query',
            query
        );

        fetch(
            box.dataset.ajaxUrl,
            {
                method:'POST',
                credentials:'same-origin',
                headers:{
                    'Content-Type':
                        'application/x-www-form-urlencoded; charset=UTF-8'
                },
                body:data.toString()
            }
        )
        .then(
            function(response) {
                return response.json();
            }
        )
        .then(
            function(payload) {

                if (
                    !payload
                    ||
                    !payload.success
                ) {

                    var message =
                        payload
                        &&
                        payload.data
                        &&
                        payload.data.message
                        ? payload.data.message
                        : 'The company lookup could not be completed.';

                    status.textContent =
                        message;

                    return;
                }

                var companies =
                    payload.data
                    &&
                    Array.isArray(
                        payload.data.results
                    )
                    ? payload.data.results
                    : [];

                status.textContent =
                    companies.length
                    ? companies.length +
                      ' result(s) found.'
                    : 'No matching companies were found.';

                rudBrregRenderResults(
                    box,
                    companies
                );
            }
        )
        .catch(
            function() {

                status.textContent =
                    'Could not contact Brønnøysundregistrene. Please try again.';
            }
        );
    }

    function rudBrregSetMode(box, mode) {

        box
            .querySelectorAll(
                '[data-rud-brreg-panel]'
            )
            .forEach(
                function(panel) {

                    panel.hidden =
                        panel.dataset.rudBrregPanel !==
                        mode;
                }
            );

        var results =
            box.querySelector(
                '[data-rud-brreg-results]'
            );

        var status =
            box.querySelector(
                '[data-rud-brreg-status]'
            );

        if (results) {
            results.innerHTML = '';
        }

        if (status) {

            status.textContent =
                mode === 'manual'
                ? 'Manual entry selected. Enter the company information directly in the CRM fields below.'
                : '';
        }
    }

    function rudBrregInit(box) {

        if (
            !box
            ||
            box.dataset.rudBrregReady === '1'
        ) {
            return;
        }

        box.dataset.rudBrregReady =
            '1';

        box
            .querySelectorAll(
                'input[name="rud_crm_company_entry_method"]'
            )
            .forEach(
                function(radio) {

                    radio.addEventListener(
                        'change',
                        function() {

                            if (radio.checked) {

                                rudBrregSetMode(
                                    box,
                                    radio.value
                                );
                            }
                        }
                    );
                }
            );

        box
            .querySelectorAll(
                '[data-rud-brreg-search]'
            )
            .forEach(
                function(button) {

                    button.addEventListener(
                        'click',
                        function() {

                            rudBrregSearch(
                                box,
                                button.dataset.rudBrregSearch
                            );
                        }
                    );
                }
            );

        box
            .querySelectorAll(
                '[data-rud-brreg-query]'
            )
            .forEach(
                function(input) {

                    input.addEventListener(
                        'keydown',
                        function(event) {

                            if (
                                event.key ===
                                'Enter'
                            ) {

                                event.preventDefault();

                                rudBrregSearch(
                                    box,
                                    input.dataset.rudBrregQuery
                                );
                            }
                        }
                    );
                }
            );

        var checked =
            box.querySelector(
                'input[name="rud_crm_company_entry_method"]:checked'
            );

        rudBrregSetMode(
            box,
            checked
            ? checked.value
            : 'manual'
        );
    }

    function rudBrregInitAll(context) {

        (
            context || document
        )
        .querySelectorAll(
            '[data-rud-brreg]'
        )
        .forEach(
            rudBrregInit
        );
    }

    document.addEventListener(
        'DOMContentLoaded',
        function() {

            rudBrregInitAll(
                document
            );
        }
    );

    window.rudCrmInitBrreg =
        rudBrregInitAll;

})();
JS;

    wp_register_script(
        'rud-crm-brreg',
        false,
        array(),
        defined( 'RUD_CRM_VERSION' )
        ? RUD_CRM_VERSION
        : '1.0',
        true
    );

    wp_enqueue_script(
        'rud-crm-brreg'
    );

    wp_add_inline_script(
        'rud-crm-brreg',
        $js,
        'after'
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_brreg_assets',
    30
);