<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END TASKS / REMINDERS / TO DO LIST
 * Version 1.4
 * =========================================================
 *
 * Provides:
 * - TO DO LIST on Customer Open Profile
 * - Add Task
 * - Edit Task
 * - Mark Done
 * - Reopen
 * - Delete
 *
 * Reminder delivery by CRM / Email / SMS will be connected
 * in later modules.
 *
 * =========================================================
 */


/*
 * =========================================================
 * PERMISSION
 * =========================================================
 */

function rud_crm_frontend_tasks_can_manage_customer(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! is_user_logged_in()
    ) {
        return false;
    }

    /*
     * Use the same edit-permission logic as Edit Customer.
     * This supports RUD CRM Admin levels as well as customer owners.
     */

    if (
        function_exists(
            'rud_crm_frontend_edit_can_edit'
        )
    ) {

        return (bool)
            rud_crm_frontend_edit_can_edit(
                $customer_id
            );
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_user_owns_customer'
        )
        &&
        rud_crm_user_owns_customer(
            get_current_user_id(),
            $customer_id
        )
    ) {
        return true;
    }

    return false;
}


/*
 * =========================================================
 * CUSTOMER PROFILE URL
 * =========================================================
 */

function rud_crm_frontend_tasks_customer_url(
    $customer_id,
    $args = array()
) {

    $url =
        add_query_arg(
            array(
                'rud_customer_id' =>
                    absint(
                        $customer_id
                    ),
            ),
            home_url(
                '/customer-crm/'
            )
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * FORM DATA
 * =========================================================
 */

function rud_crm_frontend_task_request_data() {

    return array(

        'title' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['title']
                    ?? ''
                )
            ),

        'description' =>
            sanitize_textarea_field(
                wp_unslash(
                    $_POST['description']
                    ?? ''
                )
            ),

        'task_type' =>
            sanitize_key(
                wp_unslash(
                    $_POST['task_type']
                    ?? 'general'
                )
            ),

        'status' =>
            sanitize_key(
                wp_unslash(
                    $_POST['status']
                    ?? 'active'
                )
            ),

        'priority' =>
            sanitize_key(
                wp_unslash(
                    $_POST['priority']
                    ?? 'normal'
                )
            ),

        'customer_id' =>
            absint(
                $_POST['rud_customer_id']
                ?? 0
            ),

        'contact_id' =>
            absint(
                $_POST['contact_id']
                ?? 0
            ),

        'project_id' =>
            absint(
                $_POST['project_id']
                ?? 0
            ),

        'assigned_user_id' =>
            get_current_user_id(),

        'due_date' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['due_date']
                    ?? ''
                )
            ),

        'due_time' =>
            sanitize_text_field(
                wp_unslash(
                    $_POST['due_time']
                    ?? ''
                )
            ),

        'reminder_type' =>
            sanitize_key(
                wp_unslash(
                    $_POST['reminder_type']
                    ?? 'none'
                )
            ),

        'reminder_custom_minutes' =>
            absint(
                $_POST['reminder_custom_minutes']
                ?? 0
            ),

        'notify_crm' =>
            ! empty(
                $_POST['notify_crm']
            )
            ? 1
            : 0,

        'notify_email' =>
            ! empty(
                $_POST['notify_email']
            )
            ? 1
            : 0,

        'notify_sms' =>
            ! empty(
                $_POST['notify_sms']
            )
            ? 1
            : 0,

        'email_template_id' =>
            absint(
                $_POST['email_template_id']
                ?? 0
            ),

        'sms_template_id' =>
            absint(
                $_POST['sms_template_id']
                ?? 0
            ),
    );
}


/*
 * =========================================================
 * ADD TASK
 * =========================================================
 */

function rud_crm_frontend_process_add_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'add_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'You do not have permission to add tasks for this customer.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_add_task_' .
            $customer_id
        )
    ) {

        wp_die(
            esc_html__(
                'Security verification failed.',
                'rud-crm-server'
            )
        );
    }

    $result =
        rud_crm_create_task(
            rud_crm_frontend_task_request_data()
        );

    $args =
        is_wp_error(
            $result
        )
        ? array(
            'rud_task_error' =>
                $result->get_error_code(),
        )
        : array(
            'rud_task_message' =>
                'added',
        );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            $args
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_add_task',
    41
);


/*
 * =========================================================
 * UPDATE TASK
 * =========================================================
 */

function rud_crm_frontend_process_update_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'update_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['rud_task_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return;
    }

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
        ||
        absint(
            $task->customer_id
        )
        !==
        $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_update_task_' .
            $task_id
        )
    ) {
        return;
    }

    $result =
        rud_crm_update_task(
            $task_id,
            rud_crm_frontend_task_request_data()
        );

    $args =
        is_wp_error(
            $result
        )
        ? array(
            'rud_task_error' =>
                $result->get_error_code(),

            'rud_edit_task' =>
                $task_id,
        )
        : array(
            'rud_task_message' =>
                'updated',
        );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            $args
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_update_task',
    42
);


/*
 * =========================================================
 * SNOOZE TASK
 * =========================================================
 */

function rud_crm_frontend_process_snooze_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'snooze_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['rud_task_id']
            ?? 0
        );

    $snooze_minutes =
        absint(
            $_POST['snooze_minutes']
            ?? 60
        );

    if (
        ! in_array(
            $snooze_minutes,
            array(
                60,
                240,
                1440,
                4320,
                10080,
            ),
            true
        )
    ) {
        $snooze_minutes = 60;
    }

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return;
    }

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
        ||
        absint(
            $task->customer_id
        )
        !==
        $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_snooze_task_' .
            $task_id
        )
    ) {
        return;
    }

    $until =
        wp_date(
            'Y-m-d H:i:s',
            current_time(
                'timestamp'
            )
            +
            (
                $snooze_minutes *
                MINUTE_IN_SECONDS
            )
        );

    rud_crm_snooze_task(
        $task_id,
        $until
    );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            array(
                'rud_task_message' =>
                    'snoozed',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_snooze_task',
    43
);


/*
 * =========================================================
 * MARK DONE
 * =========================================================
 */

function rud_crm_frontend_process_complete_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'complete_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['rud_task_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return;
    }

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
        ||
        absint(
            $task->customer_id
        )
        !==
        $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_complete_task_' .
            $task_id
        )
    ) {
        return;
    }

    rud_crm_complete_task(
        $task_id
    );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            array(
                'rud_task_message' =>
                    'completed',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_complete_task',
    44
);


/*
 * =========================================================
 * REOPEN TASK
 * =========================================================
 */

function rud_crm_frontend_process_reopen_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'reopen_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['rud_task_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return;
    }

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
        ||
        absint(
            $task->customer_id
        )
        !==
        $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_reopen_task_' .
            $task_id
        )
    ) {
        return;
    }

    rud_crm_reopen_task(
        $task_id
    );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            array(
                'rud_task_message' =>
                    'reopened',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_reopen_task',
    45
);


/*
 * =========================================================
 * DELETE TASK
 * =========================================================
 */

function rud_crm_frontend_process_delete_task() {

    if (
        empty(
            $_POST['rud_crm_task_action']
        )
        ||
        'delete_task' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_task_action']
            )
        )
    ) {
        return;
    }

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    $task_id =
        absint(
            $_POST['rud_task_id']
            ?? 0
        );

    if (
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return;
    }

    $task =
        rud_crm_get_task(
            $task_id
        );

    if (
        ! $task
        ||
        absint(
            $task->customer_id
        )
        !==
        $customer_id
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_task_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_task_nonce']
                )
            ),
            'rud_crm_delete_task_' .
            $task_id
        )
    ) {
        return;
    }

    rud_crm_delete_task(
        $task_id
    );

    wp_safe_redirect(
        rud_crm_frontend_tasks_customer_url(
            $customer_id,
            array(
                'rud_task_message' =>
                    'deleted',
            )
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_frontend_process_delete_task',
    46
);


/*
 * =========================================================
 * SELECT HELPER
 * =========================================================
 */

function rud_crm_frontend_task_select(
    $name,
    $options,
    $selected = ''
) {

    ob_start();

    ?>

    <select name="<?php echo esc_attr( $name ); ?>">

        <?php foreach ( $options as $value => $label ) : ?>

            <option
                value="<?php echo esc_attr( $value ); ?>"
                <?php selected( $selected, $value ); ?>
            >
                <?php echo esc_html( $label ); ?>
            </option>

        <?php endforeach; ?>

    </select>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CONTACT PERSON OPTIONS
 * =========================================================
 */

function rud_crm_frontend_task_contact_options(
    $customer_id
) {

    $contacts =
        function_exists(
            'rud_crm_get_company_contacts'
        )
        ? rud_crm_get_company_contacts(
            $customer_id
        )
        : array();

    $options =
        array(
            0 =>
                'No Contact Person',
        );

    foreach (
        $contacts
        as
        $contact
    ) {

        $name =
            trim(
                implode(
                    ' ',
                    array_filter(
                        array(
                            $contact->first_name ?? '',
                            $contact->middle_name ?? '',
                            $contact->last_name ?? '',
                        )
                    )
                )
            );

        if (
            $name
        ) {

            $options[
                absint(
                    $contact->id
                )
            ] =
                $name;
        }
    }

    return $options;
}


/*
 * =========================================================
 * PROJECT OPTIONS
 * =========================================================
 */

function rud_crm_frontend_task_project_options(
    $customer_id
) {

    $projects =
        function_exists(
            'rud_crm_get_customer_projects'
        )
        ? rud_crm_get_customer_projects(
            $customer_id
        )
        : array();

    $options =
        array(
            0 =>
                'No Project',
        );

    foreach (
        $projects
        as
        $project
    ) {

        $label =
            $project->project_title
            ??
            $project->title
            ??
            $project->project_number
            ??
            (
                'Project #' .
                absint(
                    $project->id
                    ?? 0
                )
            );

        $options[
            absint(
                $project->id
                ?? $project->project_id
                ?? 0
            )
        ] =
            $label;
    }

    return $options;
}


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_frontend_tasks_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_task_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_task_error']
                ?? ''
            )
        );

    $messages =
        array(

            'added' =>
                'Task added.',

            'updated' =>
                'Task updated.',

            'snoozed' =>
                'Task snoozed.',

            'completed' =>
                'Task marked as completed.',

            'reopened' =>
                'Task reopened.',

            'deleted' =>
                'Task deleted.',
        );

    if (
        isset(
            $messages[
                $message
            ]
        )
    ) {

        return
            '<div class="rud-crm-task-message rud-crm-task-success">' .
            esc_html(
                $messages[
                    $message
                ]
            ) .
            '</div>';
    }

    if (
        $error
    ) {

        return
            '<div class="rud-crm-task-message rud-crm-task-error">' .
            'The task could not be saved.' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * TO DO LIST
 * =========================================================
 */

function rud_crm_frontend_todo_list(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! function_exists(
            'rud_crm_get_tasks'
        )
        ||
        ! rud_crm_frontend_tasks_can_manage_customer(
            $customer_id
        )
    ) {
        return '';
    }

    $tasks =
        rud_crm_get_tasks(
            array(
                'customer_id' =>
                    $customer_id,

                'include_completed' =>
                    true,

                'limit' =>
                    100,
            )
        );

    $statuses =
        rud_crm_task_statuses();

    $types =
        rud_crm_task_types();

    $priorities =
        rud_crm_task_priorities();

    $reminders =
        rud_crm_task_reminder_options();

    $email_templates =
        function_exists(
            'rud_crm_get_email_templates'
        )
        ? rud_crm_get_email_templates(
            'active'
        )
        : array();

    $email_template_options =
        array(
            0 =>
                'No Email Template',
        );

    foreach (
        $email_templates
        as
        $email_template
    ) {

        $email_template_options[
            absint(
                $email_template->id
            )
        ] =
            $email_template->template_name;
    }

    $sms_templates =
        function_exists(
            'rud_crm_get_sms_templates'
        )
        ? rud_crm_get_sms_templates(
            'active'
        )
        : array();

    $sms_template_options =
        array(
            0 =>
                'No SMS Template',
        );

    foreach (
        $sms_templates
        as
        $sms_template
    ) {

        $sms_template_options[
            absint(
                $sms_template->id
            )
        ] =
            $sms_template->template_name;
    }

    $contact_options =
        rud_crm_frontend_task_contact_options(
            $customer_id
        );

    $project_options =
        rud_crm_frontend_task_project_options(
            $customer_id
        );

    $edit_task_id =
        absint(
            $_GET['rud_edit_task']
            ?? 0
        );

    $edit_task =
        null;

    if (
        $edit_task_id
    ) {

        $candidate =
            rud_crm_get_task(
                $edit_task_id
            );

        if (
            $candidate
            &&
            absint(
                $candidate->customer_id
            )
            ===
            $customer_id
        ) {
            $edit_task =
                $candidate;
        }
    }

    ob_start();

    ?>

    <section class="rud-crm-todo-section">

        <div class="rud-crm-todo-header">

            <div>

                <h2>
                    TO DO LIST
                </h2>

                <p>
                    Tasks, follow-ups, meetings, calls and reminders connected to this customer.
                </p>

            </div>

        </div>

        <?php
        echo rud_crm_frontend_tasks_message_html();
        ?>

        <?php if ( ! empty( $tasks ) ) : ?>

            <div class="rud-crm-todo-list">

                <?php foreach ( $tasks as $task ) : ?>

                    <?php

                    $display_status =
                        rud_crm_task_display_status(
                            $task
                        );

                    $type_label =
                        $types[
                            $task->task_type
                        ]
                        ??
                        ucfirst(
                            str_replace(
                                '_',
                                ' ',
                                $task->task_type
                            )
                        );

                    $priority_label =
                        $priorities[
                            $task->priority
                        ]
                        ??
                        ucfirst(
                            $task->priority
                        );

                    $due_label = '';

                    if (
                        ! empty(
                            $task->due_at
                        )
                    ) {

                        $timestamp =
                            strtotime(
                                $task->due_at
                            );

                        if (
                            $timestamp
                        ) {

                            $due_label =
                                wp_date(
                                    'd M Y - H:i',
                                    $timestamp
                                );
                        }
                    }

                    ?>

                    <article class="rud-crm-todo-item">

                        <div class="rud-crm-todo-main">

                            <div class="rud-crm-todo-title-row">

                                <strong class="rud-crm-todo-title">
                                    <?php echo esc_html( $task->title ); ?>
                                </strong>

                                <span class="rud-crm-task-status rud-crm-task-status-<?php echo esc_attr( sanitize_html_class( strtolower( str_replace( ' ', '-', $display_status ) ) ) ); ?>">
                                    <?php echo esc_html( $display_status ); ?>
                                </span>

                                <span class="rud-crm-task-priority rud-crm-task-priority-<?php echo esc_attr( sanitize_html_class( $task->priority ) ); ?>">
                                    <?php echo esc_html( $priority_label ); ?>
                                </span>

                            </div>

                            <div class="rud-crm-todo-meta">

                                <span>
                                    Type:
                                    <strong><?php echo esc_html( $type_label ); ?></strong>
                                </span>

                                <?php if ( $due_label ) : ?>

                                    <span>
                                        Due:
                                        <strong><?php echo esc_html( $due_label ); ?></strong>
                                    </span>

                                <?php endif; ?>

                                <?php if ( ! empty( $task->contact_id ) && isset( $contact_options[ $task->contact_id ] ) ) : ?>

                                    <span>
                                        Contact:
                                        <strong><?php echo esc_html( $contact_options[ $task->contact_id ] ); ?></strong>
                                    </span>

                                <?php endif; ?>

                                <?php if ( ! empty( $task->project_id ) && isset( $project_options[ $task->project_id ] ) ) : ?>

                                    <span>
                                        Project:
                                        <strong><?php echo esc_html( $project_options[ $task->project_id ] ); ?></strong>
                                    </span>

                                <?php endif; ?>

                            </div>

                            <?php if ( ! empty( $task->description ) ) : ?>

                                <div class="rud-crm-todo-description">
                                    <?php echo nl2br( esc_html( $task->description ) ); ?>
                                </div>

                            <?php endif; ?>

                        </div>

                        <div class="rud-crm-todo-actions">

                            <a
                                href="<?php
                                echo esc_url(
                                    rud_crm_frontend_tasks_customer_url(
                                        $customer_id,
                                        array(
                                            'rud_edit_task' =>
                                                $task->id,
                                        )
                                    )
                                );
                                ?>"
                                class="rud-crm-task-action-link"
                            >
                                EDIT
                            </a>

                            <?php if ( ! in_array( $task->status, array( 'completed', 'cancelled' ), true ) ) : ?>

                                <form method="post" class="rud-crm-task-snooze-form">

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_snooze_task_' .
                                        $task->id,
                                        'rud_crm_task_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_task_action"
                                        value="snooze_task"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_customer_id"
                                        value="<?php echo esc_attr( $customer_id ); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_task_id"
                                        value="<?php echo esc_attr( $task->id ); ?>"
                                    >

                                    <select name="snooze_minutes">
                                        <option value="60">1 Hour</option>
                                        <option value="240">4 Hours</option>
                                        <option value="1440">1 Day</option>
                                        <option value="4320">3 Days</option>
                                        <option value="10080">1 Week</option>
                                    </select>

                                    <button type="submit">
                                        SNOOZE
                                    </button>

                                </form>

                            <?php endif; ?>

                            <?php if ( 'completed' !== $task->status ) : ?>

                                <form method="post">

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_complete_task_' .
                                        $task->id,
                                        'rud_crm_task_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_task_action"
                                        value="complete_task"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_customer_id"
                                        value="<?php echo esc_attr( $customer_id ); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_task_id"
                                        value="<?php echo esc_attr( $task->id ); ?>"
                                    >

                                    <button type="submit">
                                        MARK DONE
                                    </button>

                                </form>

                            <?php else : ?>

                                <form method="post">

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_reopen_task_' .
                                        $task->id,
                                        'rud_crm_task_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_task_action"
                                        value="reopen_task"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_customer_id"
                                        value="<?php echo esc_attr( $customer_id ); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="rud_task_id"
                                        value="<?php echo esc_attr( $task->id ); ?>"
                                    >

                                    <button type="submit">
                                        REOPEN
                                    </button>

                                </form>

                            <?php endif; ?>

                            <form method="post">

                                <?php
                                wp_nonce_field(
                                    'rud_crm_delete_task_' .
                                    $task->id,
                                    'rud_crm_task_nonce'
                                );
                                ?>

                                <input
                                    type="hidden"
                                    name="rud_crm_task_action"
                                    value="delete_task"
                                >

                                <input
                                    type="hidden"
                                    name="rud_customer_id"
                                    value="<?php echo esc_attr( $customer_id ); ?>"
                                >

                                <input
                                    type="hidden"
                                    name="rud_task_id"
                                    value="<?php echo esc_attr( $task->id ); ?>"
                                >

                                <button
                                    type="submit"
                                    class="rud-crm-task-delete"
                                    onclick="return confirm('Delete this task?');"
                                >
                                    DELETE
                                </button>

                            </form>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else : ?>

            <div class="rud-crm-todo-empty">
                No tasks have been added yet.
            </div>

        <?php endif; ?>


        <?php if ( $edit_task ) : ?>

            <div class="rud-crm-add-task-panel rud-crm-edit-task-panel">

                <div class="rud-crm-edit-task-heading">

                    <strong>
                        EDIT TASK / REMINDER
                    </strong>

                    <a
                        href="<?php echo esc_url( rud_crm_frontend_tasks_customer_url( $customer_id ) ); ?>"
                    >
                        Cancel
                    </a>

                </div>

                <div class="rud-crm-add-task-form">

                    <form method="post">

                        <?php
                        wp_nonce_field(
                            'rud_crm_update_task_' .
                            $edit_task->id,
                            'rud_crm_task_nonce'
                        );
                        ?>

                        <input
                            type="hidden"
                            name="rud_crm_task_action"
                            value="update_task"
                        >

                        <input
                            type="hidden"
                            name="rud_customer_id"
                            value="<?php echo esc_attr( $customer_id ); ?>"
                        >

                        <input
                            type="hidden"
                            name="rud_task_id"
                            value="<?php echo esc_attr( $edit_task->id ); ?>"
                        >

                        <div class="rud-crm-task-form-grid">

                            <div class="rud-crm-task-wide">
                                <label>Task Title</label>
                                <input
                                    type="text"
                                    name="title"
                                    required
                                    value="<?php echo esc_attr( $edit_task->title ); ?>"
                                >
                            </div>

                            <div>
                                <label>Task Type</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'task_type',
                                    $types,
                                    $edit_task->task_type
                                );
                                ?>
                            </div>

                            <div>
                                <label>Status</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'status',
                                    $statuses,
                                    $edit_task->status
                                );
                                ?>
                            </div>

                            <div>
                                <label>Priority</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'priority',
                                    $priorities,
                                    $edit_task->priority
                                );
                                ?>
                            </div>

                            <div>
                                <label>Contact Person</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'contact_id',
                                    $contact_options,
                                    absint( $edit_task->contact_id )
                                );
                                ?>
                            </div>

                            <div>
                                <label>Project</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'project_id',
                                    $project_options,
                                    absint( $edit_task->project_id )
                                );
                                ?>
                            </div>

                            <div>
                                <label>Due Date</label>
                                <input
                                    type="date"
                                    name="due_date"
                                    value="<?php echo esc_attr( $edit_task->due_date ?? '' ); ?>"
                                >
                            </div>

                            <div>
                                <label>Due Time</label>
                                <input
                                    type="time"
                                    name="due_time"
                                    value="<?php echo esc_attr( ! empty( $edit_task->due_time ) ? substr( $edit_task->due_time, 0, 5 ) : '' ); ?>"
                                >
                            </div>

                            <div>
                                <label>Reminder</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'reminder_type',
                                    $reminders,
                                    $edit_task->reminder_type
                                );
                                ?>
                            </div>

                            <div>
                                <label>Email Template</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'email_template_id',
                                    $email_template_options,
                                    absint(
                                        $edit_task->email_template_id
                                        ?? 0
                                    )
                                );
                                ?>
                                <small class="rud-crm-task-field-help">
                                    Used only when Email reminder delivery is checked.
                                </small>
                            </div>

                            <div>
                                <label>SMS Template</label>
                                <?php
                                echo rud_crm_frontend_task_select(
                                    'sms_template_id',
                                    $sms_template_options,
                                    absint(
                                        $edit_task->sms_template_id
                                        ?? 0
                                    )
                                );
                                ?>
                                <small class="rud-crm-task-field-help">
                                    Used only when SMS reminder delivery is checked.
                                </small>
                            </div>

                            <div class="rud-crm-task-wide">
                                <label>Task Note</label>
                                <textarea
                                    name="description"
                                    rows="5"
                                ><?php echo esc_textarea( $edit_task->description ); ?></textarea>
                            </div>

                            <div class="rud-crm-task-wide rud-crm-task-notifications">

                                <label>Reminder Delivery</label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_crm"
                                        value="1"
                                        <?php checked( $edit_task->notify_crm, 1 ); ?>
                                    >
                                    CRM Notification
                                </label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_email"
                                        value="1"
                                        <?php checked( $edit_task->notify_email, 1 ); ?>
                                    >
                                    Email
                                    <small>Will be activated when Email Setup is connected.</small>
                                </label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_sms"
                                        value="1"
                                        <?php checked( $edit_task->notify_sms, 1 ); ?>
                                    >
                                    SMS
                                    <small>Will be activated when SMS Setup is connected.</small>
                                </label>

                            </div>

                        </div>

                        <button
                            type="submit"
                            class="rud-crm-task-save"
                        >
                            SAVE CHANGES
                        </button>

                    </form>

                </div>

            </div>

        <?php else : ?>

            <details class="rud-crm-add-task-panel">

                <summary>
                    + ADD TASK / REMINDER
                </summary>

                <div class="rud-crm-add-task-form">

                    <form method="post">

                        <?php
                        wp_nonce_field(
                            'rud_crm_add_task_' .
                            $customer_id,
                            'rud_crm_task_nonce'
                        );
                        ?>

                        <input
                            type="hidden"
                            name="rud_crm_task_action"
                            value="add_task"
                        >

                        <input
                            type="hidden"
                            name="rud_customer_id"
                            value="<?php echo esc_attr( $customer_id ); ?>"
                        >

                        <div class="rud-crm-task-form-grid">

                            <div class="rud-crm-task-wide">

                                <label>
                                    Task Title
                                </label>

                                <input
                                    type="text"
                                    name="title"
                                    required
                                    placeholder="Example: Follow up Kari Olsen"
                                >

                            </div>

                            <div>

                                <label>
                                    Task Type
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'task_type',
                                    $types,
                                    'general'
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Status
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'status',
                                    $statuses,
                                    'active'
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Priority
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'priority',
                                    $priorities,
                                    'normal'
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Contact Person
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'contact_id',
                                    $contact_options,
                                    0
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Project
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'project_id',
                                    $project_options,
                                    0
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Due Date
                                </label>

                                <input
                                    type="date"
                                    name="due_date"
                                >

                            </div>

                            <div>

                                <label>
                                    Due Time
                                </label>

                                <input
                                    type="time"
                                    name="due_time"
                                >

                            </div>

                            <div>

                                <label>
                                    Reminder
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'reminder_type',
                                    $reminders,
                                    'none'
                                );
                                ?>

                            </div>

                            <div>

                                <label>
                                    Email Template
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'email_template_id',
                                    $email_template_options,
                                    0
                                );
                                ?>

                                <small class="rud-crm-task-field-help">
                                    Used only when Email reminder delivery is checked.
                                </small>

                            </div>

                            <div>

                                <label>
                                    SMS Template
                                </label>

                                <?php
                                echo rud_crm_frontend_task_select(
                                    'sms_template_id',
                                    $sms_template_options,
                                    0
                                );
                                ?>

                                <small class="rud-crm-task-field-help">
                                    Used only when SMS reminder delivery is checked.
                                </small>

                            </div>

                            <div class="rud-crm-task-wide">

                                <label>
                                    Task Note
                                </label>

                                <textarea
                                    name="description"
                                    rows="5"
                                    placeholder="Add details, instructions or follow-up notes."
                                ></textarea>

                            </div>

                            <div class="rud-crm-task-wide rud-crm-task-notifications">

                                <label>
                                    Reminder Delivery
                                </label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_crm"
                                        value="1"
                                        checked
                                    >
                                    CRM Notification
                                </label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_email"
                                        value="1"
                                    >
                                    Email
                                    <small>Will be activated when Email Setup is connected.</small>
                                </label>

                                <label class="rud-crm-task-checkbox">
                                    <input
                                        type="checkbox"
                                        name="notify_sms"
                                        value="1"
                                    >
                                    SMS
                                    <small>Will be activated when SMS Setup is connected.</small>
                                </label>

                            </div>

                        </div>

                        <button
                            type="submit"
                            class="rud-crm-task-save"
                        >
                            SAVE TASK
                        </button>

                    </form>

                </div>

            </details>

        <?php endif; ?>

    </section>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_tasks_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-todo-section {
        width:100%;
        margin-top:28px;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
        box-sizing:border-box;
    }

    .rud-crm-todo-section * {
        box-sizing:border-box;
    }

    .rud-crm-todo-header h2 {
        margin:0 0 5px !important;
    }

    .rud-crm-todo-header p {
        margin:0 0 18px;
        color:#667085;
    }

    .rud-crm-todo-list {
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-todo-item {
        display:flex;
        align-items:flex-start;
        justify-content:space-between;
        gap:18px;
        padding:16px;
        border-bottom:1px solid #eaecf0;
    }

    .rud-crm-todo-item:last-child {
        border-bottom:0;
    }

    .rud-crm-todo-main {
        min-width:0;
        flex:1 1 auto;
    }

    .rud-crm-todo-title-row {
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
    }

    .rud-crm-todo-title {
        font-size:16px;
    }

    .rud-crm-task-status,
    .rud-crm-task-priority {
        display:inline-flex;
        padding:3px 7px;
        border-radius:999px;
        background:#f2f4f7;
        font-size:10px;
        font-weight:700;
        text-transform:uppercase;
    }

    .rud-crm-task-status-overdue {
        background:#fff1f0;
    }

    .rud-crm-task-priority-urgent,
    .rud-crm-task-priority-high {
        font-weight:800;
    }

    .rud-crm-todo-meta {
        display:flex;
        gap:14px;
        flex-wrap:wrap;
        margin-top:8px;
        color:#667085;
        font-size:12px;
    }

    .rud-crm-todo-description {
        margin-top:10px;
        line-height:1.55;
    }

    .rud-crm-todo-actions {
        display:flex;
        gap:7px;
        flex-wrap:wrap;
        flex:0 0 auto;
    }

    .rud-crm-todo-actions form {
        margin:0;
    }

    .rud-crm-task-action-link {
        display:inline-flex;
        align-items:center;
        justify-content:center;
        min-height:36px;
        padding:7px 11px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#fff;
        color:#1d2939 !important;
        text-decoration:none !important;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-task-snooze-form {
        display:flex;
        align-items:stretch;
        gap:5px;
    }

    .rud-crm-task-snooze-form select {
        min-height:36px;
        padding:6px 8px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font-size:11px;
    }

    .rud-crm-edit-task-heading {
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:14px;
        padding:14px 16px;
    }

    .rud-crm-edit-task-heading a {
        font-size:12px;
        font-weight:700;
    }

    .rud-crm-todo-actions button,
    .rud-crm-task-save {
        min-height:36px;
        padding:7px 11px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff;
        cursor:pointer;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-todo-actions .rud-crm-task-delete {
        border-color:#b42318;
        background:#fff;
        color:#b42318;
    }

    .rud-crm-todo-empty {
        margin-bottom:18px;
        padding:14px 16px;
        border:1px solid #eaecf0;
        border-radius:8px;
        color:#667085;
    }

    .rud-crm-add-task-panel {
        margin-top:18px;
        border:1px solid #eaecf0;
        border-radius:9px;
        overflow:hidden;
    }

    .rud-crm-add-task-panel summary {
        padding:14px 16px;
        cursor:pointer;
        font-weight:700;
        list-style:none;
    }

    .rud-crm-add-task-panel summary::-webkit-details-marker {
        display:none;
    }

    .rud-crm-add-task-form {
        padding:18px;
        border-top:1px solid #eaecf0;
        background:#f9fafb;
    }

    .rud-crm-task-form-grid {
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:14px;
    }

    .rud-crm-task-wide {
        grid-column:1 / -1;
    }

    .rud-crm-task-form-grid label {
        display:block;
        margin-bottom:6px;
        font-weight:600;
    }

    .rud-crm-task-form-grid input,
    .rud-crm-task-form-grid select,
    .rud-crm-task-form-grid textarea {
        width:100%;
        padding:10px 12px;
        border:1px solid #d0d5dd;
        border-radius:7px;
        background:#fff;
        font:inherit;
    }

    .rud-crm-task-field-help {
        display:block;
        margin-top:5px;
        color:#667085;
        font-size:11px;
        line-height:1.4;
    }

    .rud-crm-task-notifications {
        display:flex;
        gap:16px;
        flex-wrap:wrap;
        align-items:flex-start;
    }

    .rud-crm-task-notifications > label:first-child {
        width:100%;
    }

    .rud-crm-task-checkbox {
        display:flex !important;
        align-items:center;
        gap:7px;
        margin:0 !important;
    }

    .rud-crm-task-checkbox input {
        width:auto;
    }

    .rud-crm-task-checkbox small {
        color:#667085;
        font-weight:400;
    }

    .rud-crm-task-save {
        margin-top:18px;
    }

    .rud-crm-task-message {
        margin-bottom:16px;
        padding:11px 13px;
        border-radius:7px;
    }

    .rud-crm-task-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-task-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:800px) {

        .rud-crm-todo-item {
            flex-direction:column;
        }

        .rud-crm-task-form-grid {
            grid-template-columns:1fr;
        }

        .rud-crm-task-wide {
            grid-column:auto;
        }
    }

    ';

    wp_register_style(
        'rud-crm-frontend-tasks',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-frontend-tasks'
    );

    wp_add_inline_style(
        'rud-crm-frontend-tasks',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_tasks_styles',
    50
);
