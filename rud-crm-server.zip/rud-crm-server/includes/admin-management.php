<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * ADMINISTRATOR MANAGEMENT
 * =========================================================
 *
 * GLOBAL ACCOUNT RULE:
 *
 * EMAIL ADDRESS = LOGIN / USERNAME
 *
 * ADMIN-LEVEL-001 — System Admin Owner
 * ADMIN-LEVEL-002 — System Administrator
 * ADMIN-LEVEL-003 — System Support
 * ADMIN-LEVEL-004 — Senior Administrator
 * ADMIN-LEVEL-005 — Sales / Customer Manager
 * ADMIN-LEVEL-006 — Sales / Customer Assistant
 *
 * =========================================================
 */


/*
 * =========================================================
 * ADMIN PAGE ACCESS
 * =========================================================
 */

function rud_crm_admin_management_can_access() {

    return
        function_exists( 'rud_crm_is_crm_admin' )
        &&
        rud_crm_is_crm_admin();
}


/*
 * =========================================================
 * ROLE LABEL
 * =========================================================
 */

function rud_crm_admin_management_role_label( $level ) {

    if (
        function_exists(
            'rud_crm_admin_level_label'
        )
    ) {

        return rud_crm_admin_level_label(
            $level
        );
    }


    return sprintf(
        'ADMIN-LEVEL-%03d',
        absint( $level )
    );
}


/*
 * =========================================================
 * ROLE SLUG
 * =========================================================
 */

function rud_crm_admin_management_role_slug( $level ) {

    if (
        function_exists(
            'rud_crm_admin_role_from_level'
        )
    ) {

        return rud_crm_admin_role_from_level(
            $level
        );
    }


    return '';
}


/*
 * =========================================================
 * PHONE COUNTRIES
 * =========================================================
 */

function rud_crm_admin_phone_countries() {

    return array(

        'NO' => array(
            'name' => 'Norway',
            'flag' => '🇳🇴',
            'code' => '+47'
        ),

        'SE' => array(
            'name' => 'Sweden',
            'flag' => '🇸🇪',
            'code' => '+46'
        ),

        'DK' => array(
            'name' => 'Denmark',
            'flag' => '🇩🇰',
            'code' => '+45'
        ),

        'FI' => array(
            'name' => 'Finland',
            'flag' => '🇫🇮',
            'code' => '+358'
        ),

        'IS' => array(
            'name' => 'Iceland',
            'flag' => '🇮🇸',
            'code' => '+354'
        ),

        'GB' => array(
            'name' => 'United Kingdom',
            'flag' => '🇬🇧',
            'code' => '+44'
        ),

        'US' => array(
            'name' => 'United States',
            'flag' => '🇺🇸',
            'code' => '+1'
        ),

        'CA' => array(
            'name' => 'Canada',
            'flag' => '🇨🇦',
            'code' => '+1'
        ),

        'DE' => array(
            'name' => 'Germany',
            'flag' => '🇩🇪',
            'code' => '+49'
        ),

        'NL' => array(
            'name' => 'Netherlands',
            'flag' => '🇳🇱',
            'code' => '+31'
        ),

        'BE' => array(
            'name' => 'Belgium',
            'flag' => '🇧🇪',
            'code' => '+32'
        ),

        'FR' => array(
            'name' => 'France',
            'flag' => '🇫🇷',
            'code' => '+33'
        ),

        'ES' => array(
            'name' => 'Spain',
            'flag' => '🇪🇸',
            'code' => '+34'
        ),

        'PT' => array(
            'name' => 'Portugal',
            'flag' => '🇵🇹',
            'code' => '+351'
        ),

        'IT' => array(
            'name' => 'Italy',
            'flag' => '🇮🇹',
            'code' => '+39'
        ),

        'CH' => array(
            'name' => 'Switzerland',
            'flag' => '🇨🇭',
            'code' => '+41'
        ),

        'AT' => array(
            'name' => 'Austria',
            'flag' => '🇦🇹',
            'code' => '+43'
        ),

        'IE' => array(
            'name' => 'Ireland',
            'flag' => '🇮🇪',
            'code' => '+353'
        ),

        'PL' => array(
            'name' => 'Poland',
            'flag' => '🇵🇱',
            'code' => '+48'
        ),

        'CZ' => array(
            'name' => 'Czech Republic',
            'flag' => '🇨🇿',
            'code' => '+420'
        ),

        'SK' => array(
            'name' => 'Slovakia',
            'flag' => '🇸🇰',
            'code' => '+421'
        ),

        'EE' => array(
            'name' => 'Estonia',
            'flag' => '🇪🇪',
            'code' => '+372'
        ),

        'LV' => array(
            'name' => 'Latvia',
            'flag' => '🇱🇻',
            'code' => '+371'
        ),

        'LT' => array(
            'name' => 'Lithuania',
            'flag' => '🇱🇹',
            'code' => '+370'
        ),

        'GR' => array(
            'name' => 'Greece',
            'flag' => '🇬🇷',
            'code' => '+30'
        ),

        'TR' => array(
            'name' => 'Turkey',
            'flag' => '🇹🇷',
            'code' => '+90'
        ),

        'RO' => array(
            'name' => 'Romania',
            'flag' => '🇷🇴',
            'code' => '+40'
        ),

        'BG' => array(
            'name' => 'Bulgaria',
            'flag' => '🇧🇬',
            'code' => '+359'
        ),

        'HR' => array(
            'name' => 'Croatia',
            'flag' => '🇭🇷',
            'code' => '+385'
        ),

        'SI' => array(
            'name' => 'Slovenia',
            'flag' => '🇸🇮',
            'code' => '+386'
        ),

        'HU' => array(
            'name' => 'Hungary',
            'flag' => '🇭🇺',
            'code' => '+36'
        ),

        'UA' => array(
            'name' => 'Ukraine',
            'flag' => '🇺🇦',
            'code' => '+380'
        ),

        'AE' => array(
            'name' => 'United Arab Emirates',
            'flag' => '🇦🇪',
            'code' => '+971'
        ),

        'ZA' => array(
            'name' => 'South Africa',
            'flag' => '🇿🇦',
            'code' => '+27'
        ),

        'IN' => array(
            'name' => 'India',
            'flag' => '🇮🇳',
            'code' => '+91'
        ),

        'TH' => array(
            'name' => 'Thailand',
            'flag' => '🇹🇭',
            'code' => '+66'
        ),

        'LK' => array(
            'name' => 'Sri Lanka',
            'flag' => '🇱🇰',
            'code' => '+94'
        ),

        'AU' => array(
            'name' => 'Australia',
            'flag' => '🇦🇺',
            'code' => '+61'
        ),

        'NZ' => array(
            'name' => 'New Zealand',
            'flag' => '🇳🇿',
            'code' => '+64'
        ),

        'JP' => array(
            'name' => 'Japan',
            'flag' => '🇯🇵',
            'code' => '+81'
        ),

        'KR' => array(
            'name' => 'South Korea',
            'flag' => '🇰🇷',
            'code' => '+82'
        ),

        'SG' => array(
            'name' => 'Singapore',
            'flag' => '🇸🇬',
            'code' => '+65'
        ),

        'BR' => array(
            'name' => 'Brazil',
            'flag' => '🇧🇷',
            'code' => '+55'
        ),

        'MX' => array(
            'name' => 'Mexico',
            'flag' => '🇲🇽',
            'code' => '+52'
        )
    );
}


/*
 * =========================================================
 * PHONE COUNTRY DATA
 * =========================================================
 */

function rud_crm_admin_phone_country_data( $country ) {

    $countries =
        rud_crm_admin_phone_countries();


    $country =
        strtoupper(
            sanitize_key(
                $country
            )
        );


    if (
        isset(
            $countries[ $country ]
        )
    ) {

        return $countries[ $country ];
    }


    return $countries['NO'];
}


/*
 * =========================================================
 * CLEAN MOBILE
 * =========================================================
 */

function rud_crm_admin_clean_mobile( $mobile ) {

    $mobile =
        sanitize_text_field(
            $mobile
        );


    return preg_replace(
        '/[^0-9]/',
        '',
        $mobile
    );
}


/*
 * =========================================================
 * COMPLETE MOBILE
 * =========================================================
 */

function rud_crm_admin_complete_mobile(
    $country,
    $mobile
) {

    $mobile =
        rud_crm_admin_clean_mobile(
            $mobile
        );


    if (
        '' === $mobile
    ) {

        return '';
    }


    $country_data =
        rud_crm_admin_phone_country_data(
            $country
        );


    $mobile =
        ltrim(
            $mobile,
            '0'
        );


    return
        $country_data['code']
        .
        ' '
        .
        $mobile;
}


/*
 * =========================================================
 * COUNTRY SELECT
 * =========================================================
 */

function rud_crm_admin_country_select(
    $name,
    $selected = 'NO'
) {

    $countries =
        rud_crm_admin_phone_countries();


    $selected =
        strtoupper(
            $selected
        );

    ?>

    <select
        name="<?php echo esc_attr( $name ); ?>"
        class="rud-crm-admin-country-select"
    >

        <?php

        foreach (
            $countries as
            $iso =>
            $country
        ) :

        ?>

            <option
                value="<?php echo esc_attr( $iso ); ?>"
                <?php selected( $selected, $iso ); ?>
            >

                <?php

                echo esc_html(
                    $country['flag']
                    .
                    ' '
                    .
                    $country['name']
                    .
                    ' '
                    .
                    $country['code']
                );

                ?>

            </option>

        <?php endforeach; ?>

    </select>

    <?php
}


/*
 * =========================================================
 * CREATABLE LEVELS
 * =========================================================
 */

function rud_crm_admin_management_creatable_levels(
    $user_id = 0
) {

    if ( ! $user_id ) {

        $user_id =
            get_current_user_id();
    }


    $levels =
        array();


    for (
        $level = 2;
        $level <= 6;
        $level++
    ) {

        if (
            function_exists(
                'rud_crm_can_create_admin_level'
            )
            &&
            rud_crm_can_create_admin_level(
                $level,
                $user_id
            )
        ) {

            $levels[] =
                $level;
        }
    }


    return $levels;
}


/*
 * =========================================================
 * NOTICES
 * =========================================================
 */

function rud_crm_admin_management_notice() {

    if (
        empty(
            $_GET['rud_crm_admin_notice']
        )
    ) {

        return;
    }


    $notice =
        sanitize_key(
            wp_unslash(
                $_GET['rud_crm_admin_notice']
            )
        );


    $messages =
        array(

            'created' =>
                array(
                    'success',
                    'Administrator account created successfully.'
                ),

            'updated' =>
                array(
                    'success',
                    'Administrator account updated successfully.'
                ),

            'deleted' =>
                array(
                    'success',
                    'Administrator account deleted successfully.'
                ),

            'not_allowed' =>
                array(
                    'error',
                    'You are not allowed to perform that administrator action.'
                ),

            'invalid_user' =>
                array(
                    'error',
                    'The selected administrator account could not be found.'
                ),

            'invalid_level' =>
                array(
                    'error',
                    'The selected administrator level is not allowed.'
                ),

            'invalid_email' =>
                array(
                    'error',
                    'Please enter a valid email address.'
                ),

            'email_too_long' =>
                array(
                    'error',
                    'The email address is too long to be used as a new WordPress login.'
                ),

            'email_exists' =>
                array(
                    'error',
                    'That email address is already connected to another account.'
                ),

            'missing' =>
                array(
                    'error',
                    'Please complete all required fields.'
                ),

            'password_short' =>
                array(
                    'error',
                    'Password must contain at least 8 characters.'
                ),

            'error' =>
                array(
                    'error',
                    'The administrator account could not be saved.'
                )
        );


    if (
        ! isset(
            $messages[ $notice ]
        )
    ) {

        return;
    }

    ?>

    <div
        class="notice notice-<?php echo esc_attr( $messages[ $notice ][0] ); ?> is-dismissible"
    >

        <p>
            <?php
            echo esc_html(
                $messages[ $notice ][1]
            );
            ?>
        </p>

    </div>

    <?php
}


/*
 * =========================================================
 * REDIRECT
 * =========================================================
 */

function rud_crm_admin_management_redirect( $notice ) {

    $url =
        add_query_arg(
            'rud_crm_admin_notice',
            sanitize_key( $notice ),
            admin_url(
                'admin.php?page=rud-crm-admin-management'
            )
        );


    wp_safe_redirect(
        $url
    );

    exit;
}


/*
 * =========================================================
 * CREATE ADMINISTRATOR
 * =========================================================
 */

function rud_crm_admin_management_process_create() {

    if (
        empty(
            $_POST['rud_crm_admin_management_action']
        )
        ||
        'create_admin' !==
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_admin_management_action']
            )
        )
    ) {

        return;
    }


    if (
        ! rud_crm_admin_management_can_access()
    ) {

        wp_die(
            'You are not allowed to create CRM administrators.'
        );
    }


    if (
        empty(
            $_POST['rud_crm_admin_management_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_admin_management_nonce']
                )
            ),
            'rud_crm_create_admin'
        )
    ) {

        wp_die(
            'Security verification failed.'
        );
    }


    $company =
        isset( $_POST['company'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['company']
            )
        )
        : '';


    $first_name =
        isset( $_POST['first_name'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['first_name']
            )
        )
        : '';


    $last_name =
        isset( $_POST['last_name'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['last_name']
            )
        )
        : '';


    $mobile_country =
        isset( $_POST['mobile_country'] )
        ? strtoupper(
            sanitize_key(
                wp_unslash(
                    $_POST['mobile_country']
                )
            )
        )
        : 'NO';


    $mobile =
        isset( $_POST['mobile'] )
        ? rud_crm_admin_clean_mobile(
            wp_unslash(
                $_POST['mobile']
            )
        )
        : '';


    $email =
        isset( $_POST['email'] )
        ? sanitize_email(
            wp_unslash(
                $_POST['email']
            )
        )
        : '';


    $password =
        isset( $_POST['password'] )
        ? (string)
        wp_unslash(
            $_POST['password']
        )
        : '';


    $level =
        isset( $_POST['admin_level'] )
        ? absint(
            $_POST['admin_level']
        )
        : 0;


    if (
        '' === $first_name
        ||
        '' === $last_name
        ||
        '' === $email
        ||
        '' === $password
    ) {

        rud_crm_admin_management_redirect(
            'missing'
        );
    }


    if (
        ! is_email(
            $email
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_email'
        );
    }


    /*
     * Email becomes the login username.
     */

    if (
        function_exists(
            'rud_crm_username_from_email'
        )
    ) {

        $username =
            rud_crm_username_from_email(
                $email
            );

    } else {

        $username =
            strtolower(
                trim(
                    $email
                )
            );
    }


    if (
        '' ===
        $username
    ) {

        rud_crm_admin_management_redirect(
            'email_too_long'
        );
    }


    if (
        strlen(
            $password
        ) < 8
    ) {

        rud_crm_admin_management_redirect(
            'password_short'
        );
    }


    $countries =
        rud_crm_admin_phone_countries();


    if (
        ! isset(
            $countries[ $mobile_country ]
        )
    ) {

        $mobile_country =
            'NO';
    }


    if (
        ! function_exists(
            'rud_crm_can_create_admin_level'
        )
        ||
        ! rud_crm_can_create_admin_level(
            $level
        )
        ||
        1 === $level
    ) {

        rud_crm_admin_management_redirect(
            'invalid_level'
        );
    }


    if (
        function_exists(
            'rud_crm_email_available'
        )
    ) {

        if (
            ! rud_crm_email_available(
                $email
            )
        ) {

            rud_crm_admin_management_redirect(
                'email_exists'
            );
        }

    } elseif (
        email_exists(
            $email
        )
    ) {

        rud_crm_admin_management_redirect(
            'email_exists'
        );
    }


    /*
     * Because email is also the WordPress username
     * for NEW RUD CRM accounts, check both.
     */

    if (
        username_exists(
            $username
        )
    ) {

        rud_crm_admin_management_redirect(
            'email_exists'
        );
    }


    $role =
        rud_crm_admin_management_role_slug(
            $level
        );


    if (
        ! $role
        ||
        ! get_role(
            $role
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_level'
        );
    }


    $user_id =
        wp_insert_user(
            array(

                /*
                 * GLOBAL RULE:
                 * Email = username.
                 */

                'user_login' =>
                    $username,

                'user_email' =>
                    $email,

                'user_pass' =>
                    $password,

                'first_name' =>
                    $first_name,

                'last_name' =>
                    $last_name,

                'display_name' =>
                    trim(
                        $first_name .
                        ' ' .
                        $last_name
                    ),

                'role' =>
                    $role
            )
        );


    if (
        is_wp_error(
            $user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'error'
        );
    }


    update_user_meta(
        $user_id,
        'rud_crm_admin_company',
        $company
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_mobile_country',
        $mobile_country
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_mobile',
        $mobile
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_mobile_full',
        rud_crm_admin_complete_mobile(
            $mobile_country,
            $mobile
        )
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_level',
        $level
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_created_by',
        get_current_user_id()
    );


    update_user_meta(
        $user_id,
        'rud_crm_admin_created_at',
        current_time(
            'mysql'
        )
    );


    rud_crm_admin_management_redirect(
        'created'
    );
}


add_action(
    'admin_init',
    'rud_crm_admin_management_process_create',
    20
);


/*
 * =========================================================
 * UPDATE ADMINISTRATOR
 * =========================================================
 *
 * IMPORTANT:
 *
 * Existing WordPress user_login is NOT forcibly rewritten.
 *
 * If the email changes, the RUD CRM login system still uses
 * the NEW email to locate the account and authenticate it.
 *
 * =========================================================
 */

function rud_crm_admin_management_process_update() {

    if (
        empty(
            $_POST['rud_crm_admin_management_action']
        )
        ||
        'update_admin' !==
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_admin_management_action']
            )
        )
    ) {

        return;
    }


    if (
        ! rud_crm_admin_management_can_access()
    ) {

        wp_die(
            'You are not allowed to manage CRM administrators.'
        );
    }


    if (
        empty(
            $_POST['rud_crm_admin_management_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_admin_management_nonce']
                )
            ),
            'rud_crm_update_admin'
        )
    ) {

        wp_die(
            'Security verification failed.'
        );
    }


    $target_user_id =
        isset( $_POST['user_id'] )
        ? absint(
            $_POST['user_id']
        )
        : 0;


    if (
        ! $target_user_id
        ||
        ! get_userdata(
            $target_user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_user'
        );
    }


    if (
        ! function_exists(
            'rud_crm_can_manage_admin_user'
        )
        ||
        ! rud_crm_can_manage_admin_user(
            $target_user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'not_allowed'
        );
    }


    $new_level =
        isset( $_POST['admin_level'] )
        ? absint(
            $_POST['admin_level']
        )
        : 0;


    if (
        ! $new_level
        ||
        1 === $new_level
        ||
        ! rud_crm_can_create_admin_level(
            $new_level
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_level'
        );
    }


    $company =
        isset( $_POST['company'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['company']
            )
        )
        : '';


    $first_name =
        isset( $_POST['first_name'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['first_name']
            )
        )
        : '';


    $last_name =
        isset( $_POST['last_name'] )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['last_name']
            )
        )
        : '';


    $mobile_country =
        isset( $_POST['mobile_country'] )
        ? strtoupper(
            sanitize_key(
                wp_unslash(
                    $_POST['mobile_country']
                )
            )
        )
        : 'NO';


    $mobile =
        isset( $_POST['mobile'] )
        ? rud_crm_admin_clean_mobile(
            wp_unslash(
                $_POST['mobile']
            )
        )
        : '';


    $email =
        isset( $_POST['email'] )
        ? sanitize_email(
            wp_unslash(
                $_POST['email']
            )
        )
        : '';


    if (
        '' === $first_name
        ||
        '' === $last_name
        ||
        ! is_email(
            $email
        )
    ) {

        rud_crm_admin_management_redirect(
            'missing'
        );
    }


    if (
        function_exists(
            'rud_crm_email_available'
        )
    ) {

        if (
            ! rud_crm_email_available(
                $email,
                $target_user_id
            )
        ) {

            rud_crm_admin_management_redirect(
                'email_exists'
            );
        }

    } else {

        $email_owner =
            email_exists(
                $email
            );


        if (
            $email_owner
            &&
            absint(
                $email_owner
            )
            !==
            $target_user_id
        ) {

            rud_crm_admin_management_redirect(
                'email_exists'
            );
        }
    }


    $updated =
        wp_update_user(
            array(

                'ID' =>
                    $target_user_id,

                'user_email' =>
                    $email,

                'first_name' =>
                    $first_name,

                'last_name' =>
                    $last_name,

                'display_name' =>
                    trim(
                        $first_name .
                        ' ' .
                        $last_name
                    )
            )
        );


    if (
        is_wp_error(
            $updated
        )
    ) {

        rud_crm_admin_management_redirect(
            'error'
        );
    }


    /*
     * Change administrator level.
     */

    $new_role =
        rud_crm_admin_management_role_slug(
            $new_level
        );


    if (
        ! $new_role
        ||
        ! get_role(
            $new_role
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_level'
        );
    }


    $target_user =
        new WP_User(
            $target_user_id
        );


    $crm_admin_roles =
        array();


    for (
        $level = 1;
        $level <= 6;
        $level++
    ) {

        $role_slug =
            rud_crm_admin_management_role_slug(
                $level
            );


        if (
            $role_slug
        ) {

            $crm_admin_roles[] =
                $role_slug;
        }
    }


    foreach (
        $crm_admin_roles as
        $role_slug
    ) {

        $target_user->remove_role(
            $role_slug
        );
    }


    $target_user->add_role(
        $new_role
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_level',
        $new_level
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_company',
        $company
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_mobile_country',
        $mobile_country
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_mobile',
        $mobile
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_mobile_full',
        rud_crm_admin_complete_mobile(
            $mobile_country,
            $mobile
        )
    );


    if (
        ! empty(
            $_POST['password']
        )
    ) {

        $password =
            (string)
            wp_unslash(
                $_POST['password']
            );


        if (
            strlen(
                $password
            ) < 8
        ) {

            rud_crm_admin_management_redirect(
                'password_short'
            );
        }


        wp_set_password(
            $password,
            $target_user_id
        );
    }


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_updated_by',
        get_current_user_id()
    );


    update_user_meta(
        $target_user_id,
        'rud_crm_admin_updated_at',
        current_time(
            'mysql'
        )
    );


    rud_crm_admin_management_redirect(
        'updated'
    );
}


add_action(
    'admin_init',
    'rud_crm_admin_management_process_update',
    21
);


/*
 * =========================================================
 * DELETE ADMINISTRATOR
 * =========================================================
 */

function rud_crm_admin_management_process_delete() {

    if (
        empty(
            $_GET['rud_crm_delete_admin']
        )
    ) {

        return;
    }


    if (
        ! rud_crm_admin_management_can_access()
    ) {

        wp_die(
            'You are not allowed to delete CRM administrators.'
        );
    }


    $target_user_id =
        absint(
            $_GET['rud_crm_delete_admin']
        );


    if (
        ! $target_user_id
        ||
        ! get_userdata(
            $target_user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'invalid_user'
        );
    }


    if (
        1 ===
        rud_crm_get_admin_level(
            $target_user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'not_allowed'
        );
    }


    if (
        ! rud_crm_can_manage_admin_user(
            $target_user_id
        )
    ) {

        rud_crm_admin_management_redirect(
            'not_allowed'
        );
    }


    if (
        empty(
            $_GET['_wpnonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_GET['_wpnonce']
                )
            ),
            'rud_crm_delete_admin_' .
            $target_user_id
        )
    ) {

        wp_die(
            'Security verification failed.'
        );
    }


    require_once
        ABSPATH .
        'wp-admin/includes/user.php';


    $deleted =
        wp_delete_user(
            $target_user_id
        );


    if (
        ! $deleted
    ) {

        rud_crm_admin_management_redirect(
            'error'
        );
    }


    rud_crm_admin_management_redirect(
        'deleted'
    );
}


add_action(
    'admin_init',
    'rud_crm_admin_management_process_delete',
    22
);


/*
 * =========================================================
 * GET ADMINISTRATORS
 * =========================================================
 */

function rud_crm_admin_management_get_admins() {

    $roles =
        array();


    for (
        $level = 1;
        $level <= 6;
        $level++
    ) {

        $role =
            rud_crm_admin_management_role_slug(
                $level
            );


        if (
            $role
        ) {

            $roles[] =
                $role;
        }
    }


    $users =
        get_users(
            array(

                'role__in' =>
                    $roles,

                'orderby' =>
                    'display_name',

                'order' =>
                    'ASC'
            )
        );


    if (
        function_exists(
            'rud_crm_get_system_admin_owner_user_id'
        )
    ) {

        $owner_id =
            rud_crm_get_system_admin_owner_user_id();


        if (
            $owner_id
        ) {

            $owner =
                get_userdata(
                    $owner_id
                );


            if (
                $owner
            ) {

                $found =
                    false;


                foreach (
                    $users as
                    $user
                ) {

                    if (
                        absint(
                            $user->ID
                        )
                        ===
                        absint(
                            $owner_id
                        )
                    ) {

                        $found =
                            true;

                        break;
                    }
                }


                if (
                    ! $found
                ) {

                    $users[] =
                        $owner;
                }
            }
        }
    }


    usort(
        $users,
        function(
            $a,
            $b
        ) {

            $level_a =
                rud_crm_get_admin_level(
                    $a->ID
                );


            $level_b =
                rud_crm_get_admin_level(
                    $b->ID
                );


            if (
                $level_a ===
                $level_b
            ) {

                return strcasecmp(
                    $a->display_name,
                    $b->display_name
                );
            }


            return
                $level_a
                <=>
                $level_b;
        }
    );


    return $users;
}


/*
 * =========================================================
 * ADMIN MANAGEMENT PAGE
 * =========================================================
 */

function rud_crm_admin_management_page() {

    if (
        ! rud_crm_admin_management_can_access()
    ) {

        wp_die(
            'You are not allowed to access Administrator Management.'
        );
    }


    $current_user_id =
        get_current_user_id();


    $current_level =
        rud_crm_get_admin_level(
            $current_user_id
        );


    $creatable_levels =
        rud_crm_admin_management_creatable_levels(
            $current_user_id
        );


    $admins =
        rud_crm_admin_management_get_admins();


    rud_crm_admin_management_notice();

    ?>

    <div class="wrap">


        <style>

            .rud-crm-phone-wrap {
                display: flex;
                gap: 8px;
                max-width: 650px;
            }

            .rud-crm-admin-country-select {
                min-width: 250px;
            }

            .rud-crm-admin-mobile-input {
                flex: 1;
                min-width: 180px;
            }

            .rud-crm-admin-ladder-table td {
                vertical-align: middle;
            }

            .rud-crm-admin-edit-box {
                margin-top: 15px;
                padding: 18px;
                max-width: 700px;
                background: #f6f7f7;
                border-radius: 6px;
            }

            .rud-crm-owner-badge {
                display: inline-block;
                margin-top: 5px;
                padding: 3px 8px;
                border-radius: 10px;
                background: #2271b1;
                color: #ffffff;
                font-size: 11px;
                font-weight: 600;
            }

            @media
            (
                max-width: 700px
            ) {

                .rud-crm-phone-wrap {
                    display: block;
                }

                .rud-crm-admin-country-select,
                .rud-crm-admin-mobile-input {
                    width: 100%;
                    max-width: 100%;
                    margin-bottom: 8px;
                }
            }

        </style>


        <h1>
            RUD CRM Administrator Management
        </h1>


        <p>

            Your administrator level:

            <strong>
                <?php
                echo esc_html(
                    rud_crm_admin_management_role_label(
                        $current_level
                    )
                );
                ?>
            </strong>

        </p>


        <hr>


        <?php if ( ! empty( $creatable_levels ) ) : ?>


            <h2>
                Create Administrator
            </h2>


            <form method="post">


                <?php

                wp_nonce_field(
                    'rud_crm_create_admin',
                    'rud_crm_admin_management_nonce'
                );

                ?>


                <input
                    type="hidden"
                    name="rud_crm_admin_management_action"
                    value="create_admin"
                >


                <table class="form-table">


                    <tr>

                        <th>
                            Company
                        </th>

                        <td>

                            <input
                                type="text"
                                name="company"
                                class="regular-text"
                                autocomplete="organization"
                            >

                        </td>

                    </tr>


                    <tr>

                        <th>
                            First Name
                        </th>

                        <td>

                            <input
                                type="text"
                                name="first_name"
                                class="regular-text"
                                required
                                autocomplete="given-name"
                            >

                        </td>

                    </tr>


                    <tr>

                        <th>
                            Last Name
                        </th>

                        <td>

                            <input
                                type="text"
                                name="last_name"
                                class="regular-text"
                                required
                                autocomplete="family-name"
                            >

                        </td>

                    </tr>


                    <tr>

                        <th>
                            Mobile Phone
                        </th>

                        <td>

                            <div class="rud-crm-phone-wrap">

                                <?php

                                rud_crm_admin_country_select(
                                    'mobile_country',
                                    'NO'
                                );

                                ?>

                                <input
                                    type="tel"
                                    name="mobile"
                                    class="regular-text rud-crm-admin-mobile-input"
                                    placeholder="91234567"
                                    autocomplete="tel-national"
                                >

                            </div>

                            <p class="description">
                                Select country and enter the mobile number without the international country code.
                            </p>

                        </td>

                    </tr>


                    <tr>

                        <th>
                            Email / Login
                        </th>

                        <td>

                            <input
                                type="email"
                                name="email"
                                class="regular-text"
                                required
                                autocomplete="email"
                            >

                            <p class="description">
                                Your email address is also your username and will be used to log in to RUD CRM.
                            </p>

                        </td>

                    </tr>


                    <tr>

                        <th>
                            Password
                        </th>

                        <td>

                            <input
                                type="password"
                                name="password"
                                class="regular-text"
                                minlength="8"
                                required
                                autocomplete="new-password"
                            >

                            <p class="description">
                                Minimum 8 characters.
                            </p>

                        </td>

                    </tr>


                    <tr>

                        <th>
                            Administrator Level
                        </th>

                        <td>

                            <select
                                name="admin_level"
                                required
                            >

                                <?php

                                foreach (
                                    $creatable_levels as
                                    $level
                                ) :

                                ?>

                                    <option
                                        value="<?php echo esc_attr( $level ); ?>"
                                    >

                                        <?php
                                        echo esc_html(
                                            rud_crm_admin_management_role_label(
                                                $level
                                            )
                                        );
                                        ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </td>

                    </tr>


                </table>


                <?php

                submit_button(
                    'Create Administrator'
                );

                ?>


            </form>


            <hr>


        <?php endif; ?>


        <h2>
            Administrator Ladder
        </h2>


        <table class="widefat striped rud-crm-admin-ladder-table">


            <thead>

                <tr>

                    <th>
                        Level
                    </th>

                    <th>
                        Company
                    </th>

                    <th>
                        Name
                    </th>

                    <th>
                        Mobile
                    </th>

                    <th>
                        Email / Login
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php

            if (
                empty(
                    $admins
                )
            ) :

            ?>

                <tr>

                    <td colspan="6">
                        No administrators found.
                    </td>

                </tr>


            <?php

            else :


                foreach (
                    $admins as
                    $admin
                ) :


                    $level =
                        rud_crm_get_admin_level(
                            $admin->ID
                        );


                    $company =
                        get_user_meta(
                            $admin->ID,
                            'rud_crm_admin_company',
                            true
                        );


                    $mobile_country =
                        get_user_meta(
                            $admin->ID,
                            'rud_crm_admin_mobile_country',
                            true
                        );


                    if (
                        ! $mobile_country
                    ) {

                        $mobile_country =
                            'NO';
                    }


                    $mobile =
                        get_user_meta(
                            $admin->ID,
                            'rud_crm_admin_mobile',
                            true
                        );


                    $mobile_full =
                        get_user_meta(
                            $admin->ID,
                            'rud_crm_admin_mobile_full',
                            true
                        );


                    if (
                        ! $mobile_full
                        &&
                        $mobile
                    ) {

                        $mobile_full =
                            rud_crm_admin_complete_mobile(
                                $mobile_country,
                                $mobile
                            );
                    }


                    $country_data =
                        rud_crm_admin_phone_country_data(
                            $mobile_country
                        );


                    $can_manage =
                        rud_crm_can_manage_admin_user(
                            $admin->ID,
                            $current_user_id
                        );


                    $is_owner =
                        1 ===
                        $level;

            ?>


                <tr>


                    <td>

                        <strong>
                            <?php
                            echo esc_html(
                                rud_crm_admin_management_role_label(
                                    $level
                                )
                            );
                            ?>
                        </strong>


                        <?php if ( $is_owner ) : ?>

                            <br>

                            <span class="rud-crm-owner-badge">
                                PROTECTED OWNER
                            </span>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?php
                        echo esc_html(
                            $company
                            ? $company
                            : '—'
                        );
                        ?>

                    </td>


                    <td>

                        <?php
                        echo esc_html(
                            $admin->display_name
                        );
                        ?>

                    </td>


                    <td>

                        <?php

                        if (
                            $mobile_full
                        ) {

                            echo esc_html(
                                $country_data['flag']
                                .
                                ' '
                                .
                                $mobile_full
                            );

                        } else {

                            echo '—';
                        }

                        ?>

                    </td>


                    <td>

                        <strong>
                            <?php
                            echo esc_html(
                                $admin->user_email
                            );
                            ?>
                        </strong>

                    </td>


                    <td>


                        <?php if ( $can_manage ) : ?>


                            <details>


                                <summary
                                    style="cursor:pointer;font-weight:600;"
                                >
                                    Edit
                                </summary>


                                <div class="rud-crm-admin-edit-box">


                                    <form method="post">


                                        <?php

                                        wp_nonce_field(
                                            'rud_crm_update_admin',
                                            'rud_crm_admin_management_nonce'
                                        );

                                        ?>


                                        <input
                                            type="hidden"
                                            name="rud_crm_admin_management_action"
                                            value="update_admin"
                                        >


                                        <input
                                            type="hidden"
                                            name="user_id"
                                            value="<?php echo esc_attr( $admin->ID ); ?>"
                                        >


                                        <p>

                                            <label>
                                                <strong>
                                                    Company
                                                </strong>
                                            </label>

                                            <br>

                                            <input
                                                type="text"
                                                name="company"
                                                value="<?php echo esc_attr( $company ); ?>"
                                                class="regular-text"
                                            >

                                        </p>


                                        <p>

                                            <label>
                                                <strong>
                                                    First Name
                                                </strong>
                                            </label>

                                            <br>

                                            <input
                                                type="text"
                                                name="first_name"
                                                value="<?php echo esc_attr( $admin->first_name ); ?>"
                                                class="regular-text"
                                                required
                                            >

                                        </p>


                                        <p>

                                            <label>
                                                <strong>
                                                    Last Name
                                                </strong>
                                            </label>

                                            <br>

                                            <input
                                                type="text"
                                                name="last_name"
                                                value="<?php echo esc_attr( $admin->last_name ); ?>"
                                                class="regular-text"
                                                required
                                            >

                                        </p>


                                        <p>
                                            <strong>
                                                Mobile Phone
                                            </strong>
                                        </p>


                                        <div class="rud-crm-phone-wrap">

                                            <?php

                                            rud_crm_admin_country_select(
                                                'mobile_country',
                                                $mobile_country
                                            );

                                            ?>

                                            <input
                                                type="tel"
                                                name="mobile"
                                                value="<?php echo esc_attr( $mobile ); ?>"
                                                class="regular-text rud-crm-admin-mobile-input"
                                            >

                                        </div>


                                        <p>

                                            <label>
                                                <strong>
                                                    Email / Login
                                                </strong>
                                            </label>

                                            <br>

                                            <input
                                                type="email"
                                                name="email"
                                                value="<?php echo esc_attr( $admin->user_email ); ?>"
                                                class="regular-text"
                                                required
                                            >

                                            <br>

                                            <span class="description">
                                                This email address is the RUD CRM login address.
                                            </span>

                                        </p>


                                        <p>

                                            <label>
                                                <strong>
                                                    Administrator Level
                                                </strong>
                                            </label>

                                            <br>

                                            <select
                                                name="admin_level"
                                                required
                                            >

                                                <?php

                                                foreach (
                                                    $creatable_levels as
                                                    $allowed_level
                                                ) :

                                                ?>

                                                    <option
                                                        value="<?php echo esc_attr( $allowed_level ); ?>"
                                                        <?php selected( $level, $allowed_level ); ?>
                                                    >

                                                        <?php
                                                        echo esc_html(
                                                            rud_crm_admin_management_role_label(
                                                                $allowed_level
                                                            )
                                                        );
                                                        ?>

                                                    </option>

                                                <?php endforeach; ?>

                                            </select>

                                        </p>


                                        <p>

                                            <label>
                                                <strong>
                                                    New Password
                                                </strong>
                                            </label>

                                            <br>

                                            <input
                                                type="password"
                                                name="password"
                                                class="regular-text"
                                                minlength="8"
                                                autocomplete="new-password"
                                            >

                                            <br>

                                            <span class="description">
                                                Leave blank to keep the current password.
                                            </span>

                                        </p>


                                        <?php

                                        submit_button(
                                            'Save Changes',
                                            'secondary',
                                            'submit',
                                            false
                                        );

                                        ?>


                                        <?php

                                        $delete_url =
                                            wp_nonce_url(
                                                add_query_arg(
                                                    array(

                                                        'page' =>
                                                            'rud-crm-admin-management',

                                                        'rud_crm_delete_admin' =>
                                                            $admin->ID
                                                    ),
                                                    admin_url(
                                                        'admin.php'
                                                    )
                                                ),
                                                'rud_crm_delete_admin_' .
                                                $admin->ID
                                            );

                                        ?>


                                        <a
                                            href="<?php echo esc_url( $delete_url ); ?>"
                                            class="button"
                                            style="margin-left:10px;color:#b32d2e;"
                                            onclick="return confirm('Delete this administrator account?');"
                                        >
                                            Delete
                                        </a>


                                    </form>


                                </div>


                            </details>


                        <?php else : ?>


                            <?php if ( $is_owner ) : ?>

                                <strong>
                                    Protected
                                </strong>

                            <?php else : ?>

                                <span style="opacity:.65;">
                                    Protected
                                </span>

                            <?php endif; ?>


                        <?php endif; ?>


                    </td>


                </tr>


            <?php

                endforeach;

            endif;

            ?>


            </tbody>


        </table>


    </div>

    <?php
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_admin_management_menu() {

    if (
        ! rud_crm_admin_management_can_access()
    ) {

        return;
    }


    add_submenu_page(

        'rud-crm',

        'Administrators',

        'Administrators',

        'read',

        'rud-crm-admin-management',

        'rud_crm_admin_management_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_admin_management_menu',
    30
);