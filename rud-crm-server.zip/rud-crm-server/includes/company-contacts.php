<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * COMPANY CONTACT PERSONS / EMPLOYEES
 * Version 1.0
 * =========================================================
 *
 * Purpose:
 * - Multiple contact persons / employees per company
 * - Job Title / Position dropdown
 * - Department dropdown
 * - Direct office phone
 * - Mobile phone
 * - Work email
 * - Private email
 * - WhatsApp
 * - Primary contact
 * - Personal Contact Notes
 *
 * =========================================================
 */


/*
 * =========================================================
 * TABLE NAME
 * =========================================================
 */

function rud_crm_company_contacts_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_company_contacts';
}


/*
 * =========================================================
 * CREATE / ENSURE TABLE
 * =========================================================
 */

function rud_crm_ensure_company_contacts_table() {

    global $wpdb;

    $table =
        rud_crm_company_contacts_table();

    $charset_collate =
        $wpdb->get_charset_collate();

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $sql =
        "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            customer_id BIGINT UNSIGNED NOT NULL,

            first_name VARCHAR(100) NOT NULL DEFAULT '',
            middle_name VARCHAR(100) NOT NULL DEFAULT '',
            last_name VARCHAR(100) NOT NULL DEFAULT '',

            job_title VARCHAR(150) NOT NULL DEFAULT '',
            job_title_custom VARCHAR(150) NOT NULL DEFAULT '',
            department VARCHAR(150) NOT NULL DEFAULT '',
            department_custom VARCHAR(150) NOT NULL DEFAULT '',

            direct_office_phone VARCHAR(50) NOT NULL DEFAULT '',
            mobile_phone VARCHAR(50) NOT NULL DEFAULT '',
            work_email VARCHAR(190) NOT NULL DEFAULT '',
            private_email VARCHAR(190) NOT NULL DEFAULT '',
            whatsapp VARCHAR(50) NOT NULL DEFAULT '',

            is_primary TINYINT(1) NOT NULL DEFAULT 0,

            personal_notes LONGTEXT NULL,

            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,

            PRIMARY KEY  (id),
            KEY customer_id (customer_id),
            KEY is_primary (is_primary),
            KEY last_name (last_name),
            KEY job_title (job_title),
            KEY department (department),
            KEY created_by (created_by)
        ) {$charset_collate};";

    dbDelta(
        $sql
    );
}


add_action(
    'admin_init',
    'rud_crm_ensure_company_contacts_table'
);


/*
 * Also ensure the table on normal front-end requests.
 * This makes the feature available immediately after the
 * module is loaded, without requiring a plugin reactivation.
 */

add_action(
    'init',
    'rud_crm_ensure_company_contacts_table',
    20
);


/*
 * =========================================================
 * JOB TITLE / POSITION OPTIONS
 * =========================================================
 */

function rud_crm_company_contact_job_titles() {

    return array(

        '' =>
            'Select Job Title / Position',

        'ceo_managing_director' =>
            'CEO / Managing Director',

        'general_manager' =>
            'General Manager',

        'owner' =>
            'Owner',

        'chairman' =>
            'Chairman',

        'board_member' =>
            'Board Member',

        'sales_manager' =>
            'Sales Manager',

        'sales_representative' =>
            'Sales Representative',

        'key_account_manager' =>
            'Key Account Manager',

        'account_manager' =>
            'Account Manager',

        'marketing_manager' =>
            'Marketing Manager',

        'marketing_coordinator' =>
            'Marketing Coordinator',

        'communications_manager' =>
            'Communications Manager',

        'pr_manager' =>
            'PR Manager',

        'project_manager' =>
            'Project Manager',

        'production_manager' =>
            'Production Manager',

        'technical_manager' =>
            'Technical Manager',

        'service_manager' =>
            'Service Manager',

        'workshop_manager' =>
            'Workshop Manager',

        'operations_manager' =>
            'Operations Manager',

        'purchasing_manager' =>
            'Purchasing Manager',

        'procurement_manager' =>
            'Procurement Manager',

        'logistics_manager' =>
            'Logistics Manager',

        'finance_manager' =>
            'Finance Manager',

        'accounting_manager' =>
            'Accounting Manager',

        'accountant' =>
            'Accountant',

        'hr_manager' =>
            'HR Manager',

        'office_manager' =>
            'Office Manager',

        'customer_service_manager' =>
            'Customer Service Manager',

        'it_manager' =>
            'IT Manager',

        'consultant' =>
            'Consultant',

        'advisor' =>
            'Advisor',

        'coordinator' =>
            'Coordinator',

        'assistant' =>
            'Assistant',

        'other' =>
            'Other',
    );
}


/*
 * =========================================================
 * DEPARTMENT OPTIONS
 * =========================================================
 */

function rud_crm_company_contact_departments() {

    return array(

        '' =>
            'Select Department',

        'management' =>
            'Management',

        'sales' =>
            'Sales',

        'marketing' =>
            'Marketing',

        'communications_pr' =>
            'Communications / PR',

        'accounting' =>
            'Accounting',

        'finance' =>
            'Finance',

        'administration' =>
            'Administration',

        'human_resources' =>
            'Human Resources',

        'customer_service' =>
            'Customer Service',

        'technical' =>
            'Technical',

        'service' =>
            'Service',

        'workshop' =>
            'Workshop',

        'production' =>
            'Production',

        'operations' =>
            'Operations',

        'purchasing' =>
            'Purchasing',

        'procurement' =>
            'Procurement',

        'logistics' =>
            'Logistics',

        'it' =>
            'IT',

        'project_management' =>
            'Project Management',

        'other' =>
            'Other',
    );
}


/*
 * =========================================================
 * GET ONE CONTACT
 * =========================================================
 */

function rud_crm_get_company_contact(
    $contact_id
) {

    global $wpdb;

    $contact_id =
        absint(
            $contact_id
        );

    if (
        ! $contact_id
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_company_contacts_table() .
                "
                 WHERE id = %d
                 LIMIT 1",
                $contact_id
            )
        );
}


/*
 * =========================================================
 * GET COMPANY CONTACTS
 * =========================================================
 */

function rud_crm_get_company_contacts(
    $customer_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
    ) {
        return array();
    }

    return
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_company_contacts_table() .
                "
                 WHERE customer_id = %d
                 ORDER BY
                    is_primary DESC,
                    last_name ASC,
                    first_name ASC,
                    id ASC",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * NORMALIZE CONTACT DATA
 * =========================================================
 */

function rud_crm_company_contact_sanitize_data(
    $data
) {

    $job_titles =
        rud_crm_company_contact_job_titles();

    $departments =
        rud_crm_company_contact_departments();

    $job_title =
        sanitize_key(
            $data['job_title']
            ?? ''
        );

    if (
        ! array_key_exists(
            $job_title,
            $job_titles
        )
    ) {
        $job_title =
            '';
    }

    $department =
        sanitize_key(
            $data['department']
            ?? ''
        );

    if (
        ! array_key_exists(
            $department,
            $departments
        )
    ) {
        $department =
            '';
    }

    $direct_office_phone =
        sanitize_text_field(
            $data['direct_office_phone']
            ?? ''
        );

    $mobile_phone =
        sanitize_text_field(
            $data['mobile_phone']
            ?? ''
        );

    $whatsapp =
        sanitize_text_field(
            $data['whatsapp']
            ?? ''
        );

    if (
        function_exists(
            'rud_crm_sanitize_phone_number'
        )
    ) {

        $direct_office_phone =
            rud_crm_sanitize_phone_number(
                $direct_office_phone
            );

        $mobile_phone =
            rud_crm_sanitize_phone_number(
                $mobile_phone
            );

        $whatsapp =
            rud_crm_sanitize_phone_number(
                $whatsapp
            );
    }

    return array(

        'first_name' =>
            sanitize_text_field(
                $data['first_name']
                ?? ''
            ),

        'middle_name' =>
            sanitize_text_field(
                $data['middle_name']
                ?? ''
            ),

        'last_name' =>
            sanitize_text_field(
                $data['last_name']
                ?? ''
            ),

        'job_title' =>
            $job_title,

        'job_title_custom' =>
            sanitize_text_field(
                $data['job_title_custom']
                ?? ''
            ),

        'department' =>
            $department,

        'department_custom' =>
            sanitize_text_field(
                $data['department_custom']
                ?? ''
            ),

        'direct_office_phone' =>
            $direct_office_phone,

        'mobile_phone' =>
            $mobile_phone,

        'work_email' =>
            sanitize_email(
                $data['work_email']
                ?? ''
            ),

        'private_email' =>
            sanitize_email(
                $data['private_email']
                ?? ''
            ),

        'whatsapp' =>
            $whatsapp,

        'is_primary' =>
            ! empty(
                $data['is_primary']
            )
            ? 1
            : 0,

        'personal_notes' =>
            sanitize_textarea_field(
                $data['personal_notes']
                ?? ''
            ),
    );
}


/*
 * =========================================================
 * CREATE CONTACT
 * =========================================================
 */

function rud_crm_create_company_contact(
    $customer_id,
    $data
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
    ) {

        return new WP_Error(
            'invalid_customer',
            'Invalid company customer.'
        );
    }

    $data =
        rud_crm_company_contact_sanitize_data(
            $data
        );

    if (
        '' ===
        trim(
            $data['first_name']
        )
        &&
        '' ===
        trim(
            $data['last_name']
        )
    ) {

        return new WP_Error(
            'contact_name_required',
            'Enter at least a first name or last name.'
        );
    }

    if (
        $data['is_primary']
    ) {

        $wpdb->update(
            rud_crm_company_contacts_table(),
            array(
                'is_primary' =>
                    0,
            ),
            array(
                'customer_id' =>
                    $customer_id,
            ),
            array(
                '%d',
            ),
            array(
                '%d',
            )
        );
    }

    $now =
        current_time(
            'mysql'
        );

    $insert_data =
        array_merge(
            $data,
            array(
                'customer_id' =>
                    $customer_id,

                'created_by' =>
                    get_current_user_id(),

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    $result =
        $wpdb->insert(
            rud_crm_company_contacts_table(),
            $insert_data
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'contact_create_failed',
            'The contact person could not be created.'
        );
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * UPDATE CONTACT
 * =========================================================
 */

function rud_crm_update_company_contact(
    $contact_id,
    $data
) {

    global $wpdb;

    $contact =
        rud_crm_get_company_contact(
            $contact_id
        );

    if (
        ! $contact
    ) {

        return new WP_Error(
            'contact_not_found',
            'Contact person could not be found.'
        );
    }

    $data =
        rud_crm_company_contact_sanitize_data(
            $data
        );

    if (
        '' ===
        trim(
            $data['first_name']
        )
        &&
        '' ===
        trim(
            $data['last_name']
        )
    ) {

        return new WP_Error(
            'contact_name_required',
            'Enter at least a first name or last name.'
        );
    }

    if (
        $data['is_primary']
    ) {

        $wpdb->query(
            $wpdb->prepare(
                "UPDATE " .
                rud_crm_company_contacts_table() .
                "
                 SET is_primary = 0
                 WHERE customer_id = %d
                 AND id <> %d",
                $contact->customer_id,
                $contact->id
            )
        );
    }

    $data['updated_at'] =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->update(
            rud_crm_company_contacts_table(),
            $data,
            array(
                'id' =>
                    absint(
                        $contact_id
                    ),
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'contact_update_failed',
            'The contact person could not be updated.'
        );
    }

    return true;
}


/*
 * =========================================================
 * DELETE CONTACT
 * =========================================================
 */

function rud_crm_delete_company_contact(
    $contact_id
) {

    global $wpdb;

    $contact_id =
        absint(
            $contact_id
        );

    if (
        ! $contact_id
    ) {
        return false;
    }

    return
        false !==
        $wpdb->delete(
            rud_crm_company_contacts_table(),
            array(
                'id' =>
                    $contact_id,
            ),
            array(
                '%d',
            )
        );
}


/*
 * =========================================================
 * PRIMARY CONTACT
 * =========================================================
 */

function rud_crm_get_company_primary_contact(
    $customer_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_company_contacts_table() .
                "
                 WHERE customer_id = %d
                 AND is_primary = 1
                 ORDER BY id ASC
                 LIMIT 1",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * DISPLAY HELPERS
 * =========================================================
 */

function rud_crm_company_contact_job_title_label(
    $contact
) {

    if (
        ! $contact
    ) {
        return '';
    }

    if (
        'other' ===
        $contact->job_title
        &&
        ! empty(
            $contact->job_title_custom
        )
    ) {

        return
            $contact->job_title_custom;
    }

    $options =
        rud_crm_company_contact_job_titles();

    return
        $options[
            $contact->job_title
        ]
        ?? '';
}


function rud_crm_company_contact_department_label(
    $contact
) {

    if (
        ! $contact
    ) {
        return '';
    }

    if (
        'other' ===
        $contact->department
        &&
        ! empty(
            $contact->department_custom
        )
    ) {

        return
            $contact->department_custom;
    }

    $options =
        rud_crm_company_contact_departments();

    return
        $options[
            $contact->department
        ]
        ?? '';
}
