<?php
/**
 * RUD CRM - Frontend Access Control
 *
 * Purpose:
 * - Hide the WordPress admin toolbar for CRM users on the frontend.
 * - Keep the toolbar for real WordPress Administrators.
 * - Block non-admin CRM users from accessing /wp-admin/.
 * - Redirect blocked users back to the CRM Account page.
 *
 * This file is intentionally isolated and does not modify account.php,
 * customer functions, or import/export functionality.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Return true when the current user is a real WordPress Administrator.
 *
 * We use manage_options because this is the capability reserved for
 * site administrators in this CRM installation.
 */
function rud_crm_frontend_access_is_wordpress_admin() {
    return is_user_logged_in() && current_user_can( 'manage_options' );
}

/**
 * Return true when the current user should be treated as a CRM frontend user.
 *
 * This intentionally covers CRM roles/capabilities without exposing
 * WordPress administration UI.
 */
function rud_crm_frontend_access_is_crm_user() {
    if ( ! is_user_logged_in() ) {
        return false;
    }

    if ( rud_crm_frontend_access_is_wordpress_admin() ) {
        return false;
    }

    $user = wp_get_current_user();

    if ( ! $user || empty( $user->ID ) ) {
        return false;
    }

    $roles = (array) $user->roles;

    $crm_roles = array(
        'rud_crm_manager',
        'rud_crm_editor',
        'rud_crm_viewer',
        'rud_crm_demo',
    );

    if ( array_intersect( $crm_roles, $roles ) ) {
        return true;
    }

    $crm_capabilities = array(
        'rud_crm_view',
        'rud_crm_create',
        'rud_crm_edit',
        'rud_crm_delete',
        'rud_crm_export',
    );

    foreach ( $crm_capabilities as $capability ) {
        if ( current_user_can( $capability ) ) {
            return true;
        }
    }

    return false;
}

/**
 * Hide the WordPress admin toolbar for CRM frontend users.
 *
 * WordPress Administrators keep the toolbar.
 */
function rud_crm_frontend_access_hide_admin_bar( $show ) {
    if ( rud_crm_frontend_access_is_crm_user() ) {
        return false;
    }

    return $show;
}
add_filter( 'show_admin_bar', 'rud_crm_frontend_access_hide_admin_bar', 1000 );

/**
 * Remove the toolbar preference for CRM frontend users as an extra safeguard.
 *
 * This does not change Administrator behavior.
 */
function rud_crm_frontend_access_force_toolbar_hidden() {
    if ( rud_crm_frontend_access_is_crm_user() ) {
        show_admin_bar( false );
    }
}
add_action( 'after_setup_theme', 'rud_crm_frontend_access_force_toolbar_hidden', 1000 );

/**
 * Redirect CRM frontend users away from wp-admin.
 *
 * Exceptions:
 * - AJAX requests
 * - admin-post.php requests
 * - Administrator users
 *
 * These exceptions are important because frontend CRM forms may rely on
 * WordPress admin endpoints internally even though the user never sees them.
 */
function rud_crm_frontend_access_block_wp_admin() {
    if ( ! is_user_logged_in() ) {
        return;
    }

    if ( rud_crm_frontend_access_is_wordpress_admin() ) {
        return;
    }

    if ( ! rud_crm_frontend_access_is_crm_user() ) {
        return;
    }

    if ( wp_doing_ajax() ) {
        return;
    }

    global $pagenow;

    if ( 'admin-post.php' === $pagenow ) {
        return;
    }

    if ( ! is_admin() ) {
        return;
    }

    $redirect_url = home_url( '/crm-account/' );

    wp_safe_redirect( $redirect_url );
    exit;
}
add_action( 'admin_init', 'rud_crm_frontend_access_block_wp_admin', 1 );

/**
 * Optional login redirect for CRM users.
 *
 * WordPress Administrators keep the normal WordPress login behavior.
 * CRM users are sent to the public CRM Account page after login.
 */
function rud_crm_frontend_access_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
    if ( ! $user instanceof WP_User ) {
        return $redirect_to;
    }

    if ( user_can( $user, 'manage_options' ) ) {
        return $redirect_to;
    }

    $roles = (array) $user->roles;

    $crm_roles = array(
        'rud_crm_manager',
        'rud_crm_editor',
        'rud_crm_viewer',
        'rud_crm_demo',
    );

    $is_crm_user = ! empty( array_intersect( $crm_roles, $roles ) );

    if ( ! $is_crm_user ) {
        foreach (
            array(
                'rud_crm_view',
                'rud_crm_create',
                'rud_crm_edit',
                'rud_crm_delete',
                'rud_crm_export',
            )
            as $capability
        ) {
            if ( user_can( $user, $capability ) ) {
                $is_crm_user = true;
                break;
            }
        }
    }

    if ( $is_crm_user ) {
        return home_url( '/crm-account/' );
    }

    return $redirect_to;
}
add_filter( 'login_redirect', 'rud_crm_frontend_access_login_redirect', 100, 3 );
