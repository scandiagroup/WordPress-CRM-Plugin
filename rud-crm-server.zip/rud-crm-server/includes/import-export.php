<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * EXCEL IMPORT / EXPORT SYSTEM
 * =========================================================
 *
 * Planned workbook sheets:
 *
 * - Customers
 * - Details
 * - Addresses
 * - Contacts
 * - Social Media
 * - Permissions
 * - Activity
 * - Ownership
 *
 * Character support requirement:
 *
 * Æ Ø Å
 * æ ø å
 *
 * =========================================================
 */


/*
 * =========================================================
 * IMPORT / EXPORT RULES
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * STANDARD USER IMPORT LIMIT
 * ---------------------------------------------------------
 */

function rud_crm_excel_standard_import_limit() {

    return 1000;
}


/*
 * ---------------------------------------------------------
 * STANDARD USER EXPORT LIMIT
 * ---------------------------------------------------------
 */

function rud_crm_excel_standard_export_limit() {

    return 5000;
}


/*
 * ---------------------------------------------------------
 * DEMO USER LIMIT
 * ---------------------------------------------------------
 *
 * Demo users may only work with their own
 * maximum 10 real customers.
 *
 * ---------------------------------------------------------
 */

function rud_crm_excel_demo_customer_limit() {

    if (
        function_exists(
            'rud_crm_trial_customer_limit'
        )
    ) {

        return
            rud_crm_trial_customer_limit();
    }


    return 10;
}


/*
 * =========================================================
 * USER ACCESS LEVEL
 * =========================================================
 */

function rud_crm_excel_access_level(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return 'none';
    }


    $user =
        get_userdata(
            $user_id
        );


    if (
        ! $user
    ) {

        return 'none';
    }


    $roles =
        (array)
        $user->roles;


    /*
     * Administrator:
     *
     * Unlimited import/export.
     */

    if (
        in_array(
            'administrator',
            $roles,
            true
        )
    ) {

        return 'unlimited';
    }


    /*
     * CRM Manager:
     *
     * Unlimited import/export.
     */

    if (
        in_array(
            'rud_crm_manager',
            $roles,
            true
        )
    ) {

        return 'unlimited';
    }


    /*
     * Demo account.
     */

    if (
        in_array(
            'rud_crm_demo',
            $roles,
            true
        )
    ) {

        return 'demo';
    }


    /*
     * Other CRM users.
     */

    if (
        current_user_can(
            'rud_crm_view'
        )
    ) {

        return 'standard';
    }


    return 'none';
}


/*
 * =========================================================
 * IMPORT LIMIT FOR CURRENT USER
 * =========================================================
 *
 * NULL means unlimited.
 *
 * =========================================================
 */

function rud_crm_excel_import_limit(
    $user_id = 0
) {

    $level =
        rud_crm_excel_access_level(
            $user_id
        );


    if (
        'unlimited' ===
        $level
    ) {

        return null;
    }


    if (
        'demo' ===
        $level
    ) {

        return
            rud_crm_excel_demo_customer_limit();
    }


    if (
        'standard' ===
        $level
    ) {

        return
            rud_crm_excel_standard_import_limit();
    }


    return 0;
}


/*
 * =========================================================
 * EXPORT LIMIT FOR CURRENT USER
 * =========================================================
 *
 * NULL means unlimited.
 *
 * =========================================================
 */

function rud_crm_excel_export_limit(
    $user_id = 0
) {

    $level =
        rud_crm_excel_access_level(
            $user_id
        );


    if (
        'unlimited' ===
        $level
    ) {

        return null;
    }


    if (
        'demo' ===
        $level
    ) {

        return
            rud_crm_excel_demo_customer_limit();
    }


    if (
        'standard' ===
        $level
    ) {

        return
            rud_crm_excel_standard_export_limit();
    }


    return 0;
}


/*
 * =========================================================
 * PHPSPREADSHEET DETECTION
 * =========================================================
 */

function rud_crm_excel_library_loaded() {

    return
        class_exists(
            '\PhpOffice\PhpSpreadsheet\Spreadsheet'
        )
        &&
        class_exists(
            '\PhpOffice\PhpSpreadsheet\IOFactory'
        );
}


/*
 * =========================================================
 * POSSIBLE COMPOSER AUTOLOAD LOCATIONS
 * =========================================================
 */

function rud_crm_excel_load_library() {

    /*
     * Already loaded.
     */

    if (
        rud_crm_excel_library_loaded()
    ) {

        return true;
    }


    $possible_files =
        array(

            RUD_CRM_PLUGIN_DIR .
            'vendor/autoload.php',

            RUD_CRM_PLUGIN_DIR .
            'includes/vendor/autoload.php'
        );


    foreach (
        $possible_files as
        $autoload_file
    ) {

        if (
            file_exists(
                $autoload_file
            )
        ) {

            require_once
                $autoload_file;


            if (
                rud_crm_excel_library_loaded()
            ) {

                return true;
            }
        }
    }


    return false;
}


/*
 * Try to load library.
 */

rud_crm_excel_load_library();


/*
 * =========================================================
 * REQUIRED WORKBOOK SHEETS
 * =========================================================
 */

function rud_crm_excel_sheet_definitions() {

    return array(

        'Customers' =>
            'Main customer information',

        'Details' =>
            'Customer details and notes',

        'Addresses' =>
            'Private, business, billing and delivery addresses',

        'Contacts' =>
            'Email, telephone and WhatsApp',

        'Social Media' =>
            'Social media accounts',

        'Permissions' =>
            'Customer consent and permissions',

        'Activity' =>
            'Customer timeline and activity history',

        'Ownership' =>
            'CRM customer ownership information'
    );
}


/*
 * =========================================================
 * UNICODE / NORWEGIAN CHARACTER TEST
 * =========================================================
 */

function rud_crm_excel_unicode_test_text() {

    return
        'ÆØÅ æøå – Bjørn Ødegård – Åse Håland – Ægir AS';
}


/*
 * =========================================================
 * FORMAT LIMIT
 * =========================================================
 */

function rud_crm_excel_format_limit(
    $limit
) {

    if (
        null ===
        $limit
    ) {

        return 'Unlimited';
    }


    return
        number_format_i18n(
            absint(
                $limit
            )
        );
}


/*
 * =========================================================
 * EXPORT PERMISSION CHECK
 * =========================================================
 */

function rud_crm_excel_user_can_export() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_view'
        );
}


/*
 * =========================================================
 * DATABASE TABLE EXISTS
 * =========================================================
 */

function rud_crm_excel_table_exists(
    $table_name
) {

    global $wpdb;


    return
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table_name
            )
        )
        ===
        $table_name;
}


/*
 * =========================================================
 * EXPORT CUSTOMER IDS
 * =========================================================
 *
 * Demo users:
 * - only their own customers
 * - never more than the demo limit
 *
 * Other CRM users:
 * - limited by their configured export limit
 * - Administrator / CRM Manager: unlimited
 *
 * =========================================================
 */

function rud_crm_excel_export_customer_ids() {

    global $wpdb;


    $level =
        rud_crm_excel_access_level();


    $limit =
        rud_crm_excel_export_limit();


    if (
        'none' ===
        $level
    ) {

        return array();
    }


    if (
        'demo' ===
        $level
    ) {

        $user_id =
            get_current_user_id();


        if (
            function_exists(
                'rud_crm_get_user_owned_customer_ids'
            )
        ) {

            $ids =
                rud_crm_get_user_owned_customer_ids(
                    $user_id
                );

        } else {

            $ownership_table =
                $wpdb->prefix .
                'rudcrm_customer_ownership';


            if (
                ! rud_crm_excel_table_exists(
                    $ownership_table
                )
            ) {

                return array();
            }


            $ids =
                $wpdb->get_col(
                    $wpdb->prepare(
                        "SELECT customer_id
                         FROM {$ownership_table}
                         WHERE user_id = %d
                         ORDER BY customer_id ASC",
                        $user_id
                    )
                );
        }


        $ids =
            array_values(
                array_unique(
                    array_filter(
                        array_map(
                            'absint',
                            (array) $ids
                        )
                    )
                )
            );


        $demo_limit =
            rud_crm_excel_demo_customer_limit();


        if (
            count(
                $ids
            )
            >
            $demo_limit
        ) {

            $ids =
                array_slice(
                    $ids,
                    0,
                    $demo_limit
                );
        }


        return $ids;
    }


    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';


    if (
        ! rud_crm_excel_table_exists(
            $customers_table
        )
    ) {

        return array();
    }


    $sql =
        "SELECT id
         FROM {$customers_table}
         ORDER BY id ASC";


    if (
        null !==
        $limit
    ) {

        $sql .=
            ' LIMIT ' .
            absint(
                $limit
            );
    }


    return
        array_values(
            array_filter(
                array_map(
                    'absint',
                    (array)
                    $wpdb->get_col(
                        $sql
                    )
                )
            )
        );
}


/*
 * =========================================================
 * EXPORT TABLE DEFINITIONS
 * =========================================================
 */

function rud_crm_excel_export_table_definitions() {

    global $wpdb;


    return array(

        'Customers' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_customers',

                'customer_key' =>
                    'id'
            ),

        'Details' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_customer_details',

                'customer_key' =>
                    'customer_id'
            ),

        'Addresses' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_addresses',

                'customer_key' =>
                    'customer_id'
            ),

        'Contacts' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_contact_methods',

                'customer_key' =>
                    'customer_id'
            ),

        'Social Media' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_social_accounts',

                'customer_key' =>
                    'customer_id'
            ),

        'Permissions' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_customer_permissions',

                'customer_key' =>
                    'customer_id'
            ),

        'Activity' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_customer_activity',

                'customer_key' =>
                    'customer_id'
            ),

        'Ownership' =>
            array(
                'table' =>
                    $wpdb->prefix .
                    'rudcrm_customer_ownership',

                'customer_key' =>
                    'customer_id'
            )
    );
}


/*
 * =========================================================
 * TABLE COLUMNS
 * =========================================================
 */

function rud_crm_excel_table_columns(
    $table_name
) {

    global $wpdb;


    if (
        ! rud_crm_excel_table_exists(
            $table_name
        )
    ) {

        return array();
    }


    $columns =
        $wpdb->get_col(
            "SHOW COLUMNS
             FROM `{$table_name}`",
            0
        );


    return
        array_values(
            array_filter(
                array_map(
                    'strval',
                    (array) $columns
                )
            )
        );
}


/*
 * =========================================================
 * TABLE ROWS FOR CUSTOMER IDS
 * =========================================================
 */

function rud_crm_excel_table_rows(
    $table_name,
    $customer_key,
    $customer_ids
) {

    global $wpdb;


    $customer_ids =
        array_values(
            array_filter(
                array_map(
                    'absint',
                    (array) $customer_ids
                )
            )
        );


    if (
        empty(
            $customer_ids
        )
        ||
        ! rud_crm_excel_table_exists(
            $table_name
        )
    ) {

        return array();
    }


    $columns =
        rud_crm_excel_table_columns(
            $table_name
        );


    if (
        ! in_array(
            $customer_key,
            $columns,
            true
        )
    ) {

        return array();
    }


    $id_list =
        implode(
            ',',
            $customer_ids
        );


    $order_column =
        in_array(
            'id',
            $columns,
            true
        )
        ? 'id'
        : $customer_key;


    $sql =
        "SELECT *
         FROM `{$table_name}`
         WHERE `{$customer_key}` IN ({$id_list})
         ORDER BY `{$customer_key}` ASC,
                  `{$order_column}` ASC";


    return
        (array)
        $wpdb->get_results(
            $sql,
            ARRAY_A
        );
}


/*
 * =========================================================
 * WRITE ONE WORKSHEET
 * =========================================================
 */

function rud_crm_excel_write_sheet(
    $sheet,
    $columns,
    $rows
) {

    $columns =
        array_values(
            (array) $columns
        );


    if (
        empty(
            $columns
        )
    ) {

        $sheet->setCellValue(
            'A1',
            'Table not available on this CRM installation.'
        );

        return;
    }


    foreach (
        $columns as
        $column_index =>
        $column_name
    ) {

        $coordinate =
            \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(
                $column_index + 1
            ) .
            '1';


        $sheet->setCellValueExplicit(
            $coordinate,
            (string) $column_name,
            \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING
        );
    }


    $row_number = 2;


    foreach (
        (array) $rows as
        $row
    ) {

        foreach (
            $columns as
            $column_index =>
            $column_name
        ) {

            $coordinate =
                \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(
                    $column_index + 1
                ) .
                $row_number;


            $value =
                array_key_exists(
                    $column_name,
                    $row
                )
                &&
                null !==
                $row[
                    $column_name
                ]
                ? (string)
                    $row[
                        $column_name
                    ]
                : '';


            $sheet->setCellValueExplicit(
                $coordinate,
                $value,
                \PhpOffice\PhpSpreadsheet\Cell\DataType::TYPE_STRING
            );
        }


        $row_number++;
    }


    $last_column =
        \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(
            count(
                $columns
            )
        );


    $sheet->freezePane(
        'A2'
    );


    $sheet->setAutoFilter(
        'A1:' .
        $last_column .
        max(
            1,
            $row_number - 1
        )
    );


    $sheet->getStyle(
        'A1:' .
        $last_column .
        '1'
    )
    ->getFont()
    ->setBold(
        true
    );


    foreach (
        range(
            1,
            count(
                $columns
            )
        ) as
        $column_index
    ) {

        $column_letter =
            \PhpOffice\PhpSpreadsheet\Cell\Coordinate::stringFromColumnIndex(
                $column_index
            );


        $sheet->getColumnDimension(
            $column_letter
        )
        ->setAutoSize(
            true
        );
    }
}


/*
 * =========================================================
 * BUILD EXCEL WORKBOOK
 * =========================================================
 */

function rud_crm_excel_build_export_workbook() {

    if (
        ! rud_crm_excel_load_library()
    ) {

        return new WP_Error(
            'excel_library_missing',
            'PhpSpreadsheet is not available.'
        );
    }


    $customer_ids =
        rud_crm_excel_export_customer_ids();


    $spreadsheet =
        new \PhpOffice\PhpSpreadsheet\Spreadsheet();


    $spreadsheet
        ->getProperties()
        ->setCreator(
            'RUD CRM Server'
        )
        ->setTitle(
            'RUD CRM Customer Export'
        )
        ->setSubject(
            'RUD CRM Customer Data'
        )
        ->setDescription(
            'Customer export generated by RUD CRM Server.'
        );


    $definitions =
        rud_crm_excel_export_table_definitions();


    $sheet_index = 0;


    foreach (
        $definitions as
        $sheet_name =>
        $definition
    ) {

        if (
            0 ===
            $sheet_index
        ) {

            $sheet =
                $spreadsheet->getActiveSheet();

        } else {

            $sheet =
                $spreadsheet->createSheet();
        }


        $sheet->setTitle(
            $sheet_name
        );


        $columns =
            rud_crm_excel_table_columns(
                $definition[
                    'table'
                ]
            );


        $rows =
            rud_crm_excel_table_rows(
                $definition[
                    'table'
                ],
                $definition[
                    'customer_key'
                ],
                $customer_ids
            );


        rud_crm_excel_write_sheet(
            $sheet,
            $columns,
            $rows
        );


        $sheet_index++;
    }


    $spreadsheet->setActiveSheetIndex(
        0
    );


    return $spreadsheet;
}


/*
 * =========================================================
 * DOWNLOAD XLSX EXPORT
 * =========================================================
 */

function rud_crm_excel_process_export() {

    if (
        ! rud_crm_excel_user_can_export()
    ) {

        wp_die(
            esc_html__(
                'You are not allowed to export CRM customers.',
                'rud-crm-server'
            )
        );
    }


    check_admin_referer(
        'rud_crm_excel_export_action',
        'rud_crm_excel_export_nonce'
    );


    $workbook =
        rud_crm_excel_build_export_workbook();


    if (
        is_wp_error(
            $workbook
        )
    ) {

        wp_die(
            esc_html(
                $workbook->get_error_message()
            )
        );
    }


    $filename =
        'rud-crm-customers-' .
        gmdate(
            'Y-m-d-His'
        ) .
        '.xlsx';


    while (
        ob_get_level()
        >
        0
    ) {

        ob_end_clean();
    }


    nocache_headers();


    header(
        'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );

    header(
        'Content-Disposition: attachment; filename="' .
        $filename .
        '"'
    );

    header(
        'Content-Transfer-Encoding: binary'
    );


    $writer =
        new \PhpOffice\PhpSpreadsheet\Writer\Xlsx(
            $workbook
        );


    $writer->save(
        'php://output'
    );


    $workbook->disconnectWorksheets();


    exit;
}


add_action(
    'admin_post_rud_crm_export_customers_xlsx',
    'rud_crm_excel_process_export'
);


/*
 * =========================================================
 * IMPORT PREVIEW PERMISSION CHECK
 * =========================================================
 */

function rud_crm_excel_user_can_preview_import() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    return
        current_user_can(
            'manage_options'
        )
        ||
        current_user_can(
            'rud_crm_view'
        );
}


/*
 * =========================================================
 * NORMALIZE IMPORT HEADER ROW
 * =========================================================
 */

function rud_crm_excel_normalize_header_row(
    $row
) {

    $headers = array();


    foreach (
        (array) $row as
        $value
    ) {

        $value =
            is_scalar(
                $value
            )
            ? trim(
                (string) $value
            )
            : '';


        if (
            '' !==
            $value
        ) {

            $headers[] =
                $value;
        }
    }


    return $headers;
}


/*
 * =========================================================
 * PREVIEW XLSX IMPORT
 * =========================================================
 *
 * This validates the workbook and shows what would be
 * imported. It does NOT write anything to the database.
 *
 * =========================================================
 */

function rud_crm_excel_build_import_preview(
    $uploaded_file
) {

    if (
        ! rud_crm_excel_user_can_preview_import()
    ) {

        return new WP_Error(
            'import_not_allowed',
            'You are not allowed to preview CRM imports.'
        );
    }


    if (
        ! rud_crm_excel_load_library()
    ) {

        return new WP_Error(
            'excel_library_missing',
            'PhpSpreadsheet is not available.'
        );
    }


    if (
        ! is_array(
            $uploaded_file
        )
        ||
        empty(
            $uploaded_file[
                'tmp_name'
            ]
        )
    ) {

        return new WP_Error(
            'import_file_missing',
            'Please select an .xlsx file.'
        );
    }


    $upload_error =
        isset(
            $uploaded_file[
                'error'
            ]
        )
        ? absint(
            $uploaded_file[
                'error'
            ]
        )
        : UPLOAD_ERR_NO_FILE;


    if (
        UPLOAD_ERR_OK !==
        $upload_error
    ) {

        return new WP_Error(
            'import_upload_error',
            'The Excel file could not be uploaded. Upload error code: ' .
            $upload_error
        );
    }


    $original_name =
        isset(
            $uploaded_file[
                'name'
            ]
        )
        ? sanitize_file_name(
            wp_unslash(
                $uploaded_file[
                    'name'
                ]
            )
        )
        : '';


    $extension =
        strtolower(
            pathinfo(
                $original_name,
                PATHINFO_EXTENSION
            )
        );


    if (
        'xlsx' !==
        $extension
    ) {

        return new WP_Error(
            'import_wrong_extension',
            'Only Microsoft Excel .xlsx files are accepted.'
        );
    }


    $tmp_name =
        (string)
        $uploaded_file[
            'tmp_name'
        ];


    if (
        ! is_uploaded_file(
            $tmp_name
        )
        &&
        ! file_exists(
            $tmp_name
        )
    ) {

        return new WP_Error(
            'import_temp_missing',
            'The uploaded Excel file is not available for validation.'
        );
    }


    try {

        $identified_type =
            \PhpOffice\PhpSpreadsheet\IOFactory::identify(
                $tmp_name
            );


        if (
            'Xlsx' !==
            $identified_type
        ) {

            return new WP_Error(
                'import_wrong_excel_type',
                'The selected file is not a valid .xlsx workbook.'
            );
        }


        $reader =
            \PhpOffice\PhpSpreadsheet\IOFactory::createReader(
                'Xlsx'
            );


        $reader->setReadDataOnly(
            true
        );


        $spreadsheet =
            $reader->load(
                $tmp_name
            );

    } catch (
        \Throwable $exception
    ) {

        return new WP_Error(
            'import_read_error',
            'The .xlsx workbook could not be read: ' .
            $exception->getMessage()
        );
    }


    $required_sheets =
        array_keys(
            rud_crm_excel_sheet_definitions()
        );


    $available_sheets =
        $spreadsheet->getSheetNames();


    $missing_sheets =
        array_values(
            array_diff(
                $required_sheets,
                $available_sheets
            )
        );


    if (
        ! empty(
            $missing_sheets
        )
    ) {

        $spreadsheet->disconnectWorksheets();


        return new WP_Error(
            'import_missing_sheets',
            'Required sheet(s) missing: ' .
            implode(
                ', ',
                $missing_sheets
            )
        );
    }


    $preview = array(
        'file_name' =>
            $original_name,

        'file_size' =>
            isset(
                $uploaded_file[
                    'size'
                ]
            )
            ? absint(
                $uploaded_file[
                    'size'
                ]
            )
            : 0,

        'customer_rows' =>
            0,

        'sheets' =>
            array(),

        'warnings' =>
            array()
    );


    foreach (
        $required_sheets as
        $sheet_name
    ) {

        $worksheet =
            $spreadsheet->getSheetByName(
                $sheet_name
            );


        if (
            ! $worksheet
        ) {

            continue;
        }


        $highest_column =
            $worksheet->getHighestDataColumn();


        $highest_row =
            $worksheet->getHighestDataRow();


        $header_row =
            $worksheet->rangeToArray(
                'A1:' .
                $highest_column .
                '1',
                null,
                true,
                false
            );


        $headers =
            rud_crm_excel_normalize_header_row(
                isset(
                    $header_row[0]
                )
                ? $header_row[0]
                : array()
            );


        $data_rows = 0;


        if (
            $highest_row > 1
        ) {

            for (
                $row_number = 2;
                $row_number <= $highest_row;
                $row_number++
            ) {

                $row_values =
                    $worksheet->rangeToArray(
                        'A' .
                        $row_number .
                        ':' .
                        $highest_column .
                        $row_number,
                        null,
                        true,
                        false
                    );


                $has_value = false;


                foreach (
                    isset(
                        $row_values[0]
                    )
                    ? $row_values[0]
                    : array()
                    as
                    $cell_value
                ) {

                    if (
                        null !==
                        $cell_value
                        &&
                        '' !==
                        trim(
                            (string) $cell_value
                        )
                    ) {

                        $has_value = true;

                        break;
                    }
                }


                if (
                    $has_value
                ) {

                    $data_rows++;
                }
            }
        }


        if (
            empty(
                $headers
            )
        ) {

            $preview[
                'warnings'
            ][] =
                $sheet_name .
                ': no header columns were found.';
        }


        if (
            'Customers' ===
            $sheet_name
            &&
            ! in_array(
                'id',
                $headers,
                true
            )
        ) {

            $preview[
                'warnings'
            ][] =
                'Customers: required header "id" was not found.';
        }


        if (
            'Customers' !==
            $sheet_name
            &&
            ! empty(
                $headers
            )
            &&
            ! in_array(
                'customer_id',
                $headers,
                true
            )
        ) {

            $preview[
                'warnings'
            ][] =
                $sheet_name .
                ': expected header "customer_id" was not found.';
        }


        $preview[
            'sheets'
        ][
            $sheet_name
        ] = array(
            'rows' =>
                $data_rows,

            'headers' =>
                $headers
        );


        if (
            'Customers' ===
            $sheet_name
        ) {

            $preview[
                'customer_rows'
            ] =
                $data_rows;
        }
    }


    $import_limit =
        rud_crm_excel_import_limit();


    if (
        null !==
        $import_limit
        &&
        $preview[
            'customer_rows'
        ]
        >
        $import_limit
    ) {

        $preview[
            'warnings'
        ][] =
            'The workbook contains ' .
            number_format_i18n(
                $preview[
                    'customer_rows'
                ]
            ) .
            ' customer rows, which exceeds your import limit of ' .
            number_format_i18n(
                $import_limit
            ) .
            '.';
    }


    $spreadsheet->disconnectWorksheets();


    return $preview;
}


/*
 * =========================================================
 * HANDLE IMPORT PREVIEW REQUEST
 * =========================================================
 */

function rud_crm_excel_maybe_process_import_preview() {

    if (
        'POST' !==
        strtoupper(
            isset(
                $_SERVER[
                    'REQUEST_METHOD'
                ]
            )
            ? sanitize_text_field(
                wp_unslash(
                    $_SERVER[
                        'REQUEST_METHOD'
                    ]
                )
            )
            : ''
        )
    ) {

        return null;
    }


    if (
        empty(
            $_POST[
                'rud_crm_excel_preview_import'
            ]
        )
    ) {

        return null;
    }


    if (
        ! rud_crm_excel_user_can_preview_import()
    ) {

        return new WP_Error(
            'import_not_allowed',
            'You are not allowed to preview CRM imports.'
        );
    }


    check_admin_referer(
        'rud_crm_excel_import_preview_action',
        'rud_crm_excel_import_preview_nonce'
    );


    $uploaded_file =
        isset(
            $_FILES[
                'rud_crm_excel_import_file'
            ]
        )
        ? $_FILES[
            'rud_crm_excel_import_file'
        ]
        : array();


    return
        rud_crm_excel_build_import_preview(
            $uploaded_file
        );
}


/*
 * =========================================================
 * ACTUAL XLSX IMPORT PERMISSION CHECK
 * =========================================================
 *
 * Preview may be available to CRM viewers, but a database
 * import requires create permission (or Administrator).
 *
 * =========================================================
 */

function rud_crm_excel_user_can_import() {

    if ( ! is_user_logged_in() ) {
        return false;
    }

    return
        current_user_can( 'manage_options' )
        ||
        current_user_can( 'rud_crm_create' );
}


/*
 * =========================================================
 * IMPORT TABLE DEFINITIONS
 * =========================================================
 */

function rud_crm_excel_import_table_definitions() {

    global $wpdb;

    return array(
        'Customers'    => $wpdb->prefix . 'rudcrm_customers',
        'Details'      => $wpdb->prefix . 'rudcrm_customer_details',
        'Addresses'    => $wpdb->prefix . 'rudcrm_addresses',
        'Contacts'     => $wpdb->prefix . 'rudcrm_contact_methods',
        'Social Media' => $wpdb->prefix . 'rudcrm_social_accounts',
        'Permissions'  => $wpdb->prefix . 'rudcrm_customer_permissions',
        'Activity'     => $wpdb->prefix . 'rudcrm_customer_activity',
        'Ownership'    => $wpdb->prefix . 'rudcrm_customer_ownership',
    );
}


/*
 * =========================================================
 * READ ONE WORKSHEET AS ASSOCIATIVE ROWS
 * =========================================================
 */

function rud_crm_excel_import_sheet_rows( $spreadsheet, $sheet_name ) {

    $worksheet = $spreadsheet->getSheetByName( $sheet_name );

    if ( ! $worksheet ) {
        return new WP_Error(
            'import_sheet_missing',
            'Required sheet missing: ' . $sheet_name
        );
    }

    $highest_column = $worksheet->getHighestDataColumn();
    $highest_row    = $worksheet->getHighestDataRow();

    $header_values = $worksheet->rangeToArray(
        'A1:' . $highest_column . '1',
        null,
        true,
        false
    );

    $headers = isset( $header_values[0] )
        ? rud_crm_excel_normalize_header_row( $header_values[0] )
        : array();

    if ( empty( $headers ) ) {
        return new WP_Error(
            'import_headers_missing',
            $sheet_name . ': no header columns were found.'
        );
    }

    $rows = array();

    for ( $row_number = 2; $row_number <= $highest_row; $row_number++ ) {

        $row_values = $worksheet->rangeToArray(
            'A' . $row_number . ':' . $highest_column . $row_number,
            null,
            true,
            false
        );

        $values = isset( $row_values[0] )
            ? $row_values[0]
            : array();

        $has_value = false;

        foreach ( $values as $value ) {
            if ( null !== $value && '' !== trim( (string) $value ) ) {
                $has_value = true;
                break;
            }
        }

        if ( ! $has_value ) {
            continue;
        }

        $row = array();

        foreach ( $headers as $index => $header ) {
            $row[ $header ] = array_key_exists( $index, $values )
                ? $values[ $index ]
                : null;
        }

        $rows[] = $row;
    }

    return $rows;
}


/*
 * =========================================================
 * FILTER IMPORT DATA AGAINST LIVE DATABASE COLUMNS
 * =========================================================
 *
 * This allows the importer to stay compatible with the live
 * RUD CRM schema while refusing to write unknown columns.
 *
 * =========================================================
 */

function rud_crm_excel_import_filter_table_data( $table_name, $row ) {

    $columns = rud_crm_excel_table_columns( $table_name );

    if ( empty( $columns ) ) {
        return array();
    }

    $allowed = array_fill_keys( $columns, true );
    $data    = array();

    foreach ( (array) $row as $column => $value ) {

        if ( 'id' === $column ) {
            continue;
        }

        if ( ! isset( $allowed[ $column ] ) ) {
            continue;
        }

        if ( is_scalar( $value ) || null === $value ) {
            $data[ $column ] = $value;
        }
    }

    return $data;
}


/*
 * =========================================================
 * IMPORT LIMIT CHECK
 * =========================================================
 */

function rud_crm_excel_import_customer_limit_check( $customer_count ) {

    $customer_count = absint( $customer_count );
    $limit          = rud_crm_excel_import_limit();

    if ( null !== $limit && $customer_count > $limit ) {
        return new WP_Error(
            'import_limit_exceeded',
            'The workbook contains ' .
            number_format_i18n( $customer_count ) .
            ' customers, which exceeds your import limit of ' .
            number_format_i18n( $limit ) . '.'
        );
    }

    if ( 'demo' === rud_crm_excel_access_level() ) {

        $remaining = null;
        $user_id   = get_current_user_id();

        if ( function_exists( 'rud_crm_trial_customer_slots_remaining' ) ) {
            $remaining = absint(
                rud_crm_trial_customer_slots_remaining( $user_id )
            );
        } else {

            $owned_count = 0;

            if ( function_exists( 'rud_crm_count_owned_customers' ) ) {
                $owned_count = absint(
                    rud_crm_count_owned_customers( $user_id, 'trial' )
                );
            }

            $remaining = max(
                0,
                rud_crm_excel_demo_customer_limit() - $owned_count
            );
        }

        if ( $customer_count > $remaining ) {
            return new WP_Error(
                'import_demo_slots_exceeded',
                'Your Demo account has only ' .
                number_format_i18n( $remaining ) .
                ' customer slot(s) remaining.'
            );
        }
    }

    return true;
}


/*
 * =========================================================
 * GENERATE SAFE NEW CUSTOMER NUMBER
 * =========================================================
 */

function rud_crm_excel_import_customer_number( $customer_id ) {

    if ( function_exists( 'rud_crm_frontend_create_customer_number' ) ) {
        return rud_crm_frontend_create_customer_number( $customer_id );
    }

    return sprintf(
        'CUST-%s-%06d',
        wp_date( 'y' ),
        absint( $customer_id )
    );
}


/*
 * =========================================================
 * IMPORT XLSX WORKBOOK INTO NEW CRM RECORDS
 * =========================================================
 *
 * SAFETY MODEL:
 * - Existing CRM customers are never updated or overwritten.
 * - Source database IDs are never reused.
 * - Each imported customer receives a new UUID and customer
 *   number.
 * - Related rows are remapped from old customer_id to the new
 *   customer_id.
 * - All writes run inside one database transaction. Any failed
 *   insert triggers a rollback.
 *
 * =========================================================
 */

function rud_crm_excel_import_workbook( $uploaded_file ) {

    global $wpdb;

    if ( ! rud_crm_excel_user_can_import() ) {
        return new WP_Error(
            'import_not_allowed',
            'You are not allowed to import CRM customers.'
        );
    }

    if ( ! rud_crm_excel_load_library() ) {
        return new WP_Error(
            'excel_library_missing',
            'PhpSpreadsheet is not available.'
        );
    }

    if (
        ! is_array( $uploaded_file )
        ||
        empty( $uploaded_file['tmp_name'] )
    ) {
        return new WP_Error(
            'import_file_missing',
            'Please select an .xlsx file.'
        );
    }

    $upload_error = isset( $uploaded_file['error'] )
        ? absint( $uploaded_file['error'] )
        : UPLOAD_ERR_NO_FILE;

    if ( UPLOAD_ERR_OK !== $upload_error ) {
        return new WP_Error(
            'import_upload_error',
            'The Excel file could not be uploaded. Upload error code: ' .
            $upload_error
        );
    }

    $original_name = isset( $uploaded_file['name'] )
        ? sanitize_file_name( wp_unslash( $uploaded_file['name'] ) )
        : '';

    if (
        'xlsx' !== strtolower(
            pathinfo( $original_name, PATHINFO_EXTENSION )
        )
    ) {
        return new WP_Error(
            'import_wrong_extension',
            'Only Microsoft Excel .xlsx files are accepted.'
        );
    }

    $tmp_name = (string) $uploaded_file['tmp_name'];

    try {

        if ( 'Xlsx' !== \PhpOffice\PhpSpreadsheet\IOFactory::identify( $tmp_name ) ) {
            return new WP_Error(
                'import_wrong_excel_type',
                'The selected file is not a valid .xlsx workbook.'
            );
        }

        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader( 'Xlsx' );
        $reader->setReadDataOnly( true );
        $spreadsheet = $reader->load( $tmp_name );

    } catch ( \Throwable $exception ) {
        return new WP_Error(
            'import_read_error',
            'The .xlsx workbook could not be read: ' .
            $exception->getMessage()
        );
    }

    $required_sheets = array_keys( rud_crm_excel_sheet_definitions() );
    $available       = $spreadsheet->getSheetNames();
    $missing         = array_values( array_diff( $required_sheets, $available ) );

    if ( ! empty( $missing ) ) {
        $spreadsheet->disconnectWorksheets();
        return new WP_Error(
            'import_missing_sheets',
            'Required sheet(s) missing: ' . implode( ', ', $missing )
        );
    }

    $tables = rud_crm_excel_import_table_definitions();

    foreach ( $tables as $sheet_name => $table_name ) {
        if ( ! rud_crm_excel_table_exists( $table_name ) ) {
            $spreadsheet->disconnectWorksheets();
            return new WP_Error(
                'import_table_missing',
                'Required CRM database table is missing for sheet ' .
                $sheet_name . ': ' . $table_name
            );
        }
    }

    $sheet_rows = array();

    foreach ( $required_sheets as $sheet_name ) {

        $rows = rud_crm_excel_import_sheet_rows(
            $spreadsheet,
            $sheet_name
        );

        if ( is_wp_error( $rows ) ) {
            $spreadsheet->disconnectWorksheets();
            return $rows;
        }

        $sheet_rows[ $sheet_name ] = $rows;
    }

    $customers = isset( $sheet_rows['Customers'] )
        ? $sheet_rows['Customers']
        : array();

    if ( empty( $customers ) ) {
        $spreadsheet->disconnectWorksheets();
        return new WP_Error(
            'import_no_customers',
            'The Customers sheet contains no customer rows.'
        );
    }

    $limit_check = rud_crm_excel_import_customer_limit_check(
        count( $customers )
    );

    if ( is_wp_error( $limit_check ) ) {
        $spreadsheet->disconnectWorksheets();
        return $limit_check;
    }

    foreach ( $customers as $customer_row ) {
        if ( empty( $customer_row['id'] ) || ! absint( $customer_row['id'] ) ) {
            $spreadsheet->disconnectWorksheets();
            return new WP_Error(
                'import_customer_id_missing',
                'Every Customers row must contain a valid source id.'
            );
        }
    }

    $wpdb->query( 'START TRANSACTION' );

    $id_map        = array();
    $insert_counts = array_fill_keys( $required_sheets, 0 );

    try {

        $customers_table = $tables['Customers'];

        foreach ( $customers as $customer_row ) {

            $old_customer_id = absint( $customer_row['id'] );

            if ( isset( $id_map[ $old_customer_id ] ) ) {
                throw new \RuntimeException(
                    'Duplicate source customer id found: ' . $old_customer_id
                );
            }

            $data = rud_crm_excel_import_filter_table_data(
                $customers_table,
                $customer_row
            );

            $uuid = wp_generate_uuid4();

            if ( array_key_exists( 'customer_uuid', $data ) ) {
                $data['customer_uuid'] = $uuid;
            }

            if ( array_key_exists( 'customer_number', $data ) ) {
                $data['customer_number'] =
                    'TMP-' .
                    strtoupper(
                        substr(
                            str_replace( '-', '', $uuid ),
                            0,
                            20
                        )
                    );
            }

            if ( array_key_exists( 'updated_at', $data ) ) {
                $data['updated_at'] = current_time( 'mysql' );
            }

            $inserted = $wpdb->insert( $customers_table, $data );

            if ( false === $inserted ) {
                throw new \RuntimeException(
                    'Customers insert failed for source id ' .
                    $old_customer_id . ': ' . $wpdb->last_error
                );
            }

            $new_customer_id = absint( $wpdb->insert_id );

            if ( ! $new_customer_id ) {
                throw new \RuntimeException(
                    'Customers insert did not return a new database id.'
                );
            }

            $new_customer_number = rud_crm_excel_import_customer_number(
                $new_customer_id
            );

            $number_updated = $wpdb->update(
                $customers_table,
                array(
                    'customer_number' => $new_customer_number,
                    'updated_at'      => current_time( 'mysql' ),
                ),
                array(
                    'id' => $new_customer_id,
                ),
                array( '%s', '%s' ),
                array( '%d' )
            );

            if ( false === $number_updated ) {
                throw new \RuntimeException(
                    'Could not assign the final customer number to new customer ' .
                    $new_customer_id . ': ' . $wpdb->last_error
                );
            }

            $id_map[ $old_customer_id ] = $new_customer_id;
            $insert_counts['Customers']++;
        }

        foreach ( $required_sheets as $sheet_name ) {

            if ( 'Customers' === $sheet_name ) {
                continue;
            }

            $table_name = $tables[ $sheet_name ];

            foreach ( $sheet_rows[ $sheet_name ] as $source_row ) {

                $old_customer_id = isset( $source_row['customer_id'] )
                    ? absint( $source_row['customer_id'] )
                    : 0;

                if ( ! $old_customer_id ) {
                    throw new \RuntimeException(
                        $sheet_name . ': a row is missing customer_id.'
                    );
                }

                if ( ! isset( $id_map[ $old_customer_id ] ) ) {
                    /*
                     * Exported workbooks may contain related records that do
                     * not belong to a customer included in the Customers
                     * sheet. Those rows are intentionally skipped.
                     */
                    continue;
                }

                $data = rud_crm_excel_import_filter_table_data(
                    $table_name,
                    $source_row
                );

                $data['customer_id'] = $id_map[ $old_customer_id ];

                if ( 'Ownership' === $sheet_name ) {

                    $source_user_id = isset( $data['user_id'] )
                        ? absint( $data['user_id'] )
                        : 0;

                    if ( ! current_user_can( 'manage_options' ) ) {
                        $data['user_id'] = get_current_user_id();
                    } elseif ( ! $source_user_id || ! get_userdata( $source_user_id ) ) {
                        $data['user_id'] = get_current_user_id();
                    }
                }

                if ( array_key_exists( 'updated_at', $data ) ) {
                    $data['updated_at'] = current_time( 'mysql' );
                }

                $inserted = $wpdb->insert( $table_name, $data );

                if ( false === $inserted ) {
                    throw new \RuntimeException(
                        $sheet_name . ' insert failed for source customer id ' .
                        $old_customer_id . ': ' . $wpdb->last_error
                    );
                }

                $insert_counts[ $sheet_name ]++;
            }
        }

        /*
         * Non-administrator imports must always leave every new customer
         * assigned to the importing account, even when the workbook had no
         * Ownership row for that customer.
         */
        if ( ! current_user_can( 'manage_options' ) ) {

            $ownership_table = $tables['Ownership'];
            $current_user_id = get_current_user_id();

            foreach ( $id_map as $new_customer_id ) {

                $already_owned = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id FROM {$ownership_table} WHERE customer_id = %d LIMIT 1",
                        $new_customer_id
                    )
                );

                if ( $already_owned ) {
                    continue;
                }

                $ownership_type = 'client';

                if ( 'demo' === rud_crm_excel_access_level() ) {
                    $ownership_type = 'trial';
                }

                $inserted = $wpdb->insert(
                    $ownership_table,
                    array(
                        'customer_id'    => $new_customer_id,
                        'user_id'        => $current_user_id,
                        'ownership_type' => $ownership_type,
                        'created_at'     => current_time( 'mysql' ),
                        'updated_at'     => current_time( 'mysql' ),
                    )
                );

                if ( false === $inserted ) {
                    throw new \RuntimeException(
                        'Ownership assignment failed for new customer ' .
                        $new_customer_id . ': ' . $wpdb->last_error
                    );
                }

                $insert_counts['Ownership']++;
            }
        }

        $wpdb->query( 'COMMIT' );

    } catch ( \Throwable $exception ) {

        $wpdb->query( 'ROLLBACK' );
        $spreadsheet->disconnectWorksheets();

        return new WP_Error(
            'import_database_error',
            'Import rolled back. No imported records were kept. ' .
            $exception->getMessage()
        );
    }

    $spreadsheet->disconnectWorksheets();

    return array(
        'file_name'     => $original_name,
        'customers'     => $insert_counts['Customers'],
        'sheet_counts'  => $insert_counts,
        'related_rows'  => array_sum( $insert_counts ) - $insert_counts['Customers'],
    );
}


/*
 * =========================================================
 * HANDLE ACTUAL IMPORT
 * =========================================================
 */

function rud_crm_excel_process_import() {

    if ( ! rud_crm_excel_user_can_import() ) {
        wp_die(
            esc_html__(
                'You are not allowed to import CRM customers.',
                'rud-crm-server'
            )
        );
    }

    check_admin_referer(
        'rud_crm_excel_import_action',
        'rud_crm_excel_import_nonce'
    );

    if ( empty( $_POST['rud_crm_excel_confirm_import'] ) ) {
        $result = new WP_Error(
            'import_not_confirmed',
            'You must confirm that you understand the import creates new CRM records.'
        );
    } else {
        $uploaded_file = isset( $_FILES['rud_crm_excel_import_file'] )
            ? $_FILES['rud_crm_excel_import_file']
            : array();

        $result = rud_crm_excel_import_workbook( $uploaded_file );
    }

    $redirect_url = admin_url( 'admin.php?page=rud-crm-import-export' );

    if ( is_wp_error( $result ) ) {

        $redirect_url = add_query_arg(
            array(
                'rud_crm_import'         => 'error',
                'rud_crm_import_message' => rawurlencode(
                    $result->get_error_message()
                ),
            ),
            $redirect_url
        );

    } else {

        $redirect_url = add_query_arg(
            array(
                'rud_crm_import'   => 'success',
                'rud_crm_customers'=> absint( $result['customers'] ),
                'rud_crm_related'  => absint( $result['related_rows'] ),
            ),
            $redirect_url
        );
    }

    wp_safe_redirect( $redirect_url );
    exit;
}

add_action(
    'admin_post_rud_crm_import_customers_xlsx',
    'rud_crm_excel_process_import'
);


/*
 * =========================================================
 * IMPORT RESULT NOTICE
 * =========================================================
 */

function rud_crm_excel_import_result_notice() {

    $status = isset( $_GET['rud_crm_import'] )
        ? sanitize_key( wp_unslash( $_GET['rud_crm_import'] ) )
        : '';

    if ( 'success' === $status ) {

        $customers = isset( $_GET['rud_crm_customers'] )
            ? absint( $_GET['rud_crm_customers'] )
            : 0;

        $related = isset( $_GET['rud_crm_related'] )
            ? absint( $_GET['rud_crm_related'] )
            : 0;

        ?>
        <div class="notice notice-success inline">
            <p>
                <strong>Import completed successfully.</strong>
                <?php echo esc_html( number_format_i18n( $customers ) ); ?>
                new customer(s) and
                <?php echo esc_html( number_format_i18n( $related ) ); ?>
                related record(s) were created.
            </p>
        </div>
        <?php

    } elseif ( 'error' === $status ) {

        $message = isset( $_GET['rud_crm_import_message'] )
            ? sanitize_text_field(
                rawurldecode(
                    wp_unslash( $_GET['rud_crm_import_message'] )
                )
            )
            : 'The import failed.';

        ?>
        <div class="notice notice-error inline">
            <p>
                <strong>Import Failed:</strong>
                <?php echo esc_html( $message ); ?>
            </p>
        </div>
        <?php
    }
}


/*
 * =========================================================
 * ADMIN PAGE
 * =========================================================
 */

function rud_crm_import_export_admin_page() {

    if (
        ! current_user_can(
            'manage_options'
        )
        &&
        ! current_user_can(
            'rud_crm_view'
        )
    ) {

        wp_die(
            esc_html__(
                'You are not allowed to access CRM Import / Export.',
                'rud-crm-server'
            )
        );
    }


    $access_level =
        rud_crm_excel_access_level();


    $import_limit =
        rud_crm_excel_import_limit();


    $export_limit =
        rud_crm_excel_export_limit();


    $library_ready =
        rud_crm_excel_load_library();


    $import_preview =
        rud_crm_excel_maybe_process_import_preview();


    ?>

    <div class="wrap">

        <h1>
            RUD CRM Excel Import / Export
        </h1>


        <p>
            Import and export complete CRM customer data using
            Microsoft Excel .xlsx workbooks.
        </p>

        <?php rud_crm_excel_import_result_notice(); ?>

        <hr>


        <h2>
            System Status
        </h2>


        <table class="widefat striped"
               style="max-width:900px;">

            <tbody>


            <tr>

                <td style="width:280px;">
                    <strong>
                        Access Level
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        ucfirst(
                            $access_level
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Import Limit
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_format_limit(
                            $import_limit
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Export Limit
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_format_limit(
                            $export_limit
                        )
                    );
                    ?>
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Excel Library
                    </strong>
                </td>

                <td>

                    <?php

                    if (
                        $library_ready
                    ) {

                        ?>

                        <span style="color:green;font-weight:bold;">
                            READY
                        </span>

                        <?php

                    } else {

                        ?>

                        <span style="color:#b32d2e;font-weight:bold;">
                            NOT INSTALLED
                        </span>

                        <?php
                    }

                    ?>

                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Excel Format
                    </strong>
                </td>

                <td>
                    .xlsx
                </td>

            </tr>


            <tr>

                <td>
                    <strong>
                        Norwegian Character Test
                    </strong>
                </td>

                <td>
                    <?php
                    echo esc_html(
                        rud_crm_excel_unicode_test_text()
                    );
                    ?>
                </td>

            </tr>


            </tbody>

        </table>


        <br>


        <h2>
            Excel Workbook Structure
        </h2>


        <table class="widefat striped"
               style="max-width:900px;">

            <thead>

            <tr>

                <th>
                    Sheet
                </th>

                <th>
                    Content
                </th>

            </tr>

            </thead>

            <tbody>

            <?php

            foreach (
                rud_crm_excel_sheet_definitions()
                as
                $sheet =>
                $description
            ) {

                ?>

                <tr>

                    <td>
                        <strong>
                            <?php
                            echo esc_html(
                                $sheet
                            );
                            ?>
                        </strong>
                    </td>

                    <td>
                        <?php
                        echo esc_html(
                            $description
                        );
                        ?>
                    </td>

                </tr>

                <?php
            }

            ?>

            </tbody>

        </table>


        <br>


        <h2>
            Export Customers
        </h2>


        <?php

        if (
            ! $library_ready
        ) {

            ?>

            <div class="notice notice-warning inline">

                <p>
                    Excel support is not installed yet.
                    The next step will install/connect the
                    PhpSpreadsheet library.
                </p>

            </div>

            <?php

        } else {

            ?>

            <p>
                Excel library is ready.
            </p>

            <?php
        }

        ?>


        <?php if ( $library_ready ) : ?>

            <form
                method="post"
                action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
            >

                <input
                    type="hidden"
                    name="action"
                    value="rud_crm_export_customers_xlsx"
                >

                <?php
                wp_nonce_field(
                    'rud_crm_excel_export_action',
                    'rud_crm_excel_export_nonce'
                );
                ?>

                <button
                    type="submit"
                    class="button button-primary"
                >
                    Export Customers to .xlsx
                </button>

            </form>

        <?php else : ?>

            <button
                type="button"
                class="button button-primary"
                disabled
            >
                Export Customers to .xlsx
            </button>

        <?php endif; ?>


        <br><br>


        <h2>
            Import Customers
        </h2>


        <p>
            Select an RUD CRM .xlsx workbook and preview it before import.
            Preview does not change the database.
        </p>


        <?php

        if (
            is_wp_error(
                $import_preview
            )
        ) {

            ?>

            <div class="notice notice-error inline">

                <p>
                    <strong>
                        Import Preview Failed:
                    </strong>
                    <?php
                    echo esc_html(
                        $import_preview->get_error_message()
                    );
                    ?>
                </p>

            </div>

            <?php

        } elseif (
            is_array(
                $import_preview
            )
        ) {

            ?>

            <div class="notice notice-success inline">

                <p>
                    <strong>
                        Workbook validated successfully.
                    </strong>
                    No database changes have been made.
                </p>

            </div>


            <table class="widefat striped"
                   style="max-width:1100px;margin-top:15px;">

                <tbody>

                <tr>
                    <td style="width:280px;">
                        <strong>File</strong>
                    </td>
                    <td>
                        <?php
                        echo esc_html(
                            $import_preview[
                                'file_name'
                            ]
                        );
                        ?>
                    </td>
                </tr>

                <tr>
                    <td>
                        <strong>File Size</strong>
                    </td>
                    <td>
                        <?php
                        echo esc_html(
                            size_format(
                                $import_preview[
                                    'file_size'
                                ]
                            )
                        );
                        ?>
                    </td>
                </tr>

                <tr>
                    <td>
                        <strong>Customer Rows</strong>
                    </td>
                    <td>
                        <?php
                        echo esc_html(
                            number_format_i18n(
                                $import_preview[
                                    'customer_rows'
                                ]
                            )
                        );
                        ?>
                    </td>
                </tr>

                </tbody>

            </table>


            <h3 style="margin-top:25px;">
                Workbook Preview
            </h3>


            <table class="widefat striped"
                   style="max-width:1100px;">

                <thead>

                <tr>
                    <th>Sheet</th>
                    <th>Data Rows</th>
                    <th>Columns Found</th>
                </tr>

                </thead>

                <tbody>

                <?php

                foreach (
                    $import_preview[
                        'sheets'
                    ] as
                    $preview_sheet_name =>
                    $preview_sheet
                ) {

                    ?>

                    <tr>

                        <td>
                            <strong>
                                <?php
                                echo esc_html(
                                    $preview_sheet_name
                                );
                                ?>
                            </strong>
                        </td>

                        <td>
                            <?php
                            echo esc_html(
                                number_format_i18n(
                                    $preview_sheet[
                                        'rows'
                                    ]
                                )
                            );
                            ?>
                        </td>

                        <td>
                            <?php
                            echo esc_html(
                                implode(
                                    ', ',
                                    $preview_sheet[
                                        'headers'
                                    ]
                                )
                            );
                            ?>
                        </td>

                    </tr>

                    <?php
                }

                ?>

                </tbody>

            </table>


            <?php

            if (
                ! empty(
                    $import_preview[
                        'warnings'
                    ]
                )
            ) {

                ?>

                <div class="notice notice-warning inline"
                     style="margin-top:15px;">

                    <p>
                        <strong>
                            Validation Warnings
                        </strong>
                    </p>

                    <ul style="list-style:disc;padding-left:22px;">

                        <?php

                        foreach (
                            $import_preview[
                                'warnings'
                            ] as
                            $warning
                        ) {

                            ?>

                            <li>
                                <?php
                                echo esc_html(
                                    $warning
                                );
                                ?>
                            </li>

                            <?php
                        }

                        ?>

                    </ul>

                </div>

                <?php
            }

            ?>


            <?php if ( rud_crm_excel_user_can_import() ) : ?>

                <div class="notice notice-warning inline"
                     style="margin-top:18px;">
                    <p>
                        <strong>Safe Import Mode:</strong>
                        Existing CRM customers will not be overwritten.
                        The imported customers will be created as new records
                        with new database IDs, new UUIDs and new customer numbers.
                    </p>
                </div>

                <form
                    method="post"
                    action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
                    enctype="multipart/form-data"
                    style="margin-top:18px;max-width:900px;"
                >

                    <input
                        type="hidden"
                        name="action"
                        value="rud_crm_import_customers_xlsx"
                    >

                    <?php
                    wp_nonce_field(
                        'rud_crm_excel_import_action',
                        'rud_crm_excel_import_nonce'
                    );
                    ?>

                    <p>
                        <strong>Select the same validated .xlsx workbook again:</strong>
                    </p>

                    <p>
                        <input
                            type="file"
                            name="rud_crm_excel_import_file"
                            accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                            required
                        >
                    </p>

                    <p>
                        <label>
                            <input
                                type="checkbox"
                                name="rud_crm_excel_confirm_import"
                                value="1"
                                required
                            >
                            I understand that this creates new CRM customer records
                            and does not overwrite existing customers.
                        </label>
                    </p>

                    <p>
                        <button
                            type="submit"
                            class="button button-primary"
                        >
                            Import Customers
                        </button>
                    </p>

                </form>

            <?php else : ?>

                <p class="description">
                    Your account may preview workbooks, but does not have
                    permission to create/import CRM customers.
                </p>

            <?php endif; ?>

            <?php
        }

        ?>


        <?php if ( $library_ready ) : ?>

            <form
                method="post"
                enctype="multipart/form-data"
            >

                <?php
                wp_nonce_field(
                    'rud_crm_excel_import_preview_action',
                    'rud_crm_excel_import_preview_nonce'
                );
                ?>

                <input
                    type="file"
                    name="rud_crm_excel_import_file"
                    accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    required
                >

                <button
                    type="submit"
                    name="rud_crm_excel_preview_import"
                    value="1"
                    class="button"
                >
                    Preview Import
                </button>

            </form>

        <?php else : ?>

            <input
                type="file"
                accept=".xlsx"
                disabled
            >

            <button
                type="button"
                class="button"
                disabled
            >
                Preview Import
            </button>

        <?php endif; ?>


        <p class="description">
            Preview validates the .xlsx workbook, required RUD CRM sheets,
            column headers and row counts. It does not write to the database.
        </p>


    </div>

    <?php
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_import_export_admin_menu() {

    add_submenu_page(

        'rud-crm',

        'Import / Export',

        'Import / Export',

        'read',

        'rud-crm-import-export',

        'rud_crm_import_export_admin_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_import_export_admin_menu',
    40
);