<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * ACCOUNT IDENTITY
 * =========================================================
 *
 * GLOBAL RUD CRM RULE:
 *
 * EMAIL ADDRESS = LOGIN / USERNAME
 *
 * Applies to:
 *
 * ADMIN-LEVEL-001 through ADMIN-LEVEL-006
 * CRM Clients
 * Demo accounts
 * Public registration
 * CRM login
 *
 * WordPress may retain an older internal user_login for
 * existing users, but RUD CRM never asks the customer
 * to know or use it.
 *
 * =========================================================
 */


/*
 * =========================================================
 * GET ACCOUNT LOGIN EMAIL
 * =========================================================
 */

function rud_crm_account_login_email( $user_id ) {

    $user =
        get_userdata(
            absint(
                $user_id
            )
        );


    if ( ! $user ) {
        return '';
    }


    return sanitize_email(
        $user->user_email
    );
}


/*
 * =========================================================
 * EMAIL IS THE NEW ACCOUNT USERNAME
 * =========================================================
 */

function rud_crm_username_from_email( $email ) {

    $email =
        strtolower(
            trim(
                sanitize_email(
                    $email
                )
            )
        );


    if (
        ! is_email(
            $email
        )
    ) {
        return '';
    }


    /*
     * WordPress user_login has a practical length limit.
     */

    if (
        strlen(
            $email
        ) > 60
    ) {
        return '';
    }


    return $email;
}


/*
 * =========================================================
 * CHECK EMAIL AVAILABILITY
 * =========================================================
 */

function rud_crm_email_available(
    $email,
    $exclude_user_id = 0
) {

    $email =
        sanitize_email(
            $email
        );


    if (
        ! is_email(
            $email
        )
    ) {
        return false;
    }


    $existing_user_id =
        email_exists(
            $email
        );


    if (
        ! $existing_user_id
    ) {
        return true;
    }


    return
        absint(
            $existing_user_id
        )
        ===
        absint(
            $exclude_user_id
        );
}


/*
 * =========================================================
 * RUD CRM LOGIN
 * =========================================================
 *
 * Login form sends EMAIL.
 *
 * We resolve the WordPress user from that email and then
 * authenticate with its internal user_login.
 *
 * This means older accounts can still use their EMAIL even
 * if WordPress internally contains an old username.
 *
 * =========================================================
 */

function rud_crm_signon_with_email(
    $email,
    $password,
    $remember = false
) {

    $email =
        sanitize_email(
            $email
        );


    if (
        ! is_email(
            $email
        )
    ) {

        return new WP_Error(
            'rud_crm_invalid_email',
            'Please enter a valid email address.'
        );
    }


    $user =
        get_user_by(
            'email',
            $email
        );


    if (
        ! $user
    ) {

        return new WP_Error(
            'rud_crm_invalid_login',
            'The email address or password is incorrect.'
        );
    }


    return wp_signon(
        array(

            /*
             * Internal WordPress value.
             *
             * The customer never needs to know this.
             */

            'user_login' =>
                $user->user_login,

            'user_password' =>
                (string) $password,

            'remember' =>
                (bool) $remember

        ),
        is_ssl()
    );
}


/*
 * =========================================================
 * ACCOUNT IDENTIFIER LABEL
 * =========================================================
 */

function rud_crm_account_identifier_label() {

    return 'Email Address';
}


/*
 * =========================================================
 * DISPLAY LOGIN NAME
 * =========================================================
 *
 * Never expose WordPress user_login as the account's
 * customer-facing login name.
 *
 * =========================================================
 */

function rud_crm_account_display_login( $user_id ) {

    return rud_crm_account_login_email(
        $user_id
    );
}