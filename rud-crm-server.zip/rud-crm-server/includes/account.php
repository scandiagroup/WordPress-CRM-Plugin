<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * ACCOUNT / LOGIN / MY ACCOUNT
 * =========================================================
 *
 * CRM ACCOUNT PAGE
 * ----------------
 * Slug:
 * /crm-account/
 *
 * Shortcode:
 * [rud_crm_account]
 *
 *
 * MY ACCOUNT PAGE
 * ---------------
 * Slug:
 * /my-account/
 *
 * Shortcode:
 * [rud_crm_my_account]
 *
 *
 * NORMAL RUD CRM LOGIN RULE
 * -------------------------
 * Email Address = Username / Login
 *
 *
 * FLOW
 * ----
 *
 * Register
 * -> Accept Terms / Privacy
 * -> CAPTCHA
 * -> Verification Email
 * -> Verify Email
 * -> CRM Account Login
 * -> My Account
 * -> GO TO RUD CRM
 *
 * =========================================================
 */


/*
 * =========================================================
 * CRM ACCOUNT PAGE URL
 * =========================================================
 */

function rud_crm_account_page_url() {

    $page =
        get_page_by_path(
            'crm-account'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    return home_url(
        '/crm-account/'
    );
}


/*
 * =========================================================
 * MY ACCOUNT PAGE URL
 * =========================================================
 */

function rud_crm_my_account_page_url() {

    $page =
        get_page_by_path(
            'my-account'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    return home_url(
        '/my-account/'
    );
}


/*
 * =========================================================
 * REGISTRATION PAGE URL
 * =========================================================
 */

function rud_crm_register_page_url() {

    $page =
        get_page_by_path(
            'register-crm-account'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    $page =
        get_page_by_path(
            'register'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    $page =
        get_page_by_path(
            'crm-register'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    return home_url(
        '/register/'
    );
}


/*
 * =========================================================
 * CUSTOMER CRM PORTAL URL
 * =========================================================
 */

function rud_crm_customer_frontend_url() {

    $page =
        get_page_by_path(
            'customer-crm'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    return home_url(
        '/customer-crm/'
    );
}


/*
 * =========================================================
 * PROJECTS PAGE URL
 * =========================================================
 */

function rud_crm_projects_page_url() {

    $page =
        get_page_by_path(
            'projects'
        );


    if (
        $page &&
        'publish' === $page->post_status
    ) {

        return get_permalink(
            $page->ID
        );
    }


    return home_url(
        '/projects/'
    );
}


/*
 * =========================================================
 * ELEMENTOR REQUEST CHECK
 * =========================================================
 */

function rud_crm_account_is_elementor_request() {

    if (
        isset(
            $_GET['elementor-preview']
        )
    ) {

        return true;
    }


    if (
        isset(
            $_GET['action']
        )
        &&
        'elementor' ===
        sanitize_key(
            wp_unslash(
                $_GET['action']
            )
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * PAGE REDIRECTS
 * =========================================================
 */

function rud_crm_account_redirect_logged_in_user() {

    if (
        is_admin()
        ||
        rud_crm_account_is_elementor_request()
    ) {

        return;
    }


    if (
        is_user_logged_in()
        &&
        is_page(
            'crm-account'
        )
    ) {

        wp_safe_redirect(
            rud_crm_my_account_page_url()
        );

        exit;
    }
}


add_action(
    'template_redirect',
    'rud_crm_account_redirect_logged_in_user',
    5
);


function rud_crm_my_account_protect_page() {

    if (
        is_admin()
        ||
        rud_crm_account_is_elementor_request()
    ) {

        return;
    }


    if (
        ! is_user_logged_in()
        &&
        is_page(
            'my-account'
        )
    ) {

        wp_safe_redirect(
            rud_crm_account_page_url()
        );

        exit;
    }
}


add_action(
    'template_redirect',
    'rud_crm_my_account_protect_page',
    6
);


/*
 * =========================================================
 * SECURITY PROVIDER
 * =========================================================
 */

function rud_crm_account_security_provider() {

    if (
        function_exists(
            'rud_crm_security_provider'
        )
    ) {

        return rud_crm_security_provider();
    }


    return 'disabled';
}


/*
 * =========================================================
 * LOAD CAPTCHA ASSETS
 * =========================================================
 */

function rud_crm_account_load_security_assets() {

    if (
        ! is_page(
            'crm-account'
        )
    ) {

        return;
    }


    $provider =
        rud_crm_account_security_provider();


    if (
        'turnstile' ===
        $provider
    ) {

        if (
            function_exists(
                'rud_crm_security_provider_configured'
            )
            &&
            ! rud_crm_security_provider_configured(
                'turnstile'
            )
        ) {

            return;
        }


        wp_enqueue_script(
            'rud-crm-account-turnstile',
            'https://challenges.cloudflare.com/turnstile/v0/api.js',
            array(),
            null,
            true
        );
    }


    if (
        'recaptcha' ===
        $provider
    ) {

        if (
            function_exists(
                'rud_crm_security_provider_configured'
            )
            &&
            ! rud_crm_security_provider_configured(
                'recaptcha'
            )
        ) {

            return;
        }


        wp_enqueue_script(
            'rud-crm-account-recaptcha',
            'https://www.google.com/recaptcha/api.js',
            array(),
            null,
            true
        );
    }
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_account_load_security_assets',
    20
);


/*
 * =========================================================
 * CAPTCHA HTML
 * =========================================================
 */

function rud_crm_account_captcha_html() {

    $provider =
        rud_crm_account_security_provider();


    if (
        'disabled' ===
        $provider
    ) {

        return '';
    }


    if (
        'turnstile' ===
        $provider
    ) {

        if (
            ! function_exists(
                'rud_crm_turnstile_site_key'
            )
        ) {

            return
                '<div class="rud-crm-account-security-error">' .
                '<strong>Cloudflare Turnstile is not configured.</strong>' .
                '</div>';
        }


        $site_key =
            rud_crm_turnstile_site_key();


        if (
            '' ===
            trim(
                (string)
                $site_key
            )
        ) {

            return
                '<div class="rud-crm-account-security-error">' .
                '<strong>Cloudflare Turnstile is not configured.</strong>' .
                '</div>';
        }


        return
            '<div class="rud-crm-account-captcha">' .

                '<div class="rud-crm-security-label">' .
                    'Security Verification' .
                '</div>' .

                '<div class="cf-turnstile" data-sitekey="' .
                    esc_attr(
                        $site_key
                    ) .
                '"></div>' .

            '</div>';
    }


    if (
        'recaptcha' ===
        $provider
    ) {

        if (
            ! function_exists(
                'rud_crm_recaptcha_site_key'
            )
        ) {

            return
                '<div class="rud-crm-account-security-error">' .
                '<strong>Google reCAPTCHA is not configured.</strong>' .
                '</div>';
        }


        $site_key =
            rud_crm_recaptcha_site_key();


        if (
            '' ===
            trim(
                (string)
                $site_key
            )
        ) {

            return
                '<div class="rud-crm-account-security-error">' .
                '<strong>Google reCAPTCHA is not configured.</strong>' .
                '</div>';
        }


        return
            '<div class="rud-crm-account-captcha">' .

                '<div class="rud-crm-security-label">' .
                    'Security Verification' .
                '</div>' .

                '<div class="g-recaptcha" data-sitekey="' .
                    esc_attr(
                        $site_key
                    ) .
                '"></div>' .

            '</div>';
    }


    return '';
}


/*
 * =========================================================
 * LOGIN ERROR STORAGE
 * =========================================================
 */

function rud_crm_account_login_errors() {

    static $errors = null;


    if (
        null ===
        $errors
    ) {

        $errors =
            new WP_Error();
    }


    return $errors;
}


/*
 * =========================================================
 * VALIDATE LOGIN CAPTCHA
 * =========================================================
 */

function rud_crm_account_validate_captcha() {

    $provider =
        rud_crm_account_security_provider();


    if (
        'disabled' ===
        $provider
    ) {

        return true;
    }


    if (
        function_exists(
            'rud_crm_registration_validate_captcha'
        )
    ) {

        return
            rud_crm_registration_validate_captcha();
    }


    return new WP_Error(
        'rud_crm_login_security_unavailable',
        'Login security could not be verified. Please contact the administrator.'
    );
}


/*
 * =========================================================
 * PROCESS LOGIN
 * =========================================================
 */

function rud_crm_account_process_login() {

    if (
        empty(
            $_POST['rud_crm_account_action']
        )
    ) {

        return;
    }


    $action =
        sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_account_action']
            )
        );


    if (
        'login' !==
        $action
    ) {

        return;
    }


    if (
        is_user_logged_in()
    ) {

        return;
    }


    if (
        empty(
            $_POST['rud_crm_account_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_account_nonce']
                )
            ),
            'rud_crm_account_login'
        )
    ) {

        rud_crm_account_login_errors()->add(
            'security',
            'Security verification failed. Please reload the page and try again.'
        );

        return;
    }


    if (
        ! empty(
            $_POST['rud_crm_account_website']
        )
    ) {

        rud_crm_account_login_errors()->add(
            'spam',
            'Login could not be completed.'
        );

        return;
    }


    $captcha_result =
        rud_crm_account_validate_captcha();


    if (
        is_wp_error(
            $captcha_result
        )
    ) {

        rud_crm_account_login_errors()->add(
            $captcha_result->get_error_code(),
            $captcha_result->get_error_message()
        );

        return;
    }


    $identifier =
        isset(
            $_POST['rud_crm_login_identifier']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_login_identifier']
            )
        )
        : '';


    $password =
        isset(
            $_POST['rud_crm_login_password']
        )
        ? (string)
        wp_unslash(
            $_POST['rud_crm_login_password']
        )
        : '';


    $remember =
        ! empty(
            $_POST['rud_crm_login_remember']
        );


    if (
        '' ===
        trim(
            $identifier
        )
    ) {

        rud_crm_account_login_errors()->add(
            'identifier',
            'Please enter your username or email address.'
        );

        return;
    }


    if (
        '' ===
        $password
    ) {

        rud_crm_account_login_errors()->add(
            'password',
            'Please enter your password.'
        );

        return;
    }


    if (
        is_email(
            $identifier
        )
    ) {

        $email =
            sanitize_email(
                $identifier
            );


        if (
            function_exists(
                'rud_crm_signon_with_email'
            )
        ) {

            $user =
                rud_crm_signon_with_email(
                    $email,
                    $password,
                    $remember
                );

        } else {

            $account =
                get_user_by(
                    'email',
                    $email
                );


            if (
                ! $account
            ) {

                $user =
                    new WP_Error(
                        'invalid_login',
                        'The username/email address or password is incorrect.'
                    );

            } else {

                $user =
                    wp_signon(
                        array(

                            'user_login' =>
                                $account->user_login,

                            'user_password' =>
                                $password,

                            'remember' =>
                                $remember
                        ),
                        is_ssl()
                    );
            }
        }

    } else {

        $user =
            wp_signon(
                array(

                    'user_login' =>
                        sanitize_user(
                            $identifier
                        ),

                    'user_password' =>
                        $password,

                    'remember' =>
                        $remember
                ),
                is_ssl()
            );
    }


    if (
        is_wp_error(
            $user
        )
    ) {

        rud_crm_account_login_errors()->add(
            'login',
            $user->get_error_message()
        );

        return;
    }


    wp_safe_redirect(
        add_query_arg(
            'rud_crm_account',
            'login_success',
            rud_crm_my_account_page_url()
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_account_process_login',
    20
);


/*
 * =========================================================
 * CRM ACCOUNT STATUS MESSAGES
 * =========================================================
 */

function rud_crm_account_status_message() {

    if (
        isset(
            $_GET['rud_crm_registration']
        )
    ) {

        $status =
            sanitize_key(
                wp_unslash(
                    $_GET['rud_crm_registration']
                )
            );


        if (
            'check_email' ===
            $status
        ) {

            return array(

                'type' =>
                    'info',

                'title' =>
                    'Check Your Email',

                'message' =>
                    'Your RUD CRM account has been created. We have sent you an email verification link. Please verify your email address before logging in.'
            );
        }
    }


    if (
        isset(
            $_GET['rud_crm_email_verification']
        )
    ) {

        $status =
            sanitize_key(
                wp_unslash(
                    $_GET['rud_crm_email_verification']
                )
            );


        if (
            'verified' ===
            $status
        ) {

            return array(

                'type' =>
                    'success',

                'title' =>
                    'Email Successfully Verified',

                'message' =>
                    'Your email address has been successfully verified. You can now log in to your RUD CRM account.'
            );
        }


        if (
            'pending' ===
            $status
        ) {

            return array(

                'type' =>
                    'info',

                'title' =>
                    'Please Verify Your Email',

                'message' =>
                    'Your email address has not yet been verified. Please use the verification link sent to your email.'
            );
        }


        if (
            'expired' ===
            $status
        ) {

            return array(

                'type' =>
                    'error',

                'title' =>
                    'Verification Link Expired',

                'message' =>
                    'Your email verification link has expired. A new verification link is required before you can log in.'
            );
        }


        if (
            'invalid' ===
            $status
        ) {

            return array(

                'type' =>
                    'error',

                'title' =>
                    'Invalid Verification Link',

                'message' =>
                    'The verification link is invalid or could not be verified.'
            );
        }
    }


    return false;
}


/*
 * =========================================================
 * STATUS MESSAGE HTML
 * =========================================================
 */

function rud_crm_account_status_message_html() {

    $status =
        rud_crm_account_status_message();


    if (
        ! $status
    ) {

        return '';
    }


    $class =
        'rud-crm-account-notice-info';


    if (
        'success' ===
        $status['type']
    ) {

        $class =
            'rud-crm-account-notice-success';
    }


    if (
        'error' ===
        $status['type']
    ) {

        $class =
            'rud-crm-account-notice-error';
    }


    ob_start();

    ?>

    <div class="rud-crm-account-notice <?php echo esc_attr( $class ); ?>">

        <h3>
            <?php
            echo esc_html(
                $status['title']
            );
            ?>
        </h3>

        <p>
            <?php
            echo esc_html(
                $status['message']
            );
            ?>
        </p>

    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * CRM LOGIN FORM
 * =========================================================
 */

function rud_crm_account_login_form() {

    $errors =
        rud_crm_account_login_errors();


    $identifier =
        isset(
            $_POST['rud_crm_login_identifier']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_login_identifier']
            )
        )
        : '';


    ob_start();

    ?>

    <div class="rud-crm-login-section">


        <h2>
            Login to RUD CRM
        </h2>


        <p class="rud-crm-login-intro">
            Log in with the username / email address and password connected to your RUD CRM account.
        </p>


        <?php

        if (
            $errors->has_errors()
        ) :

        ?>

            <div class="rud-crm-account-errors">

                <?php

                foreach (
                    $errors->get_error_messages()
                    as
                    $message
                ) :

                ?>

                    <p>
                        <?php
                        echo wp_kses_post(
                            $message
                        );
                        ?>
                    </p>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <form
            method="post"
            class="rud-crm-account-login-form"
            autocomplete="on"
        >


            <?php

            wp_nonce_field(
                'rud_crm_account_login',
                'rud_crm_account_nonce'
            );

            ?>


            <input
                type="hidden"
                name="rud_crm_account_action"
                value="login"
            >


            <div
                aria-hidden="true"
                style="
                    position:absolute !important;
                    left:-9999px !important;
                    top:-9999px !important;
                    width:1px !important;
                    height:1px !important;
                    overflow:hidden !important;
                "
            >

                <input
                    type="text"
                    name="rud_crm_account_website"
                    value=""
                    tabindex="-1"
                    autocomplete="off"
                >

            </div>


            <div class="rud-crm-account-field">

                <label for="rud_crm_login_identifier">

                    Username / Email Address

                </label>


                <input
                    type="text"
                    id="rud_crm_login_identifier"
                    name="rud_crm_login_identifier"
                    value="<?php echo esc_attr( $identifier ); ?>"
                    required
                    autocomplete="username"
                >


                <small>

                    Your email address is normally your RUD CRM username.

                </small>

            </div>


            <div class="rud-crm-account-field">

                <label for="rud_crm_login_password">

                    Password

                </label>


                <input
                    type="password"
                    id="rud_crm_login_password"
                    name="rud_crm_login_password"
                    required
                    autocomplete="current-password"
                >

            </div>


            <div class="rud-crm-account-remember">

                <label>

                    <input
                        type="checkbox"
                        name="rud_crm_login_remember"
                        value="1"
                    >

                    Remember me

                </label>

            </div>


            <?php

            echo rud_crm_account_captcha_html();

            ?>


            <button
                type="submit"
                class="rud-crm-account-login-button"
            >

                LOGIN

            </button>


        </form>


        <div class="rud-crm-forgot-password">

            <a
                href="<?php
                echo esc_url(
                    wp_lostpassword_url(
                        rud_crm_account_page_url()
                    )
                );
                ?>"
            >

                Forgot your password?

            </a>

        </div>


    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * REGISTRATION SECTION ON CRM ACCOUNT PAGE
 * =========================================================
 */

function rud_crm_account_registration_box() {

    ob_start();

    ?>

    <div class="rud-crm-register-section">


        <h2>
            Register Your CRM Account
        </h2>


        <p>
            New to RUD CRM? Create your account and start with the available Demo version.
        </p>


        <p>
            During registration you will enter your account information, accept the Terms and Privacy Policy, complete the security verification and verify your email address.
        </p>


        <a
            href="<?php
            echo esc_url(
                rud_crm_register_page_url()
            );
            ?>"
            class="rud-crm-register-button"
        >

            REGISTER YOUR CRM ACCOUNT

        </a>


    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * ACCOUNT TYPE
 * =========================================================
 */

function rud_crm_my_account_type_label(
    $user
) {

    if (
        ! (
            $user instanceof WP_User
        )
    ) {

        return '';
    }


    $roles =
        (array)
        $user->roles;


    if (
        in_array(
            'rud_crm_demo',
            $roles,
            true
        )
    ) {

        return 'Demo Account';
    }


    if (
        in_array(
            'rud_crm_client',
            $roles,
            true
        )
    ) {

        return 'Full CRM Account';
    }


    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
    ) {

        $level =
            rud_crm_get_admin_level(
                $user->ID
            );


        if (
            $level
        ) {

            if (
                function_exists(
                    'rud_crm_admin_level_label'
                )
            ) {

                return
                    rud_crm_admin_level_label(
                        $level
                    );
            }


            return sprintf(
                'ADMIN-LEVEL-%03d',
                $level
            );
        }
    }


    return 'RUD CRM Account';
}


/*
 * =========================================================
 * FORMAT DATE
 * =========================================================
 */

function rud_crm_my_account_format_date(
    $date
) {

    if (
        ! $date
    ) {

        return '—';
    }


    $timestamp =
        strtotime(
            $date
        );


    if (
        ! $timestamp
    ) {

        return $date;
    }


    return wp_date(
        get_option(
            'date_format'
        ),
        $timestamp
    );
}


/*
 * =========================================================
 * DEMO DAYS REMAINING
 * =========================================================
 */

function rud_crm_my_account_days_remaining(
    $user_id
) {

    $valid_until =
        get_user_meta(
            $user_id,
            'rud_crm_valid_until',
            true
        );


    if (
        ! $valid_until
    ) {

        return null;
    }


    $timestamp =
        strtotime(
            $valid_until
        );


    if (
        ! $timestamp
    ) {

        return null;
    }


    $seconds =
        $timestamp -
        time();


    if (
        $seconds <= 0
    ) {

        return 0;
    }


    return (int)
        ceil(
            $seconds /
            DAY_IN_SECONDS
        );
}


/*
 * =========================================================
 * MY ACCOUNT
 * =========================================================
 */

function rud_crm_my_account_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return '';
    }


    $user =
        wp_get_current_user();


    $user_id =
        $user->ID;


    $first_name =
        get_user_meta(
            $user_id,
            'first_name',
            true
        );


    $last_name =
        get_user_meta(
            $user_id,
            'last_name',
            true
        );


    $company =
        get_user_meta(
            $user_id,
            'rud_crm_company',
            true
        );


    if (
        ! $company
    ) {

        $company =
            get_user_meta(
                $user_id,
                'rud_crm_admin_company',
                true
            );
    }


    $phone =
        get_user_meta(
            $user_id,
            'rud_crm_phone_full',
            true
        );


    if (
        ! $phone
    ) {

        $phone =
            get_user_meta(
                $user_id,
                'rud_crm_phone',
                true
            );
    }


    if (
        ! $phone
    ) {

        $phone =
            get_user_meta(
                $user_id,
                'rud_crm_admin_mobile_full',
                true
            );
    }


    $client_number =
        get_user_meta(
            $user_id,
            'rud_crm_client_number',
            true
        );


    $account_type =
        rud_crm_my_account_type_label(
            $user
        );


    $email_verified =
        true;


    if (
        function_exists(
            'rud_crm_email_is_verified'
        )
    ) {

        $email_verified =
            rud_crm_email_is_verified(
                $user_id
            );
    }


    $is_demo =
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        );


    $valid_from =
        get_user_meta(
            $user_id,
            'rud_crm_valid_from',
            true
        );


    $valid_until =
        get_user_meta(
            $user_id,
            'rud_crm_valid_until',
            true
        );


    $days_remaining =
        rud_crm_my_account_days_remaining(
            $user_id
        );


    $customer_count =
        0;


    $customer_limit =
        10;


    if (
        function_exists(
            'rud_crm_count_owned_customers'
        )
    ) {

        $customer_count =
            absint(
                rud_crm_count_owned_customers(
                    $user_id,
                    'trial'
                )
            );
    }


    if (
        function_exists(
            'rud_crm_trial_customer_limit'
        )
    ) {

        $customer_limit =
            absint(
                rud_crm_trial_customer_limit()
            );
    }


    ob_start();

    ?>

    <div class="rud-crm-my-account">


        <?php

        rud_crm_account_styles();

        ?>


        <?php

        if (
            isset(
                $_GET['rud_crm_account']
            )
            &&
            'login_success' ===
            sanitize_key(
                wp_unslash(
                    $_GET['rud_crm_account']
                )
            )
        ) :

        ?>

            <div class="rud-crm-account-notice rud-crm-account-notice-success">

                <h3>
                    Login Successful
                </h3>

                <p>
                    Welcome to your RUD CRM account.
                </p>

            </div>

        <?php endif; ?>


        <div class="rud-crm-my-account-card">


            <h2>
                My Account
            </h2>


            <p class="rud-crm-my-account-description">

                Your RUD CRM account, company and subscription information.

            </p>


            <div class="rud-crm-account-grid">


                <?php if ( $client_number ) : ?>

                    <div class="rud-crm-account-info">

                        <span>
                            CRM Client Number
                        </span>

                        <strong>
                            <?php
                            echo esc_html(
                                $client_number
                            );
                            ?>
                        </strong>

                    </div>

                <?php endif; ?>


                <div class="rud-crm-account-info">

                    <span>
                        Account Type
                    </span>

                    <strong>
                        <?php
                        echo esc_html(
                            $account_type
                        );
                        ?>
                    </strong>

                </div>


                <div class="rud-crm-account-info">

                    <span>
                        Account Status
                    </span>

                    <strong class="rud-crm-status-active">

                        ACTIVE

                    </strong>

                </div>


                <div class="rud-crm-account-info">

                    <span>
                        Name
                    </span>

                    <strong>

                        <?php

                        $full_name =
                            trim(
                                $first_name .
                                ' ' .
                                $last_name
                            );


                        echo esc_html(
                            $full_name
                            ? $full_name
                            : $user->display_name
                        );

                        ?>

                    </strong>

                </div>


                <?php if ( $company ) : ?>

                    <div class="rud-crm-account-info">

                        <span>
                            Company
                        </span>

                        <strong>
                            <?php
                            echo esc_html(
                                $company
                            );
                            ?>
                        </strong>

                    </div>

                <?php endif; ?>


                <div class="rud-crm-account-info">

                    <span>
                        Username / Email Address
                    </span>

                    <strong>
                        <?php
                        echo esc_html(
                            $user->user_email
                        );
                        ?>
                    </strong>

                </div>


                <?php if ( $phone ) : ?>

                    <div class="rud-crm-account-info">

                        <span>
                            Mobile Phone
                        </span>

                        <strong>
                            <?php
                            echo esc_html(
                                $phone
                            );
                            ?>
                        </strong>

                    </div>

                <?php endif; ?>


                <div class="rud-crm-account-info">

                    <span>
                        Email Verification
                    </span>


                    <?php if ( $email_verified ) : ?>


                        <strong class="rud-crm-status-active">

                            VERIFIED

                        </strong>


                    <?php else : ?>


                        <strong class="rud-crm-status-warning">

                            NOT VERIFIED

                        </strong>


                    <?php endif; ?>


                </div>


            </div>


            <?php if ( $is_demo ) : ?>


                <div class="rud-crm-demo-box">


                    <h3>
                        Demo Account
                    </h3>


                    <div class="rud-crm-account-grid">


                        <div class="rud-crm-account-info">

                            <span>
                                Demo Started
                            </span>

                            <strong>

                                <?php

                                echo esc_html(
                                    rud_crm_my_account_format_date(
                                        $valid_from
                                    )
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="rud-crm-account-info">

                            <span>
                                Demo Valid Until
                            </span>

                            <strong>

                                <?php

                                echo esc_html(
                                    rud_crm_my_account_format_date(
                                        $valid_until
                                    )
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="rud-crm-account-info">

                            <span>
                                Days Remaining
                            </span>

                            <strong>

                                <?php

                                echo esc_html(
                                    null ===
                                    $days_remaining
                                    ? '—'
                                    : $days_remaining
                                );

                                ?>

                            </strong>

                        </div>


                        <div class="rud-crm-account-info">

                            <span>
                                My Customers
                            </span>

                            <strong>

                                <?php

                                echo esc_html(
                                    $customer_count .
                                    ' / ' .
                                    $customer_limit
                                );

                                ?>

                            </strong>

                        </div>


                    </div>


                    <div class="rud-crm-upgrade-box">


                        <h3>
                            Upgrade Your RUD CRM
                        </h3>


                        <p>

                            Upgrade your Demo account to the full RUD CRM version.

                        </p>


<a
    href="<?php
    echo esc_url(
        home_url(
            '/upgrade-account/'
        )
    );
    ?>"
    class="rud-crm-upgrade-button"
>
    UPGRADE TO FULL VERSION
</a>


                    </div>


                </div>


            <?php endif; ?>


            <div class="rud-crm-account-actions">


                <a
                    href="<?php
                    echo esc_url(
                        rud_crm_customer_frontend_url()
                    );
                    ?>"
                    class="rud-crm-go-to-crm-button"
                >

                    GO TO RUD CRM

                </a>


                <a
                    href="<?php
                    echo esc_url(
                        wp_logout_url(
                            rud_crm_account_page_url()
                        )
                    );
                    ?>"
                    class="rud-crm-logout-button"
                >

                    LOG OUT

                </a>


            </div>


        </div>


    </div>

    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * ACCOUNT STYLES
 * =========================================================
 */

function rud_crm_account_styles() {

    ?>

    <style>


        .rud-crm-account-wrap,
        .rud-crm-my-account {

            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }


        .rud-crm-login-section {

            width: 100%;
            box-sizing: border-box;
        }


        .rud-crm-login-section h2 {

            margin-top: 0;
            margin-bottom: 8px;
        }


        .rud-crm-login-intro {

            margin-bottom: 24px;
        }


        .rud-crm-account-field {

            margin-bottom: 18px;
        }


        .rud-crm-account-field label {

            display: block;
            margin-bottom: 6px;
            font-weight: 600;
        }


        .rud-crm-account-field input {

            width: 100%;
            box-sizing: border-box;
            padding: 12px 14px;
            border: 1px solid #cccccc;
            border-radius: 4px;
            font-size: 16px;
        }


        .rud-crm-account-field small {

            display: block;
            margin-top: 6px;
            opacity: .72;
        }


        .rud-crm-account-remember {

            margin-bottom: 20px;
        }


        .rud-crm-account-captcha {

            margin-top: 20px;
            margin-bottom: 22px;
        }


        .rud-crm-security-label {

            margin-bottom: 8px;
            font-weight: 600;
        }


        .rud-crm-account-security-error {

            margin: 20px 0;
            padding: 14px 16px;
            border-left: 4px solid #b32d2e;
            background: #fff5f5;
        }


        .rud-crm-account-login-button {

            display: block;
            width: 100%;
            box-sizing: border-box;
            padding: 14px 20px;
            border: 0;
            border-radius: 5px;
            background: #1d2327;
            color: #ffffff;
            cursor: pointer;
            font-size: 16px;
            font-weight: 700;
        }


        .rud-crm-forgot-password {

            margin-top: 16px;
            text-align: center;
        }


        .rud-crm-account-errors {

            margin-bottom: 20px;
            padding: 15px 18px;
            border-left: 4px solid #b32d2e;
            background: #fff5f5;
        }


        .rud-crm-account-errors p {

            margin: 5px 0;
        }


        .rud-crm-register-section {

            margin-top: 35px;
            padding-top: 30px;
            border-top: 1px solid #dddddd;
            text-align: center;
        }


        .rud-crm-register-section h2 {

            margin-top: 0;
        }


        .rud-crm-register-button {

            display: inline-block;
            margin-top: 10px;
            padding: 14px 25px;
            border-radius: 5px;
            background: #1d2327;
            color: #ffffff;
            text-decoration: none;
            font-weight: 700;
        }


        .rud-crm-account-notice {

            box-sizing: border-box;
            margin-bottom: 22px;
            padding: 18px 20px;
            border-radius: 6px;
        }


        .rud-crm-account-notice h3 {

            margin-top: 0;
            margin-bottom: 8px;
        }


        .rud-crm-account-notice p {

            margin-bottom: 0;
        }


        .rud-crm-account-notice-info {

            border-left: 4px solid #2271b1;
            background: #f4f8fc;
        }


        .rud-crm-account-notice-success {

            border-left: 4px solid #00a32a;
            background: #f3fff5;
        }


        .rud-crm-account-notice-error {

            border-left: 4px solid #b32d2e;
            background: #fff5f5;
        }


        .rud-crm-my-account-card {

            width: 100%;
            box-sizing: border-box;
            padding: 30px;
            border: 1px solid #dddddd;
            border-radius: 8px;
            background: #ffffff;
        }


        .rud-crm-my-account-card h2 {

            margin-top: 0;
        }


        .rud-crm-my-account-description {

            margin-bottom: 20px;
        }


        .rud-crm-account-grid {

            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 20px;
        }


        .rud-crm-account-info {

            padding: 15px;
            background: #f7f7f7;
            border-radius: 5px;
        }


        .rud-crm-account-info span {

            display: block;
            margin-bottom: 5px;
            font-size: 13px;
            opacity: .7;
        }


        .rud-crm-status-active {

            color: #008a20;
        }


        .rud-crm-status-warning {

            color: #b32d2e;
        }


        .rud-crm-demo-box {

            margin-top: 25px;
            padding: 20px;
            border: 1px solid #dddddd;
            border-radius: 6px;
        }


        .rud-crm-upgrade-box {

            margin-top: 25px;
            padding: 20px;
            text-align: center;
            background: #f7f7f7;
            border-radius: 6px;
        }


        .rud-crm-upgrade-button {

            display: inline-block;
            padding: 14px 24px;
            border-radius: 5px;
            background: #1d2327;
            color: #ffffff;
            text-decoration: none;
            font-weight: 700;
        }


        .rud-crm-account-actions {

            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 28px;
        }


        .rud-crm-go-to-crm-button {

            display: inline-block;
            padding: 14px 24px;
            border-radius: 5px;
            background: #1d2327;
            color: #ffffff;
            text-decoration: none;
            font-weight: 700;
        }


        .rud-crm-logout-button {

            display: inline-block;
            padding: 13px 22px;
            border: 1px solid #b32d2e;
            border-radius: 5px;
            background: #ffffff;
            color: #b32d2e;
            text-decoration: none;
            font-weight: 600;
        }


        @media
        (
            max-width: 600px
        ) {

            .rud-crm-account-grid {

                grid-template-columns: 1fr;
            }


            .rud-crm-account-actions {

                display: block;
            }


            .rud-crm-go-to-crm-button,
            .rud-crm-logout-button {

                display: block;
                width: 100%;
                box-sizing: border-box;
                margin-bottom: 12px;
                text-align: center;
            }
        }


    </style>

    <?php
}


/*
 * =========================================================
 * CRM ACCOUNT SHORTCODE
 * =========================================================
 */

function rud_crm_account_shortcode() {

    /*
     * Normal logged-in visitors should not see the public
     * CRM Account login page.
     *
     * IMPORTANT:
     * Elementor edit / preview must still render the page
     * so the design does not disappear inside Elementor.
     */
    if (
        is_user_logged_in()
        &&
        ! rud_crm_account_is_elementor_request()
    ) {

        return '';
    }


    ob_start();


    rud_crm_account_styles();


    ?>

    <div class="rud-crm-account-wrap">


        <?php

        echo rud_crm_account_status_message_html();

        echo rud_crm_account_login_form();

        echo rud_crm_account_registration_box();

        ?>


    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_account',
    'rud_crm_account_shortcode'
);


/*
 * =========================================================
 * RUD CRM AUTOMATIC ACCOUNT MENU
 * =========================================================
 *
 * Logged-in menu:
 *
 * My Account
 *     Account Overview
 *     Go to CRM
 *     Projects
 *     Notifications
 *     Email Templates
 *     SMS Setup
 *     SMS Templates
 *     Mass SMS
 *     Edit My Profile
 *     Statistics
 *     Upgrade to Full Version
 *     Log Out
 *
 * =========================================================
 */

function rud_crm_account_menu_render_filter(
    $items,
    $args
) {

    if (
        is_admin()
        ||
        rud_crm_account_is_elementor_request()
    ) {
        return $items;
    }


    if (
        ! is_user_logged_in()
    ) {
        return $items;
    }


    $crm_account_url =
        rud_crm_account_page_url();

    $my_account_url =
        rud_crm_my_account_page_url();

    $customer_crm_url =
        rud_crm_customer_frontend_url();

    $projects_url =
        rud_crm_projects_page_url();

    $notifications_url =
        home_url(
            '/crm-notifications/'
        );

    $email_templates_url =
        home_url(
            '/email-setup/'
        );

    $sms_setup_url =
        home_url(
            '/sms-setup/'
        );

    $sms_templates_url =
        home_url(
            '/sms-templates/'
        );

    $mass_sms_url =
        home_url(
            '/multi-sms/'
        );

    $notification_count =
        function_exists(
            'rud_crm_get_unread_notification_count'
        )
        ? rud_crm_get_unread_notification_count(
            get_current_user_id()
        )
        : 0;

    $notifications_label =
        'Notifications';

    if (
        $notification_count > 0
    ) {

        $notifications_label .=
            ' (' .
            absint(
                $notification_count
            ) .
            ')';
    }

    $edit_profile_url =
        home_url(
            '/edit-my-profile/'
        );

    $statistics_url =
        home_url(
            '/statistics/'
        );

    $upgrade_url =
        home_url(
            '/upgrade-account/'
        );

    $logout_url =
        wp_logout_url(
            rud_crm_account_page_url()
        );


    $crm_account_candidates =
        array_unique(
            array(
                $crm_account_url,
                esc_url(
                    $crm_account_url
                ),
                trailingslashit(
                    untrailingslashit(
                        $crm_account_url
                    )
                ),
                esc_url(
                    trailingslashit(
                        untrailingslashit(
                            $crm_account_url
                        )
                    )
                )
            )
        );


    foreach (
        $crm_account_candidates
        as
        $candidate
    ) {

        $quoted =
            preg_quote(
                $candidate,
                '~'
            );


        $pattern =
            '~<li\\b([^>]*)>\\s*' .
            '<a\\b([^>]*?)href=(["\\\'])' .
            $quoted .
            '\\3([^>]*)>.*?</a>\\s*</li>~is';


        if (
            ! preg_match(
                $pattern,
                $items,
                $match
            )
        ) {
            continue;
        }


        $li_attributes =
            isset(
                $match[1]
            )
            ? $match[1]
            : '';

        $anchor_before_href =
            isset(
                $match[2]
            )
            ? $match[2]
            : '';

        $href_quote =
            isset(
                $match[3]
            )
            ? $match[3]
            : '"';

        $anchor_after_href =
            isset(
                $match[4]
            )
            ? $match[4]
            : '';


        if (
            preg_match(
                '/class=(["\\\'])(.*?)\\1/i',
                $li_attributes,
                $class_match
            )
        ) {

            $classes =
                preg_split(
                    '/\\s+/',
                    trim(
                        $class_match[2]
                    )
                );

            $classes[] =
                'menu-item-has-children';

            $classes[] =
                'rud-crm-auto-account-menu';

            if (
                is_page(
                    array(
                        'my-account',
                        'customer-crm',
                        'projects',
                        'edit-my-profile',
                        'statistics',
                        'upgrade-account'
                    )
                )
            ) {

                $classes[] =
                    'current-menu-ancestor';

                $classes[] =
                    'current-menu-parent';
            }

            $classes =
                array_values(
                    array_unique(
                        array_filter(
                            $classes
                        )
                    )
                );

            $new_class_attribute =
                'class=' .
                $class_match[1] .
                esc_attr(
                    implode(
                        ' ',
                        $classes
                    )
                ) .
                $class_match[1];

            $li_attributes =
                preg_replace(
                    '/class=(["\\\'])(.*?)\\1/i',
                    $new_class_attribute,
                    $li_attributes,
                    1
                );

        } else {

            $li_attributes .=
                ' class="menu-item menu-item-has-children rud-crm-auto-account-menu"';
        }


        $anchor_attributes =
            trim(
                $anchor_before_href .
                ' ' .
                $anchor_after_href
            );

        if (
            preg_match(
                '/class=(["\\\'])(.*?)\\1/i',
                $anchor_attributes,
                $anchor_class_match
            )
        ) {

            $anchor_classes =
                preg_split(
                    '/\\s+/',
                    trim(
                        $anchor_class_match[2]
                    )
                );

            $anchor_classes[] =
                'has-submenu';

            $anchor_classes[] =
                'rud-crm-my-account-link';

            $anchor_classes =
                array_values(
                    array_unique(
                        array_filter(
                            $anchor_classes
                        )
                    )
                );

            $new_anchor_class_attribute =
                'class=' .
                $anchor_class_match[1] .
                esc_attr(
                    implode(
                        ' ',
                        $anchor_classes
                    )
                ) .
                $anchor_class_match[1];

            $anchor_attributes =
                preg_replace(
                    '/class=(["\\\'])(.*?)\\1/i',
                    $new_anchor_class_attribute,
                    $anchor_attributes,
                    1
                );

        } else {

            $anchor_attributes .=
                ' class="has-submenu rud-crm-my-account-link"';
        }


        $anchor_attributes =
            preg_replace(
                '/\\saria-haspopup=(["\\\']).*?\\1/i',
                '',
                $anchor_attributes
            );

        $anchor_attributes =
            preg_replace(
                '/\\saria-expanded=(["\\\']).*?\\1/i',
                '',
                $anchor_attributes
            );

        $anchor_attributes .=
            ' aria-haspopup="true" aria-expanded="false"';


        $submenu =
            '<ul class="sub-menu elementor-nav-menu--dropdown">' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-account-overview">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $my_account_url ) . '">Account Overview</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-go-to-crm">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $customer_crm_url ) . '">Go to CRM</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-projects">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $projects_url ) . '">Projects</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-notifications">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $notifications_url ) . '">' .
                        esc_html( $notifications_label ) .
                    '</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-email-templates">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $email_templates_url ) . '">Email Templates</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-sms-setup">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $sms_setup_url ) . '">SMS Setup</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-sms-templates">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $sms_templates_url ) . '">SMS Templates</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-mass-sms">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $mass_sms_url ) . '">Mass SMS</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-edit-profile">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $edit_profile_url ) . '">Edit My Profile</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-statistics">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $statistics_url ) . '">Statistics</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-upgrade">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $upgrade_url ) . '">Upgrade to Full Version</a>' .
                '</li>' .

                '<li class="menu-item menu-item-type-custom menu-item-object-custom rud-crm-menu-logout">' .
                    '<a class="elementor-sub-item" href="' . esc_url( $logout_url ) . '">Log Out</a>' .
                '</li>' .

            '</ul>';


        $replacement =
            '<li' .
            $li_attributes .
            '>' .

                '<a ' .
                trim(
                    $anchor_attributes
                ) .
                ' href=' .
                $href_quote .
                esc_url(
                    $my_account_url
                ) .
                $href_quote .
                '>' .
                    'My Account' .
                '</a>' .

                $submenu .

            '</li>';


        $items =
            preg_replace(
                $pattern,
                $replacement,
                $items,
                1
            );


        return $items;
    }


    return $items;
}


add_filter(
    'wp_nav_menu_items',
    'rud_crm_account_menu_render_filter',
    999,
    2
);


/*
 * =========================================================
 * AUTOMATIC MY ACCOUNT SUBMENU TEXT COLOR
 * =========================================================
 */

function rud_crm_account_menu_readable_styles() {

    if ( ! is_user_logged_in() ) {
        return;
    }

    ?>

    <style id="rud-crm-account-menu-readable-styles">

        .rud-crm-auto-account-menu > ul.sub-menu > li > a,
        .rud-crm-auto-account-menu > ul.sub-menu > li > a.elementor-sub-item,
        .rud-crm-auto-account-menu > ul.elementor-nav-menu--dropdown > li > a,
        .rud-crm-auto-account-menu > ul.elementor-nav-menu--dropdown > li > a.elementor-sub-item {
            color: #ffffff !important;
            opacity: 1 !important;
        }

        .rud-crm-auto-account-menu > ul.sub-menu > li > a:hover,
        .rud-crm-auto-account-menu > ul.sub-menu > li > a:focus,
        .rud-crm-auto-account-menu > ul.elementor-nav-menu--dropdown > li > a:hover,
        .rud-crm-auto-account-menu > ul.elementor-nav-menu--dropdown > li > a:focus {
            color: #ffffff !important;
        }

        .rud-crm-auto-account-menu .rud-crm-menu-logout > a,
        .rud-crm-auto-account-menu .rud-crm-menu-logout > a:hover,
        .rud-crm-auto-account-menu .rud-crm-menu-logout > a:focus {
            color: #ffffff !important;
        }

    </style>

    <?php
}

add_action(
    'wp_head',
    'rud_crm_account_menu_readable_styles',
    999
);


/*
 * =========================================================
 * MY ACCOUNT SHORTCODE
 * =========================================================
 */

add_shortcode(
    'rud_crm_my_account',
    'rud_crm_my_account_shortcode'
);
