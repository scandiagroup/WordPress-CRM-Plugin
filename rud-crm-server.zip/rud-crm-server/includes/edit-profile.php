<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * EDIT MY PROFILE
 * =========================================================
 *
 * Shortcode:
 *
 * [rud_crm_edit_my_profile]
 *
 * Logged-in CRM users may edit:
 *
 * - First Name
 * - Last Name
 * - Company
 * - Mobile Phone
 * - Password
 *
 * Email / Login is currently read-only.
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_edit_profile_can_access() {

    if (
        ! is_user_logged_in()
    ) {

        return false;
    }


    $user =
        wp_get_current_user();


    if (
        ! $user
        ||
        ! $user->exists()
    ) {

        return false;
    }


    /*
     * CRM Demo Client
     */

    if (
        in_array(
            'rud_crm_demo',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    /*
     * Full CRM Client
     */

    if (
        in_array(
            'rud_crm_client',
            (array)
            $user->roles,
            true
        )
    ) {

        return true;
    }


    /*
     * CRM administrators may also edit
     * their own profile.
     */

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            $user->ID
        )
    ) {

        return true;
    }


    return false;
}


/*
 * =========================================================
 * MESSAGE STORAGE
 * =========================================================
 */

function rud_crm_edit_profile_messages() {

    static $messages = array();


    return $messages;
}


function rud_crm_edit_profile_add_message(
    $type,
    $message
) {

    global $rud_crm_edit_profile_messages;


    if (
        ! isset(
            $rud_crm_edit_profile_messages
        )
        ||
        ! is_array(
            $rud_crm_edit_profile_messages
        )
    ) {

        $rud_crm_edit_profile_messages =
            array();
    }


    $rud_crm_edit_profile_messages[] =
        array(

            'type' =>
                sanitize_key(
                    $type
                ),

            'message' =>
                $message
        );
}


function rud_crm_edit_profile_get_messages() {

    global $rud_crm_edit_profile_messages;


    if (
        ! isset(
            $rud_crm_edit_profile_messages
        )
        ||
        ! is_array(
            $rud_crm_edit_profile_messages
        )
    ) {

        return array();
    }


    return
        $rud_crm_edit_profile_messages;
}


/*
 * =========================================================
 * PROCESS PROFILE UPDATE
 * =========================================================
 */

function rud_crm_process_edit_profile() {

    if (
        empty(
            $_POST['rud_crm_edit_profile_action']
        )
        ||
        'save_profile' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_edit_profile_action']
            )
        )
    ) {

        return;
    }


    if (
        ! rud_crm_edit_profile_can_access()
    ) {

        return;
    }


    /*
     * -----------------------------------------------------
     * NONCE
     * -----------------------------------------------------
     */

    if (
        empty(
            $_POST['rud_crm_edit_profile_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_edit_profile_nonce']
                )
            ),
            'rud_crm_edit_profile'
        )
    ) {

        rud_crm_edit_profile_add_message(
            'error',
            'Security verification failed. Please reload the page and try again.'
        );

        return;
    }


    $user_id =
        get_current_user_id();


    /*
     * -----------------------------------------------------
     * FIRST NAME
     * -----------------------------------------------------
     */

    $first_name =
        isset(
            $_POST['rud_crm_first_name']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_first_name']
            )
        )
        : '';


    /*
     * -----------------------------------------------------
     * LAST NAME
     * -----------------------------------------------------
     */

    $last_name =
        isset(
            $_POST['rud_crm_last_name']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_last_name']
            )
        )
        : '';


    /*
     * -----------------------------------------------------
     * COMPANY
     * -----------------------------------------------------
     */

    $company =
        isset(
            $_POST['rud_crm_company']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_company']
            )
        )
        : '';


    /*
     * -----------------------------------------------------
     * PHONE
     * -----------------------------------------------------
     */

    $phone =
        isset(
            $_POST['rud_crm_phone']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_phone']
            )
        )
        : '';


    if (
        function_exists(
            'rud_crm_sanitize_phone_number'
        )
    ) {

        $phone =
            rud_crm_sanitize_phone_number(
                $phone
            );
    }


    $phone_country =
        isset(
            $_POST['rud_crm_phone_country']
        )
        ? strtoupper(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_phone_country']
                )
            )
        )
        : '';


    $phone_dial_code =
        isset(
            $_POST['rud_crm_phone_dial_code']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_POST['rud_crm_phone_dial_code']
            )
        )
        : '';


    /*
     * -----------------------------------------------------
     * BASIC VALIDATION
     * -----------------------------------------------------
     */

    if (
        '' ===
        trim(
            $first_name
        )
    ) {

        rud_crm_edit_profile_add_message(
            'error',
            'First Name is required.'
        );

        return;
    }


    if (
        '' ===
        trim(
            $last_name
        )
    ) {

        rud_crm_edit_profile_add_message(
            'error',
            'Last Name is required.'
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * SAVE WORDPRESS USER DATA
     * -----------------------------------------------------
     */

    $display_name =
        trim(
            $first_name .
            ' ' .
            $last_name
        );


    $result =
        wp_update_user(
            array(

                'ID' =>
                    $user_id,

                'first_name' =>
                    $first_name,

                'last_name' =>
                    $last_name,

                'display_name' =>
                    $display_name
            )
        );


    if (
        is_wp_error(
            $result
        )
    ) {

        rud_crm_edit_profile_add_message(
            'error',
            $result->get_error_message()
        );

        return;
    }


    /*
     * -----------------------------------------------------
     * SAVE CRM PROFILE DATA
     * -----------------------------------------------------
     */

    update_user_meta(
        $user_id,
        'rud_crm_company',
        $company
    );


    update_user_meta(
        $user_id,
        'rud_crm_phone',
        $phone
    );


    update_user_meta(
        $user_id,
        'rud_crm_phone_full',
        $phone
    );


    update_user_meta(
        $user_id,
        'rud_crm_phone_country',
        $phone_country
    );


    update_user_meta(
        $user_id,
        'rud_crm_phone_dial_code',
        $phone_dial_code
    );


    /*
     * -----------------------------------------------------
     * PASSWORD CHANGE
     * -----------------------------------------------------
     */

    $new_password =
        isset(
            $_POST['rud_crm_new_password']
        )
        ? (string)
        wp_unslash(
            $_POST['rud_crm_new_password']
        )
        : '';


    $confirm_password =
        isset(
            $_POST['rud_crm_confirm_password']
        )
        ? (string)
        wp_unslash(
            $_POST['rud_crm_confirm_password']
        )
        : '';


    if (
        '' !==
        $new_password
        ||
        '' !==
        $confirm_password
    ) {

        if (
            strlen(
                $new_password
            )
            <
            8
        ) {

            rud_crm_edit_profile_add_message(
                'error',
                'The new password must contain at least 8 characters.'
            );

            return;
        }


        if (
            $new_password !==
            $confirm_password
        ) {

            rud_crm_edit_profile_add_message(
                'error',
                'The new passwords do not match.'
            );

            return;
        }


        wp_set_password(
            $new_password,
            $user_id
        );


        /*
         * wp_set_password invalidates the current
         * authentication cookie.
         *
         * Log the user back in securely.
         */

        $user =
            get_userdata(
                $user_id
            );


        if (
            $user
        ) {

            wp_set_current_user(
                $user_id
            );


            wp_set_auth_cookie(
                $user_id,
                true,
                is_ssl()
            );
        }


        rud_crm_edit_profile_add_message(
            'success',
            'Your profile and password have been updated.'
        );

        return;
    }


    rud_crm_edit_profile_add_message(
        'success',
        'Your profile has been updated successfully.'
    );
}


add_action(
    'template_redirect',
    'rud_crm_process_edit_profile',
    20
);


/*
 * =========================================================
 * MESSAGE HTML
 * =========================================================
 */

function rud_crm_edit_profile_message_html() {

    $messages =
        rud_crm_edit_profile_get_messages();


    if (
        empty(
            $messages
        )
    ) {

        return '';
    }


    ob_start();


    foreach (
        $messages
        as
        $message
    ) {

        $class =
            'rud-crm-profile-message-success';


        if (
            'error' ===
            $message['type']
        ) {

            $class =
                'rud-crm-profile-message-error';
        }

        ?>

        <div
            class="rud-crm-profile-message <?php echo esc_attr( $class ); ?>"
        >

            <?php
            echo esc_html(
                $message['message']
            );
            ?>

        </div>

        <?php
    }


    return ob_get_clean();
}


/*
 * =========================================================
 * EDIT PROFILE SHORTCODE
 * =========================================================
 */

function rud_crm_edit_my_profile_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return
            '<div class="rud-crm-profile-message rud-crm-profile-message-error">' .
            'You must be logged in to edit your profile.' .
            '</div>';
    }


    if (
        ! rud_crm_edit_profile_can_access()
    ) {

        return
            '<div class="rud-crm-profile-message rud-crm-profile-message-error">' .
            'Your account does not have permission to edit this profile.' .
            '</div>';
    }


    $user =
        wp_get_current_user();


    $user_id =
        $user->ID;


    $first_name =
        get_user_meta(
            $user_id,
            'first_name',
            true
        );


    $last_name =
        get_user_meta(
            $user_id,
            'last_name',
            true
        );


    $company =
        get_user_meta(
            $user_id,
            'rud_crm_company',
            true
        );


    if (
        ! $company
    ) {

        $company =
            get_user_meta(
                $user_id,
                'rud_crm_admin_company',
                true
            );
    }


    $phone =
        get_user_meta(
            $user_id,
            'rud_crm_phone_full',
            true
        );


    if (
        ! $phone
    ) {

        $phone =
            get_user_meta(
                $user_id,
                'rud_crm_phone',
                true
            );
    }


    $phone_country =
        get_user_meta(
            $user_id,
            'rud_crm_phone_country',
            true
        );


    $phone_dial_code =
        get_user_meta(
            $user_id,
            'rud_crm_phone_dial_code',
            true
        );


    /*
     * Load global smart phone field.
     */

    if (
        function_exists(
            'rud_crm_enqueue_phone_assets'
        )
    ) {

        rud_crm_enqueue_phone_assets();
    }


    ob_start();

    ?>

    <div class="rud-crm-edit-profile">


        <?php

        echo rud_crm_edit_profile_message_html();

        ?>


        <div class="rud-crm-edit-profile-card">


            <h2>
                Edit My Profile
            </h2>


            <p>
                Update your personal and company information.
            </p>


            <form
                method="post"
                autocomplete="on"
            >


                <?php

                wp_nonce_field(
                    'rud_crm_edit_profile',
                    'rud_crm_edit_profile_nonce'
                );

                ?>


                <input
                    type="hidden"
                    name="rud_crm_edit_profile_action"
                    value="save_profile"
                >


                <div class="rud-crm-profile-grid">


                    <div class="rud-crm-profile-field">

                        <label for="rud_crm_first_name">
                            First Name
                        </label>

                        <input
                            type="text"
                            id="rud_crm_first_name"
                            name="rud_crm_first_name"
                            value="<?php echo esc_attr( $first_name ); ?>"
                            required
                            autocomplete="given-name"
                        >

                    </div>


                    <div class="rud-crm-profile-field">

                        <label for="rud_crm_last_name">
                            Last Name
                        </label>

                        <input
                            type="text"
                            id="rud_crm_last_name"
                            name="rud_crm_last_name"
                            value="<?php echo esc_attr( $last_name ); ?>"
                            required
                            autocomplete="family-name"
                        >

                    </div>


                </div>


                <div class="rud-crm-profile-field">

                    <label for="rud_crm_company">
                        Company
                    </label>

                    <input
                        type="text"
                        id="rud_crm_company"
                        name="rud_crm_company"
                        value="<?php echo esc_attr( $company ); ?>"
                        autocomplete="organization"
                    >

                </div>


                <!-- EMAIL / LOGIN -->


                <div class="rud-crm-profile-field">

                    <label>
                        Username / Email Address
                    </label>

                    <input
                        type="email"
                        value="<?php
                        echo esc_attr(
                            $user->user_email
                        );
                        ?>"
                        readonly
                    >

                    <small>
                        Your email address is your RUD CRM login.
                        Changing the login email will require email verification and will be added separately.
                    </small>

                </div>


                <!-- SMART MOBILE PHONE -->


                <div class="rud-crm-profile-field">

                    <label for="rud_crm_phone">
                        Mobile Phone
                    </label>


                    <?php

                    if (
                        function_exists(
                            'rud_crm_render_phone_field'
                        )
                    ) {

                        echo wp_kses(
                            rud_crm_render_phone_field(
                                'rud_crm_phone',
                                $phone,
                                array(

                                    'id' =>
                                        'rud_crm_phone',

                                    'country_field' =>
                                        'rud_crm_phone_country',

                                    'dial_code_field' =>
                                        'rud_crm_phone_dial_code',

                                    'description' =>
                                        'Select your country flag and enter your mobile phone number.'
                                )
                            ),
                            rud_crm_phone_allowed_html()
                        );

                    } else {

                        ?>

                        <input
                            type="tel"
                            id="rud_crm_phone"
                            name="rud_crm_phone"
                            value="<?php echo esc_attr( $phone ); ?>"
                            autocomplete="tel"
                        >

                        <?php
                    }

                    ?>


                    <input
                        type="hidden"
                        name="rud_crm_phone_country"
                        value="<?php echo esc_attr( $phone_country ); ?>"
                    >


                    <input
                        type="hidden"
                        name="rud_crm_phone_dial_code"
                        value="<?php echo esc_attr( $phone_dial_code ); ?>"
                    >


                </div>


                <div class="rud-crm-password-section">


                    <h3>
                        Change Password
                    </h3>


                    <p>
                        Leave these fields empty if you do not want to change your password.
                    </p>


                    <div class="rud-crm-profile-grid">


                        <div class="rud-crm-profile-field">

                            <label for="rud_crm_new_password">
                                New Password
                            </label>

                            <input
                                type="password"
                                id="rud_crm_new_password"
                                name="rud_crm_new_password"
                                minlength="8"
                                autocomplete="new-password"
                            >

                        </div>


                        <div class="rud-crm-profile-field">

                            <label for="rud_crm_confirm_password">
                                Confirm New Password
                            </label>

                            <input
                                type="password"
                                id="rud_crm_confirm_password"
                                name="rud_crm_confirm_password"
                                minlength="8"
                                autocomplete="new-password"
                            >

                        </div>


                    </div>


                </div>


                <div class="rud-crm-profile-actions">


                    <button
                        type="submit"
                        class="rud-crm-profile-save-button"
                    >
                        SAVE MY PROFILE
                    </button>


                    <?php

                    $my_account_url =
                        function_exists(
                            'rud_crm_my_account_page_url'
                        )
                        ? rud_crm_my_account_page_url()
                        : home_url(
                            '/my-account/'
                        );

                    ?>


                    <a
                        href="<?php
                        echo esc_url(
                            $my_account_url
                        );
                        ?>"
                        class="rud-crm-profile-cancel-button"
                    >
                        BACK TO MY ACCOUNT
                    </a>


                </div>


            </form>


        </div>


    </div>


    <style>

        .rud-crm-edit-profile {
            width:100%;
            max-width:800px;
            margin:0 auto;
        }


        .rud-crm-edit-profile-card {
            padding:30px;
            border:1px solid #dddddd;
            border-radius:8px;
            background:#ffffff;
        }


        .rud-crm-edit-profile-card h2 {
            margin-top:0;
        }


        .rud-crm-profile-grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:18px;
        }


        .rud-crm-profile-field {
            margin-bottom:20px;
        }


        .rud-crm-profile-field label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }


        .rud-crm-profile-field input[type="text"],
        .rud-crm-profile-field input[type="email"],
        .rud-crm-profile-field input[type="password"],
        .rud-crm-profile-field input[type="tel"] {
            width:100%;
            box-sizing:border-box;
            padding:12px 14px;
            border:1px solid #cccccc;
            border-radius:5px;
            font-size:16px;
        }


        .rud-crm-profile-field input[readonly] {
            background:#f3f4f5;
        }


        .rud-crm-profile-field small {
            display:block;
            margin-top:6px;
            opacity:.7;
        }


        .rud-crm-password-section {
            margin-top:30px;
            padding-top:25px;
            border-top:1px solid #dddddd;
        }


        .rud-crm-profile-actions {
            display:flex;
            gap:12px;
            flex-wrap:wrap;
            margin-top:25px;
        }


        .rud-crm-profile-save-button {
            padding:14px 24px;
            border:0;
            border-radius:5px;
            background:#1d2327;
            color:#ffffff;
            font-weight:700;
            cursor:pointer;
        }


        .rud-crm-profile-cancel-button {
            display:inline-block;
            padding:13px 22px;
            border:1px solid #cccccc;
            border-radius:5px;
            text-decoration:none;
        }


        .rud-crm-profile-message {
            margin-bottom:20px;
            padding:16px 18px;
            border-radius:5px;
        }


        .rud-crm-profile-message-success {
            border-left:4px solid #00a32a;
            background:#f3fff5;
        }


        .rud-crm-profile-message-error {
            border-left:4px solid #b32d2e;
            background:#fff5f5;
        }


        @media (max-width:600px) {

            .rud-crm-profile-grid {
                grid-template-columns:1fr;
                gap:0;
            }


            .rud-crm-edit-profile-card {
                padding:20px;
            }


            .rud-crm-profile-save-button,
            .rud-crm-profile-cancel-button {
                width:100%;
                box-sizing:border-box;
                text-align:center;
            }
        }

    </style>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_edit_my_profile',
    'rud_crm_edit_my_profile_shortcode'
);