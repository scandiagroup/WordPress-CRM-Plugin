<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM CUSTOMERS
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * CUSTOMERS SUBMENU
 * ---------------------------------------------------------
 */

function rud_crm_customers_admin_menu() {

    add_submenu_page(
        'rud-crm',
        'Customers',
        'Customers',
        'manage_options',
        'rud-crm-customers',
        'rud_crm_customers_page'
    );
}

add_action(
    'admin_menu',
    'rud_crm_customers_admin_menu',
    20
);


/*
 * ---------------------------------------------------------
 * NEXT CUSTOMER NUMBER
 * ---------------------------------------------------------
 */

function rud_crm_next_customer_number() {

    global $wpdb;

    $table =
        $wpdb->prefix .
        'rudcrm_customers';

    $highest_id =
        (int) $wpdb->get_var(
            "SELECT MAX(id)
             FROM $table"
        );

    return 'RUD-' .
        str_pad(
            $highest_id + 1,
            8,
            '0',
            STR_PAD_LEFT
        );
}


/*
 * ---------------------------------------------------------
 * FORM INPUT HELPER
 * ---------------------------------------------------------
 */

function rud_crm_customer_input(
    $name,
    $label,
    $type = 'text',
    $description = ''
) {

    echo '<tr>';

    echo '<th scope="row">';

    echo '<label for="' .
        esc_attr( $name ) .
        '">' .
        esc_html( $label ) .
        '</label>';

    echo '</th>';

    echo '<td>';

    echo '<input
        type="' . esc_attr( $type ) . '"
        name="' . esc_attr( $name ) . '"
        id="' . esc_attr( $name ) . '"
        class="regular-text"
    >';

    if ( $description ) {

        echo '<p class="description">' .
            esc_html( $description ) .
            '</p>';
    }

    echo '</td>';

    echo '</tr>';
}


/*
 * ---------------------------------------------------------
 * SAVE CONTACT METHOD
 * ---------------------------------------------------------
 */

function rud_crm_customer_insert_contact(
    $customer_id,
    $contact_type,
    $contact_label,
    $contact_value,
    $is_primary = 0
) {

    global $wpdb;

    $contact_value =
        trim(
            (string) $contact_value
        );

    if ( '' === $contact_value ) {
        return;
    }

    $now =
        current_time(
            'mysql'
        );

    $wpdb->insert(
        $wpdb->prefix .
        'rudcrm_contact_methods',
        array(
            'customer_id'   => $customer_id,
            'contact_type'  => $contact_type,
            'contact_label' => $contact_label,
            'contact_value' => $contact_value,
            'is_primary'    => $is_primary,
            'is_verified'   => 0,
            'created_at'    => $now,
            'updated_at'    => $now
        )
    );
}


/*
 * ---------------------------------------------------------
 * SAVE SOCIAL MEDIA ACCOUNTS
 * ---------------------------------------------------------
 */

function rud_crm_customer_save_social_accounts(
    $customer_id
) {

    global $wpdb;

    if (
        ! function_exists(
            'rud_crm_social_platforms'
        )
    ) {
        return;
    }

    $table =
        $wpdb->prefix .
        'rudcrm_social_accounts';

    $platforms =
        rud_crm_social_platforms();

    $now =
        current_time(
            'mysql'
        );

    foreach (
        $platforms as
        $platform_key =>
        $platform_name
    ) {

        $active =
            isset(
                $_POST['social_active'][
                    $platform_key
                ]
            )
            ? 1
            : 0;

        $account =
            isset(
                $_POST['social_account'][
                    $platform_key
                ]
            )
            ? sanitize_text_field(
                wp_unslash(
                    $_POST['social_account'][
                        $platform_key
                    ]
                )
            )
            : '';

        $profile_url =
            isset(
                $_POST['social_url'][
                    $platform_key
                ]
            )
            ? esc_url_raw(
                wp_unslash(
                    $_POST['social_url'][
                        $platform_key
                    ]
                )
            )
            : '';

        if (
            ! $active &&
            '' === $account &&
            '' === $profile_url
        ) {
            continue;
        }

        $wpdb->replace(
            $table,
            array(
                'customer_id'  => $customer_id,
                'platform'     => $platform_key,
                'is_active'    => $active,
                'account_name' => $account,
                'profile_url'  => $profile_url,
                'notes'        => '',
                'created_at'   => $now,
                'updated_at'   => $now
            )
        );
    }
}


/*
 * ---------------------------------------------------------
 * CREATE CUSTOMER
 * ---------------------------------------------------------
 */

function rud_crm_customer_create() {

    global $wpdb;

    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';

    $details_table =
        $wpdb->prefix .
        'rudcrm_customer_details';

    $addresses_table =
        $wpdb->prefix .
        'rudcrm_addresses';


    $first_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['first_name'] ?? ''
            )
        );

    $middle_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['middle_name'] ?? ''
            )
        );

    $last_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['last_name'] ?? ''
            )
        );

    $company_name =
        sanitize_text_field(
            wp_unslash(
                $_POST['company_name'] ?? ''
            )
        );


    if (
        '' === $first_name &&
        '' === $last_name &&
        '' === $company_name
    ) {

        return new WP_Error(
            'missing_name',
            'Please enter at least a customer name or company name.'
        );
    }


    $now =
        current_time(
            'mysql'
        );

    $customer_number =
        rud_crm_next_customer_number();


    $inserted =
        $wpdb->insert(
            $customers_table,
            array(
                'customer_uuid' =>
                    wp_generate_uuid4(),

                'customer_number' =>
                    $customer_number,

                'customer_type' =>
                    '' !== $company_name
                    ? 'company'
                    : 'person',

                'title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['title'] ?? ''
                        )
                    ),

                'first_name' =>
                    $first_name,

                'middle_name' =>
                    $middle_name,

                'last_name' =>
                    $last_name,

                'preferred_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['preferred_name'] ?? ''
                        )
                    ),

                'company_name' =>
                    $company_name,

                'organization_number' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['organization_number'] ?? ''
                        )
                    ),

                'job_title' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['job_title'] ?? ''
                        )
                    ),

                'department' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['department'] ?? ''
                        )
                    ),

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status'] ?? 'customer'
                        )
                    ),

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            )
        );


    if ( false === $inserted ) {

        return new WP_Error(
            'database_error',
            'Customer could not be created.'
        );
    }


    $customer_id =
        (int)
        $wpdb->insert_id;


    /*
     * PERSONAL DETAILS
     */

    $birth_date =
        sanitize_text_field(
            wp_unslash(
                $_POST['birth_date'] ?? ''
            )
        );

    $birth_year =
        null;

    if (
        preg_match(
            '/^\d{4}-\d{2}-\d{2}$/',
            $birth_date
        )
    ) {

        $birth_year =
            (int) substr(
                $birth_date,
                0,
                4
            );

    } else {

        $birth_date =
            '';
    }


    $wpdb->insert(
        $details_table,
        array(
            'customer_id' =>
                $customer_id,

            'birth_date' =>
                $birth_date
                ? $birth_date
                : null,

            'birth_year' =>
                $birth_year,

            'gender' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['gender'] ?? ''
                    )
                ),

            'preferred_language' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['preferred_language'] ?? ''
                    )
                ),

            'nationality' =>
                sanitize_text_field(
                    wp_unslash(
                        $_POST['nationality'] ?? ''
                    )
                ),

            'website_url' =>
                '',

            'notes' =>
                sanitize_textarea_field(
                    wp_unslash(
                        $_POST['notes'] ?? ''
                    )
                ),

            'created_at' =>
                $now,

            'updated_at' =>
                $now
        )
    );


    /*
     * CONTACT INFORMATION
     */

    rud_crm_customer_insert_contact(
        $customer_id,
        'private_email',
        'Private Email',
        sanitize_email(
            wp_unslash(
                $_POST['private_email'] ?? ''
            )
        ),
        1
    );

    rud_crm_customer_insert_contact(
        $customer_id,
        'work_email',
        'Work Email',
        sanitize_email(
            wp_unslash(
                $_POST['work_email'] ?? ''
            )
        )
    );

    rud_crm_customer_insert_contact(
        $customer_id,
        'mobile_phone',
        'Mobile Phone',
        sanitize_text_field(
            wp_unslash(
                $_POST['mobile_phone'] ?? ''
            )
        ),
        1
    );

    rud_crm_customer_insert_contact(
        $customer_id,
        'home_phone',
        'Home Phone',
        sanitize_text_field(
            wp_unslash(
                $_POST['home_phone'] ?? ''
            )
        )
    );

    rud_crm_customer_insert_contact(
        $customer_id,
        'office_phone',
        'Office Phone',
        sanitize_text_field(
            wp_unslash(
                $_POST['office_phone'] ?? ''
            )
        )
    );

    rud_crm_customer_insert_contact(
        $customer_id,
        'whatsapp',
        'WhatsApp',
        sanitize_text_field(
            wp_unslash(
                $_POST['whatsapp'] ?? ''
            )
        )
    );


    /*
     * PRIVATE ADDRESS
     */

    $address_line_1 =
        sanitize_text_field(
            wp_unslash(
                $_POST['address_line_1'] ?? ''
            )
        );

    $address_line_2 =
        sanitize_text_field(
            wp_unslash(
                $_POST['address_line_2'] ?? ''
            )
        );

    $postal_code =
        sanitize_text_field(
            wp_unslash(
                $_POST['postal_code'] ?? ''
            )
        );

    $city =
        sanitize_text_field(
            wp_unslash(
                $_POST['city'] ?? ''
            )
        );

    $state_region =
        sanitize_text_field(
            wp_unslash(
                $_POST['state_region'] ?? ''
            )
        );

    $country_code =
        strtoupper(
            sanitize_text_field(
                wp_unslash(
                    $_POST['country_code'] ?? ''
                )
            )
        );


    if (
        $address_line_1 ||
        $address_line_2 ||
        $postal_code ||
        $city ||
        $state_region ||
        $country_code
    ) {

        /*
         * Read actual table columns so this stays
         * compatible with the existing address table.
         */

        $columns_raw =
            $wpdb->get_results(
                "SHOW COLUMNS FROM $addresses_table"
            );

        $columns =
            array();

        if ( $columns_raw ) {

            foreach (
                $columns_raw as
                $column
            ) {

                $columns[] =
                    $column->Field;
            }
        }


        $address_data =
            array(
                'customer_id' =>
                    $customer_id,

                'address_type' =>
                    'private',

                'company_name' =>
                    '',

                'address_line_1' =>
                    $address_line_1,

                'address_line_2' =>
                    $address_line_2,

                'address_line_3' =>
                    '',

                'postal_code' =>
                    $postal_code,

                'city' =>
                    $city,

                'state_region' =>
                    $state_region,

                'country_code' =>
                    $country_code,

                'is_primary' =>
                    1,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            );


        foreach (
            array_keys(
                $address_data
            ) as
            $column_name
        ) {

            if (
                ! in_array(
                    $column_name,
                    $columns,
                    true
                )
            ) {

                unset(
                    $address_data[
                        $column_name
                    ]
                );
            }
        }


        $wpdb->insert(
            $addresses_table,
            $address_data
        );
    }


    /*
     * SOCIAL MEDIA
     */

    rud_crm_customer_save_social_accounts(
        $customer_id
    );


    return array(
        'customer_id' =>
            $customer_id,

        'customer_number' =>
            $customer_number
    );
}


/*
 * =========================================================
 * CUSTOMERS PAGE
 * =========================================================
 */

function rud_crm_customers_page() {

    global $wpdb;


    if (
        ! current_user_can(
            'manage_options'
        )
    ) {
        return;
    }


    /*
     * ---------------------------------------------------------
     * PROFILE MODE
     * ---------------------------------------------------------
     */

    $customer_id =
        isset(
            $_GET['customer_id']
        )
        ? absint(
            $_GET['customer_id']
        )
        : 0;


    if (
        $customer_id > 0 &&
        function_exists(
            'rud_crm_render_customer_profile'
        )
    ) {

        rud_crm_render_customer_profile(
            $customer_id
        );

        return;
    }


    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';


    /*
     * ---------------------------------------------------------
     * CREATE CUSTOMER
     * ---------------------------------------------------------
     */

    if (
        isset(
            $_POST['rud_crm_add_customer']
        )
    ) {

        check_admin_referer(
            'rud_crm_add_customer_action',
            'rud_crm_add_customer_nonce'
        );

        $result =
            rud_crm_customer_create();


        if (
            is_wp_error(
                $result
            )
        ) {

            echo '<div class="notice notice-error">';

            echo '<p>' .
                esc_html(
                    $result->get_error_message()
                ) .
                '</p>';

            echo '</div>';

        } else {

            echo '<div class="notice notice-success">';

            echo '<p>';

            echo 'Customer created successfully: <strong>' .
                esc_html(
                    $result['customer_number']
                ) .
                '</strong>';

            echo '</p>';

            echo '</div>';
        }
    }


    /*
     * ---------------------------------------------------------
     * SEARCH
     * ---------------------------------------------------------
     */

    $search =
        isset(
            $_GET['customer_search']
        )
        ? sanitize_text_field(
            wp_unslash(
                $_GET['customer_search']
            )
        )
        : '';


    if (
        '' !==
        $search
    ) {

        $like =
            '%' .
            $wpdb->esc_like(
                $search
            ) .
            '%';

        $customers =
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM $customers_table
                     WHERE customer_number LIKE %s
                     OR first_name LIKE %s
                     OR middle_name LIKE %s
                     OR last_name LIKE %s
                     OR company_name LIKE %s
                     ORDER BY id DESC",
                    $like,
                    $like,
                    $like,
                    $like,
                    $like
                )
            );

    } else {

        $customers =
            $wpdb->get_results(
                "SELECT *
                 FROM $customers_table
                 ORDER BY id DESC"
            );
    }


    /*
     * ---------------------------------------------------------
     * PAGE
     * ---------------------------------------------------------
     */

    echo '<div class="wrap">';

    echo '<h1>Customers</h1>';


    /*
     * SEARCH FORM
     */

    echo '<form
        method="get"
        style="margin:20px 0;"
    >';

    echo '<input
        type="hidden"
        name="page"
        value="rud-crm-customers"
    >';

    echo '<input
        type="search"
        name="customer_search"
        value="' .
        esc_attr(
            $search
        ) .
        '"
        placeholder="Search name, company or customer ID"
        style="min-width:360px;"
    > ';

    submit_button(
        'Search Customers',
        'secondary',
        '',
        false
    );

    echo '</form>';


    /*
     * ---------------------------------------------------------
     * CUSTOMER LIST
     * ---------------------------------------------------------
     */

    echo '<h2>Customer List</h2>';


    if (
        empty(
            $customers
        )
    ) {

        echo '<p>No customers found.</p>';

    } else {

        echo '<table class="widefat striped">';

        echo '<thead>';

        echo '<tr>';

        echo '<th>Customer ID</th>';

        echo '<th>Name</th>';

        echo '<th>Company</th>';

        echo '<th>Status</th>';

        echo '<th>Created</th>';

        echo '<th>Profile</th>';

        echo '</tr>';

        echo '</thead>';

        echo '<tbody>';


        foreach (
            $customers as
            $customer
        ) {

            $name =
                trim(
                    implode(
                        ' ',
                        array_filter(
                            array(
                                $customer->first_name,
                                $customer->middle_name,
                                $customer->last_name
                            )
                        )
                    )
                );


            $profile_url =
                admin_url(
                    'admin.php?page=rud-crm-customers&customer_id=' .
                    absint(
                        $customer->id
                    )
                );


            echo '<tr>';


            echo '<td>';

            echo '<strong>' .
                esc_html(
                    $customer->customer_number
                ) .
                '</strong>';

            echo '</td>';


            echo '<td>';

            echo '<a href="' .
                esc_url(
                    $profile_url
                ) .
                '">';

            echo '<strong>' .
                esc_html(
                    $name
                    ? $name
                    : 'Unnamed Customer'
                ) .
                '</strong>';

            echo '</a>';

            echo '</td>';


            echo '<td>' .
                esc_html(
                    $customer->company_name
                ) .
                '</td>';


            echo '<td>' .
                esc_html(
                    ucfirst(
                        $customer->status
                    )
                ) .
                '</td>';


            echo '<td>' .
                esc_html(
                    $customer->created_at
                ) .
                '</td>';


            echo '<td>';

            echo '<a
                class="button button-primary"
                href="' .
                esc_url(
                    $profile_url
                ) .
                '"
            >
                Open Profile
            </a>';

            echo '</td>';


            echo '</tr>';
        }


        echo '</tbody>';

        echo '</table>';
    }


    /*
     * =========================================================
     * ADD NEW CUSTOMER
     * =========================================================
     */

    echo '<hr style="margin:35px 0;">';

    echo '<h2>Add New Customer</h2>';

    echo '<form method="post">';


    wp_nonce_field(
        'rud_crm_add_customer_action',
        'rud_crm_add_customer_nonce'
    );


    /*
     * NAME
     */

    echo '<h3>Name</h3>';

    echo '<table class="form-table">';

    rud_crm_customer_input(
        'title',
        'Title'
    );

    rud_crm_customer_input(
        'first_name',
        'First Name'
    );

    rud_crm_customer_input(
        'middle_name',
        'Middle Name'
    );

    rud_crm_customer_input(
        'last_name',
        'Last Name'
    );

    rud_crm_customer_input(
        'preferred_name',
        'Preferred Name'
    );

    echo '</table>';


    /*
     * COMPANY
     */

    echo '<h3>Company</h3>';

    echo '<table class="form-table">';

    rud_crm_customer_input(
        'company_name',
        'Company Name'
    );

    rud_crm_customer_input(
        'organization_number',
        'Organization Number'
    );

    rud_crm_customer_input(
        'job_title',
        'Job Title'
    );

    rud_crm_customer_input(
        'department',
        'Department'
    );

    echo '</table>';


    /*
     * STATUS
     */

    echo '<h3>Customer Status</h3>';

    echo '<table class="form-table">';

    echo '<tr>';

    echo '<th>';

    echo '<label for="status">Status</label>';

    echo '</th>';

    echo '<td>';

    echo '<select
        name="status"
        id="status"
    >';

    echo '<option value="lead">';
    echo 'Lead';
    echo '</option>';

    echo '<option
        value="customer"
        selected
    >';
    echo 'Customer';
    echo '</option>';

    echo '<option value="partner">';
    echo 'Partner';
    echo '</option>';

    echo '<option value="inactive">';
    echo 'Inactive';
    echo '</option>';

    echo '</select>';

    echo '</td>';

    echo '</tr>';

    echo '</table>';


    /*
     * PERSONAL INFORMATION
     */

    echo '<h3>Personal Information</h3>';

    echo '<table class="form-table">';

    rud_crm_customer_input(
        'birth_date',
        'Birth Date',
        'date'
    );

    rud_crm_customer_input(
        'gender',
        'Gender'
    );

    rud_crm_customer_input(
        'preferred_language',
        'Preferred Language'
    );

    rud_crm_customer_input(
        'nationality',
        'Nationality'
    );

    echo '</table>';


    /*
     * =========================================================
     * CONTACT INFORMATION
     * =========================================================
     */

    echo '<h3>Contact Information</h3>';

    echo '<table class="form-table">';


    /*
     * EMAIL
     */

    rud_crm_customer_input(
        'private_email',
        'Private Email',
        'email'
    );

    rud_crm_customer_input(
        'work_email',
        'Work Email',
        'email'
    );


    /*
     * INTERNATIONAL PHONE FIELDS
     */

    if (
        function_exists(
            'rud_crm_phone_input'
        )
    ) {

        rud_crm_phone_input(
            'mobile_phone',
            'Mobile Phone'
        );

        rud_crm_phone_input(
            'home_phone',
            'Home Phone'
        );

        rud_crm_phone_input(
            'office_phone',
            'Office Phone'
        );

        rud_crm_phone_input(
            'whatsapp',
            'WhatsApp'
        );

    } else {

        /*
         * Safety fallback.
         */

        rud_crm_customer_input(
            'mobile_phone',
            'Mobile Phone'
        );

        rud_crm_customer_input(
            'home_phone',
            'Home Phone'
        );

        rud_crm_customer_input(
            'office_phone',
            'Office Phone'
        );

        rud_crm_customer_input(
            'whatsapp',
            'WhatsApp'
        );
    }

    echo '</table>';


    /*
     * PRIVATE ADDRESS
     */

    echo '<h3>Private Address</h3>';

    echo '<table class="form-table">';

    rud_crm_customer_input(
        'address_line_1',
        'Address Line 1'
    );

    rud_crm_customer_input(
        'address_line_2',
        'Address Line 2'
    );

    rud_crm_customer_input(
        'postal_code',
        'Postal Code'
    );

    rud_crm_customer_input(
        'city',
        'City'
    );

    rud_crm_customer_input(
        'state_region',
        'State / Region'
    );

    rud_crm_customer_input(
        'country_code',
        'Country Code',
        'text',
        'Example: NO, SE, DK'
    );

    echo '</table>';


    /*
     * SOCIAL MEDIA
     */

    if (
        function_exists(
            'rud_crm_social_platforms'
        )
    ) {

        echo '<h3>Social Media & Messaging</h3>';

        echo '<p>';

        echo 'Activate only the platforms used by this customer.';

        echo '</p>';

        echo '<p>';

        echo '<button
            type="button"
            class="button"
            onclick="rudCustomerSocialAll(true);"
        >
            Activate All
        </button> ';

        echo '<button
            type="button"
            class="button"
            onclick="rudCustomerSocialAll(false);"
        >
            Clear All
        </button>';

        echo '</p>';


        echo '<table class="widefat striped">';

        echo '<thead>';

        echo '<tr>';

        echo '<th>Platform</th>';

        echo '<th style="width:90px;">Active</th>';

        echo '<th>Username / Account</th>';

        echo '<th>Profile Link</th>';

        echo '</tr>';

        echo '</thead>';

        echo '<tbody>';


        foreach (
            rud_crm_social_platforms()
            as
            $platform_key =>
            $platform_name
        ) {

            echo '<tr>';

            echo '<td>';

            echo '<strong>' .
                esc_html(
                    $platform_name
                ) .
                '</strong>';

            echo '</td>';


            echo '<td>';

            echo '<input
                class="rud-customer-social-active"
                type="checkbox"
                name="social_active[' .
                esc_attr(
                    $platform_key
                ) .
                ']"
                value="1"
            >';

            echo '</td>';


            echo '<td>';

            echo '<input
                type="text"
                name="social_account[' .
                esc_attr(
                    $platform_key
                ) .
                ']"
                class="regular-text"
            >';

            echo '</td>';


            echo '<td>';

            echo '<input
                type="url"
                name="social_url[' .
                esc_attr(
                    $platform_key
                ) .
                ']"
                class="large-text"
                placeholder="https://"
            >';

            echo '</td>';

            echo '</tr>';
        }


        echo '</tbody>';

        echo '</table>';
    }


    /*
     * NOTES
     */

    echo '<h3>Internal CRM Notes</h3>';

    echo '<textarea
        name="notes"
        rows="6"
        class="large-text"
    ></textarea>';


    /*
     * CREATE CUSTOMER BUTTON
     */

    echo '<div
        style="
            margin-top:30px;
            margin-bottom:30px;
            padding:20px;
            background:#fff;
            border:1px solid #ccd0d4;
        "
    >';

    submit_button(
        'Create Customer',
        'primary large',
        'rud_crm_add_customer',
        false
    );

    echo '</div>';


    echo '</form>';


    /*
     * ---------------------------------------------------------
     * JAVASCRIPT
     * ---------------------------------------------------------
     */

    ?>

    <script>

    function rudCustomerSocialAll(state) {

        document
            .querySelectorAll(
                '.rud-customer-social-active'
            )
            .forEach(
                function(box) {

                    box.checked =
                        state;
                }
            );
    }

    </script>

    <?php


    echo '</div>';
}