<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * DEMO DATA GENERATOR
 * =========================================================
 *
 * Creates 35 shared demo customers:
 *
 * DEMO-0001 -> DEMO-0035
 *
 * These records are intended ONLY for demo/testing.
 *
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * NUMBER OF DEMO CUSTOMERS
 * ---------------------------------------------------------
 */

function rud_crm_demo_customer_count() {

    return 35;
}


/*
 * ---------------------------------------------------------
 * DEMO CUSTOMER NUMBER
 * ---------------------------------------------------------
 */

function rud_crm_demo_customer_number(
    $number
) {

    return
        'DEMO-' .
        str_pad(
            absint( $number ),
            4,
            '0',
            STR_PAD_LEFT
        );
}


/*
 * ---------------------------------------------------------
 * DEMO CUSTOMER UUID
 * ---------------------------------------------------------
 */

function rud_crm_demo_customer_uuid(
    $number
) {

    return sprintf(
        '00000000-0000-4000-8000-%012d',
        absint( $number )
    );
}


/*
 * =========================================================
 * CREATE DEMO CUSTOMERS
 * =========================================================
 */

function rud_crm_create_demo_customers() {

    global $wpdb;


    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';


    $details_table =
        $wpdb->prefix .
        'rudcrm_customer_details';


    $addresses_table =
        $wpdb->prefix .
        'rudcrm_addresses';


    $contacts_table =
        $wpdb->prefix .
        'rudcrm_contact_methods';


    $social_table =
        $wpdb->prefix .
        'rudcrm_social_accounts';


    $activity_table =
        $wpdb->prefix .
        'rudcrm_customer_activity';


    $now =
        current_time(
            'mysql'
        );


    $created =
        0;


    $skipped =
        0;


    for (
        $i = 1;
        $i <= rud_crm_demo_customer_count();
        $i++
    ) {

        $customer_number =
            rud_crm_demo_customer_number(
                $i
            );


        /*
         * -------------------------------------------------
         * SKIP IF ALREADY EXISTS
         * -------------------------------------------------
         */

        $existing_id =
            (int)
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id
                     FROM {$customers_table}
                     WHERE customer_number = %s
                     LIMIT 1",
                    $customer_number
                )
            );


        if (
            $existing_id
        ) {

            $skipped++;

            continue;
        }


        /*
         * -------------------------------------------------
         * BASIC CUSTOMER DATA
         * -------------------------------------------------
         */

        $customer_label =
            str_pad(
                $i,
                3,
                '0',
                STR_PAD_LEFT
            );


        $first_name =
            'Demo';


        $middle_name =
            'Customer';


        $last_name =
            'NO-' .
            $customer_label;


        $company_name =
            'Demo Company ' .
            $customer_label .
            ' AS';


        /*
         * -------------------------------------------------
         * INSERT CUSTOMER
         * -------------------------------------------------
         */

        $inserted =
            $wpdb->insert(

                $customers_table,

                array(

                    'customer_uuid' =>
                        rud_crm_demo_customer_uuid(
                            $i
                        ),

                    'customer_number' =>
                        $customer_number,

                    'customer_type' =>
                        'person',

                    'title' =>
                        'Demo',

                    'first_name' =>
                        $first_name,

                    'middle_name' =>
                        $middle_name,

                    'last_name' =>
                        $last_name,

                    'preferred_name' =>
                        'Demo Customer ' .
                        $customer_label,

                    'company_name' =>
                        $company_name,

                    'organization_number' =>
                        'TEST-' .
                        str_pad(
                            $i,
                            6,
                            '0',
                            STR_PAD_LEFT
                        ),

                    'job_title' =>
                        'Demo Position ' .
                        $customer_label,

                    'department' =>
                        'Demo Department ' .
                        (
                            (
                                $i - 1
                            )
                            %
                            5
                            +
                            1
                        ),

                    'status' =>
                        (
                            0 ===
                            $i % 3
                        )
                        ?
                        'lead'
                        :
                        'active',

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now
                ),

                array(
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s',
                    '%s'
                )
            );


        if (
            false ===
            $inserted
        ) {

            continue;
        }


        $customer_id =
            (int)
            $wpdb->insert_id;


        if (
            ! $customer_id
        ) {

            continue;
        }


        /*
         * -------------------------------------------------
         * CUSTOMER DETAILS
         * -------------------------------------------------
         */

        $birth_year =
            1970 +
            (
                $i %
                30
            );


        $birth_month =
            str_pad(
                (
                    (
                        $i - 1
                    )
                    %
                    12
                )
                +
                1,
                2,
                '0',
                STR_PAD_LEFT
            );


        $birth_day =
            str_pad(
                (
                    (
                        $i - 1
                    )
                    %
                    27
                )
                +
                1,
                2,
                '0',
                STR_PAD_LEFT
            );


        $wpdb->insert(

            $details_table,

            array(

                'customer_id' =>
                    $customer_id,

                'birth_date' =>
                    $birth_year .
                    '-' .
                    $birth_month .
                    '-' .
                    $birth_day,

                'birth_year' =>
                    $birth_year,

                'gender' =>
                    (
                        0 ===
                        $i % 2
                    )
                    ?
                    'Female'
                    :
                    'Male',

                'preferred_language' =>
                    (
                        0 ===
                        $i % 4
                    )
                    ?
                    'en'
                    :
                    'no',

                'nationality' =>
                    'Demo Nationality ' .
                    (
                        (
                            $i - 1
                        )
                        %
                        5
                        +
                        1
                    ),

                'website_url' =>
                    'https://example.test/demo-' .
                    $customer_label,

                'notes' =>
                    'DEMO CUSTOMER. Test data only. Customer ' .
                    $customer_label .
                    ' is used exclusively for the RUD CRM demo environment.',

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            ),

            array(
                '%d',
                '%s',
                '%d',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s'
            )
        );


        /*
         * -------------------------------------------------
         * PRIVATE ADDRESS
         * -------------------------------------------------
         */

        $wpdb->insert(

            $addresses_table,

            array(

                'customer_id' =>
                    $customer_id,

                'address_type' =>
                    'private',

                'company_name' =>
                    '',

                'address_line_1' =>
                    'Demo Street ' .
                    $customer_label,

                'address_line_2' =>
                    'Demo House ' .
                    $customer_label,

                'address_line_3' =>
                    '',

                'postal_code' =>
                    str_pad(
                        1000 +
                        $i,
                        4,
                        '0',
                        STR_PAD_LEFT
                    ),

                'city' =>
                    'Demo City ' .
                    (
                        (
                            $i - 1
                        )
                        %
                        7
                        +
                        1
                    ),

                'state_region' =>
                    'Demo Region',

                'country_code' =>
                    'NO',

                'is_primary' =>
                    1,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            )
        );


        /*
         * -------------------------------------------------
         * BUSINESS ADDRESS
         * -------------------------------------------------
         */

        $wpdb->insert(

            $addresses_table,

            array(

                'customer_id' =>
                    $customer_id,

                'address_type' =>
                    'business',

                'company_name' =>
                    $company_name,

                'address_line_1' =>
                    'Demo Business Road ' .
                    $customer_label,

                'address_line_2' =>
                    'Office ' .
                    $customer_label,

                'address_line_3' =>
                    '',

                'postal_code' =>
                    str_pad(
                        2000 +
                        $i,
                        4,
                        '0',
                        STR_PAD_LEFT
                    ),

                'city' =>
                    'Demo Business City',

                'state_region' =>
                    'Demo Region',

                'country_code' =>
                    'NO',

                'is_primary' =>
                    0,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            )
        );


        /*
         * -------------------------------------------------
         * EMAIL / PHONE
         * -------------------------------------------------
         */

        $private_email =
            sprintf(
                'demo-customer-account-%03d@example.test',
                $i
            );


        $work_email =
            sprintf(
                'demo-customer-work-%03d@example.test',
                $i
            );


        $mobile_phone =
            '+47 900 ' .
            str_pad(
                $i,
                5,
                '0',
                STR_PAD_LEFT
            );


        $home_phone =
            '+47 220 ' .
            str_pad(
                $i,
                5,
                '0',
                STR_PAD_LEFT
            );


        $office_phone =
            '+47 230 ' .
            str_pad(
                $i,
                5,
                '0',
                STR_PAD_LEFT
            );


        $contacts =
            array(

                array(
                    'private_email',
                    'Private Email',
                    $private_email,
                    1
                ),

                array(
                    'work_email',
                    'Work Email',
                    $work_email,
                    0
                ),

                array(
                    'mobile_phone',
                    'Mobile Phone',
                    $mobile_phone,
                    1
                ),

                array(
                    'home_phone',
                    'Home Phone',
                    $home_phone,
                    0
                ),

                array(
                    'office_phone',
                    'Office Phone',
                    $office_phone,
                    0
                ),

                array(
                    'whatsapp',
                    'WhatsApp',
                    $mobile_phone,
                    0
                )
            );


        foreach (
            $contacts as
            $contact
        ) {

            $wpdb->insert(

                $contacts_table,

                array(

                    'customer_id' =>
                        $customer_id,

                    'contact_type' =>
                        $contact[0],

                    'contact_label' =>
                        $contact[1],

                    'contact_value' =>
                        $contact[2],

                    'is_primary' =>
                        $contact[3],

                    'is_verified' =>
                        0,

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now
                )
            );
        }


        /*
         * -------------------------------------------------
         * SOCIAL MEDIA
         * -------------------------------------------------
         */

        $social_accounts =
            array(

                'facebook' =>
                    'https://example.test/facebook/' .
                    $customer_label,

                'instagram' =>
                    'https://example.test/instagram/' .
                    $customer_label,

                'linkedin' =>
                    'https://example.test/linkedin/' .
                    $customer_label,

                'youtube' =>
                    'https://example.test/youtube/' .
                    $customer_label
            );


        foreach (
            $social_accounts as
            $platform =>
            $profile_url
        ) {

            $wpdb->insert(

                $social_table,

                array(

                    'customer_id' =>
                        $customer_id,

                    'platform' =>
                        $platform,

                    'is_active' =>
                        1,

                    'account_name' =>
                        'demo-account-' .
                        $customer_label,

                    'profile_url' =>
                        $profile_url,

                    'notes' =>
                        'Demo social account.',

                    'created_at' =>
                        $now,

                    'updated_at' =>
                        $now
                )
            );
        }


        /*
         * -------------------------------------------------
         * CUSTOMER PERMISSIONS
         * -------------------------------------------------
         */

        if (
            function_exists(
                'rud_crm_allow_all_customer_permissions'
            )
        ) {

            rud_crm_allow_all_customer_permissions(
                $customer_id,
                'Demo Generator'
            );
        }


        /*
         * -------------------------------------------------
         * ACTIVITY TIMELINE
         * -------------------------------------------------
         */

        $activity_table_exists =
            $wpdb->get_var(
                $wpdb->prepare(
                    'SHOW TABLES LIKE %s',
                    $activity_table
                )
            );


        if (
            $activity_table_exists ===
            $activity_table
        ) {

            $activities =
                array(

                    array(
                        'system',
                        'Demo customer created',
                        'This demo customer was automatically created for the RUD CRM demonstration environment.'
                    ),

                    array(
                        'note',
                        'Example customer note',
                        'This is fictional customer information used only to demonstrate the CRM timeline.'
                    ),

                    array(
                        'call',
                        'Example phone call',
                        'DEMO CALL: Customer service discussed a fictional follow-up request.'
                    ),

                    array(
                        'email',
                        'Example email activity',
                        'DEMO EMAIL: Example communication recorded for CRM demonstration purposes.'
                    )
                );


            foreach (
                $activities as
                $activity
            ) {

                $wpdb->insert(

                    $activity_table,

                    array(

                        'customer_id' =>
                            $customer_id,

                        'activity_type' =>
                            $activity[0],

                        'title' =>
                            $activity[1],

                        'content' =>
                            $activity[2],

                        'source' =>
                            'Demo Generator',

                        'source_reference' =>
                            '',

                        'created_by' =>
                            get_current_user_id(),

                        'activity_date' =>
                            $now,

                        'created_at' =>
                            $now,

                        'updated_at' =>
                            $now
                    )
                );
            }
        }


        $created++;
    }


    return array(

        'created' =>
            $created,

        'skipped' =>
            $skipped,

        'total' =>
            rud_crm_demo_customer_count()
    );
}


/*
 * =========================================================
 * DELETE ALL DEMO CUSTOMERS
 * =========================================================
 */

function rud_crm_delete_demo_customers() {

    global $wpdb;


    $customers_table =
        $wpdb->prefix .
        'rudcrm_customers';


    $demo_ids =
        $wpdb->get_col(
            "SELECT id
             FROM {$customers_table}
             WHERE customer_number LIKE 'DEMO-%'"
        );


    if (
        empty(
            $demo_ids
        )
    ) {

        return 0;
    }


    $deleted =
        0;


    foreach (
        $demo_ids as
        $customer_id
    ) {

        $customer_id =
            absint(
                $customer_id
            );


        if (
            ! $customer_id
        ) {

            continue;
        }


        $related_tables =
            array(

                'rudcrm_customer_details',
                'rudcrm_addresses',
                'rudcrm_contact_methods',
                'rudcrm_social_accounts',
                'rudcrm_customer_images',
                'rudcrm_customer_sites',
                'rudcrm_customer_permissions',
                'rudcrm_customer_activity'
            );


        foreach (
            $related_tables as
            $table_suffix
        ) {

            $table_name =
                $wpdb->prefix .
                $table_suffix;


            $table_exists =
                $wpdb->get_var(
                    $wpdb->prepare(
                        'SHOW TABLES LIKE %s',
                        $table_name
                    )
                );


            if (
                $table_exists !==
                $table_name
            ) {

                continue;
            }


            $wpdb->delete(

                $table_name,

                array(
                    'customer_id' =>
                        $customer_id
                ),

                array(
                    '%d'
                )
            );
        }


        $wpdb->delete(

            $customers_table,

            array(
                'id' =>
                    $customer_id
            ),

            array(
                '%d'
            )
        );


        $deleted++;
    }


    return $deleted;
}


/*
 * =========================================================
 * ADMIN PAGE
 * =========================================================
 */

function rud_crm_demo_data_admin_page() {

    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return;
    }


    $message =
        '';


    /*
     * CREATE
     */

    if (
        isset(
            $_POST['rud_crm_create_demo_data']
        )
    ) {

        check_admin_referer(
            'rud_crm_demo_data_action'
        );


        $result =
            rud_crm_create_demo_customers();


        $message =
            sprintf(
                'Demo data complete. Created: %d. Existing/skipped: %d. Target: %d.',
                $result['created'],
                $result['skipped'],
                $result['total']
            );
    }


    /*
     * DELETE
     */

    if (
        isset(
            $_POST['rud_crm_delete_demo_data']
        )
    ) {

        check_admin_referer(
            'rud_crm_demo_data_action'
        );


        $deleted =
            rud_crm_delete_demo_customers();


        $message =
            sprintf(
                'Deleted %d demo customers.',
                $deleted
            );
    }


    ?>

    <div class="wrap">

        <h1>
            RUD CRM Demo Data
        </h1>

        <p>
            Creates 35 fictional CRM customers for testing.
        </p>

        <p>
            Customer numbers:
            <strong>
                DEMO-0001 through DEMO-0035
            </strong>
        </p>


        <?php

        if (
            '' !==
            $message
        ) {

            ?>

            <div class="notice notice-success is-dismissible">

                <p>
                    <?php
                    echo esc_html(
                        $message
                    );
                    ?>
                </p>

            </div>

            <?php
        }

        ?>


        <form method="post">

            <?php

            wp_nonce_field(
                'rud_crm_demo_data_action'
            );

            ?>


            <p>

                <button
                    type="submit"
                    name="rud_crm_create_demo_data"
                    value="1"
                    class="button button-primary"
                >
                    Create 35 Demo Customers
                </button>

            </p>


            <p>

                <button
                    type="submit"
                    name="rud_crm_delete_demo_data"
                    value="1"
                    class="button"
                    onclick="return confirm('Delete ALL demo customers?');"
                >
                    Delete All Demo Customers
                </button>

            </p>

        </form>

    </div>

    <?php
}


/*
 * =========================================================
 * ADMIN MENU
 * =========================================================
 */

function rud_crm_demo_data_admin_menu() {

    add_submenu_page(

        'rud-crm',

        'Demo Data',

        'Demo Data',

        'manage_options',

        'rud-crm-demo-data',

        'rud_crm_demo_data_admin_page'
    );
}


add_action(
    'admin_menu',
    'rud_crm_demo_data_admin_menu',
    30
);