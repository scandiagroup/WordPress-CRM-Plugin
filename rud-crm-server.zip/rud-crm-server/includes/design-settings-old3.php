<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * GLOBAL DESIGN SETTINGS
 * Version 1.0
 * =========================================================
 *
 * Purpose:
 *
 * - Global CRM typography settings
 * - Administrator-only editing
 * - Settings stored in WordPress options
 * - Applies to all users viewing RUD CRM pages
 *
 * Shortcode:
 *
 * [rud_crm_design_settings]
 *
 * =========================================================
 */


/*
 * =========================================================
 * OPTION NAME
 * =========================================================
 */

function rud_crm_design_option_name() {

    return 'rud_crm_global_design_settings';
}


/*
 * =========================================================
 * DEFAULT SETTINGS
 * =========================================================
 */

function rud_crm_design_defaults() {

    return array(

        'font_family' => 'inherit',

        'body_size'   => 14,
        'body_weight' => 400,

        'main_heading_size'   => 22,
        'main_heading_weight' => 600,

        'section_heading_size'   => 18,
        'section_heading_weight' => 600,

        'label_size'   => 14,
        'label_weight' => 600,

        'button_size'   => 14,
        'button_weight' => 600,

        'body_color'            => '#333333',
        'main_heading_color'    => '#1d2327',
        'section_heading_color' => '#1d2327',
        'label_color'           => '#1d2327',
        'button_text_color'     => '#ffffff',
        'button_bg_color'       => '#1d2327',
        'button_hover_color'    => '#2c3338',
        'border_color'          => '#dddddd',
        'card_bg_color'         => '#ffffff',
    );
}


/*
 * =========================================================
 * GET SETTINGS
 * =========================================================
 */

function rud_crm_design_get_settings() {

    $saved =
        get_option(
            rud_crm_design_option_name(),
            array()
        );

    if (
        ! is_array(
            $saved
        )
    ) {
        $saved = array();
    }

    return wp_parse_args(
        $saved,
        rud_crm_design_defaults()
    );
}


/*
 * =========================================================
 * ALLOWED FONT FAMILIES
 * =========================================================
 */

function rud_crm_design_font_choices() {

    return array(

        'inherit' =>
            'System / Theme Default',

        'Arial, sans-serif' =>
            'Arial',

        'Helvetica, Arial, sans-serif' =>
            'Helvetica',

        'Verdana, Geneva, sans-serif' =>
            'Verdana',

        'Tahoma, Geneva, sans-serif' =>
            'Tahoma',

        '"Trebuchet MS", Arial, sans-serif' =>
            'Trebuchet MS',

        'Georgia, serif' =>
            'Georgia',

        '"Times New Roman", Times, serif' =>
            'Times New Roman',

        'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' =>
            'Modern System Font'
    );
}


/*
 * =========================================================
 * ALLOWED FONT WEIGHTS
 * =========================================================
 */

function rud_crm_design_weight_choices() {

    return array(

        400 => 'Normal',
        500 => 'Medium',
        600 => 'Semibold',
        700 => 'Bold'
    );
}


/*
 * =========================================================
 * SANITIZE FONT FAMILY
 * =========================================================
 */

function rud_crm_design_sanitize_font_family(
    $font_family
) {

    $font_family =
        (string)
        $font_family;

    $choices =
        rud_crm_design_font_choices();

    if (
        ! array_key_exists(
            $font_family,
            $choices
        )
    ) {
        return 'inherit';
    }

    return $font_family;
}


/*
 * =========================================================
 * SANITIZE FONT SIZE
 * =========================================================
 */

function rud_crm_design_sanitize_size(
    $size,
    $default
) {

    $size =
        absint(
            $size
        );

    if (
        $size < 8
        ||
        $size > 72
    ) {
        return absint(
            $default
        );
    }

    return $size;
}


/*
 * =========================================================
 * SANITIZE FONT WEIGHT
 * =========================================================
 */

function rud_crm_design_sanitize_weight(
    $weight,
    $default
) {

    $weight =
        absint(
            $weight
        );

    $allowed =
        array(
            400,
            500,
            600,
            700
        );

    if (
        ! in_array(
            $weight,
            $allowed,
            true
        )
    ) {
        return absint(
            $default
        );
    }

    return $weight;
}


/*
 * =========================================================
 * SANITIZE COLOR
 * =========================================================
 */

function rud_crm_design_sanitize_color(
    $color,
    $default
) {

    $color =
        sanitize_hex_color(
            (string) $color
        );

    if (
        empty(
            $color
        )
    ) {
        return sanitize_hex_color(
            $default
        );
    }

    return $color;
}


/*
 * =========================================================
 * PROCESS SAVE / RESET
 * =========================================================
 */

function rud_crm_design_process_form() {

    if (
        ! is_user_logged_in()
        ||
        ! current_user_can(
            'manage_options'
        )
    ) {
        return;
    }

    if (
        empty(
            $_POST[
                'rud_crm_design_action'
            ]
        )
    ) {
        return;
    }

    $action =
        sanitize_key(
            wp_unslash(
                $_POST[
                    'rud_crm_design_action'
                ]
            )
        );

    if (
        empty(
            $_POST[
                'rud_crm_design_nonce'
            ]
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST[
                        'rud_crm_design_nonce'
                    ]
                )
            ),
            'rud_crm_save_design_settings'
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed.',
                'rud-crm-server'
            )
        );
    }


    /*
     * RESET
     */

    if (
        'reset' ===
        $action
    ) {

        delete_option(
            rud_crm_design_option_name()
        );

        wp_safe_redirect(
            add_query_arg(
                'rud_crm_design',
                'reset',
                rud_crm_design_current_url()
            )
        );

        exit;
    }


    /*
     * SAVE
     */

    if (
        'save' !==
        $action
    ) {
        return;
    }

    $defaults =
        rud_crm_design_defaults();


    $settings =
        array(

            'font_family' =>
                rud_crm_design_sanitize_font_family(
                    isset(
                        $_POST[
                            'font_family'
                        ]
                    )
                    ? wp_unslash(
                        $_POST[
                            'font_family'
                        ]
                    )
                    : 'inherit'
                ),

            'body_size' =>
                rud_crm_design_sanitize_size(
                    $_POST[
                        'body_size'
                    ] ?? $defaults[
                        'body_size'
                    ],
                    $defaults[
                        'body_size'
                    ]
                ),

            'body_weight' =>
                rud_crm_design_sanitize_weight(
                    $_POST[
                        'body_weight'
                    ] ?? $defaults[
                        'body_weight'
                    ],
                    $defaults[
                        'body_weight'
                    ]
                ),

            'main_heading_size' =>
                rud_crm_design_sanitize_size(
                    $_POST[
                        'main_heading_size'
                    ] ?? $defaults[
                        'main_heading_size'
                    ],
                    $defaults[
                        'main_heading_size'
                    ]
                ),

            'main_heading_weight' =>
                rud_crm_design_sanitize_weight(
                    $_POST[
                        'main_heading_weight'
                    ] ?? $defaults[
                        'main_heading_weight'
                    ],
                    $defaults[
                        'main_heading_weight'
                    ]
                ),

            'section_heading_size' =>
                rud_crm_design_sanitize_size(
                    $_POST[
                        'section_heading_size'
                    ] ?? $defaults[
                        'section_heading_size'
                    ],
                    $defaults[
                        'section_heading_size'
                    ]
                ),

            'section_heading_weight' =>
                rud_crm_design_sanitize_weight(
                    $_POST[
                        'section_heading_weight'
                    ] ?? $defaults[
                        'section_heading_weight'
                    ],
                    $defaults[
                        'section_heading_weight'
                    ]
                ),

            'label_size' =>
                rud_crm_design_sanitize_size(
                    $_POST[
                        'label_size'
                    ] ?? $defaults[
                        'label_size'
                    ],
                    $defaults[
                        'label_size'
                    ]
                ),

            'label_weight' =>
                rud_crm_design_sanitize_weight(
                    $_POST[
                        'label_weight'
                    ] ?? $defaults[
                        'label_weight'
                    ],
                    $defaults[
                        'label_weight'
                    ]
                ),

            'button_size' =>
                rud_crm_design_sanitize_size(
                    $_POST[
                        'button_size'
                    ] ?? $defaults[
                        'button_size'
                    ],
                    $defaults[
                        'button_size'
                    ]
                ),

            'button_weight' =>
                rud_crm_design_sanitize_weight(
                    $_POST[
                        'button_weight'
                    ] ?? $defaults[
                        'button_weight'
                    ],
                    $defaults[
                        'button_weight'
                    ]
                ),

            'body_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['body_color'] ?? $defaults['body_color'],
                    $defaults['body_color']
                ),

            'main_heading_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['main_heading_color'] ?? $defaults['main_heading_color'],
                    $defaults['main_heading_color']
                ),

            'section_heading_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['section_heading_color'] ?? $defaults['section_heading_color'],
                    $defaults['section_heading_color']
                ),

            'label_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['label_color'] ?? $defaults['label_color'],
                    $defaults['label_color']
                ),

            'button_text_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['button_text_color'] ?? $defaults['button_text_color'],
                    $defaults['button_text_color']
                ),

            'button_bg_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['button_bg_color'] ?? $defaults['button_bg_color'],
                    $defaults['button_bg_color']
                ),

            'button_hover_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['button_hover_color'] ?? $defaults['button_hover_color'],
                    $defaults['button_hover_color']
                ),

            'border_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['border_color'] ?? $defaults['border_color'],
                    $defaults['border_color']
                ),

            'card_bg_color' =>
                rud_crm_design_sanitize_color(
                    $_POST['card_bg_color'] ?? $defaults['card_bg_color'],
                    $defaults['card_bg_color']
                )
        );


    update_option(
        rud_crm_design_option_name(),
        $settings,
        false
    );


    wp_safe_redirect(
        add_query_arg(
            'rud_crm_design',
            'saved',
            rud_crm_design_current_url()
        )
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_design_process_form',
    15
);


/*
 * =========================================================
 * CURRENT URL
 * =========================================================
 */

function rud_crm_design_current_url() {

    $scheme =
        is_ssl()
        ? 'https://'
        : 'http://';

    $host =
        isset(
            $_SERVER[
                'HTTP_HOST'
            ]
        )
        ? sanitize_text_field(
            wp_unslash(
                $_SERVER[
                    'HTTP_HOST'
                ]
            )
        )
        : '';

    $uri =
        isset(
            $_SERVER[
                'REQUEST_URI'
            ]
        )
        ? wp_unslash(
            $_SERVER[
                'REQUEST_URI'
            ]
        )
        : '/';

    return esc_url_raw(
        remove_query_arg(
            'rud_crm_design',
            $scheme .
            $host .
            $uri
        )
    );
}


/*
 * =========================================================
 * GLOBAL FRONT-END CSS
 * =========================================================
 */

function rud_crm_design_output_global_css() {

    if (
        is_admin()
    ) {
        return;
    }

    $settings =
        rud_crm_design_get_settings();

    $font_family =
        rud_crm_design_sanitize_font_family(
            $settings[
                'font_family'
            ]
        );

    $body_size =
        rud_crm_design_sanitize_size(
            $settings[
                'body_size'
            ],
            14
        );

    $body_weight =
        rud_crm_design_sanitize_weight(
            $settings[
                'body_weight'
            ],
            400
        );

    $main_size =
        rud_crm_design_sanitize_size(
            $settings[
                'main_heading_size'
            ],
            22
        );

    $main_weight =
        rud_crm_design_sanitize_weight(
            $settings[
                'main_heading_weight'
            ],
            600
        );

    $section_size =
        rud_crm_design_sanitize_size(
            $settings[
                'section_heading_size'
            ],
            18
        );

    $section_weight =
        rud_crm_design_sanitize_weight(
            $settings[
                'section_heading_weight'
            ],
            600
        );

    $label_size =
        rud_crm_design_sanitize_size(
            $settings[
                'label_size'
            ],
            14
        );

    $label_weight =
        rud_crm_design_sanitize_weight(
            $settings[
                'label_weight'
            ],
            600
        );

    $button_size =
        rud_crm_design_sanitize_size(
            $settings[
                'button_size'
            ],
            14
        );

    $button_weight =
        rud_crm_design_sanitize_weight(
            $settings[
                'button_weight'
            ],
            600
        );

    $body_color =
        rud_crm_design_sanitize_color(
            $settings['body_color'],
            '#333333'
        );

    $main_heading_color =
        rud_crm_design_sanitize_color(
            $settings['main_heading_color'],
            '#1d2327'
        );

    $section_heading_color =
        rud_crm_design_sanitize_color(
            $settings['section_heading_color'],
            '#1d2327'
        );

    $label_color =
        rud_crm_design_sanitize_color(
            $settings['label_color'],
            '#1d2327'
        );

    $button_text_color =
        rud_crm_design_sanitize_color(
            $settings['button_text_color'],
            '#ffffff'
        );

    $button_bg_color =
        rud_crm_design_sanitize_color(
            $settings['button_bg_color'],
            '#1d2327'
        );

    $button_hover_color =
        rud_crm_design_sanitize_color(
            $settings['button_hover_color'],
            '#2c3338'
        );

    $border_color =
        rud_crm_design_sanitize_color(
            $settings['border_color'],
            '#dddddd'
        );

    $card_bg_color =
        rud_crm_design_sanitize_color(
            $settings['card_bg_color'],
            '#ffffff'
        );

    ?>
    <style id="rud-crm-global-design">

        /*
         * =============================================
         * GLOBAL RUD CRM TYPOGRAPHY
         * =============================================
         */

        [class^="rud-crm-"],
        [class*=" rud-crm-"] {
            font-family: <?php echo esc_html( $font_family ); ?>;
            font-size: <?php echo esc_html( $body_size ); ?>px;
            font-weight: <?php echo esc_html( $body_weight ); ?>;
            color: <?php echo esc_html( $body_color ); ?>;
        }


        /*
         * MAIN CRM HEADINGS
         */

        [class^="rud-crm-"] h1,
        [class*=" rud-crm-"] h1,
        .rud-crm-main-heading {
            font-family: <?php echo esc_html( $font_family ); ?>;
            font-size: <?php echo esc_html( $main_size ); ?>px !important;
            font-weight: <?php echo esc_html( $main_weight ); ?> !important;
            color: <?php echo esc_html( $main_heading_color ); ?> !important;
            line-height: 1.25;
        }


        /*
         * SECTION HEADINGS
         *
         * This intentionally normalizes H2 and H3 inside
         * RUD CRM blocks. This is the first step toward
         * making headings such as Company Name,
         * Send Email, Send SMS and To Do List consistent.
         */

        [class^="rud-crm-"] h2,
        [class*=" rud-crm-"] h2,
        [class^="rud-crm-"] h3,
        [class*=" rud-crm-"] h3,
        .rud-crm-section-heading {
            font-family: <?php echo esc_html( $font_family ); ?>;
            font-size: <?php echo esc_html( $section_size ); ?>px !important;
            font-weight: <?php echo esc_html( $section_weight ); ?> !important;
            color: <?php echo esc_html( $section_heading_color ); ?> !important;
            line-height: 1.3;
        }


        /*
         * LABELS
         */

        [class^="rud-crm-"] label,
        [class*=" rud-crm-"] label,
        .rud-crm-label {
            font-family: <?php echo esc_html( $font_family ); ?>;
            font-size: <?php echo esc_html( $label_size ); ?>px !important;
            font-weight: <?php echo esc_html( $label_weight ); ?> !important;
            color: <?php echo esc_html( $label_color ); ?> !important;
        }


        /*
         * BUTTONS / LINKS DISPLAYED AS BUTTONS
         */

        .rud-crm-button,
        [class^="rud-crm-"] button,
        [class*=" rud-crm-"] button,
        [class^="rud-crm-"] input[type="submit"],
        [class*=" rud-crm-"] input[type="submit"] {
            font-family: <?php echo esc_html( $font_family ); ?>;
            font-size: <?php echo esc_html( $button_size ); ?>px !important;
            font-weight: <?php echo esc_html( $button_weight ); ?> !important;
            color: <?php echo esc_html( $button_text_color ); ?> !important;
            background-color: <?php echo esc_html( $button_bg_color ); ?> !important;
        }

        .rud-crm-button:hover,
        .rud-crm-button:focus,
        [class^="rud-crm-"] button:hover,
        [class*=" rud-crm-"] button:hover,
        [class^="rud-crm-"] button:focus,
        [class*=" rud-crm-"] button:focus,
        [class^="rud-crm-"] input[type="submit"]:hover,
        [class*=" rud-crm-"] input[type="submit"]:hover {
            background-color: <?php echo esc_html( $button_hover_color ); ?> !important;
            color: <?php echo esc_html( $button_text_color ); ?> !important;
        }

        .rud-crm-card,
        .rud-crm-customer-card,
        .rud-crm-account-card,
        .rud-crm-design-card,
        .rud-crm-customer-section {
            background-color: <?php echo esc_html( $card_bg_color ); ?> !important;
            border-color: <?php echo esc_html( $border_color ); ?> !important;
        }

        .rud-crm-design-settings input,
        .rud-crm-design-settings select,
        [class^="rud-crm-"] input,
        [class*=" rud-crm-"] input,
        [class^="rud-crm-"] select,
        [class*=" rud-crm-"] select,
        [class^="rud-crm-"] textarea,
        [class*=" rud-crm-"] textarea {
            border-color: <?php echo esc_html( $border_color ); ?>;
        }

    </style>
    <?php
}


add_action(
    'wp_head',
    'rud_crm_design_output_global_css',
    999
);


/*
 * =========================================================
 * ADMIN NOTICE
 * =========================================================
 */

function rud_crm_design_status_notice() {

    if (
        empty(
            $_GET[
                'rud_crm_design'
            ]
        )
    ) {
        return '';
    }

    $status =
        sanitize_key(
            wp_unslash(
                $_GET[
                    'rud_crm_design'
                ]
            )
        );

    if (
        'saved' ===
        $status
    ) {
        return
            '<div class="rud-crm-design-notice rud-crm-design-notice-success">' .
            'Global design settings saved.' .
            '</div>';
    }

    if (
        'reset' ===
        $status
    ) {
        return
            '<div class="rud-crm-design-notice rud-crm-design-notice-success">' .
            'Global design settings reset to defaults.' .
            '</div>';
    }

    return '';
}


/*
 * =========================================================
 * SELECT FIELD HELPERS
 * =========================================================
 */

function rud_crm_design_size_select(
    $name,
    $selected
) {

    echo '<select name="' .
        esc_attr(
            $name
        ) .
        '">';

    for (
        $size = 8;
        $size <= 32;
        $size++
    ) {

        echo '<option value="' .
            esc_attr(
                $size
            ) .
            '"' .
            selected(
                absint(
                    $selected
                ),
                $size,
                false
            ) .
            '>' .
            esc_html(
                $size .
                ' px'
            ) .
            '</option>';
    }

    echo '</select>';
}


function rud_crm_design_weight_select(
    $name,
    $selected
) {

    $choices =
        rud_crm_design_weight_choices();

    echo '<select name="' .
        esc_attr(
            $name
        ) .
        '">';

    foreach (
        $choices
        as
        $weight =>
        $label
    ) {

        echo '<option value="' .
            esc_attr(
                $weight
            ) .
            '"' .
            selected(
                absint(
                    $selected
                ),
                absint(
                    $weight
                ),
                false
            ) .
            '>' .
            esc_html(
                $label
            ) .
            '</option>';
    }

    echo '</select>';
}


/*
 * =========================================================
 * DESIGN SETTINGS PAGE
 * =========================================================
 */

function rud_crm_design_settings_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return
            '<div class="rud-crm-design-access">' .
            '<p>You must be logged in to access Design Settings.</p>' .
            '</div>';
    }


    if (
        ! current_user_can(
            'manage_options'
        )
    ) {

        return
            '<div class="rud-crm-design-access">' .
            '<p>Design Settings are available to the Administrator only.</p>' .
            '</div>';
    }


    $settings =
        rud_crm_design_get_settings();

    $fonts =
        rud_crm_design_font_choices();


    ob_start();

    ?>
    <div class="rud-crm-design-settings">

        <style>

            .rud-crm-design-settings {
                max-width: 1000px;
                margin: 0 auto;
            }

            .rud-crm-design-card {
                background: #fff;
                border: 1px solid #ddd;
                border-radius: 10px;
                padding: 24px;
                margin-bottom: 24px;
            }

            .rud-crm-design-grid {
                display: grid;
                grid-template-columns: minmax(180px, 1fr) minmax(140px, 220px) minmax(140px, 220px);
                gap: 16px;
                align-items: center;
            }

            .rud-crm-design-grid-heading {
                font-weight: 700;
                padding-bottom: 8px;
                border-bottom: 1px solid #ddd;
            }

            .rud-crm-design-label {
                font-weight: 600;
            }

            .rud-crm-design-settings select {
                width: 100%;
                min-height: 42px;
            }

            .rud-crm-design-color-grid {
                display: grid;
                grid-template-columns: repeat(2, minmax(220px, 1fr));
                gap: 16px 24px;
                margin-top: 28px;
                padding-top: 24px;
                border-top: 1px solid #ddd;
            }

            .rud-crm-design-color-field {
                display: grid;
                grid-template-columns: 1fr 82px 110px;
                gap: 12px;
                align-items: center;
            }

            .rud-crm-design-color-field input[type="color"] {
                width: 82px;
                height: 42px;
                padding: 3px;
                border: 1px solid #bbb;
                border-radius: 5px;
                cursor: pointer;
                background: #fff;
            }

            .rud-crm-design-color-field input.rud-crm-design-hex {
                width: 110px;
                height: 42px;
                box-sizing: border-box;
                padding: 8px 10px;
                border: 1px solid #bbb;
                border-radius: 5px;
                background: #fff;
                font-family: monospace;
                font-size: 14px;
                text-transform: uppercase;
            }

            .rud-crm-design-actions {
                display: flex;
                flex-wrap: wrap;
                gap: 12px;
                margin-top: 24px;
            }

            .rud-crm-design-save,
            .rud-crm-design-reset {
                min-height: 42px;
                padding: 10px 18px;
                border-radius: 6px;
                cursor: pointer;
            }

            .rud-crm-design-save {
                border: 1px solid #2271b1;
            }

            .rud-crm-design-reset {
                border: 1px solid #999;
            }

            .rud-crm-design-notice {
                padding: 14px 16px;
                margin-bottom: 20px;
                border-radius: 6px;
            }

            .rud-crm-design-notice-success {
                border: 1px solid #b8d8bf;
            }

            .rud-crm-design-preview {
                margin-top: 24px;
                padding: 20px;
                border: 1px solid #ddd;
                border-radius: 8px;
            }

            @media (max-width: 700px) {

                .rud-crm-design-grid {
                    grid-template-columns: 1fr;
                }

                .rud-crm-design-grid-heading {
                    display: none;
                }

                .rud-crm-design-color-grid {
                    grid-template-columns: 1fr;
                }
            }

        </style>


        <?php
        echo wp_kses_post(
            rud_crm_design_status_notice()
        );
        ?>


        <div class="rud-crm-design-card">

            <h2>
                Global CRM Design Settings
            </h2>

            <p>
                These settings apply globally to RUD CRM pages for all WordPress users.
                Only an Administrator can change them.
            </p>


            <form method="post">

                <?php
                wp_nonce_field(
                    'rud_crm_save_design_settings',
                    'rud_crm_design_nonce'
                );
                ?>


                <input
                    type="hidden"
                    name="rud_crm_design_action"
                    value="save"
                >


                <div class="rud-crm-design-grid">

                    <div class="rud-crm-design-label">
                        Font Family
                    </div>

                    <div style="grid-column:span 2;">

                        <select
                            name="font_family"
                        >

                            <?php
                            foreach (
                                $fonts
                                as
                                $value =>
                                $label
                            ) :
                            ?>

                                <option
                                    value="<?php echo esc_attr( $value ); ?>"
                                    <?php
                                    selected(
                                        $settings[
                                            'font_family'
                                        ],
                                        $value
                                    );
                                    ?>
                                >
                                    <?php
                                    echo esc_html(
                                        $label
                                    );
                                    ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <div class="rud-crm-design-grid-heading">
                        Element
                    </div>

                    <div class="rud-crm-design-grid-heading">
                        Font Size
                    </div>

                    <div class="rud-crm-design-grid-heading">
                        Font Weight
                    </div>


                    <div class="rud-crm-design-label">
                        Normal Text
                    </div>

                    <div>
                        <?php
                        rud_crm_design_size_select(
                            'body_size',
                            $settings[
                                'body_size'
                            ]
                        );
                        ?>
                    </div>

                    <div>
                        <?php
                        rud_crm_design_weight_select(
                            'body_weight',
                            $settings[
                                'body_weight'
                            ]
                        );
                        ?>
                    </div>


                    <div class="rud-crm-design-label">
                        Main Heading
                    </div>

                    <div>
                        <?php
                        rud_crm_design_size_select(
                            'main_heading_size',
                            $settings[
                                'main_heading_size'
                            ]
                        );
                        ?>
                    </div>

                    <div>
                        <?php
                        rud_crm_design_weight_select(
                            'main_heading_weight',
                            $settings[
                                'main_heading_weight'
                            ]
                        );
                        ?>
                    </div>


                    <div class="rud-crm-design-label">
                        Section Headings
                    </div>

                    <div>
                        <?php
                        rud_crm_design_size_select(
                            'section_heading_size',
                            $settings[
                                'section_heading_size'
                            ]
                        );
                        ?>
                    </div>

                    <div>
                        <?php
                        rud_crm_design_weight_select(
                            'section_heading_weight',
                            $settings[
                                'section_heading_weight'
                            ]
                        );
                        ?>
                    </div>


                    <div class="rud-crm-design-label">
                        Form Labels
                    </div>

                    <div>
                        <?php
                        rud_crm_design_size_select(
                            'label_size',
                            $settings[
                                'label_size'
                            ]
                        );
                        ?>
                    </div>

                    <div>
                        <?php
                        rud_crm_design_weight_select(
                            'label_weight',
                            $settings[
                                'label_weight'
                            ]
                        );
                        ?>
                    </div>


                    <div class="rud-crm-design-label">
                        Buttons
                    </div>

                    <div>
                        <?php
                        rud_crm_design_size_select(
                            'button_size',
                            $settings[
                                'button_size'
                            ]
                        );
                        ?>
                    </div>

                    <div>
                        <?php
                        rud_crm_design_weight_select(
                            'button_weight',
                            $settings[
                                'button_weight'
                            ]
                        );
                        ?>
                    </div>

                </div>


                <h3 style="margin-top:30px; margin-bottom:8px;">
                    Global Colors
                </h3>

                <p style="margin-top:0;">
                    Choose the global colors used throughout RUD CRM.
                </p>

                <div class="rud-crm-design-color-grid">
                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Normal Text Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="body_color"
                            value="<?php echo esc_attr( $settings['body_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="body_color"
                            name="body_color"
                            value="<?php echo esc_attr( strtoupper( $settings['body_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Main Heading Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="main_heading_color"
                            value="<?php echo esc_attr( $settings['main_heading_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="main_heading_color"
                            name="main_heading_color"
                            value="<?php echo esc_attr( strtoupper( $settings['main_heading_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Section Heading Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="section_heading_color"
                            value="<?php echo esc_attr( $settings['section_heading_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="section_heading_color"
                            name="section_heading_color"
                            value="<?php echo esc_attr( strtoupper( $settings['section_heading_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Form Label Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="label_color"
                            value="<?php echo esc_attr( $settings['label_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="label_color"
                            name="label_color"
                            value="<?php echo esc_attr( strtoupper( $settings['label_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Button Text Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="button_text_color"
                            value="<?php echo esc_attr( $settings['button_text_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="button_text_color"
                            name="button_text_color"
                            value="<?php echo esc_attr( strtoupper( $settings['button_text_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Button Background Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="button_bg_color"
                            value="<?php echo esc_attr( $settings['button_bg_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="button_bg_color"
                            name="button_bg_color"
                            value="<?php echo esc_attr( strtoupper( $settings['button_bg_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Button Hover Background</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="button_hover_color"
                            value="<?php echo esc_attr( $settings['button_hover_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="button_hover_color"
                            name="button_hover_color"
                            value="<?php echo esc_attr( strtoupper( $settings['button_hover_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Border Color</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="border_color"
                            value="<?php echo esc_attr( $settings['border_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="border_color"
                            name="border_color"
                            value="<?php echo esc_attr( strtoupper( $settings['border_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                    <label class="rud-crm-design-color-field">
                        <span class="rud-crm-design-label">Card / Section Background</span>
                        <input
                            type="color"
                            class="rud-crm-design-color-picker"
                            data-target="card_bg_color"
                            value="<?php echo esc_attr( $settings['card_bg_color'] ); ?>"
                        >
                        <input
                            type="text"
                            class="rud-crm-design-hex"
                            id="card_bg_color"
                            name="card_bg_color"
                            value="<?php echo esc_attr( strtoupper( $settings['card_bg_color'] ) ); ?>"
                            maxlength="7"
                            pattern="#[0-9A-Fa-f]{6}"
                            title="Enter a HEX color code, for example #330000"
                            spellcheck="false"
                        >
                    </label>

                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        document.querySelectorAll('.rud-crm-design-color-picker').forEach(function (picker) {
                            var text = document.getElementById(picker.dataset.target);
                            if (!text) { return; }

                            picker.addEventListener('input', function () {
                                text.value = picker.value.toUpperCase();
                            });

                            text.addEventListener('input', function () {
                                var value = text.value.trim();
                                if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
                                    picker.value = value;
                                }
                            });

                            text.addEventListener('blur', function () {
                                text.value = text.value.trim().toUpperCase();
                            });
                        });
                    });
                </script>


                <div class="rud-crm-design-actions">

                    <button
                        type="submit"
                        class="rud-crm-design-save"
                    >
                        SAVE GLOBAL DESIGN
                    </button>

                </div>

            </form>


            <form
                method="post"
                style="margin-top:12px;"
                onsubmit="return confirm('Reset all RUD CRM design settings to defaults?');"
            >

                <?php
                wp_nonce_field(
                    'rud_crm_save_design_settings',
                    'rud_crm_design_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_design_action"
                    value="reset"
                >

                <button
                    type="submit"
                    class="rud-crm-design-reset"
                >
                    RESET TO DEFAULTS
                </button>

            </form>


            <div class="rud-crm-design-preview">

                <h2>
                    Section Heading Preview
                </h2>

                <p>
                    This is normal CRM text.
                </p>

                <p>
                    <label>
                        Form Label Preview
                    </label>
                </p>

                <p>
                    <button type="button">
                        BUTTON PREVIEW
                    </button>
                </p>

            </div>

        </div>

    </div>
    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_design_settings',
    'rud_crm_design_settings_shortcode'
);

/*
 * =========================================================
 * MY ACCOUNT MENU INTEGRATION
 * =========================================================
 *
 * IMPORTANT:
 * This does NOT modify account.php.
 * account.php creates the My Account menu at priority 20.
 * This filter runs afterwards at priority 30 and adds
 * Design Settings for Administrators only.
 *
 * =========================================================
 */

function rud_crm_design_add_account_menu_item(
    $items,
    $args
) {

    if (
        is_admin()
        ||
        ! is_user_logged_in()
        ||
        ! current_user_can(
            'manage_options'
        )
    ) {
        return $items;
    }


    /*
     * Do not add the item twice.
     */

    foreach (
        $items
        as
        $existing_item
    ) {

        if (
            isset(
                $existing_item->ID
            )
            &&
            -900008 ===
            (int) $existing_item->ID
        ) {
            return $items;
        }

        if (
            isset(
                $existing_item->classes
            )
            &&
            is_array(
                $existing_item->classes
            )
            &&
            in_array(
                'rud-crm-menu-design-settings',
                $existing_item->classes,
                true
            )
        ) {
            return $items;
        }
    }


    /*
     * Find the My Account parent created by account.php.
     */

    $parent_id = 0;

    foreach (
        $items
        as
        $existing_item
    ) {

        if (
            isset(
                $existing_item->ID
            )
            &&
            -900001 ===
            (int) $existing_item->ID
        ) {

            $parent_id =
                (int)
                $existing_item->ID;

            break;
        }

        if (
            isset(
                $existing_item->classes
            )
            &&
            is_array(
                $existing_item->classes
            )
            &&
            in_array(
                'rud-crm-my-account-menu',
                $existing_item->classes,
                true
            )
        ) {

            $parent_id =
                (int)
                $existing_item->ID;

            break;
        }
    }


    if (
        0 ===
        $parent_id
    ) {
        return $items;
    }


    /*
     * Resolve the Design Settings page URL.
     */

    $design_page =
        get_page_by_path(
            'design-settings'
        );

    if (
        $design_page
        &&
        'publish' ===
        $design_page->post_status
    ) {

        $design_url =
            get_permalink(
                $design_page->ID
            );

    } else {

        $design_url =
            home_url(
                '/design-settings/'
            );
    }


    /*
     * Build the submenu item using the same structure
     * as the generated items in account.php.
     */

    $item =
        new stdClass();

    $item->ID =
        -900008;

    $item->db_id =
        -900008;

    $item->menu_item_parent =
        $parent_id;

    $item->object_id =
        -900008;

    $item->object =
        'custom';

    $item->type =
        'custom';

    $item->type_label =
        'Custom Link';

    $item->title =
        'Design Settings';

    $item->url =
        $design_url;

    $item->target =
        '';

    $item->attr_title =
        '';

    $item->description =
        '';

    $item->classes =
        array(
            'rud-crm-menu-design-settings'
        );

    $item->xfn =
        '';

    $item->status =
        '';

    $item->current =
        is_page(
            'design-settings'
        );

    $item->current_item_ancestor =
        false;

    $item->current_item_parent =
        false;

    $item->rud_crm_generated =
        true;


    /*
     * Insert directly after Statistics (-900005).
     * If Statistics cannot be found, add it at the end
     * of the My Account children rather than changing
     * the existing account menu.
     */

    $inserted =
        false;

    foreach (
        $items
        as
        $index =>
        $existing_item
    ) {

        if (
            isset(
                $existing_item->ID
            )
            &&
            -900005 ===
            (int) $existing_item->ID
        ) {

            array_splice(
                $items,
                $index + 1,
                0,
                array(
                    $item
                )
            );

            $inserted =
                true;

            break;
        }
    }


    if (
        ! $inserted
    ) {

        $items[] =
            $item;
    }


    return $items;
}


add_filter(
    'wp_nav_menu_objects',
    'rud_crm_design_add_account_menu_item',
    30,
    2
);


/*
 * =========================================================
 * FINAL MY ACCOUNT MENU FALLBACK
 * =========================================================
 *
 * The My Account menu is generated dynamically by account.php.
 * On some Astra/menu render paths those generated items are not
 * available to this module during wp_nav_menu_objects.
 *
 * This final-output fallback inserts Design Settings only after
 * the complete menu HTML already exists. It does not modify
 * account.php, Astra settings, or any existing menu item.
 *
 * Administrator only.
 * =========================================================
 */

function rud_crm_design_add_account_menu_final_html(
    $nav_menu,
    $args
) {

    if (
        is_admin()
        ||
        ! is_user_logged_in()
        ||
        ! current_user_can(
            'manage_options'
        )
    ) {
        return $nav_menu;
    }


    /*
     * Do nothing if Design Settings is already present.
     */

    if (
        false !== strpos(
            $nav_menu,
            'rud-crm-menu-design-settings'
        )
        ||
        false !== strpos(
            $nav_menu,
            '>Design Settings<'
        )
    ) {
        return $nav_menu;
    }


    /*
     * Only act on the dynamically generated My Account menu.
     */

    if (
        false === strpos(
            $nav_menu,
            'rud-crm-my-account-menu'
        )
        ||
        false === strpos(
            $nav_menu,
            'rud-crm-menu-statistics'
        )
    ) {
        return $nav_menu;
    }


    $design_page =
        get_page_by_path(
            'design-settings'
        );

    if (
        $design_page
        &&
        'publish' ===
        $design_page->post_status
    ) {

        $design_url =
            get_permalink(
                $design_page->ID
            );

    } else {

        $design_url =
            home_url(
                '/design-settings/'
            );
    }


    $design_item =
        '<li class="menu-item rud-crm-menu-design-settings">' .
        '<a class="menu-link" href="' .
        esc_url(
            $design_url
        ) .
        '">Design Settings</a>' .
        '</li>';


    /*
     * Insert directly before Upgrade to Full Version.
     * That places it immediately after Statistics in the
     * existing My Account submenu.
     */

    $pattern =
        '/(<li\\b[^>]*class="[^"]*rud-crm-menu-upgrade[^"]*"[^>]*>)/i';

    if (
        preg_match(
            $pattern,
            $nav_menu
        )
    ) {

        $nav_menu =
            preg_replace(
                $pattern,
                $design_item . '$1',
                $nav_menu,
                1
            );
    }


    return $nav_menu;
}


add_filter(
    'wp_nav_menu',
    'rud_crm_design_add_account_menu_final_html',
    999,
    2
);
