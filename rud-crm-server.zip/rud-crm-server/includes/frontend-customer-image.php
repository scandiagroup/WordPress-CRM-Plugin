<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END CUSTOMER PROFILE IMAGE / COMPANY LOGO
 * Version 1.0
 * =========================================================
 *
 * PERSON:
 * - One JPG/JPEG/PNG profile image
 * - Stored as WordPress attachment
 * - Cropped to 100 x 100 px
 * - Displayed as circular profile image
 *
 * COMPANY / ORGANIZATION:
 * - One JPG/JPEG/PNG logo
 * - Stored as WordPress attachment
 * - Resized proportionally
 * - Maximum 100 px high
 * - Maximum 600 px wide
 * - Never stretched
 * - Never cropped
 *
 * EXISTING IMAGE:
 * - Replaced when a new image/logo is uploaded
 * - Can be removed by the customer owner/admin
 *
 * SHARED DEMO CUSTOMERS:
 * - Read only
 *
 * =========================================================
 */


/*
 * =========================================================
 * IMAGE TABLE
 * =========================================================
 */

function rud_crm_frontend_customer_image_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_customer_images';
}


/*
 * =========================================================
 * EDIT PERMISSION
 * =========================================================
 */

function rud_crm_frontend_customer_image_can_edit(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
        ||
        ! is_user_logged_in()
    ) {

        return false;
    }


    if (
        function_exists(
            'rud_crm_frontend_can_edit_customer'
        )
    ) {

        return (bool)
            rud_crm_frontend_can_edit_customer(
                $customer_id
            );
    }


    return false;
}


/*
 * =========================================================
 * GET CUSTOMER TYPE
 * =========================================================
 */

function rud_crm_frontend_customer_image_type(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return 'person';
    }


    $customer_type =
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT customer_type
                 FROM {$wpdb->prefix}rudcrm_customers
                 WHERE id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    return
        'company' ===
        $customer_type
        ? 'company'
        : 'person';
}


/*
 * =========================================================
 * GET CURRENT ATTACHMENT
 * =========================================================
 */

function rud_crm_frontend_customer_image_attachment_id(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return 0;
    }


    return
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT attachment_id
                     FROM " .
                     rud_crm_frontend_customer_image_table() .
                     "
                     WHERE customer_id = %d
                     ORDER BY is_primary DESC,
                              sort_order ASC,
                              id ASC
                     LIMIT 1",
                    $customer_id
                )
            )
        );
}


/*
 * =========================================================
 * GET CURRENT IMAGE URL
 * =========================================================
 */


function rud_crm_frontend_customer_images(
    $customer_id
) {

    global $wpdb;

    return
        $wpdb->get_results(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                 rud_crm_frontend_customer_image_table() .
                 "
                 WHERE customer_id = %d
                 ORDER BY is_primary DESC,
                          sort_order ASC,
                          id ASC",
                absint(
                    $customer_id
                )
            )
        );
}


function rud_crm_frontend_customer_image_count(
    $customer_id
) {

    global $wpdb;

    return
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*)
                     FROM " .
                     rud_crm_frontend_customer_image_table() .
                     "
                     WHERE customer_id = %d",
                    absint(
                        $customer_id
                    )
                )
            )
        );
}


function rud_crm_frontend_customer_image_normalize_files(
    $files
) {

    if (
        empty(
            $files
        )
        ||
        ! is_array(
            $files
        )
        ||
        ! isset(
            $files['name']
        )
    ) {
        return array();
    }

    if (
        ! is_array(
            $files['name']
        )
    ) {
        return array(
            $files
        );
    }

    $normalized =
        array();

    foreach (
        $files['name']
        as
        $index =>
        $name
    ) {

        if (
            empty(
                $name
            )
        ) {
            continue;
        }

        $normalized[] =
            array(
                'name' =>
                    $name,

                'type' =>
                    $files['type'][ $index ]
                    ?? '',

                'tmp_name' =>
                    $files['tmp_name'][ $index ]
                    ?? '',

                'error' =>
                    $files['error'][ $index ]
                    ?? UPLOAD_ERR_NO_FILE,

                'size' =>
                    $files['size'][ $index ]
                    ?? 0
            );
    }

    return $normalized;
}


function rud_crm_frontend_customer_image_url(
    $customer_id,
    $size = 'full'
) {

    $attachment_id =
        rud_crm_frontend_customer_image_attachment_id(
            $customer_id
        );


    if (
        ! $attachment_id
    ) {

        return '';
    }


    $url =
        wp_get_attachment_image_url(
            $attachment_id,
            $size
        );


    return
        $url
        ? $url
        : '';
}


/*
 * =========================================================
 * ALLOWED MIME TYPES
 * =========================================================
 */

function rud_crm_frontend_customer_image_allowed_mimes() {

    return array(
        'image/jpeg',
        'image/png'
    );
}


/*
 * =========================================================
 * DELETE OLD ATTACHMENT + DB ROW
 * =========================================================
 */

function rud_crm_frontend_customer_image_delete_current(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    $attachment_id =
        rud_crm_frontend_customer_image_attachment_id(
            $customer_id
        );


    $wpdb->delete(
        rud_crm_frontend_customer_image_table(),
        array(
            'customer_id' =>
                $customer_id
        ),
        array(
            '%d'
        )
    );


    if (
        $attachment_id
    ) {

        wp_delete_attachment(
            $attachment_id,
            true
        );
    }


    return true;
}


/*
 * =========================================================
 * CREATE RESIZED IMAGE FILE
 * =========================================================
 */

function rud_crm_frontend_customer_image_resize(
    $file_path,
    $customer_type
) {

    $editor =
        wp_get_image_editor(
            $file_path
        );

    if (
        is_wp_error(
            $editor
        )
    ) {
        return $editor;
    }

    $size =
        $editor->get_size();

    $width =
        absint(
            $size['width'] ?? 0
        );

    $height =
        absint(
            $size['height'] ?? 0
        );

    if (
        ! $width
        ||
        ! $height
    ) {
        return new WP_Error(
            'rud_crm_invalid_image_dimensions',
            'The uploaded image has invalid dimensions.'
        );
    }

    if (
        'company' ===
        $customer_type
    ) {

        $ratio =
            min(
                600 / $width,
                100 / $height,
                1
            );

    } else {

        /*
         * Private person:
         * preserve natural proportions,
         * but never store larger than 1200 x 1200.
         */

        $ratio =
            min(
                1200 / $width,
                1200 / $height,
                1
            );
    }

    if (
        $ratio < 1
    ) {

        $new_width =
            max(
                1,
                (int)
                round(
                    $width *
                    $ratio
                )
            );

        $new_height =
            max(
                1,
                (int)
                round(
                    $height *
                    $ratio
                )
            );

        $resized =
            $editor->resize(
                $new_width,
                $new_height,
                false
            );

        if (
            is_wp_error(
                $resized
            )
        ) {
            return $resized;
        }
    }

    if (
        method_exists(
            $editor,
            'set_quality'
        )
    ) {
        $editor->set_quality(
            82
        );
    }

    return
        $editor->save(
            $file_path
        );
}



/*
 * =========================================================
 * PROCESS UPLOAD
 * =========================================================
 */

function rud_crm_frontend_customer_image_upload(
    $customer_id,
    $file,
    $force_primary = false
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {
        return new WP_Error(
            'rud_crm_image_permission',
            'You do not have permission to change this customer image.'
        );
    }

    $customer_type =
        rud_crm_frontend_customer_image_type(
            $customer_id
        );

    $current_count =
        rud_crm_frontend_customer_image_count(
            $customer_id
        );

    $limit =
        'company' ===
        $customer_type
        ? 1
        : 11;

    if (
        $current_count >=
        $limit
    ) {
        return new WP_Error(
            'rud_crm_image_limit',
            'The maximum number of images has already been reached.'
        );
    }

    if (
        empty(
            $file['tmp_name']
        )
        ||
        ! is_uploaded_file(
            $file['tmp_name']
        )
    ) {
        return new WP_Error(
            'rud_crm_image_missing',
            'No image was uploaded.'
        );
    }

    if (
        ! empty(
            $file['size']
        )
        &&
        (int)
        $file['size'] >
        8 * MB_IN_BYTES
    ) {
        return new WP_Error(
            'rud_crm_image_too_large',
            'The image is too large. Maximum upload size is 20 MB.'
        );
    }

    $allowed_upload_mimes =
        'company' === $customer_type
        ? array(
            'jpg|jpeg' => 'image/jpeg',
            'png'      => 'image/png'
        )
        : array(
            'jpg|jpeg' => 'image/jpeg'
        );

    $allowed_mime_types =
        array_values(
            $allowed_upload_mimes
        );

    $file_check =
        wp_check_filetype_and_ext(
            $file['tmp_name'],
            $file['name'],
            $allowed_upload_mimes
        );

    $mime =
        $file_check['type'] ?? '';

    if (
        ! in_array(
            $mime,
            $allowed_mime_types,
            true
        )
    ) {
        return new WP_Error(
            'rud_crm_image_type',
            'company' === $customer_type
            ? 'Only JPG, JPEG and PNG logo files are allowed.'
            : 'Private customer images must be JPG or JPEG.'
        );
    }

    require_once
        ABSPATH .
        'wp-admin/includes/file.php';

    require_once
        ABSPATH .
        'wp-admin/includes/image.php';

    require_once
        ABSPATH .
        'wp-admin/includes/media.php';

    $uploaded =
        wp_handle_upload(
            $file,
            array(
                'test_form' =>
                    false,

                'mimes' =>
                    $allowed_upload_mimes
            )
        );

    if (
        isset(
            $uploaded['error']
        )
    ) {
        return new WP_Error(
            'rud_crm_image_upload_error',
            $uploaded['error']
        );
    }

    $file_path =
        $uploaded['file'];

    $resized =
        rud_crm_frontend_customer_image_resize(
            $file_path,
            $customer_type
        );

    if (
        is_wp_error(
            $resized
        )
    ) {

        @unlink(
            $file_path
        );

        return $resized;
    }

    $attachment_id =
        wp_insert_attachment(
            array(
                'post_mime_type' =>
                    $mime,

                'post_title' =>
                    'RUD CRM ' .
                    (
                        'company' ===
                        $customer_type
                        ? 'Company Logo'
                        : 'Customer Image'
                    )
                    .
                    ' - Customer ' .
                    $customer_id,

                'post_content' =>
                    '',

                'post_status' =>
                    'inherit'
            ),
            $file_path
        );

    if (
        is_wp_error(
            $attachment_id
        )
        ||
        ! $attachment_id
    ) {

        @unlink(
            $file_path
        );

        return new WP_Error(
            'rud_crm_attachment_error',
            'The image could not be added to the WordPress media library.'
        );
    }

    $metadata =
        wp_generate_attachment_metadata(
            $attachment_id,
            $file_path
        );

    if (
        is_array(
            $metadata
        )
    ) {
        wp_update_attachment_metadata(
            $attachment_id,
            $metadata
        );
    }

    $is_primary =
        (
            $force_primary
            ||
            0 ===
            $current_count
        )
        ? 1
        : 0;

    if (
        $is_primary
    ) {

        $wpdb->update(
            rud_crm_frontend_customer_image_table(),
            array(
                'is_primary' =>
                    0
            ),
            array(
                'customer_id' =>
                    $customer_id
            )
        );
    }

    $now =
        current_time(
            'mysql'
        );

    $inserted =
        $wpdb->insert(
            rud_crm_frontend_customer_image_table(),
            array(
                'customer_id' =>
                    $customer_id,

                'attachment_id' =>
                    $attachment_id,

                'image_type' =>
                    'company' ===
                    $customer_type
                    ? 'logo'
                    : 'gallery',

                'is_primary' =>
                    $is_primary,

                'sort_order' =>
                    $current_count +
                    1,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            )
        );

    if (
        false ===
        $inserted
    ) {

        wp_delete_attachment(
            $attachment_id,
            true
        );

        return new WP_Error(
            'rud_crm_image_database_error',
            'The image could not be saved to the CRM.'
        );
    }

    return $attachment_id;
}



/*
 * =========================================================
 * IMAGE MANAGER RETURN URL
 * =========================================================
 */


function rud_crm_frontend_customer_image_upload_multiple(
    $customer_id,
    $files
) {

    $normalized =
        rud_crm_frontend_customer_image_normalize_files(
            $files
        );

    $remaining =
        max(
            0,
            11 -
            rud_crm_frontend_customer_image_count(
                $customer_id
            )
        );

    $normalized =
        array_slice(
            $normalized,
            0,
            $remaining
        );

    $results =
        array();

    foreach (
        $normalized
        as
        $file
    ) {

        $results[] =
            rud_crm_frontend_customer_image_upload(
                $customer_id,
                $file,
                false
            );
    }

    return $results;
}


function rud_crm_frontend_customer_image_set_primary(
    $customer_id,
    $attachment_id
) {

    global $wpdb;

    $customer_id =
        absint(
            $customer_id
        );

    $attachment_id =
        absint(
            $attachment_id
        );

    if (
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {
        return false;
    }

    $exists =
        absint(
            $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*)
                     FROM " .
                     rud_crm_frontend_customer_image_table() .
                     "
                     WHERE customer_id = %d
                     AND attachment_id = %d",
                    $customer_id,
                    $attachment_id
                )
            )
        );

    if (
        ! $exists
    ) {
        return false;
    }

    $wpdb->update(
        rud_crm_frontend_customer_image_table(),
        array(
            'is_primary' =>
                0
        ),
        array(
            'customer_id' =>
                $customer_id
        )
    );

    return
        false !==
        $wpdb->update(
            rud_crm_frontend_customer_image_table(),
            array(
                'is_primary' =>
                    1
            ),
            array(
                'customer_id' =>
                    $customer_id,

                'attachment_id' =>
                    $attachment_id
            )
        );
}


function rud_crm_frontend_customer_image_delete_one(
    $customer_id,
    $attachment_id
) {

    global $wpdb;

    $row =
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                 rud_crm_frontend_customer_image_table() .
                 "
                 WHERE customer_id = %d
                 AND attachment_id = %d
                 LIMIT 1",
                absint(
                    $customer_id
                ),
                absint(
                    $attachment_id
                )
            )
        );

    if (
        ! $row
        ||
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {
        return false;
    }

    $was_primary =
        ! empty(
            $row->is_primary
        );

    $wpdb->delete(
        rud_crm_frontend_customer_image_table(),
        array(
            'customer_id' =>
                absint(
                    $customer_id
                ),

            'attachment_id' =>
                absint(
                    $attachment_id
                )
        )
    );

    wp_delete_attachment(
        absint(
            $attachment_id
        ),
        true
    );

    if (
        $was_primary
    ) {

        $next =
            absint(
                $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT attachment_id
                         FROM " .
                         rud_crm_frontend_customer_image_table() .
                         "
                         WHERE customer_id = %d
                         ORDER BY sort_order ASC,
                                  id ASC
                         LIMIT 1",
                        absint(
                            $customer_id
                        )
                    )
                )
            );

        if (
            $next
        ) {

            rud_crm_frontend_customer_image_set_primary(
                $customer_id,
                $next
            );
        }
    }

    return true;
}


function rud_crm_frontend_customer_image_return_url(
    $customer_id
) {

    if (
        function_exists(
            'rud_crm_frontend_edit_customer_url'
        )
    ) {

        return
            rud_crm_frontend_edit_customer_url(
                $customer_id
            );
    }


    if (
        function_exists(
            'rud_crm_frontend_edit_profile_url'
        )
    ) {

        return
            rud_crm_frontend_edit_profile_url(
                $customer_id
            );
    }


    return
        add_query_arg(
            'rud_customer_id',
            absint(
                $customer_id
            ),
            home_url(
                '/customer-crm/'
            )
        );
}


/*
 * =========================================================
 * PROCESS FRONT-END IMAGE ACTIONS
 * =========================================================
 */

function rud_crm_frontend_customer_image_process_actions() {

    if (
        ! is_user_logged_in()
        ||
        empty(
            $_POST['rud_crm_customer_image_action']
        )
    ) {
        return;
    }

    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_customer_image_action']
            )
        );

    $customer_id =
        absint(
            $_POST['rud_customer_id']
            ?? 0
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'You do not have permission to change these customer images.',
                'rud-crm-server'
            )
        );
    }

    if (
        empty(
            $_POST['rud_crm_customer_image_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_customer_image_nonce']
                )
            ),
            'rud_crm_customer_image_' .
            $customer_id
        )
    ) {
        wp_die(
            esc_html__(
                'Security verification failed.',
                'rud-crm-server'
            )
        );
    }

    $customer_type =
        rud_crm_frontend_customer_image_type(
            $customer_id
        );

    $status =
        'updated';

    $message =
        '';

    if (
        'upload' ===
        $action
    ) {

        if (
            'company' ===
            $customer_type
        ) {

            /*
             * Company remains one logo only.
             * Remove the old logo before saving the replacement.
             */

            rud_crm_frontend_customer_image_delete_current(
                $customer_id
            );

            $result =
                rud_crm_frontend_customer_image_upload(
                    $customer_id,
                    $_FILES['rud_crm_customer_image_file']
                    ?? array(),
                    true
                );

            if (
                is_wp_error(
                    $result
                )
            ) {
                $status =
                    'error';

                $message =
                    $result->get_error_message();
            }

        } else {

            $results =
                rud_crm_frontend_customer_image_upload_multiple(
                    $customer_id,
                    $_FILES['rud_crm_customer_image_files']
                    ?? array()
                );

            foreach (
                $results
                as
                $result
            ) {

                if (
                    is_wp_error(
                        $result
                    )
                ) {

                    $status =
                        'error';

                    $message =
                        $result->get_error_message();

                    break;
                }
            }
        }
    }

    if (
        'set_primary' ===
        $action
    ) {

        $ok =
            rud_crm_frontend_customer_image_set_primary(
                $customer_id,
                absint(
                    $_POST['rud_crm_attachment_id']
                    ?? 0
                )
            );

        $status =
            $ok
            ? 'primary'
            : 'error';

        if (
            ! $ok
        ) {
            $message =
                'The primary image could not be changed.';
        }
    }

    if (
        'remove_one' ===
        $action
    ) {

        $ok =
            rud_crm_frontend_customer_image_delete_one(
                $customer_id,
                absint(
                    $_POST['rud_crm_attachment_id']
                    ?? 0
                )
            );

        $status =
            $ok
            ? 'removed'
            : 'error';

        if (
            ! $ok
        ) {
            $message =
                'The image could not be removed.';
        }
    }

    $args =
        array(
            'rud_customer_id' =>
                $customer_id,

            'rud_crm_image' =>
                $status
        );

    if (
        $message
    ) {

        $args['rud_crm_image_message'] =
            rawurlencode(
                $message
            );
    }

    wp_safe_redirect(
        add_query_arg(
            $args,
            rud_crm_frontend_customer_image_return_url(
                $customer_id
            )
        )
    );

    exit;
}



add_action(
    'template_redirect',
    'rud_crm_frontend_customer_image_process_actions',
    28
);


/*
 * =========================================================
 * IMAGE UPLOAD FORM
 * =========================================================
 */

function rud_crm_frontend_customer_image_form(
    $customer_id
) {

    $customer_id =
        absint(
            $customer_id
        );

    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {
        return '';
    }

    $customer_type =
        rud_crm_frontend_customer_image_type(
            $customer_id
        );

    $is_company =
        'company' ===
        $customer_type;

    $images =
        rud_crm_frontend_customer_images(
            $customer_id
        );

    $count =
        count(
            $images
        );

    $remaining =
        $is_company
        ? max(
            0,
            1 - $count
        )
        : max(
            0,
            11 - $count
        );

    ob_start();

    ?>

    <section class="rud-crm-image-manager">

        <h3>
            <?php
            echo esc_html(
                $is_company
                ? 'Company Logo'
                : 'Customer Images'
            );
            ?>
        </h3>

        <?php if ( $is_company ) : ?>

            <p>
                One JPG or PNG logo. The stored logo keeps its proportions
                and is reduced to a maximum of 600 px wide and 100 px high.
            </p>

        <?php else : ?>

            <p>
                Maximum 11 JPG or JPEG images. Large images are reduced
                automatically to a maximum of 1200 × 1200 px.
                Choose any image as the Primary profile image.
            </p>

        <?php endif; ?>


        <?php if ( ! empty( $images ) ) : ?>

            <div class="rud-crm-image-manager-grid">

                <?php foreach ( $images as $image ) : ?>

                    <?php

                    $url =
                        wp_get_attachment_image_url(
                            $image->attachment_id,
                            'medium'
                        );

                    if ( ! $url ) {
                        continue;
                    }

                    ?>

                    <div class="rud-crm-image-manager-item">

                        <div class="rud-crm-image-manager-preview">

                            <img
                                src="<?php echo esc_url( $url ); ?>"
                                alt=""
                            >

                            <?php if ( ! empty( $image->is_primary ) ) : ?>

                                <span class="rud-crm-primary-badge">
                                    PRIMARY
                                </span>

                            <?php endif; ?>

                        </div>

                        <?php if ( ! $is_company && empty( $image->is_primary ) ) : ?>

                            <form method="post">

                                <?php

                                wp_nonce_field(
                                    'rud_crm_customer_image_' .
                                    $customer_id,
                                    'rud_crm_customer_image_nonce'
                                );

                                ?>

                                <input type="hidden" name="rud_customer_id" value="<?php echo esc_attr( $customer_id ); ?>">
                                <input type="hidden" name="rud_crm_attachment_id" value="<?php echo esc_attr( $image->attachment_id ); ?>">
                                <input type="hidden" name="rud_crm_customer_image_action" value="set_primary">

                                <button
                                    type="submit"
                                    class="rud-crm-set-primary-button"
                                >
                                    SET AS PRIMARY
                                </button>

                            </form>

                        <?php endif; ?>

                        <form
                            method="post"
                            onsubmit="return confirm('Remove this image?');"
                        >

                            <?php

                            wp_nonce_field(
                                'rud_crm_customer_image_' .
                                $customer_id,
                                'rud_crm_customer_image_nonce'
                            );

                            ?>

                            <input type="hidden" name="rud_customer_id" value="<?php echo esc_attr( $customer_id ); ?>">
                            <input type="hidden" name="rud_crm_attachment_id" value="<?php echo esc_attr( $image->attachment_id ); ?>">
                            <input type="hidden" name="rud_crm_customer_image_action" value="remove_one">

                            <button
                                type="submit"
                                class="rud-crm-image-remove-button"
                            >
                                REMOVE
                            </button>

                        </form>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ( $is_company || $remaining > 0 ) : ?>

            <form
                method="post"
                enctype="multipart/form-data"
                class="rud-crm-image-upload-form"
            >

                <?php

                wp_nonce_field(
                    'rud_crm_customer_image_' .
                    $customer_id,
                    'rud_crm_customer_image_nonce'
                );

                ?>

                <input type="hidden" name="rud_customer_id" value="<?php echo esc_attr( $customer_id ); ?>">
                <input type="hidden" name="rud_crm_customer_image_action" value="upload">

                <?php if ( $is_company ) : ?>

                    <label>
                        <?php echo $count ? 'Replace Company Logo' : 'Upload Company Logo'; ?>
                    </label>

                    <div class="rud-crm-dropzone" data-rud-dropzone>

                        <input
                            type="file"
                            name="rud_crm_customer_image_file"
                            accept=".jpg,.jpeg,.png,image/jpeg,image/png"
                            data-rud-drop-input
                            required
                        >

                        <div class="rud-crm-dropzone-icon" aria-hidden="true">+</div>

                        <strong>Drag & Drop Company Logo Here</strong>

                        <span>or click to browse — JPG, JPEG or PNG</span>

                        <div class="rud-crm-dropzone-selection" data-rud-drop-selection></div>

                    </div>

                <?php else : ?>

                    <label>
                        Add Images (<?php echo esc_html( $remaining ); ?> remaining)
                    </label>

                    <div class="rud-crm-dropzone" data-rud-dropzone>

                        <input
                            type="file"
                            name="rud_crm_customer_image_files[]"
                            accept=".jpg,.jpeg,image/jpeg"
                            data-rud-drop-input
                            multiple
                            required
                        >

                        <div class="rud-crm-dropzone-icon" aria-hidden="true">+</div>

                        <strong>Drag & Drop Images Here</strong>

                        <span>or click to browse — JPG/JPEG only</span>

                        <small>
                            Up to <?php echo esc_html( $remaining ); ?> more image(s)
                        </small>

                        <div class="rud-crm-dropzone-selection" data-rud-drop-selection></div>

                    </div>

                <?php endif; ?>

                <button
                    type="submit"
                    class="rud-crm-button rud-crm-button-primary"
                >
                    UPLOAD
                </button>

            </form>

        <?php endif; ?>

    </section>

    <?php

    return ob_get_clean();
}



/*
 * =========================================================
 * PROFILE HEADER MEDIA HTML
 * =========================================================
 *
 * Used by frontend.php in the next integration step.
 *
 * =========================================================
 */

function rud_crm_frontend_customer_header_media_html(
    $customer_id,
    $name = ''
) {

    $customer_id =
        absint(
            $customer_id
        );


    $customer_type =
        rud_crm_frontend_customer_image_type(
            $customer_id
        );


    $image_url =
        rud_crm_frontend_customer_image_url(
            $customer_id,
            'full'
        );


    $is_company =
        'company' ===
        $customer_type;


    ob_start();

    ?>


    <div
        class="<?php
        echo esc_attr(
            $is_company
            ? 'rud-crm-header-logo'
            : 'rud-crm-header-person-image'
        );
        ?>"
    >


        <?php if ( $image_url ) : ?>


            <img
                src="<?php
                echo esc_url(
                    $image_url
                );
                ?>"
                alt="<?php
                echo esc_attr(
                    $name
                );
                ?>"
            >


        <?php else : ?>


            <div
                class="<?php
                echo esc_attr(
                    $is_company
                    ? 'rud-crm-header-logo-placeholder'
                    : 'rud-crm-header-person-placeholder'
                );
                ?>"
            >

                <?php

                echo esc_html(
                    strtoupper(
                        substr(
                            trim(
                                (string)
                                $name
                            ),
                            0,
                            1
                        )
                    )
                );

                ?>

            </div>


        <?php endif; ?>


    </div>


    <?php

    return ob_get_clean();
}


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */


function rud_crm_frontend_customer_gallery_html(
    $customer_id
) {

    if (
        'person' !==
        rud_crm_frontend_customer_image_type(
            $customer_id
        )
    ) {
        return '';
    }

    $images =
        rud_crm_frontend_customer_images(
            $customer_id
        );

    if (
        empty(
            $images
        )
    ) {
        return '';
    }

    ob_start();

    ?>

    <section class="rud-crm-panel rud-crm-full-panel">

        <h2>
            Customer Images
        </h2>

        <div class="rud-crm-person-profile-gallery">

            <?php foreach ( $images as $image ) : ?>

                <?php

                $url =
                    wp_get_attachment_image_url(
                        $image->attachment_id,
                        'medium'
                    );

                if ( ! $url ) {
                    continue;
                }

                ?>

                <figure
                    class="<?php
                    echo esc_attr(
                        ! empty( $image->is_primary )
                        ? 'rud-crm-person-profile-image is-primary'
                        : 'rud-crm-person-profile-image'
                    );
                    ?>"
                >

                    <?php

                    $full_url =
                        wp_get_attachment_image_url(
                            $image->attachment_id,
                            'full'
                        );

                    ?>

                    <button
                        type="button"
                        class="rud-crm-gallery-lightbox-button"
                        data-rud-lightbox-image="<?php echo esc_url( $full_url ?: $url ); ?>"
                        aria-label="Open larger image"
                    >

                        <img
                            src="<?php echo esc_url( $url ); ?>"
                            alt=""
                        >

                    </button>

                    <?php if ( ! empty( $image->is_primary ) ) : ?>

                        <figcaption>
                            Primary Profile Image
                        </figcaption>

                    <?php endif; ?>

                </figure>

            <?php endforeach; ?>

        </div>


        <div
            class="rud-crm-lightbox"
            data-rud-lightbox
            hidden
            aria-hidden="true"
        >

            <div
                class="rud-crm-lightbox-backdrop"
                data-rud-lightbox-close
            ></div>

            <div
                class="rud-crm-lightbox-dialog"
                role="dialog"
                aria-modal="true"
                aria-label="Customer image preview"
            >

                <button
                    type="button"
                    class="rud-crm-lightbox-close"
                    data-rud-lightbox-close
                    aria-label="Close image preview"
                >×</button>

                <button
                    type="button"
                    class="rud-crm-lightbox-nav rud-crm-lightbox-prev"
                    data-rud-lightbox-prev
                    aria-label="Previous image"
                >‹</button>

                <div class="rud-crm-lightbox-stage">
                    <img src="" alt="" data-rud-lightbox-view>
                </div>

                <button
                    type="button"
                    class="rud-crm-lightbox-nav rud-crm-lightbox-next"
                    data-rud-lightbox-next
                    aria-label="Next image"
                >›</button>

                <div
                    class="rud-crm-lightbox-counter"
                    data-rud-lightbox-counter
                ></div>

            </div>

        </div>

    </section>

    <?php

    return ob_get_clean();
}


function rud_crm_frontend_customer_image_message_html() {

    $status =
        isset(
            $_GET['rud_crm_image']
        )
        ? sanitize_key(
            wp_unslash(
                $_GET['rud_crm_image']
            )
        )
        : '';


    if (
        'updated' ===
        $status
    ) {

        return
            '<div class="rud-crm-image-message rud-crm-image-success">' .
            '<strong>Images Updated</strong>' .
            '<span>The customer images have been saved successfully.</span>' .
            '</div>';
    }


    if (
        'primary' ===
        $status
    ) {

        return
            '<div class="rud-crm-image-message rud-crm-image-success">' .
            '<strong>Primary Image Updated</strong>' .
            '<span>The selected image is now used as the profile image.</span>' .
            '</div>';
    }


    if (
        'removed' ===
        $status
    ) {

        return
            '<div class="rud-crm-image-message rud-crm-image-success">' .
            '<strong>Image Removed</strong>' .
            '<span>The customer image has been removed.</span>' .
            '</div>';
    }


    if (
        'error' ===
        $status
    ) {

        $message =
            isset(
                $_GET['rud_crm_image_message']
            )
            ? sanitize_text_field(
                rawurldecode(
                    wp_unslash(
                        $_GET['rud_crm_image_message']
                    )
                )
            )
            : 'The image could not be processed.';


        return
            '<div class="rud-crm-image-message rud-crm-image-error">' .
            '<strong>Image Error</strong>' .
            '<span>' .
            esc_html(
                $message
            ) .
            '</span>' .
            '</div>';
    }


    return '';
}


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_frontend_customer_image_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '


    .rud-crm-dropzone {
        position:relative;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        min-height:150px;
        padding:24px;
        border:1.5px dashed #98a2b3;
        border-radius:14px;
        background:linear-gradient(180deg,#fff 0%,#f8fafc 100%);
        text-align:center;
        cursor:pointer;
        transition:border-color .18s ease,background .18s ease,box-shadow .18s ease,transform .18s ease;
    }

    .rud-crm-dropzone:hover,
    .rud-crm-dropzone.is-dragover {
        border-color:#475467;
        background:#fff;
        box-shadow:0 8px 24px rgba(16,24,40,.08);
        transform:translateY(-1px);
    }

    .rud-crm-dropzone input[type="file"] {
        position:absolute !important;
        inset:0;
        width:100% !important;
        height:100%;
        opacity:0;
        cursor:pointer;
        z-index:3;
    }

    .rud-crm-dropzone-icon {
        display:flex;
        align-items:center;
        justify-content:center;
        width:42px;
        height:42px;
        margin-bottom:10px;
        border:1px solid #d0d5dd;
        border-radius:50%;
        background:#fff;
        color:#344054;
        font-size:26px;
        line-height:1;
        box-shadow:0 2px 6px rgba(16,24,40,.06);
    }

    .rud-crm-dropzone strong {
        margin-bottom:4px;
        color:#101828;
        font-size:15px;
    }

    .rud-crm-dropzone span,
    .rud-crm-dropzone small {
        color:#667085;
    }

    .rud-crm-dropzone small {
        margin-top:5px;
        font-size:12px;
    }

    .rud-crm-dropzone-selection {
        margin-top:12px;
        color:#344054;
        font-size:12px;
        font-weight:700;
    }

    .rud-crm-gallery-lightbox-button {
        display:block;
        width:100%;
        padding:0;
        border:0;
        background:transparent;
        cursor:zoom-in;
    }

    .rud-crm-gallery-lightbox-button img {
        transition:transform .2s ease,box-shadow .2s ease;
    }

    .rud-crm-gallery-lightbox-button:hover img {
        transform:scale(1.015);
        box-shadow:0 8px 22px rgba(16,24,40,.10);
    }

    .rud-crm-lightbox[hidden] {
        display:none !important;
    }

    .rud-crm-lightbox {
        position:fixed;
        inset:0;
        z-index:999999;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:30px;
    }

    .rud-crm-lightbox-backdrop {
        position:absolute;
        inset:0;
        background:rgba(10,15,24,.84);
        backdrop-filter:blur(7px);
        -webkit-backdrop-filter:blur(7px);
    }

    .rud-crm-lightbox-dialog {
        position:relative;
        z-index:2;
        display:flex;
        align-items:center;
        justify-content:center;
        width:min(1100px,94vw);
        height:min(820px,90vh);
    }

    .rud-crm-lightbox-stage {
        display:flex;
        align-items:center;
        justify-content:center;
        width:100%;
        height:100%;
        padding:36px 64px 52px;
    }

    .rud-crm-lightbox-stage img {
        display:block;
        width:auto;
        height:auto;
        max-width:100%;
        max-height:100%;
        object-fit:contain;
        border:2px solid rgba(255,255,255,.95);
        border-radius:10px;
        box-shadow:0 24px 80px rgba(0,0,0,.42);
        background:#fff;
    }

    .rud-crm-lightbox-close {
        position:absolute;
        top:0;
        right:auto;
        z-index:4;
        width:36px;
        height:36px;
        border:1px solid rgba(255,255,255,.50);
        border-radius:50%;
        background:rgba(12,18,28,.78);
        color:#fff;
        font-size:24px;
        font-weight:400;
        line-height:1;
        cursor:pointer;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:0 0 2px;
        box-sizing:border-box;
    }

    .rud-crm-lightbox-nav {
        position:absolute;
        top:50%;
        z-index:4;
        width:38px;
        height:50px;
        margin-top:-25px;
        border:1px solid rgba(255,255,255,.24);
        border-radius:10px;
        background:rgba(255,255,255,.09);
        color:#fff;
        font-size:30px;
        line-height:1;
        cursor:pointer;
        display:flex;
        align-items:center;
        justify-content:center;
        padding:0 0 3px;
    }

    .rud-crm-lightbox-prev { left:0; }
    .rud-crm-lightbox-next { right:auto; }

    .rud-crm-lightbox-counter {
        position:absolute;
        bottom:10px;
        left:50%;
        transform:translateX(-50%);
        padding:7px 12px;
        border-radius:999px;
        background:rgba(0,0,0,.34);
        color:#fff;
        font-size:18px;
        font-weight:400;
        letter-spacing:.04em;
    }

    .rud-crm-image-manager {
        margin-top:28px;
        padding:22px;
        border:1px solid #eaecf0;
        border-radius:10px;
        background:#fff;
    }

    .rud-crm-image-manager h3 {
        margin-top:0;
    }

    .rud-crm-image-upload-form {
        display:flex;
        align-items:center;
        gap:12px;
        flex-wrap:wrap;
        margin-top:18px;
    }

    .rud-crm-image-upload-form label {
        width:100%;
        font-weight:700;
    }

    .rud-crm-image-upload-form input[type="file"] {
        flex:1 1 320px;
    }

    .rud-crm-image-manager-grid {
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
        gap:16px;
        margin:18px 0;
    }

    .rud-crm-image-manager-item {
        padding:12px;
        border:1px solid #eaecf0;
        border-radius:10px;
        background:#f9fafb;
    }

    .rud-crm-image-manager-preview {
        position:relative;
        display:flex;
        align-items:center;
        justify-content:center;
        min-height:150px;
        margin-bottom:10px;
        border-radius:8px;
        background:#fff;
        overflow:hidden;
    }

    .rud-crm-image-manager-preview img {
        display:block;
        width:auto;
        height:auto;
        max-width:100%;
        max-height:170px;
        object-fit:contain;
    }

    .rud-crm-primary-badge {
        position:absolute;
        left:8px;
        bottom:8px;
        padding:5px 8px;
        border-radius:999px;
        background:rgba(16,24,40,.88);
        color:#fff;
        font-size:11px;
        font-weight:700;
    }

    .rud-crm-set-primary-button,
    .rud-crm-image-remove-button {
        width:100%;
        margin-top:8px;
        padding:8px 10px;
        border-radius:7px;
        font-weight:700;
        cursor:pointer;
    }

    .rud-crm-set-primary-button {
        border:1px solid #344054;
        background:#fff;
        color:#344054;
    }

    .rud-crm-image-remove-button {
        border:1px solid #b42318;
        background:#fff;
        color:#b42318;
    }

    /*
     * Open profile:
     * Primary personal image = round 110 x 110.
     */

    .rud-crm-header-person-image {
        flex:0 0 110px;
        width:110px;
        height:110px;
    }

    .rud-crm-header-person-image img,
    .rud-crm-header-person-placeholder {
        display:flex;
        align-items:center;
        justify-content:center;
        width:110px !important;
        height:110px !important;
        object-fit:cover;
        border-radius:50% !important;
        border:1px solid #d0d5dd;
        padding:3px;
        background:#fff;
        overflow:hidden;
    }

    .rud-crm-header-person-placeholder {
        background:#f2f4f7;
        color:#667085;
        font-size:38px;
        font-weight:700;
    }

    /*
     * Company remains one proportional logo.
     */

    .rud-crm-header-logo {
        display:flex;
        align-items:center;
        flex:0 1 auto;
        width:auto;
        max-width:600px;
        min-width:0;
        min-height:60px;
    }

    .rud-crm-header-logo img {
        display:block;
        width:auto;
        max-width:600px;
        height:auto;
        max-height:60px;
        object-fit:contain;
    }

    .rud-crm-header-logo-placeholder {
        display:flex;
        align-items:center;
        justify-content:center;
        min-width:100px;
        height:60px;
        padding:0 10px;
        border:1px solid #d0d5dd;
        border-radius:8px;
        background:#f2f4f7;
        color:#667085;
        font-size:28px;
        font-weight:700;
    }

    /*
     * Private-person gallery.
     * Natural image proportions are preserved.
     */

    .rud-crm-person-profile-gallery {
        display:grid;
        grid-template-columns:repeat(auto-fill,minmax(190px,1fr));
        gap:18px;
    }

    .rud-crm-person-profile-image {
        margin:0;
        padding:12px;
        border:1px solid #eaecf0;
        border-radius:10px;
        background:#fff;
    }

    .rud-crm-person-profile-image img {
        display:block;
        width:auto;
        height:auto;
        max-width:100%;
        max-height:220px;
        margin:0 auto;
        object-fit:contain;
    }

    .rud-crm-person-profile-image figcaption {
        margin-top:10px;
        text-align:center;
        font-size:12px;
        font-weight:700;
        color:#475467;
    }

    .rud-crm-image-message {
        display:flex;
        flex-direction:column;
        gap:4px;
        margin:0 0 20px;
        padding:16px 18px;
        border-radius:8px;
    }

    .rud-crm-image-success {
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-image-error {
        border-left:4px solid #b32d2e;
        background:#fff5f5;
    }

    @media (max-width:767px) {

        .rud-crm-lightbox-dialog {
            width:min(94vw,1100px);
        }

        .rud-crm-header-logo,
        .rud-crm-header-logo img {
            max-width:45vw;
        }

        .rud-crm-image-upload-form {
            display:block;
        }

        .rud-crm-image-upload-form input[type="file"] {
            width:100%;
            margin:8px 0 12px;
        }

        .rud-crm-person-profile-gallery {
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:12px;
        }

        .rud-crm-person-profile-image img {
            max-height:170px;
        }
    }

    ';

    wp_register_style(
        'rud-crm-customer-image',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '2.0'
    );

    wp_enqueue_style(
        'rud-crm-customer-image'
    );

    wp_add_inline_style(
        'rud-crm-customer-image',
        $css
    );
}



add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_customer_image_styles',
    40
);



/*
 * =========================================================
 * AJAX: UPLOAD ONE PRIVATE CUSTOMER IMAGE
 * =========================================================
 *
 * Browser sends one already-optimized JPEG at a time.
 * Server performs the normal validation and storage routine.
 *
 * =========================================================
 */

function rud_crm_ajax_upload_customer_image() {

    if (
        ! is_user_logged_in()
    ) {

        wp_send_json_error(
            array(
                'message' =>
                    'You must be logged in.'
            ),
            403
        );
    }


    check_ajax_referer(
        'rud_crm_customer_image_ajax',
        'nonce'
    );


    $customer_id =
        absint(
            $_POST['customer_id']
            ?? 0
        );


    if (
        ! $customer_id
        ||
        ! rud_crm_frontend_customer_image_can_edit(
            $customer_id
        )
    ) {

        wp_send_json_error(
            array(
                'message' =>
                    'You do not have permission to upload images for this customer.'
            ),
            403
        );
    }


    if (
        'person' !==
        rud_crm_frontend_customer_image_type(
            $customer_id
        )
    ) {

        wp_send_json_error(
            array(
                'message' =>
                    'This multi-image uploader is only available for private customers.'
            ),
            400
        );
    }


    if (
        rud_crm_frontend_customer_image_count(
            $customer_id
        )
        >=
        11
    ) {

        wp_send_json_error(
            array(
                'message' =>
                    'This customer already has the maximum of 11 images.'
            ),
            400
        );
    }


    $file =
        $_FILES['image']
        ?? array();


    $result =
        rud_crm_frontend_customer_image_upload(
            $customer_id,
            $file,
            false
        );


    if (
        is_wp_error(
            $result
        )
    ) {

        wp_send_json_error(
            array(
                'message' =>
                    $result->get_error_message()
            ),
            400
        );
    }


    wp_send_json_success(
        array(
            'attachment_id' =>
                absint(
                    $result
                )
        )
    );
}


add_action(
    'wp_ajax_rud_crm_ajax_upload_customer_image',
    'rud_crm_ajax_upload_customer_image'
);


function rud_crm_frontend_customer_image_ui_scripts() {

    if ( is_admin() ) {
        return;
    }

    $ajax_url =
        admin_url(
            'admin-ajax.php'
        );

    $nonce =
        wp_create_nonce(
            'rud_crm_customer_image_ajax'
        );

    $js = <<<'JS'
(function() {

    var RUD_AJAX_URL = '__AJAX_URL__';
    var RUD_AJAX_NONCE = '__AJAX_NONCE__';


    /*
     * =====================================================
     * IMAGE COMPRESSION BEFORE UPLOAD
     * =====================================================
     *
     * Private person images:
     * - JPG/JPEG only
     * - browser reduces to max 1200 x 1200
     * - quality 0.82
     *
     * This means a 6-15 MB camera JPEG normally becomes
     * a much smaller upload before it ever reaches PHP.
     *
     * =====================================================
     */

    function rudLoadImage(file) {

        return new Promise(function(resolve, reject) {

            var url =
                URL.createObjectURL(file);

            var img =
                new Image();

            img.onload =
                function() {
                    URL.revokeObjectURL(url);
                    resolve(img);
                };

            img.onerror =
                function() {
                    URL.revokeObjectURL(url);
                    reject(new Error('Could not read image.'));
                };

            img.src =
                url;
        });
    }


    function rudResizeJpeg(file, maxWidth, maxHeight, quality) {

        return rudLoadImage(file).then(function(img) {

            var width =
                img.naturalWidth || img.width;

            var height =
                img.naturalHeight || img.height;

            var ratio =
                Math.min(
                    maxWidth / width,
                    maxHeight / height,
                    1
                );

            var targetWidth =
                Math.max(
                    1,
                    Math.round(width * ratio)
                );

            var targetHeight =
                Math.max(
                    1,
                    Math.round(height * ratio)
                );

            var canvas =
                document.createElement('canvas');

            canvas.width =
                targetWidth;

            canvas.height =
                targetHeight;

            var ctx =
                canvas.getContext('2d', {
                    alpha:false
                });

            ctx.imageSmoothingEnabled =
                true;

            ctx.imageSmoothingQuality =
                'high';

            ctx.drawImage(
                img,
                0,
                0,
                targetWidth,
                targetHeight
            );

            return new Promise(function(resolve, reject) {

                canvas.toBlob(
                    function(blob) {

                        if (!blob) {
                            reject(
                                new Error(
                                    'Could not prepare image for upload.'
                                )
                            );
                            return;
                        }

                        var baseName =
                            file.name
                                .replace(/\.[^.]+$/, '');

                        resolve(
                            new File(
                                [blob],
                                baseName + '.jpg',
                                {
                                    type:'image/jpeg',
                                    lastModified:Date.now()
                                }
                            )
                        );
                    },
                    'image/jpeg',
                    quality
                );
            });
        });
    }


    function rudUploadOnePersonImage(customerId, file) {

        return rudResizeJpeg(
            file,
            1200,
            1200,
            0.82
        ).then(function(preparedFile) {

            var data =
                new FormData();

            data.append(
                'action',
                'rud_crm_ajax_upload_customer_image'
            );

            data.append(
                'nonce',
                RUD_AJAX_NONCE
            );

            data.append(
                'customer_id',
                customerId
            );

            data.append(
                'image',
                preparedFile,
                preparedFile.name
            );

            return fetch(
                RUD_AJAX_URL,
                {
                    method:'POST',
                    credentials:'same-origin',
                    body:data
                }
            )
            .then(function(response) {
                return response.json();
            })
            .then(function(payload) {

                if (
                    !payload
                    ||
                    !payload.success
                ) {

                    var message =
                        payload
                        &&
                        payload.data
                        &&
                        payload.data.message
                        ? payload.data.message
                        : 'Image upload failed.';

                    throw new Error(message);
                }

                return payload.data;
            });
        });
    }


    /*
     * =====================================================
     * DRAG & DROP
     * =====================================================
     */

    function initDropzones() {

        document
            .querySelectorAll('[data-rud-dropzone]')
            .forEach(function(zone) {

                if (zone.dataset.ready === '1') {
                    return;
                }

                zone.dataset.ready =
                    '1';

                var input =
                    zone.querySelector(
                        '[data-rud-drop-input]'
                    );

                var selection =
                    zone.querySelector(
                        '[data-rud-drop-selection]'
                    );

                if (!input) {
                    return;
                }


                function showText(text) {

                    if (selection) {
                        selection.textContent =
                            text || '';
                    }
                }


                function filterFiles(files) {

                    var acceptsPng =
                        input.accept.indexOf('png') !== -1;

                    return files.filter(function(file) {

                        if (acceptsPng) {

                            return (
                                file.type === 'image/jpeg'
                                ||
                                file.type === 'image/png'
                            );
                        }

                        return file.type === 'image/jpeg';
                    });
                }


                function setFiles(files) {

                    files =
                        filterFiles(files);

                    if (!input.multiple) {
                        files = files.slice(0, 1);
                    } else {
                        files = files.slice(0,10);
                    }

                    var transfer =
                        new DataTransfer();

                    files.forEach(function(file) {
                        transfer.items.add(file);
                    });

                    input.files =
                        transfer.files;

                    if (!files.length) {

                        showText(
                            'No valid image files selected.'
                        );

                    } else if (files.length === 1) {

                        showText(
                            files[0].name
                        );

                    } else {

                        showText(
                            files.length +
                            ' images ready'
                        );
                    }
                }


                ['dragenter', 'dragover']
                    .forEach(function(name) {

                        zone.addEventListener(
                            name,
                            function(event) {

                                event.preventDefault();
                                event.stopPropagation();

                                zone.classList.add(
                                    'is-dragover'
                                );
                            }
                        );
                    });


                ['dragleave', 'drop']
                    .forEach(function(name) {

                        zone.addEventListener(
                            name,
                            function(event) {

                                event.preventDefault();
                                event.stopPropagation();

                                zone.classList.remove(
                                    'is-dragover'
                                );
                            }
                        );
                    });


                zone.addEventListener(
                    'drop',
                    function(event) {

                        setFiles(
                            Array.from(
                                event.dataTransfer.files || []
                            )
                        );
                    }
                );


                input.addEventListener(
                    'change',
                    function() {

                        setFiles(
                            Array.from(
                                input.files || []
                            )
                        );
                    }
                );


                /*
                 * -------------------------------------------------
                 * SMART MULTI-UPLOAD FOR PRIVATE PERSON IMAGES
                 * -------------------------------------------------
                 *
                 * Edit-customer image manager has customer id and
                 * can upload each dropped file individually.
                 *
                 * This avoids one huge multi-file POST.
                 *
                 * -------------------------------------------------
                 */

                var form =
                    zone.closest('form');

                if (
                    !form
                    ||
                    input.name !==
                    'rud_crm_customer_image_files[]'
                ) {
                    return;
                }


                form.addEventListener(
                    'submit',
                    function(event) {

                        var customerField =
                            form.querySelector(
                                'input[name="rud_customer_id"]'
                            );

                        if (!customerField) {
                            return;
                        }

                        var customerId =
                            customerField.value;

                        var files =
                            filterFiles(
                                Array.from(
                                    input.files || []
                                )
                            );

                        if (!files.length) {
                            return;
                        }

                        event.preventDefault();

                        var submit =
                            form.querySelector(
                                'button[type="submit"]'
                            );

                        if (submit) {
                            submit.disabled =
                                true;
                        }

                        var completed =
                            0;

                        var failed =
                            0;

                        showText(
                            'Preparing images...'
                        );


                        /*
                         * Sequential upload.
                         * Keeps memory/server pressure low.
                         */

                        var sequence =
                            Promise.resolve();

                        files.forEach(function(file, index) {

                            sequence =
                                sequence.then(function() {

                                    showText(
                                        'Optimizing and uploading ' +
                                        (index + 1) +
                                        ' of ' +
                                        files.length +
                                        '...'
                                    );

                                    return rudUploadOnePersonImage(
                                        customerId,
                                        file
                                    )
                                    .then(function() {
                                        completed++;
                                    })
                                    .catch(function(error) {

                                        failed++;

                                        console.error(
                                            error
                                        );
                                    });
                                });
                        });


                        sequence.then(function() {

                            if (failed > 0) {

                                showText(
                                    completed +
                                    ' uploaded, ' +
                                    failed +
                                    ' failed.'
                                );

                            } else {

                                showText(
                                    completed +
                                    ' image(s) uploaded successfully.'
                                );
                            }

                            window.setTimeout(
                                function() {
                                    window.location.reload();
                                },
                                650
                            );
                        });
                    }
                );
            });
    }


    /*
     * =====================================================
     * LIGHTBOX
     * =====================================================
     */

    function initLightbox() {

        document
            .querySelectorAll('[data-rud-lightbox]')
            .forEach(function(box) {

                if (box.dataset.ready === '1') {
                    return;
                }

                box.dataset.ready =
                    '1';

                var panel =
                    box.closest('.rud-crm-panel');

                if (!panel) {
                    return;
                }

                var buttons =
                    Array.from(
                        panel.querySelectorAll(
                            '[data-rud-lightbox-image]'
                        )
                    );

                var image =
                    box.querySelector(
                        '[data-rud-lightbox-view]'
                    );

                var counter =
                    box.querySelector(
                        '[data-rud-lightbox-counter]'
                    );

                var prev =
                    box.querySelector(
                        '[data-rud-lightbox-prev]'
                    );

                var next =
                    box.querySelector(
                        '[data-rud-lightbox-next]'
                    );

                var index = 0;


                function positionControls() {

                    if (!image || !image.complete) {
                        return;
                    }

                    var dialog =
                        box.querySelector(
                            '.rud-crm-lightbox-dialog'
                        );

                    var closeButton =
                        box.querySelector(
                            '.rud-crm-lightbox-close'
                        );

                    if (!dialog) {
                        return;
                    }

                    var dialogRect =
                        dialog.getBoundingClientRect();

                    var imageRect =
                        image.getBoundingClientRect();

                    /*
                     * Arrows:
                     * exactly 10 px outside the actual rendered image.
                     */

                    var arrowGap =
                        15;

                    if (prev) {

                        prev.style.left =
                            (
                                imageRect.left -
                                dialogRect.left -
                                prev.offsetWidth -
                                arrowGap
                            ) +
                            'px';

                        prev.style.top =
                            (
                                imageRect.top -
                                dialogRect.top +
                                (
                                    imageRect.height -
                                    prev.offsetHeight
                                ) / 2
                            ) +
                            'px';

                        prev.style.marginTop =
                            '0';
                    }

                    if (next) {

                        next.style.left =
                            (
                                imageRect.right -
                                dialogRect.left +
                                arrowGap
                            ) +
                            'px';

                        next.style.right =
                            'auto';

                        next.style.top =
                            (
                                imageRect.top -
                                dialogRect.top +
                                (
                                    imageRect.height -
                                    next.offsetHeight
                                ) / 2
                            ) +
                            'px';

                        next.style.marginTop =
                            '0';
                    }

                    /*
                     * Close button:
                     * snug against the actual top-right corner of the image.
                     * Slightly overlaps the outer corner for a polished look.
                     */

                    if (closeButton) {

                        closeButton.style.left =
                            (
                                imageRect.right -
                                dialogRect.left +
                                10
                            ) +
                            'px';

                        closeButton.style.right =
                            'auto';

                        closeButton.style.top =
                            (
                                imageRect.top -
                                dialogRect.top -
                                closeButton.offsetHeight -
                                10
                            ) +
                            'px';
                    }
                }


                function render() {

                    if (!buttons.length) {
                        return;
                    }

                    image.onload =
                        function() {

                            window.requestAnimationFrame(
                                positionControls
                            );
                        };

                    image.src =
                        buttons[index]
                            .dataset
                            .rudLightboxImage
                        || '';

                    if (counter) {
                        counter.textContent =
                            (index + 1) +
                            ' / ' +
                            buttons.length;
                    }

                    if (prev) {
                        prev.hidden =
                            buttons.length < 2;
                    }

                    if (next) {
                        next.hidden =
                            buttons.length < 2;
                    }

                    if (image.complete) {

                        window.requestAnimationFrame(
                            positionControls
                        );
                    }
                }


                function openAt(i) {

                    index =
                        i;

                    render();

                    box.hidden =
                        false;

                    box.setAttribute(
                        'aria-hidden',
                        'false'
                    );

                    document
                        .documentElement
                        .style
                        .overflow =
                            'hidden';
                }


                function close() {

                    box.hidden =
                        true;

                    box.setAttribute(
                        'aria-hidden',
                        'true'
                    );

                    image.src =
                        '';

                    document
                        .documentElement
                        .style
                        .overflow =
                            '';
                }


                buttons.forEach(function(button, i) {

                    button.addEventListener(
                        'click',
                        function() {
                            openAt(i);
                        }
                    );
                });


                box
                    .querySelectorAll(
                        '[data-rud-lightbox-close]'
                    )
                    .forEach(function(button) {

                        button.addEventListener(
                            'click',
                            close
                        );
                    });


                if (prev) {

                    prev.addEventListener(
                        'click',
                        function() {

                            index =
                                (
                                    index -
                                    1 +
                                    buttons.length
                                )
                                %
                                buttons.length;

                            render();
                        }
                    );
                }


                if (next) {

                    next.addEventListener(
                        'click',
                        function() {

                            index =
                                (
                                    index +
                                    1
                                )
                                %
                                buttons.length;

                            render();
                        }
                    );
                }


                window.addEventListener(
                    'resize',
                    function() {

                        if (
                            ! box.hidden
                        ) {

                            window.requestAnimationFrame(
                                positionControls
                            );
                        }
                    }
                );


                document.addEventListener(
                    'keydown',
                    function(event) {

                        if (box.hidden) {
                            return;
                        }

                        if (
                            event.key ===
                            'Escape'
                        ) {
                            close();
                        }

                        if (
                            event.key ===
                            'ArrowLeft'
                            &&
                            buttons.length > 1
                        ) {

                            index =
                                (
                                    index -
                                    1 +
                                    buttons.length
                                )
                                %
                                buttons.length;

                            render();
                        }

                        if (
                            event.key ===
                            'ArrowRight'
                            &&
                            buttons.length > 1
                        ) {

                            index =
                                (
                                    index +
                                    1
                                )
                                %
                                buttons.length;

                            render();
                        }
                    }
                );
            });
    }


    function init() {
        initDropzones();
        initLightbox();
    }


    if (
        document.readyState ===
        'loading'
    ) {

        document.addEventListener(
            'DOMContentLoaded',
            init
        );

    } else {

        init();
    }

})();
JS;

    $js =
        str_replace(
            array(
                '__AJAX_URL__',
                '__AJAX_NONCE__'
            ),
            array(
                esc_js(
                    $ajax_url
                ),
                esc_js(
                    $nonce
                )
            ),
            $js
        );

    wp_register_script(
        'rud-crm-customer-image-ui',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '2.2',
        true
    );

    wp_enqueue_script(
        'rud-crm-customer-image-ui'
    );

    wp_add_inline_script(
        'rud-crm-customer-image-ui',
        $js,
        'after'
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_frontend_customer_image_ui_scripts',
    41
);