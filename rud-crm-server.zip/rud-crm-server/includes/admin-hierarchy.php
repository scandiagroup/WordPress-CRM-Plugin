<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * PERMANENT ADMINISTRATOR HIERARCHY
 * =========================================================
 *
 * ADMIN-LEVEL-001 — System Admin Owner
 * ADMIN-LEVEL-002 — System Administrator
 * ADMIN-LEVEL-003 — System Support
 * ADMIN-LEVEL-004 — Senior Administrator
 * ADMIN-LEVEL-005 — Sales / Customer Manager
 * ADMIN-LEVEL-006 — Sales / Customer Assistant
 *
 * Below the administrator ladder:
 *
 * CRM-CLIENTS
 *
 * =========================================================
 */


/*
 * =========================================================
 * ROLE SLUGS
 * =========================================================
 */

function rud_crm_admin_level_001_role() {
    return 'rud_crm_admin_level_001';
}

function rud_crm_admin_level_002_role() {
    return 'rud_crm_admin_level_002';
}

function rud_crm_admin_level_003_role() {
    return 'rud_crm_admin_level_003';
}

function rud_crm_admin_level_004_role() {
    return 'rud_crm_admin_level_004';
}

function rud_crm_admin_level_005_role() {
    return 'rud_crm_admin_level_005';
}

function rud_crm_admin_level_006_role() {
    return 'rud_crm_admin_level_006';
}

function rud_crm_client_role() {
    return 'rud_crm_client';
}


/*
 * =========================================================
 * ADMIN LEVEL LABELS
 * =========================================================
 */

function rud_crm_admin_level_label( $level ) {

    $level = absint( $level );

    switch ( $level ) {

        case 1:
            return 'ADMIN-LEVEL-001 — System Admin Owner';

        case 2:
            return 'ADMIN-LEVEL-002 — System Administrator';

        case 3:
            return 'ADMIN-LEVEL-003 — System Support';

        case 4:
            return 'ADMIN-LEVEL-004 — Senior Administrator';

        case 5:
            return 'ADMIN-LEVEL-005 — Sales / Customer Manager';

        case 6:
            return 'ADMIN-LEVEL-006 — Sales / Customer Assistant';
    }

    return 'Unknown Administrator Level';
}


/*
 * =========================================================
 * ROLE SLUG FROM LEVEL
 * =========================================================
 */

function rud_crm_admin_role_from_level( $level ) {

    switch ( absint( $level ) ) {

        case 1:
            return rud_crm_admin_level_001_role();

        case 2:
            return rud_crm_admin_level_002_role();

        case 3:
            return rud_crm_admin_level_003_role();

        case 4:
            return rud_crm_admin_level_004_role();

        case 5:
            return rud_crm_admin_level_005_role();

        case 6:
            return rud_crm_admin_level_006_role();
    }

    return '';
}


/*
 * =========================================================
 * SYSTEM ADMIN OWNER
 * =========================================================
 *
 * There may only be ONE RUD CRM System Admin Owner.
 *
 * The owner user ID is stored separately so that ordinary
 * WordPress Administrators are NOT automatically treated
 * as RUD CRM ADMIN-LEVEL-001.
 *
 * =========================================================
 */

function rud_crm_get_system_admin_owner_user_id() {

    return absint(
        get_option(
            'rud_crm_system_admin_owner_user_id',
            0
        )
    );
}


/*
 * =========================================================
 * BOOTSTRAP FIRST SYSTEM ADMIN OWNER
 * =========================================================
 *
 * On the first run after installing this version, the
 * currently logged-in WordPress Administrator becomes
 * the RUD CRM System Admin Owner if no owner exists yet.
 *
 * =========================================================
 */

function rud_crm_bootstrap_system_admin_owner() {

    $existing_owner =
        rud_crm_get_system_admin_owner_user_id();


    if ( $existing_owner ) {

        $existing_user =
            get_userdata(
                $existing_owner
            );


        if ( $existing_user ) {
            return;
        }
    }


    if ( ! is_user_logged_in() ) {
        return;
    }


    $current_user =
        wp_get_current_user();


    if (
        ! $current_user
        ||
        ! $current_user->exists()
    ) {
        return;
    }


    if (
        ! in_array(
            'administrator',
            (array) $current_user->roles,
            true
        )
    ) {
        return;
    }


    update_option(
        'rud_crm_system_admin_owner_user_id',
        $current_user->ID,
        false
    );


    /*
     * Also give the owner the permanent CRM owner role.
     */

    $current_user->add_role(
        rud_crm_admin_level_001_role()
    );


    update_user_meta(
        $current_user->ID,
        'rud_crm_admin_level',
        1
    );


    update_user_meta(
        $current_user->ID,
        'rud_crm_system_admin_owner',
        '1'
    );
}


/*
 * =========================================================
 * GET ADMIN LEVEL
 * =========================================================
 */

function rud_crm_get_admin_level( $user_id = 0 ) {

    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if ( ! $user_id ) {
        return 0;
    }


    $user =
        get_userdata(
            $user_id
        );


    if ( ! $user ) {
        return 0;
    }


    /*
     * The designated System Admin Owner always has
     * ADMIN-LEVEL-001.
     */

    if (
        $user_id ===
        rud_crm_get_system_admin_owner_user_id()
    ) {
        return 1;
    }


    $roles =
        (array) $user->roles;


    if (
        in_array(
            rud_crm_admin_level_001_role(),
            $roles,
            true
        )
    ) {
        return 1;
    }


    if (
        in_array(
            rud_crm_admin_level_002_role(),
            $roles,
            true
        )
    ) {
        return 2;
    }


    if (
        in_array(
            rud_crm_admin_level_003_role(),
            $roles,
            true
        )
    ) {
        return 3;
    }


    if (
        in_array(
            rud_crm_admin_level_004_role(),
            $roles,
            true
        )
    ) {
        return 4;
    }


    if (
        in_array(
            rud_crm_admin_level_005_role(),
            $roles,
            true
        )
    ) {
        return 5;
    }


    if (
        in_array(
            rud_crm_admin_level_006_role(),
            $roles,
            true
        )
    ) {
        return 6;
    }


    return 0;
}


/*
 * =========================================================
 * ADMIN CHECKS
 * =========================================================
 */

function rud_crm_is_admin_level_001( $user_id = 0 ) {
    return 1 === rud_crm_get_admin_level( $user_id );
}

function rud_crm_is_admin_level_002( $user_id = 0 ) {
    return 2 === rud_crm_get_admin_level( $user_id );
}

function rud_crm_is_admin_level_003( $user_id = 0 ) {
    return 3 === rud_crm_get_admin_level( $user_id );
}

function rud_crm_is_admin_level_004( $user_id = 0 ) {
    return 4 === rud_crm_get_admin_level( $user_id );
}

function rud_crm_is_admin_level_005( $user_id = 0 ) {
    return 5 === rud_crm_get_admin_level( $user_id );
}

function rud_crm_is_admin_level_006( $user_id = 0 ) {
    return 6 === rud_crm_get_admin_level( $user_id );
}


function rud_crm_is_crm_admin( $user_id = 0 ) {

    return
        rud_crm_get_admin_level(
            $user_id
        ) > 0;
}


/*
 * =========================================================
 * CRM CLIENT CHECK
 * =========================================================
 */

function rud_crm_is_client_user( $user_id = 0 ) {

    if ( ! $user_id ) {
        $user_id = get_current_user_id();
    }


    $user =
        get_userdata(
            $user_id
        );


    if ( ! $user ) {
        return false;
    }


    $roles =
        (array) $user->roles;


    /*
     * Permanent CRM Client role.
     */

    if (
        in_array(
            rud_crm_client_role(),
            $roles,
            true
        )
    ) {
        return true;
    }


    /*
     * Existing Demo Users remain CRM Clients
     * while we migrate the older system.
     */

    if (
        in_array(
            'rud_crm_demo',
            $roles,
            true
        )
    ) {
        return true;
    }


    return false;
}


/*
 * =========================================================
 * ADMIN CREATION RULES
 * =========================================================
 *
 * 001 -> 002 / 003 / 004 / 005 / 006
 * 002 -> 003 / 004 / 005 / 006
 * 003 -> 004 / 005 / 006
 * 004 -> 005 / 006
 * 005 -> 006
 * 006 -> none
 *
 * ADMIN-LEVEL-001 can NEVER be created from the
 * normal Administrator Management screen.
 *
 * =========================================================
 */

function rud_crm_can_create_admin_level(
    $target_level,
    $user_id = 0
) {

    $current_level =
        rud_crm_get_admin_level(
            $user_id
        );


    $target_level =
        absint(
            $target_level
        );


    /*
     * Nobody creates ADMIN-LEVEL-001 here.
     */

    if ( 1 === $target_level ) {
        return false;
    }


    if ( 1 === $current_level ) {

        return in_array(
            $target_level,
            array(
                2,
                3,
                4,
                5,
                6
            ),
            true
        );
    }


    if ( 2 === $current_level ) {

        return in_array(
            $target_level,
            array(
                3,
                4,
                5,
                6
            ),
            true
        );
    }


    if ( 3 === $current_level ) {

        return in_array(
            $target_level,
            array(
                4,
                5,
                6
            ),
            true
        );
    }


    if ( 4 === $current_level ) {

        return in_array(
            $target_level,
            array(
                5,
                6
            ),
            true
        );
    }


    if ( 5 === $current_level ) {

        return
            6 ===
            $target_level;
    }


    return false;
}


/*
 * =========================================================
 * MANAGE ADMIN RULES
 * =========================================================
 *
 * No administrator may manage:
 *
 * - ADMIN-LEVEL-001
 * - their own account
 * - the same level
 * - any higher level
 *
 * =========================================================
 */

function rud_crm_can_manage_admin_user(
    $target_user_id,
    $current_user_id = 0
) {

    if ( ! $current_user_id ) {
        $current_user_id = get_current_user_id();
    }


    $target_user_id =
        absint(
            $target_user_id
        );


    $current_user_id =
        absint(
            $current_user_id
        );


    if (
        ! $target_user_id
        ||
        ! $current_user_id
    ) {
        return false;
    }


    /*
     * Cannot manage yourself.
     */

    if (
        $target_user_id ===
        $current_user_id
    ) {
        return false;
    }


    $current_level =
        rud_crm_get_admin_level(
            $current_user_id
        );


    $target_level =
        rud_crm_get_admin_level(
            $target_user_id
        );


    if (
        ! $current_level
        ||
        ! $target_level
    ) {
        return false;
    }


    /*
     * System Admin Owner is protected.
     */

    if ( 1 === $target_level ) {
        return false;
    }


    /*
     * Same level or higher level is protected.
     */

    if (
        $target_level <=
        $current_level
    ) {
        return false;
    }


    return rud_crm_can_create_admin_level(
        $target_level,
        $current_user_id
    );
}


/*
 * =========================================================
 * CRM CLIENT MANAGEMENT
 * =========================================================
 *
 * All six administrator levels can access CRM Clients.
 *
 * =========================================================
 */

function rud_crm_can_manage_crm_clients( $user_id = 0 ) {

    return
        rud_crm_is_crm_admin(
            $user_id
        );
}


function rud_crm_admin_can_access_all_clients( $user_id = 0 ) {

    $level =
        rud_crm_get_admin_level(
            $user_id
        );


    return in_array(
        $level,
        array(
            1,
            2,
            3,
            4,
            5,
            6
        ),
        true
    );
}


/*
 * =========================================================
 * CRM CLIENT NUMBER PREFIX
 * =========================================================
 *
 * 2026:
 *
 * CRM-CLIENTS-26001
 * CRM-CLIENTS-26002
 *
 * =========================================================
 */

function rud_crm_client_number_prefix() {

    return
        'CRM-CLIENTS-' .
        wp_date(
            'y'
        );
}


/*
 * =========================================================
 * GENERATE NEXT CRM CLIENT NUMBER
 * =========================================================
 */

function rud_crm_generate_client_number() {

    $prefix =
        rud_crm_client_number_prefix();


    $users =
        get_users(
            array(

                'meta_key' =>
                    'rud_crm_client_number',

                'meta_compare' =>
                    'EXISTS',

                'fields' =>
                    'ID'
            )
        );


    $highest = 0;


    foreach (
        $users as
        $user_id
    ) {

        $number =
            (string)
            get_user_meta(
                $user_id,
                'rud_crm_client_number',
                true
            );


        if (
            0 !==
            strpos(
                $number,
                $prefix
            )
        ) {
            continue;
        }


        $sequence =
            absint(
                substr(
                    $number,
                    strlen(
                        $prefix
                    )
                )
            );


        if (
            $sequence >
            $highest
        ) {
            $highest =
                $sequence;
        }
    }


    $next =
        $highest + 1;


    return sprintf(
        '%s%03d',
        $prefix,
        $next
    );
}


/*
 * =========================================================
 * ASSIGN CRM CLIENT NUMBER
 * =========================================================
 */

function rud_crm_assign_client_number( $user_id ) {

    $user_id =
        absint(
            $user_id
        );


    if ( ! $user_id ) {
        return false;
    }


    $existing =
        get_user_meta(
            $user_id,
            'rud_crm_client_number',
            true
        );


    if ( $existing ) {
        return $existing;
    }


    $number =
        rud_crm_generate_client_number();


    update_user_meta(
        $user_id,
        'rud_crm_client_number',
        $number
    );


    update_user_meta(
        $user_id,
        'rud_crm_client_created_at',
        current_time(
            'mysql'
        )
    );


    return $number;
}


/*
 * =========================================================
 * PUBLIC REGISTRATION CLIENT NUMBER
 * =========================================================
 */

function rud_crm_assign_number_to_public_client( $user_id ) {

    rud_crm_assign_client_number(
        $user_id
    );
}


add_action(
    'rud_crm_public_user_registered',
    'rud_crm_assign_number_to_public_client',
    5,
    1
);


/*
 * =========================================================
 * ROLE DEFINITIONS
 * =========================================================
 */

function rud_crm_admin_hierarchy_role_definitions() {

    return array(


        /*
         * ADMIN-LEVEL-001
         * SYSTEM ADMIN OWNER
         */

        rud_crm_admin_level_001_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-001 — System Admin Owner',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,
                        'rud_crm_export' => true,

                        'rud_crm_manage_sites' => true,
                        'rud_crm_manage_api' => true,
                        'rud_crm_manage_settings' => true,
                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true,

                        'rud_crm_admin_level_001' => true,
                        'rud_crm_admin_level_002' => true,
                        'rud_crm_admin_level_003' => true,
                        'rud_crm_admin_level_004' => true,
                        'rud_crm_admin_level_005' => true,
                        'rud_crm_admin_level_006' => true
                    )
            ),


        /*
         * ADMIN-LEVEL-002
         * SYSTEM ADMINISTRATOR
         */

        rud_crm_admin_level_002_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-002 — System Administrator',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,
                        'rud_crm_export' => true,

                        'rud_crm_manage_sites' => true,
                        'rud_crm_manage_api' => true,
                        'rud_crm_manage_settings' => true,
                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true,

                        'rud_crm_admin_level_003' => true,
                        'rud_crm_admin_level_004' => true,
                        'rud_crm_admin_level_005' => true,
                        'rud_crm_admin_level_006' => true
                    )
            ),


        /*
         * ADMIN-LEVEL-003
         * SYSTEM SUPPORT
         */

        rud_crm_admin_level_003_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-003 — System Support',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,
                        'rud_crm_export' => true,

                        'rud_crm_manage_sites' => true,
                        'rud_crm_manage_api' => true,
                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true,

                        'rud_crm_admin_level_004' => true,
                        'rud_crm_admin_level_005' => true,
                        'rud_crm_admin_level_006' => true
                    )
            ),


        /*
         * ADMIN-LEVEL-004
         * SENIOR ADMINISTRATOR
         */

        rud_crm_admin_level_004_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-004 — Senior Administrator',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,
                        'rud_crm_export' => true,

                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true,

                        'rud_crm_admin_level_005' => true,
                        'rud_crm_admin_level_006' => true
                    )
            ),


        /*
         * ADMIN-LEVEL-005
         * SALES / CUSTOMER MANAGER
         */

        rud_crm_admin_level_005_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-005 — Sales / Customer Manager',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,

                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true,

                        'rud_crm_admin_level_006' => true
                    )
            ),


        /*
         * ADMIN-LEVEL-006
         * SALES / CUSTOMER ASSISTANT
         */

        rud_crm_admin_level_006_role() =>
            array(

                'name' =>
                    'ADMIN-LEVEL-006 — Sales / Customer Assistant',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true,
                        'rud_crm_delete' => true,

                        'rud_crm_manage_clients' => true,
                        'rud_crm_login_as_client' => true
                    )
            ),


        /*
         * CRM CLIENT
         */

        rud_crm_client_role() =>
            array(

                'name' =>
                    'CRM Client',

                'caps' =>
                    array(

                        'read' => true,

                        'rud_crm_view' => true,
                        'rud_crm_create' => true,
                        'rud_crm_edit' => true
                    )
            )
    );
}


/*
 * =========================================================
 * INSTALL / SYNCHRONIZE ROLES
 * =========================================================
 *
 * Unlike add_role() alone, this also updates capabilities
 * when a role already exists from an earlier version.
 *
 * =========================================================
 */

function rud_crm_install_admin_hierarchy_roles() {

    global $wp_roles;


    if ( ! isset( $wp_roles ) ) {

        $wp_roles =
            wp_roles();
    }


    $definitions =
        rud_crm_admin_hierarchy_role_definitions();


    foreach (
        $definitions as
        $role_slug =>
        $definition
    ) {

        $role =
            get_role(
                $role_slug
            );


        if ( ! $role ) {

            add_role(
                $role_slug,
                $definition['name'],
                $definition['caps']
            );


            $role =
                get_role(
                    $role_slug
                );
        }


        if ( ! $role ) {
            continue;
        }


        /*
         * Remove old RUD CRM capabilities from this role
         * before applying the current definition.
         */

        foreach (
            array_keys(
                $role->capabilities
            ) as
            $capability
        ) {

            if (
                0 ===
                strpos(
                    $capability,
                    'rud_crm_'
                )
            ) {

                $role->remove_cap(
                    $capability
                );
            }
        }


        /*
         * Apply current capabilities.
         */

        foreach (
            $definition['caps'] as
            $capability =>
            $allowed
        ) {

            if ( $allowed ) {

                $role->add_cap(
                    $capability,
                    true
                );

            } else {

                $role->remove_cap(
                    $capability
                );
            }
        }


        /*
         * Update displayed role name.
         */

        if (
            isset(
                $wp_roles->roles[ $role_slug ]
            )
        ) {

            $wp_roles->roles[ $role_slug ]['name'] =
                $definition['name'];


            $wp_roles->role_names[ $role_slug ] =
                $definition['name'];
        }
    }


    update_option(
        $wp_roles->role_key,
        $wp_roles->roles
    );
}


/*
 * =========================================================
 * INITIALIZE HIERARCHY
 * =========================================================
 */

function rud_crm_initialize_admin_hierarchy() {

    rud_crm_install_admin_hierarchy_roles();

    rud_crm_bootstrap_system_admin_owner();
}


add_action(
    'admin_init',
    'rud_crm_initialize_admin_hierarchy',
    5
);


/*
 * =========================================================
 * PROFILE CLASSIFICATION
 * =========================================================
 */

function rud_crm_admin_hierarchy_profile_info( $user ) {

    if (
        ! (
            $user instanceof WP_User
        )
    ) {
        return;
    }


    $level =
        rud_crm_get_admin_level(
            $user->ID
        );


    $client_number =
        get_user_meta(
            $user->ID,
            'rud_crm_client_number',
            true
        );


    if (
        ! $level
        &&
        ! $client_number
        &&
        ! rud_crm_is_client_user(
            $user->ID
        )
    ) {
        return;
    }


    ?>

    <h2>
        RUD CRM Account Classification
    </h2>


    <table class="form-table">


        <?php if ( $level ) : ?>

            <tr>

                <th>
                    Administrator Level
                </th>

                <td>

                    <strong>
                        <?php
                        echo esc_html(
                            rud_crm_admin_level_label(
                                $level
                            )
                        );
                        ?>
                    </strong>


                    <?php if ( 1 === $level ) : ?>

                        <p class="description">
                            Protected System Admin Owner account.
                        </p>

                    <?php endif; ?>

                </td>

            </tr>

        <?php endif; ?>


        <?php

        if (
            rud_crm_is_client_user(
                $user->ID
            )
        ) :

        ?>

            <tr>

                <th>
                    CRM Client Number
                </th>

                <td>

                    <strong>
                        <?php
                        echo esc_html(
                            $client_number
                            ? $client_number
                            : 'Not assigned'
                        );
                        ?>
                    </strong>

                </td>

            </tr>

        <?php endif; ?>


    </table>

    <?php
}


add_action(
    'show_user_profile',
    'rud_crm_admin_hierarchy_profile_info'
);


add_action(
    'edit_user_profile',
    'rud_crm_admin_hierarchy_profile_info'
);