<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * EMAIL SYSTEM FOUNDATION
 * Version 1.2
 * =========================================================
 *
 * Provides:
 * - Email Templates table
 * - Email Log table
 * - Email sender settings
 * - Template variables
 * - Template CRUD helpers
 * - Email log helpers
 *
 * Actual sending will be connected in the next module.
 *
 * =========================================================
 */


/*
 * =========================================================
 * TABLE NAMES
 * =========================================================
 */

function rud_crm_email_templates_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_email_templates';
}


function rud_crm_email_log_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_email_log';
}


/*
 * =========================================================
 * ENSURE TABLES
 * =========================================================
 */

function rud_crm_ensure_email_tables() {

    global $wpdb;

    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';

    $charset_collate =
        $wpdb->get_charset_collate();

    $templates_table =
        rud_crm_email_templates_table();

    $log_table =
        rud_crm_email_log_table();


    $templates_sql =
        "CREATE TABLE {$templates_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            template_uuid CHAR(36) NOT NULL,

            template_name VARCHAR(190) NOT NULL DEFAULT '',
            subject VARCHAR(255) NOT NULL DEFAULT '',
            cc_email TEXT NULL,
            bcc_email TEXT NULL,
            body LONGTEXT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'active',

            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY template_uuid (template_uuid),
            KEY status (status),
            KEY created_by (created_by)

        ) {$charset_collate};";


    $log_sql =
        "CREATE TABLE {$log_table} (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            email_uuid CHAR(36) NOT NULL,

            customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            contact_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            project_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            task_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            template_id BIGINT UNSIGNED NOT NULL DEFAULT 0,

            sent_by BIGINT UNSIGNED NOT NULL DEFAULT 0,

            from_name VARCHAR(190) NOT NULL DEFAULT '',
            from_email VARCHAR(190) NOT NULL DEFAULT '',

            to_name VARCHAR(190) NOT NULL DEFAULT '',
            to_email VARCHAR(190) NOT NULL DEFAULT '',
            cc_email TEXT NULL,
            bcc_email TEXT NULL,

            subject VARCHAR(255) NOT NULL DEFAULT '',
            body LONGTEXT NULL,

            status VARCHAR(30) NOT NULL DEFAULT 'pending',
            error_message LONGTEXT NULL,

            sent_at DATETIME NULL,
            created_at DATETIME NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY email_uuid (email_uuid),

            KEY customer_id (customer_id),
            KEY contact_id (contact_id),
            KEY project_id (project_id),
            KEY task_id (task_id),
            KEY template_id (template_id),
            KEY sent_by (sent_by),
            KEY status (status),
            KEY sent_at (sent_at)

        ) {$charset_collate};";


    dbDelta(
        $templates_sql
    );

    dbDelta(
        $log_sql
    );
}


add_action(
    'admin_init',
    'rud_crm_ensure_email_tables'
);


add_action(
    'init',
    'rud_crm_ensure_email_tables',
    31
);


/*
 * =========================================================
 * EMAIL SETTINGS
 * =========================================================
 */

function rud_crm_email_settings_defaults() {

    return array(

        'from_name' =>
            get_bloginfo(
                'name'
            ),

        'from_email' =>
            get_option(
                'admin_email'
            ),

        'reply_to_email' =>
            get_option(
                'admin_email'
            ),

        'always_bcc_email' =>
            'olaf@rudolfsen.com',

        'send_html' =>
            1,
    );
}


function rud_crm_get_email_settings() {

    $saved =
        get_option(
            'rud_crm_email_settings',
            array()
        );

    if (
        ! is_array(
            $saved
        )
    ) {
        $saved =
            array();
    }

    return
        wp_parse_args(
            $saved,
            rud_crm_email_settings_defaults()
        );
}


function rud_crm_update_email_settings(
    $settings
) {

    $current =
        rud_crm_get_email_settings();

    $new =
        array(

            'from_name' =>
                sanitize_text_field(
                    $settings['from_name']
                    ?? $current['from_name']
                ),

            'from_email' =>
                sanitize_email(
                    $settings['from_email']
                    ?? $current['from_email']
                ),

            'reply_to_email' =>
                sanitize_email(
                    $settings['reply_to_email']
                    ?? $current['reply_to_email']
                ),

            'always_bcc_email' =>
                rud_crm_sanitize_email_address_list(
                    $settings['always_bcc_email']
                    ?? $current['always_bcc_email']
                ),

            'send_html' =>
                ! empty(
                    $settings['send_html']
                )
                ? 1
                : 0,
        );

    return
        update_option(
            'rud_crm_email_settings',
            $new
        );
}


/*
 * =========================================================
 * TEMPLATE VARIABLE DEFINITIONS
 * =========================================================
 */

function rud_crm_email_template_variables() {

    return array(

        '{company_name}' =>
            'Company Name',

        '{customer_name}' =>
            'Customer Name',

        '{customer_number}' =>
            'Customer Number',

        '{contact_first_name}' =>
            'Contact First Name',

        '{contact_last_name}' =>
            'Contact Last Name',

        '{contact_full_name}' =>
            'Contact Full Name',

        '{contact_job_title}' =>
            'Contact Job Title / Position',

        '{project_name}' =>
            'Project Name',

        '{project_number}' =>
            'Project Number',

        '{task_title}' =>
            'Task Title',

        '{due_date}' =>
            'Task Due Date',

        '{due_time}' =>
            'Task Due Time',

        '{site_name}' =>
            'Website / CRM Name',

        '{site_url}' =>
            'Website URL',
    );
}


/*
 * =========================================================
 * EMAIL ADDRESS LIST SANITIZER
 * =========================================================
 */

function rud_crm_sanitize_email_address_list(
    $value
) {

    $value =
        (string)
        $value;

    if (
        '' ===
        trim(
            $value
        )
    ) {
        return '';
    }

    $parts =
        preg_split(
            '/[\s,;]+/',
            $value
        );

    $emails =
        array();

    foreach (
        $parts
        as
        $part
    ) {

        $email =
            sanitize_email(
                trim(
                    $part
                )
            );

        if (
            $email
            &&
            is_email(
                $email
            )
        ) {

            $emails[
                strtolower(
                    $email
                )
            ] =
                $email;
        }
    }

    return
        implode(
            ', ',
            array_values(
                $emails
            )
        );
}


/*
 * =========================================================
 * TEMPLATE SANITIZER
 * =========================================================
 */

function rud_crm_sanitize_email_template_data(
    $data
) {

    $status =
        sanitize_key(
            $data['status']
            ?? 'active'
        );

    if (
        ! in_array(
            $status,
            array(
                'active',
                'inactive',
            ),
            true
        )
    ) {
        $status =
            'active';
    }

    return array(

        'template_name' =>
            sanitize_text_field(
                $data['template_name']
                ?? ''
            ),

        'subject' =>
            sanitize_text_field(
                $data['subject']
                ?? ''
            ),

        'cc_email' =>
            rud_crm_sanitize_email_address_list(
                $data['cc_email']
                ?? ''
            ),

        'bcc_email' =>
            rud_crm_sanitize_email_address_list(
                $data['bcc_email']
                ?? ''
            ),

        'body' =>
            wp_kses_post(
                $data['body']
                ?? ''
            ),

        'status' =>
            $status,
    );
}


/*
 * =========================================================
 * CREATE TEMPLATE
 * =========================================================
 */

function rud_crm_create_email_template(
    $data
) {

    global $wpdb;

    $data =
        rud_crm_sanitize_email_template_data(
            $data
        );

    if (
        '' ===
        trim(
            $data['template_name']
        )
    ) {

        return new WP_Error(
            'email_template_name_required',
            'Template Name is required.'
        );
    }

    if (
        '' ===
        trim(
            $data['subject']
        )
    ) {

        return new WP_Error(
            'email_template_subject_required',
            'Email Subject is required.'
        );
    }

    $now =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->insert(
            rud_crm_email_templates_table(),
            array(

                'template_uuid' =>
                    wp_generate_uuid4(),

                'template_name' =>
                    $data['template_name'],

                'subject' =>
                    $data['subject'],

                'cc_email' =>
                    $data['cc_email'],

                'bcc_email' =>
                    $data['bcc_email'],

                'body' =>
                    $data['body'],

                'status' =>
                    $data['status'],

                'created_by' =>
                    get_current_user_id(),

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now,
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'email_template_create_failed',
            'Email template could not be created.'
        );
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * GET TEMPLATE
 * =========================================================
 */

function rud_crm_get_email_template(
    $template_id
) {

    global $wpdb;

    $template_id =
        absint(
            $template_id
        );

    if (
        ! $template_id
    ) {
        return null;
    }

    return
        $wpdb->get_row(
            $wpdb->prepare(
                "SELECT *
                 FROM " .
                rud_crm_email_templates_table() .
                "
                 WHERE id = %d
                 LIMIT 1",
                $template_id
            )
        );
}


/*
 * =========================================================
 * GET TEMPLATES
 * =========================================================
 */

function rud_crm_get_email_templates(
    $status = ''
) {

    global $wpdb;

    if (
        $status
    ) {

        return
            $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT *
                     FROM " .
                    rud_crm_email_templates_table() .
                    "
                     WHERE status = %s
                     ORDER BY template_name ASC, id ASC",
                    sanitize_key(
                        $status
                    )
                )
            );
    }

    return
        $wpdb->get_results(
            "SELECT *
             FROM " .
            rud_crm_email_templates_table() .
            "
             ORDER BY template_name ASC, id ASC"
        );
}


/*
 * =========================================================
 * UPDATE TEMPLATE
 * =========================================================
 */

function rud_crm_update_email_template(
    $template_id,
    $data
) {

    global $wpdb;

    $template =
        rud_crm_get_email_template(
            $template_id
        );

    if (
        ! $template
    ) {

        return new WP_Error(
            'email_template_not_found',
            'Email template could not be found.'
        );
    }

    $data =
        rud_crm_sanitize_email_template_data(
            array_merge(
                (array)
                $template,
                $data
            )
        );

    if (
        '' ===
        trim(
            $data['template_name']
        )
        ||
        '' ===
        trim(
            $data['subject']
        )
    ) {

        return new WP_Error(
            'email_template_invalid',
            'Template Name and Email Subject are required.'
        );
    }

    $data['updated_at'] =
        current_time(
            'mysql'
        );

    $result =
        $wpdb->update(
            rud_crm_email_templates_table(),
            $data,
            array(
                'id' =>
                    absint(
                        $template_id
                    ),
            )
        );

    if (
        false ===
        $result
    ) {

        return new WP_Error(
            'email_template_update_failed',
            'Email template could not be updated.'
        );
    }

    return true;
}


/*
 * =========================================================
 * DELETE TEMPLATE
 * =========================================================
 */

function rud_crm_delete_email_template(
    $template_id
) {

    global $wpdb;

    return
        false !==
        $wpdb->delete(
            rud_crm_email_templates_table(),
            array(
                'id' =>
                    absint(
                        $template_id
                    ),
            ),
            array(
                '%d',
            )
        );
}


/*
 * =========================================================
 * EMAIL LOG
 * =========================================================
 */

function rud_crm_create_email_log(
    $data
) {

    global $wpdb;

    $defaults =
        array(

            'customer_id' =>
                0,

            'contact_id' =>
                0,

            'project_id' =>
                0,

            'task_id' =>
                0,

            'template_id' =>
                0,

            'sent_by' =>
                get_current_user_id(),

            'from_name' =>
                '',

            'from_email' =>
                '',

            'to_name' =>
                '',

            'to_email' =>
                '',

            'cc_email' =>
                '',

            'bcc_email' =>
                '',

            'subject' =>
                '',

            'body' =>
                '',

            'status' =>
                'pending',

            'error_message' =>
                '',

            'sent_at' =>
                null,
        );

    $data =
        wp_parse_args(
            $data,
            $defaults
        );

    $result =
        $wpdb->insert(
            rud_crm_email_log_table(),
            array(

                'email_uuid' =>
                    wp_generate_uuid4(),

                'customer_id' =>
                    absint(
                        $data['customer_id']
                    ),

                'contact_id' =>
                    absint(
                        $data['contact_id']
                    ),

                'project_id' =>
                    absint(
                        $data['project_id']
                    ),

                'task_id' =>
                    absint(
                        $data['task_id']
                    ),

                'template_id' =>
                    absint(
                        $data['template_id']
                    ),

                'sent_by' =>
                    absint(
                        $data['sent_by']
                    ),

                'from_name' =>
                    sanitize_text_field(
                        $data['from_name']
                    ),

                'from_email' =>
                    sanitize_email(
                        $data['from_email']
                    ),

                'to_name' =>
                    sanitize_text_field(
                        $data['to_name']
                    ),

                'to_email' =>
                    sanitize_email(
                        $data['to_email']
                    ),

                'cc_email' =>
                    rud_crm_sanitize_email_address_list(
                        $data['cc_email']
                    ),

                'bcc_email' =>
                    rud_crm_sanitize_email_address_list(
                        $data['bcc_email']
                    ),

                'subject' =>
                    sanitize_text_field(
                        $data['subject']
                    ),

                'body' =>
                    wp_kses_post(
                        $data['body']
                    ),

                'status' =>
                    sanitize_key(
                        $data['status']
                    ),

                'error_message' =>
                    sanitize_textarea_field(
                        $data['error_message']
                    ),

                'sent_at' =>
                    $data['sent_at'],

                'created_at' =>
                    current_time(
                        'mysql'
                    ),
            )
        );

    if (
        false ===
        $result
    ) {
        return false;
    }

    return
        absint(
            $wpdb->insert_id
        );
}


/*
 * =========================================================
 * GET EMAIL LOG
 * =========================================================
 */

function rud_crm_get_email_log(
    $args = array()
) {

    global $wpdb;

    $args =
        wp_parse_args(
            $args,
            array(

                'customer_id' =>
                    0,

                'contact_id' =>
                    0,

                'project_id' =>
                    0,

                'task_id' =>
                    0,

                'limit' =>
                    100,
            )
        );

    $where =
        array(
            '1=1'
        );

    $values =
        array();

    foreach (
        array(
            'customer_id',
            'contact_id',
            'project_id',
            'task_id',
        )
        as
        $field
    ) {

        if (
            ! empty(
                $args[
                    $field
                ]
            )
        ) {

            $where[] =
                "{$field} = %d";

            $values[] =
                absint(
                    $args[
                        $field
                    ]
                );
        }
    }

    $limit =
        max(
            1,
            min(
                500,
                absint(
                    $args['limit']
                )
            )
        );

    $sql =
        "SELECT *
         FROM " .
        rud_crm_email_log_table() .
        "
         WHERE " .
        implode(
            ' AND ',
            $where
        ) .
        "
         ORDER BY created_at DESC, id DESC
         LIMIT {$limit}";

    if (
        ! empty(
            $values
        )
    ) {

        $sql =
            $wpdb->prepare(
                $sql,
                $values
            );
    }

    return
        $wpdb->get_results(
            $sql
        );
}


/*
 * =========================================================
 * TEMPLATE VARIABLE VALUES
 * =========================================================
 */

function rud_crm_email_template_values(
    $context = array()
) {

    global $wpdb;

    $customer_id =
        absint(
            $context['customer_id']
            ?? 0
        );

    $contact_id =
        absint(
            $context['contact_id']
            ?? 0
        );

    $project_id =
        absint(
            $context['project_id']
            ?? 0
        );

    $task_id =
        absint(
            $context['task_id']
            ?? 0
        );

    $customer =
        null;

    if (
        $customer_id
    ) {

        $customer =
            $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT *
                     FROM {$wpdb->prefix}rudcrm_customers
                     WHERE id = %d
                     LIMIT 1",
                    $customer_id
                )
            );
    }

    $contact =
        (
            $contact_id
            &&
            function_exists(
                'rud_crm_get_company_contact'
            )
        )
        ? rud_crm_get_company_contact(
            $contact_id
        )
        : null;

    $project =
        (
            $project_id
            &&
            function_exists(
                'rud_crm_get_project'
            )
        )
        ? rud_crm_get_project(
            $project_id
        )
        : null;

    $task =
        (
            $task_id
            &&
            function_exists(
                'rud_crm_get_task'
            )
        )
        ? rud_crm_get_task(
            $task_id
        )
        : null;


    $company_name =
        $customer->company_name
        ?? '';

    $customer_name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $customer->first_name ?? '',
                        $customer->middle_name ?? '',
                        $customer->last_name ?? '',
                    )
                )
            )
        );

    if (
        '' ===
        $customer_name
    ) {

        $customer_name =
            $company_name;
    }

    $contact_first_name =
        $contact->first_name
        ?? '';

    $contact_last_name =
        $contact->last_name
        ?? '';

    $contact_full_name =
        trim(
            implode(
                ' ',
                array_filter(
                    array(
                        $contact->first_name ?? '',
                        $contact->middle_name ?? '',
                        $contact->last_name ?? '',
                    )
                )
            )
        );

    $contact_job_title =
        (
            $contact
            &&
            function_exists(
                'rud_crm_company_contact_job_title_label'
            )
        )
        ? rud_crm_company_contact_job_title_label(
            $contact
        )
        : '';

    $project_name =
        $project->project_title
        ??
        $project->title
        ??
        '';

    $project_number =
        $project->project_number
        ?? '';

    $due_date = '';

    $due_time = '';

    if (
        $task
        &&
        ! empty(
            $task->due_at
        )
    ) {

        $due_timestamp =
            strtotime(
                $task->due_at
            );

        if (
            $due_timestamp
        ) {

            $due_date =
                wp_date(
                    get_option(
                        'date_format'
                    ),
                    $due_timestamp
                );

            $due_time =
                wp_date(
                    get_option(
                        'time_format'
                    ),
                    $due_timestamp
                );
        }
    }

    return array(

        '{company_name}' =>
            $company_name,

        '{customer_name}' =>
            $customer_name,

        '{customer_number}' =>
            $customer->customer_number
            ?? '',

        '{contact_first_name}' =>
            $contact_first_name,

        '{contact_last_name}' =>
            $contact_last_name,

        '{contact_full_name}' =>
            $contact_full_name,

        '{contact_job_title}' =>
            $contact_job_title,

        '{project_name}' =>
            $project_name,

        '{project_number}' =>
            $project_number,

        '{task_title}' =>
            $task->title
            ?? '',

        '{due_date}' =>
            $due_date,

        '{due_time}' =>
            $due_time,

        '{site_name}' =>
            get_bloginfo(
                'name'
            ),

        '{site_url}' =>
            home_url(
                '/'
            ),
    );
}


/*
 * =========================================================
 * APPLY TEMPLATE VARIABLES
 * =========================================================
 */

function rud_crm_apply_email_template_variables(
    $text,
    $context = array()
) {

    return
        strtr(
            (string)
            $text,
            rud_crm_email_template_values(
                $context
            )
        );
}
