<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * FRONT-END SMS TEMPLATES
 * Version 1.1
 * =========================================================
 *
 * Shortcode:
 * [rud_crm_sms_templates]
 *
 * Separate SMS Template management page.
 *
 * =========================================================
 */


/*
 * =========================================================
 * ACCESS
 * =========================================================
 */

function rud_crm_sms_templates_can_manage() {

    if (
        ! is_user_logged_in()
    ) {
        return false;
    }

    if (
        current_user_can(
            'manage_options'
        )
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_frontend_is_crm_admin'
        )
        &&
        rud_crm_frontend_is_crm_admin()
    ) {
        return true;
    }

    if (
        function_exists(
            'rud_crm_get_admin_level'
        )
        &&
        rud_crm_get_admin_level(
            get_current_user_id()
        )
    ) {
        return true;
    }

    return false;
}


/*
 * =========================================================
 * PAGE URL
 * =========================================================
 */

function rud_crm_sms_templates_page_url(
    $args = array()
) {

    $url =
        home_url(
            '/sms-templates/'
        );

    if (
        ! empty(
            $args
        )
    ) {

        $url =
            add_query_arg(
                $args,
                $url
            );
    }

    return $url;
}


/*
 * =========================================================
 * FORM PROCESSOR
 * =========================================================
 */

function rud_crm_sms_templates_process_form() {

    if (
        empty(
            $_POST['rud_crm_sms_templates_action']
        )
    ) {
        return;
    }

    if (
        ! rud_crm_sms_templates_can_manage()
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_sms_templates_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_sms_templates_nonce']
                )
            ),
            'rud_crm_sms_templates'
        )
    ) {
        return;
    }

    $action =
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_sms_templates_action']
            )
        );


    if (
        'save_template' ===
        $action
    ) {

        $template_id =
            absint(
                $_POST['template_id']
                ?? 0
            );

        $data =
            array(

                'template_name' =>
                    sanitize_text_field(
                        wp_unslash(
                            $_POST['template_name']
                            ?? ''
                        )
                    ),

                'message' =>
                    sanitize_textarea_field(
                        wp_unslash(
                            $_POST['message']
                            ?? ''
                        )
                    ),

                'status' =>
                    sanitize_key(
                        wp_unslash(
                            $_POST['status']
                            ?? 'active'
                        )
                    ),
            );


        if (
            $template_id
        ) {

            $result =
                rud_crm_update_sms_template(
                    $template_id,
                    $data
                );

        } else {

            $result =
                rud_crm_create_sms_template(
                    $data
                );
        }


        if (
            is_wp_error(
                $result
            )
        ) {

            wp_safe_redirect(
                rud_crm_sms_templates_page_url(
                    array(
                        'rud_sms_template_error' =>
                            $result->get_error_code(),
                    )
                )
            );

            exit;
        }


        wp_safe_redirect(
            rud_crm_sms_templates_page_url(
                array(
                    'rud_sms_template_message' =>
                        'saved',
                )
            )
        );

        exit;
    }


    if (
        'delete_template' ===
        $action
    ) {

        $template_id =
            absint(
                $_POST['template_id']
                ?? 0
            );

        if (
            $template_id
        ) {

            rud_crm_delete_sms_template(
                $template_id
            );
        }


        wp_safe_redirect(
            rud_crm_sms_templates_page_url(
                array(
                    'rud_sms_template_message' =>
                        'deleted',
                )
            )
        );

        exit;
    }
}


add_action(
    'template_redirect',
    'rud_crm_sms_templates_process_form',
    81
);


/*
 * =========================================================
 * MESSAGES
 * =========================================================
 */

function rud_crm_sms_templates_message_html() {

    $message =
        sanitize_key(
            wp_unslash(
                $_GET['rud_sms_template_message']
                ?? ''
            )
        );

    $error =
        sanitize_key(
            wp_unslash(
                $_GET['rud_sms_template_error']
                ?? ''
            )
        );


    if (
        'saved' ===
        $message
    ) {

        return
            '<div class="rud-crm-sms-template-message rud-crm-sms-template-success">' .
            'SMS Template saved successfully.' .
            '</div>';
    }


    if (
        'deleted' ===
        $message
    ) {

        return
            '<div class="rud-crm-sms-template-message rud-crm-sms-template-success">' .
            'SMS Template deleted.' .
            '</div>';
    }


    if (
        $error
    ) {

        $text =
            'The SMS Template operation could not be completed.';

        if (
            'sms_template_name_required' ===
            $error
        ) {
            $text =
                'Template Name is required.';
        }

        if (
            'sms_template_message_required' ===
            $error
        ) {
            $text =
                'SMS Message is required.';
        }

        return
            '<div class="rud-crm-sms-template-message rud-crm-sms-template-error">' .
            esc_html(
                $text
            ) .
            '</div>';
    }


    return '';
}


/*
 * =========================================================
 * SHORTCODE
 * =========================================================
 */

function rud_crm_sms_templates_shortcode() {

    if (
        ! is_user_logged_in()
    ) {
        return
            '<p>You must be logged in to access SMS Templates.</p>';
    }

    if (
        ! rud_crm_sms_templates_can_manage()
    ) {
        return
            '<p>You do not have permission to manage SMS Templates.</p>';
    }

    if (
        ! function_exists(
            'rud_crm_get_sms_templates'
        )
    ) {
        return
            '<p>The SMS System module is not available.</p>';
    }


    $templates =
        rud_crm_get_sms_templates();


    $edit_template =
        null;

    $edit_template_id =
        absint(
            $_GET['edit_sms_template']
            ?? 0
        );

    if (
        $edit_template_id
    ) {

        $edit_template =
            rud_crm_get_sms_template(
                $edit_template_id
            );
    }


    ob_start();

    ?>

    <div class="rud-crm-sms-templates">

        <h1>
            SMS Templates
        </h1>

        <p class="rud-crm-sms-template-intro">
            Create and manage reusable SMS messages for manual sending and Task reminders.
            <strong>SMS Templates v1.1</strong>
        </p>

        <?php
        echo rud_crm_sms_templates_message_html();
        ?>


        <section class="rud-crm-sms-template-panel">

            <div class="rud-crm-sms-template-panel-header">

                <div>

                    <h2>
                        Template Library
                    </h2>

                    <p>
                        Active templates are available in Compose SMS and can later be connected to automatic SMS reminders.
                    </p>

                </div>

                <a
                    href="#rud-crm-create-sms-template"
                    class="rud-crm-sms-template-primary-button"
                >
                    + CREATE NEW SMS TEMPLATE
                </a>

            </div>


            <?php if ( ! empty( $templates ) ) : ?>

                <div class="rud-crm-sms-template-list">

                    <?php foreach ( $templates as $template ) : ?>

                        <div class="rud-crm-sms-template-row">

                            <div class="rud-crm-sms-template-info">

                                <div class="rud-crm-sms-template-title">

                                    <strong>
                                        <?php echo esc_html( $template->template_name ); ?>
                                    </strong>

                                    <span>
                                        <?php echo esc_html( ucfirst( $template->status ) ); ?>
                                    </span>

                                </div>

                                <div class="rud-crm-sms-template-preview">
                                    <?php echo nl2br( esc_html( $template->message ) ); ?>
                                </div>

                            </div>


                            <div class="rud-crm-sms-template-actions">

                                <a
                                    href="<?php
                                    echo esc_url(
                                        rud_crm_sms_templates_page_url(
                                            array(
                                                'edit_sms_template' =>
                                                    absint(
                                                        $template->id
                                                    ),
                                            )
                                        )
                                    );
                                    ?>"
                                    class="rud-crm-sms-template-secondary-button"
                                >
                                    EDIT
                                </a>


                                <form
                                    method="post"
                                    onsubmit="return confirm('Delete this SMS Template?');"
                                >

                                    <?php
                                    wp_nonce_field(
                                        'rud_crm_sms_templates',
                                        'rud_crm_sms_templates_nonce'
                                    );
                                    ?>

                                    <input
                                        type="hidden"
                                        name="rud_crm_sms_templates_action"
                                        value="delete_template"
                                    >

                                    <input
                                        type="hidden"
                                        name="template_id"
                                        value="<?php echo esc_attr( $template->id ); ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="rud-crm-sms-template-delete-button"
                                    >
                                        DELETE
                                    </button>

                                </form>

                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

            <?php else : ?>

                <p>
                    No SMS Templates have been created yet.
                </p>

            <?php endif; ?>

        </section>


        <section
            class="rud-crm-sms-template-panel"
            id="rud-crm-create-sms-template"
        >

            <h2>
                <?php
                echo $edit_template
                ? 'Edit SMS Template'
                : 'Create New SMS Template';
                ?>
            </h2>


            <form method="post">

                <?php
                wp_nonce_field(
                    'rud_crm_sms_templates',
                    'rud_crm_sms_templates_nonce'
                );
                ?>

                <input
                    type="hidden"
                    name="rud_crm_sms_templates_action"
                    value="save_template"
                >

                <input
                    type="hidden"
                    name="template_id"
                    value="<?php
                    echo esc_attr(
                        $edit_template->id
                        ?? 0
                    );
                    ?>"
                >


                <div class="rud-crm-sms-template-grid">

                    <div>

                        <label>
                            Template Name
                        </label>

                        <input
                            type="text"
                            name="template_name"
                            value="<?php
                            echo esc_attr(
                                $edit_template->template_name
                                ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <div>

                        <label>
                            Status
                        </label>

                        <select name="status">

                            <option
                                value="active"
                                <?php selected(
                                    $edit_template->status
                                    ?? 'active',
                                    'active'
                                ); ?>
                            >
                                Active
                            </option>

                            <option
                                value="inactive"
                                <?php selected(
                                    $edit_template->status
                                    ?? 'active',
                                    'inactive'
                                ); ?>
                            >
                                Inactive
                            </option>

                        </select>

                    </div>


                    <div class="rud-crm-sms-template-wide">

                        <label>
                            SMS Message
                        </label>

                        <textarea
                            name="message"
                            rows="7"
                            maxlength="1600"
                            required
                        ><?php
                        echo esc_textarea(
                            $edit_template->message
                            ?? ''
                        );
                        ?></textarea>

                        <small>
                            Template variables are replaced automatically when the SMS is sent.
                        </small>

                    </div>

                </div>


                <button
                    type="submit"
                    class="rud-crm-sms-template-primary-button"
                >
                    <?php
                    echo $edit_template
                    ? 'UPDATE SMS TEMPLATE'
                    : 'CREATE SMS TEMPLATE';
                    ?>
                </button>


                <?php if ( $edit_template ) : ?>

                    <a
                        href="<?php echo esc_url( rud_crm_sms_templates_page_url() ); ?>"
                        class="rud-crm-sms-template-secondary-button"
                    >
                        CANCEL EDIT
                    </a>

                <?php endif; ?>

            </form>

        </section>


        <section class="rud-crm-sms-template-panel">

            <h2>
                Template Variables
            </h2>

            <div class="rud-crm-sms-template-variable-list">

                <?php
                foreach (
                    rud_crm_sms_template_variables()
                    as
                    $variable =>
                    $label
                ) :
                ?>

                    <div>

                        <code>
                            <?php echo esc_html( $variable ); ?>
                        </code>

                        <span>
                            <?php echo esc_html( $label ); ?>
                        </span>

                    </div>

                <?php endforeach; ?>

            </div>

        </section>

    </div>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_sms_templates',
    'rud_crm_sms_templates_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_sms_templates_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    ?>

    <style id="rud-crm-sms-templates-styles">

        .rud-crm-sms-templates {
            width:100%;
            max-width:1100px;
            margin:0 auto;
        }

        .rud-crm-sms-template-intro {
            margin-bottom:24px;
            color:#667085;
        }

        .rud-crm-sms-template-panel {
            margin-bottom:24px;
            padding:24px;
            border:1px solid #e4e7ec;
            border-radius:12px;
            background:#fff;
        }

        .rud-crm-sms-template-panel * {
            box-sizing:border-box;
        }

        .rud-crm-sms-template-panel h2 {
            margin-top:0 !important;
        }

        .rud-crm-sms-template-panel-header {
            display:flex;
            justify-content:space-between;
            align-items:flex-start;
            gap:20px;
        }

        .rud-crm-sms-template-panel-header p {
            margin-bottom:0;
            color:#667085;
        }

        .rud-crm-sms-template-list {
            margin-top:20px;
        }

        .rud-crm-sms-template-row {
            display:flex;
            justify-content:space-between;
            gap:18px;
            padding:16px 0;
            border-bottom:1px solid #eaecf0;
        }

        .rud-crm-sms-template-info {
            min-width:0;
            flex:1 1 auto;
        }

        .rud-crm-sms-template-title span {
            margin-left:8px;
            color:#667085;
            font-size:12px;
        }

        .rud-crm-sms-template-preview {
            margin-top:7px;
            color:#475467;
            font-size:13px;
            line-height:1.5;
        }

        .rud-crm-sms-template-actions {
            display:flex;
            gap:8px;
            align-items:flex-start;
        }

        .rud-crm-sms-template-actions form {
            margin:0;
        }

        .rud-crm-sms-template-grid {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:14px;
        }

        .rud-crm-sms-template-wide {
            grid-column:1 / -1;
        }

        .rud-crm-sms-template-grid label {
            display:block;
            margin-bottom:6px;
            font-weight:600;
        }

        .rud-crm-sms-template-grid input,
        .rud-crm-sms-template-grid select,
        .rud-crm-sms-template-grid textarea {
            width:100%;
            padding:10px 12px;
            border:1px solid #d0d5dd;
            border-radius:7px;
            background:#fff;
            font:inherit;
        }

        .rud-crm-sms-template-grid small {
            display:block;
            margin-top:5px;
            color:#667085;
            font-size:11px;
        }

        .rud-crm-sms-template-primary-button,
        .rud-crm-sms-template-secondary-button,
        .rud-crm-sms-template-delete-button {
            display:inline-block;
            min-height:38px;
            padding:8px 13px;
            border-radius:7px;
            cursor:pointer;
            font-size:11px;
            font-weight:700;
            text-decoration:none;
        }

        .rud-crm-sms-template-primary-button {
            border:1px solid #1d2939;
            background:#1d2939;
            color:#fff;
        }

        .rud-crm-sms-template-secondary-button {
            border:1px solid #98a2b3;
            background:#fff;
            color:#1d2939;
        }

        .rud-crm-sms-template-delete-button {
            border:1px solid #b42318;
            background:#fff;
            color:#b42318;
        }

        .rud-crm-sms-template-variable-list {
            display:grid;
            grid-template-columns:repeat(2,minmax(0,1fr));
            gap:8px 16px;
        }

        .rud-crm-sms-template-variable-list > div {
            padding:9px 10px;
            border:1px solid #eaecf0;
            border-radius:7px;
        }

        .rud-crm-sms-template-variable-list code {
            margin-right:8px;
        }

        .rud-crm-sms-template-message {
            margin-bottom:18px;
            padding:11px 13px;
            border-radius:7px;
        }

        .rud-crm-sms-template-success {
            border-left:4px solid #00a32a;
            background:#f3fff5;
        }

        .rud-crm-sms-template-error {
            border-left:4px solid #b32d2e;
            background:#fff5f5;
        }

        @media (max-width:700px) {

            .rud-crm-sms-template-panel-header,
            .rud-crm-sms-template-row {
                display:block;
            }

            .rud-crm-sms-template-panel-header .rud-crm-sms-template-primary-button {
                margin-top:14px;
            }

            .rud-crm-sms-template-grid,
            .rud-crm-sms-template-variable-list {
                grid-template-columns:1fr;
            }

            .rud-crm-sms-template-wide {
                grid-column:auto;
            }

            .rud-crm-sms-template-actions {
                margin-top:12px;
            }
        }

    </style>

    <?php
}


add_action(
    'wp_head',
    'rud_crm_sms_templates_styles',
    91
);
