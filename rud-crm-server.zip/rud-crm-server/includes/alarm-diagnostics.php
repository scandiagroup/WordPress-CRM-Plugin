<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * ALARM DIAGNOSTICS
 * Version 1.0
 * =========================================================
 *
 * Temporary diagnostic tool for testing reminder processing.
 *
 * Shortcode:
 * [rud_crm_alarm_diagnostics]
 *
 * =========================================================
 */


/*
 * =========================================================
 * MANUAL PROCESS
 * =========================================================
 */

function rud_crm_alarm_diagnostics_process_now() {

    if (
        ! is_user_logged_in()
        ||
        empty(
            $_POST['rud_crm_alarm_diag_action']
        )
        ||
        'process_now' !==
        sanitize_key(
            wp_unslash(
                $_POST['rud_crm_alarm_diag_action']
            )
        )
    ) {
        return;
    }

    if (
        empty(
            $_POST['rud_crm_alarm_diag_nonce']
        )
        ||
        ! wp_verify_nonce(
            sanitize_text_field(
                wp_unslash(
                    $_POST['rud_crm_alarm_diag_nonce']
                )
            ),
            'rud_crm_alarm_diag_process_now'
        )
    ) {
        return;
    }

    $processed = 0;

    if (
        function_exists(
            'rud_crm_process_due_reminders_now'
        )
    ) {

        $processed =
            absint(
                rud_crm_process_due_reminders_now()
            );
    }

    $redirect =
        add_query_arg(
            array(
                'rud_alarm_processed' =>
                    $processed,
            ),
            wp_get_referer()
            ? wp_get_referer()
            : home_url(
                '/crm-notifications/'
            )
        );

    wp_safe_redirect(
        $redirect
    );

    exit;
}


add_action(
    'template_redirect',
    'rud_crm_alarm_diagnostics_process_now',
    3
);


/*
 * =========================================================
 * DIAGNOSTIC SHORTCODE
 * =========================================================
 */

function rud_crm_alarm_diagnostics_shortcode() {

    if (
        ! is_user_logged_in()
    ) {

        return
            '<p>You must be logged in to view alarm diagnostics.</p>';
    }

    global $wpdb;

    $timezone =
        wp_timezone_string();

    $wp_now =
        current_time(
            'mysql'
        );

    $server_now =
        gmdate(
            'Y-m-d H:i:s'
        );

    $tasks =
        array();

    if (
        function_exists(
            'rud_crm_tasks_table'
        )
    ) {

        $table =
            rud_crm_tasks_table();

        $tasks =
            $wpdb->get_results(
                "SELECT
                    id,
                    title,
                    status,
                    due_at,
                    reminder_at,
                    reminder_processed_at,
                    crm_notification_sent_at,
                    notify_crm,
                    assigned_user_id,
                    created_by
                 FROM {$table}
                 ORDER BY id DESC
                 LIMIT 20"
            );
    }

    $processed =
        isset(
            $_GET['rud_alarm_processed']
        )
        ? absint(
            $_GET['rud_alarm_processed']
        )
        : null;

    ob_start();

    ?>

    <section class="rud-crm-alarm-diagnostics">

        <h2>
            ALARM DIAGNOSTICS
        </h2>

        <p>
            Temporary diagnostic page for checking task reminder times and processing.
        </p>

        <?php if ( null !== $processed ) : ?>

            <div class="rud-crm-alarm-diag-message">
                Manual processing completed.
                Tasks processed:
                <strong><?php echo esc_html( $processed ); ?></strong>
            </div>

        <?php endif; ?>

        <div class="rud-crm-alarm-diag-info">

            <div>
                <strong>WordPress Timezone</strong>
                <span><?php echo esc_html( $timezone ); ?></span>
            </div>

            <div>
                <strong>WordPress Current Time</strong>
                <span><?php echo esc_html( $wp_now ); ?></span>
            </div>

            <div>
                <strong>Server UTC Time</strong>
                <span><?php echo esc_html( $server_now ); ?></span>
            </div>

        </div>

        <form method="post" class="rud-crm-alarm-diag-process">

            <?php
            wp_nonce_field(
                'rud_crm_alarm_diag_process_now',
                'rud_crm_alarm_diag_nonce'
            );
            ?>

            <input
                type="hidden"
                name="rud_crm_alarm_diag_action"
                value="process_now"
            >

            <button type="submit">
                PROCESS DUE REMINDERS NOW
            </button>

        </form>

        <h3>
            Latest Tasks
        </h3>

        <?php if ( ! empty( $tasks ) ) : ?>

            <div class="rud-crm-alarm-diag-table-wrap">

                <table class="rud-crm-alarm-diag-table">

                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Task</th>
                            <th>Status</th>
                            <th>Due At</th>
                            <th>Reminder At</th>
                            <th>CRM</th>
                            <th>Processed</th>
                            <th>CRM Sent</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ( $tasks as $task ) : ?>

                            <?php

                            $is_due =
                                ! empty(
                                    $task->reminder_at
                                )
                                &&
                                $task->reminder_at <= $wp_now
                                &&
                                empty(
                                    $task->reminder_processed_at
                                )
                                &&
                                ! in_array(
                                    $task->status,
                                    array(
                                        'completed',
                                        'cancelled',
                                    ),
                                    true
                                );

                            ?>

                            <tr<?php echo $is_due ? ' class="is-due"' : ''; ?>>

                                <td>
                                    <?php echo esc_html( $task->id ); ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->title ); ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->status ); ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->due_at ?: '—' ); ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->reminder_at ?: '—' ); ?>
                                </td>

                                <td>
                                    <?php echo ! empty( $task->notify_crm ) ? 'YES' : 'NO'; ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->reminder_processed_at ?: '—' ); ?>
                                </td>

                                <td>
                                    <?php echo esc_html( $task->crm_notification_sent_at ?: '—' ); ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php else : ?>

            <p>
                No tasks found.
            </p>

        <?php endif; ?>

    </section>

    <?php

    return ob_get_clean();
}


add_shortcode(
    'rud_crm_alarm_diagnostics',
    'rud_crm_alarm_diagnostics_shortcode'
);


/*
 * =========================================================
 * STYLES
 * =========================================================
 */

function rud_crm_alarm_diagnostics_styles() {

    if (
        is_admin()
    ) {
        return;
    }

    $css = '

    .rud-crm-alarm-diagnostics {
        width:100%;
        padding:24px;
        border:1px solid #e4e7ec;
        border-radius:12px;
        background:#fff;
        box-sizing:border-box;
    }

    .rud-crm-alarm-diagnostics * {
        box-sizing:border-box;
    }

    .rud-crm-alarm-diagnostics h2 {
        margin-top:0 !important;
    }

    .rud-crm-alarm-diag-info {
        display:grid;
        grid-template-columns:repeat(3,minmax(0,1fr));
        gap:12px;
        margin:20px 0;
    }

    .rud-crm-alarm-diag-info > div {
        padding:12px;
        border:1px solid #eaecf0;
        border-radius:8px;
    }

    .rud-crm-alarm-diag-info strong,
    .rud-crm-alarm-diag-info span {
        display:block;
    }

    .rud-crm-alarm-diag-info span {
        margin-top:4px;
        color:#667085;
    }

    .rud-crm-alarm-diag-process {
        margin:0 0 22px;
    }

    .rud-crm-alarm-diag-process button {
        min-height:40px;
        padding:8px 14px;
        border:1px solid #1d2939;
        border-radius:7px;
        background:#1d2939;
        color:#fff;
        cursor:pointer;
        font-weight:700;
    }

    .rud-crm-alarm-diag-message {
        margin:14px 0;
        padding:12px 14px;
        border-left:4px solid #00a32a;
        background:#f3fff5;
    }

    .rud-crm-alarm-diag-table-wrap {
        overflow:auto;
    }

    .rud-crm-alarm-diag-table {
        width:100%;
        border-collapse:collapse;
        font-size:12px;
    }

    .rud-crm-alarm-diag-table th,
    .rud-crm-alarm-diag-table td {
        padding:9px 10px;
        border:1px solid #eaecf0;
        text-align:left;
        white-space:nowrap;
    }

    .rud-crm-alarm-diag-table th {
        background:#f9fafb;
    }

    .rud-crm-alarm-diag-table tr.is-due {
        background:#fff6ed;
    }

    @media (max-width:700px) {

        .rud-crm-alarm-diag-info {
            grid-template-columns:1fr;
        }
    }

    ';

    wp_register_style(
        'rud-crm-alarm-diagnostics',
        false,
        array(),
        defined(
            'RUD_CRM_VERSION'
        )
        ? RUD_CRM_VERSION
        : '1.0'
    );

    wp_enqueue_style(
        'rud-crm-alarm-diagnostics'
    );

    wp_add_inline_style(
        'rud-crm-alarm-diagnostics',
        $css
    );
}


add_action(
    'wp_enqueue_scripts',
    'rud_crm_alarm_diagnostics_styles',
    70
);
