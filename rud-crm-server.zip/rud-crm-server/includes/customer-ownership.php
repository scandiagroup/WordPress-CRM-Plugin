<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


/*
 * =========================================================
 * RUD CRM SERVER
 * CUSTOMER OWNERSHIP / TRIAL LIMIT SYSTEM
 * =========================================================
 *
 * Trial model:
 *
 * - 35 shared DEMO- customers
 * - Each CRM Demo User may create up to 10
 *   real customers of their own
 * - Trial users cannot access another user's
 *   private trial customers
 *
 * =========================================================
 */


/*
 * ---------------------------------------------------------
 * DATABASE VERSION
 * ---------------------------------------------------------
 */

define(
    'RUD_CRM_OWNERSHIP_DB_VERSION',
    '1.0.0'
);


/*
 * ---------------------------------------------------------
 * TRIAL CUSTOMER LIMIT
 * ---------------------------------------------------------
 */

function rud_crm_trial_customer_limit() {

    return 10;
}


/*
 * ---------------------------------------------------------
 * OWNERSHIP TABLE
 * ---------------------------------------------------------
 */

function rud_crm_customer_ownership_table() {

    global $wpdb;

    return
        $wpdb->prefix .
        'rudcrm_customer_ownership';
}


/*
 * =========================================================
 * INSTALL TABLE
 * =========================================================
 */

function rud_crm_customer_ownership_install() {

    global $wpdb;


    require_once
        ABSPATH .
        'wp-admin/includes/upgrade.php';


    $table =
        rud_crm_customer_ownership_table();


    $charset_collate =
        $wpdb->get_charset_collate();


    $sql =
        "CREATE TABLE {$table} (

            id BIGINT UNSIGNED
                NOT NULL
                AUTO_INCREMENT,

            customer_id BIGINT UNSIGNED
                NOT NULL,

            user_id BIGINT UNSIGNED
                NOT NULL,

            ownership_type VARCHAR(30)
                NOT NULL
                DEFAULT 'trial',

            created_at DATETIME
                NOT NULL,

            updated_at DATETIME
                NOT NULL,

            PRIMARY KEY  (id),

            UNIQUE KEY customer_id
                (customer_id),

            KEY user_id
                (user_id),

            KEY ownership_type
                (ownership_type),

            KEY user_type
                (user_id, ownership_type)

        ) {$charset_collate};";


    dbDelta(
        $sql
    );


    $exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        );


    if (
        $exists ===
        $table
    ) {

        update_option(
            'rud_crm_customer_ownership_db_version',
            RUD_CRM_OWNERSHIP_DB_VERSION
        );

        return true;
    }


    return false;
}


/*
 * =========================================================
 * ENSURE TABLE EXISTS
 * =========================================================
 */

function rud_crm_customer_ownership_ensure_table() {

    global $wpdb;


    $table =
        rud_crm_customer_ownership_table();


    $exists =
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        );


    if (
        $exists ===
        $table
    ) {

        return true;
    }


    return
        rud_crm_customer_ownership_install();
}


add_action(
    'admin_init',
    'rud_crm_customer_ownership_ensure_table',
    10
);


/*
 * =========================================================
 * GET CUSTOMER OWNER
 * =========================================================
 */

function rud_crm_get_customer_owner(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return 0;
    }


    return
        (int)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT user_id
                 FROM " .
                 rud_crm_customer_ownership_table() .
                 "
                 WHERE customer_id = %d
                 LIMIT 1",
                $customer_id
            )
        );
}


/*
 * =========================================================
 * CUSTOMER HAS OWNER?
 * =========================================================
 */

function rud_crm_customer_has_owner(
    $customer_id
) {

    return
        rud_crm_get_customer_owner(
            $customer_id
        ) > 0;
}


/*
 * =========================================================
 * USER OWNS CUSTOMER?
 * =========================================================
 */

function rud_crm_user_owns_customer(
    $customer_id,
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    return
        rud_crm_get_customer_owner(
            $customer_id
        )
        ===
        $user_id;
}


/*
 * =========================================================
 * ASSIGN CUSTOMER OWNER
 * =========================================================
 */

function rud_crm_assign_customer_owner(
    $customer_id,
    $user_id,
    $ownership_type = 'trial'
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $customer_id
        ||
        ! $user_id
    ) {

        return false;
    }


    $ownership_type =
        sanitize_key(
            $ownership_type
        );


    if (
        '' ===
        $ownership_type
    ) {

        $ownership_type =
            'trial';
    }


    $now =
        current_time(
            'mysql'
        );


    $table =
        rud_crm_customer_ownership_table();


    $existing =
        (int)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id
                 FROM {$table}
                 WHERE customer_id = %d
                 LIMIT 1",
                $customer_id
            )
        );


    /*
     * Existing ownership record.
     */

    if (
        $existing
    ) {

        $result =
            $wpdb->update(

                $table,

                array(

                    'user_id' =>
                        $user_id,

                    'ownership_type' =>
                        $ownership_type,

                    'updated_at' =>
                        $now
                ),

                array(
                    'id' =>
                        $existing
                ),

                array(
                    '%d',
                    '%s',
                    '%s'
                ),

                array(
                    '%d'
                )
            );


        return
            false !==
            $result;
    }


    /*
     * New ownership record.
     */

    $result =
        $wpdb->insert(

            $table,

            array(

                'customer_id' =>
                    $customer_id,

                'user_id' =>
                    $user_id,

                'ownership_type' =>
                    $ownership_type,

                'created_at' =>
                    $now,

                'updated_at' =>
                    $now
            ),

            array(
                '%d',
                '%d',
                '%s',
                '%s',
                '%s'
            )
        );


    return
        false !==
        $result;
}


/*
 * =========================================================
 * REMOVE CUSTOMER OWNER
 * =========================================================
 */

function rud_crm_remove_customer_owner(
    $customer_id
) {

    global $wpdb;


    $customer_id =
        absint(
            $customer_id
        );


    if (
        ! $customer_id
    ) {

        return false;
    }


    $result =
        $wpdb->delete(

            rud_crm_customer_ownership_table(),

            array(
                'customer_id' =>
                    $customer_id
            ),

            array(
                '%d'
            )
        );


    return
        false !==
        $result;
}


/*
 * =========================================================
 * COUNT USER'S OWN CUSTOMERS
 * =========================================================
 */

function rud_crm_count_user_owned_customers(
    $user_id = 0,
    $ownership_type = 'trial'
) {

    global $wpdb;


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return 0;
    }


    $ownership_type =
        sanitize_key(
            $ownership_type
        );


    return
        (int)
        $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*)
                 FROM " .
                 rud_crm_customer_ownership_table() .
                 "
                 WHERE user_id = %d
                 AND ownership_type = %s",
                $user_id,
                $ownership_type
            )
        );
}


/*
 * =========================================================
 * TRIAL CUSTOMER SLOTS REMAINING
 * =========================================================
 */

function rud_crm_trial_customer_slots_remaining(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $limit =
        rud_crm_trial_customer_limit();


    $used =
        rud_crm_count_user_owned_customers(
            $user_id,
            'trial'
        );


    return
        max(
            0,
            $limit - $used
        );
}


/*
 * =========================================================
 * MAY CREATE ANOTHER TRIAL CUSTOMER?
 * =========================================================
 */

function rud_crm_can_create_trial_customer(
    $user_id = 0
) {

    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return false;
    }


    /*
     * Only CRM Demo Users use this 10-customer limit.
     */

    if (
        function_exists(
            'rud_crm_is_demo_user'
        )
        &&
        ! rud_crm_is_demo_user(
            $user_id
        )
    ) {

        return true;
    }


    /*
     * Trial must still be active.
     */

    if (
        function_exists(
            'rud_crm_user_access_is_active'
        )
        &&
        ! rud_crm_user_access_is_active(
            $user_id
        )
    ) {

        return false;
    }


    return
        rud_crm_count_user_owned_customers(
            $user_id,
            'trial'
        )
        <
        rud_crm_trial_customer_limit();
}


/*
 * =========================================================
 * GET USER'S CUSTOMER IDS
 * =========================================================
 */

function rud_crm_get_user_owned_customer_ids(
    $user_id = 0
) {

    global $wpdb;


    if (
        ! $user_id
    ) {

        $user_id =
            get_current_user_id();
    }


    $user_id =
        absint(
            $user_id
        );


    if (
        ! $user_id
    ) {

        return array();
    }


    $ids =
        $wpdb->get_col(
            $wpdb->prepare(
                "SELECT customer_id
                 FROM " .
                 rud_crm_customer_ownership_table() .
                 "
                 WHERE user_id = %d
                 ORDER BY customer_id ASC",
                $user_id
            )
        );


    return
        array_map(
            'absint',
            $ids
        );
}


/*
 * =========================================================
 * OWNERSHIP TABLE STATUS
 * =========================================================
 */

function rud_crm_customer_ownership_table_exists() {

    global $wpdb;


    $table =
        rud_crm_customer_ownership_table();


    return
        $wpdb->get_var(
            $wpdb->prepare(
                'SHOW TABLES LIKE %s',
                $table
            )
        )
        ===
        $table;
}